eval("use Tools; use RolandHp302; use Metronome; use playsmf;");

use constant { u=>undef, p=>0x01 }; my ($m, $t, $B) = (\%main::out, 0/1, 1/1);

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>u, 4=>u}); %main::trks = (); #$B = $m->{-1}{5}/$m->{-1}{6}; $t = 0*$B;

my $PhrDir = $main::WrkDir0; if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }

my $smf = "$PhrDir/style.mid"; $smf = "$PhrDir/DANCE.MID";

$t += playsmf::main($m, $t, undef, undef, $smf); $B = $m->{-1}{5}/$m->{-1}{6}; (undef, undef, $t, undef, undef, undef) = Edit::Quantize($t, $B); $t += 1*$B;

delete($m->{-1}{4}); delete($m->{-1}{5}); delete($m->{-1}{6});

my $mt = (sort {$b <=> $a} keys(%{$m}))[0]+1;

Edit::Seq($m, 0, 0*$B, 0, 0, " 1*$B:% MJumpx17 ");

$t += Edit::Seq($m, 0, $t, 0, 0, " MLabelx17 $B:% MJump-4 ") + 1*$B;

MIDI::InsertText($m, 0, 18/1, 1, "Label0x300", 0x6, '->'); MIDI::InsertText($m, 0, 20/1, 1, "Jump-4", 0x6, '->');
#MIDI::InsertText($m, 0, 24/1, 1, "Label0x20a", 0x6, '->'); MIDI::InsertText($m, 0, 26/1, 1, "Jump-4", 0x6, '->');

$t += Tools::CopyRegion($m, $t, 18/1, 2/1, undef, u, u, u, u, u, 0x100) + 1*$B; #0x400

for (my $i=0; $i<=11; $i++) { my $o = $i-12*($i>6); $t += Tools::CopyRegion($m, $t, 18/1, 2/1, [$o,$o,$o,$o+1,$o,$o,$o,$o,$o+1,$o,$o+1,$o], u, u, u, u, u, -0x100+$i) + 1*$B; } #0x200
for (my $i=1; $i<=11; $i++) { my $o = $i-12*($i>6); $t += Tools::CopyRegion($m, $t, 18/1, 2/1,  $o                                                                  ) + 1*$B; } #0x300

Metronome::Generic($m, $mt, 0*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33, 9); #

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, " $B:% MLabelx18 "); #duplicate since Cubase drops last event

#===============================================================================

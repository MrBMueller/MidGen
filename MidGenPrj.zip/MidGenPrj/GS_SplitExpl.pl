eval("use Misc; use RolandHp302; use KX; use Metronome; use StyleTrax; use Chord; use Guitar;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my ($m, $s) = (\%main::out, 0/1); #general output setup

GS::Reset(\%main::out, 0x00, $s+0/4, 1, 0x00); #

#GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x70, 0x70); #

$MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames("$main::SrcDir0/DeviceMaps/Hp503Tones0.txt")};

$MidiDebug::Prgs{0x01} = {-1 => 'SF201'};
$MidiDebug::Prgs{0x01}{0xc}{-1}{-1}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2"; # 7.586.050   Sun Mar 18 12:17:00 2001

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $s+1/4); use constant { u => undef };

my $spt = '5d';

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, $GM::RPN_0, $GS::BPx02, $GS::BPx1d, $GS::BPx1e, $GS::cBPx16, $GS::cBPx17],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl', 0x00                                                                              ],  # 00
[1, '0x00', 0x00, 0x0,    0, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  41), 1.0, 1.0,   .8, 0.5, 0.0, u, 0, k($spt), k('10g'  ), s7( 0),  .0],  # 01 live
[1, '0x01', 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  38), 1.0, 1.0,  -.8, 0.5, 0.0, u, 0, k('0c'), k($spt,-1), s7(-0), -.0],  # 02 harmonics/pad
[1, '0x02', 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0,      0,   38, 1.0, 1.0,  0.0, 0.2, 0.0],  # 03 bass
[1, '0x03', 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   2),  .7, 1.0,  0.0, 0.0, 0.0],  # 04
[1, '0x04', 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   1), 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05', 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,  120, 1.0, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06', 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07', 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   2), 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08', 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   1),  .5, 1.0,  0.0, 0.0, 0.0, u, 0, k('0c'), k($spt,-1), s7(-0), -.0],  # 09
[1, '0x09', 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  44), 1.0, 1.0,  0.0, 0.0, 0.0],  # 0a percussion
[1, '0x0a', 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b', 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c', 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d', 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e', 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f', 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.3, 0.0]); # 10

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #metronome
  34 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome bell
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD2 \ right
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1 / side within kit
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD1
  39 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #HC
  40 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD2
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH - pedal pressed    + stick \
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH - closure noise  w/o stick  > left site witin kit
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .7], #OHH - regular position + stick /
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => '*1.0+0.0', $GM::CCx07 => '*.5+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

Edit::Seq($m, 1, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Metronome::Generic(\%main::out, 0x0a, $s,   1*$m->{-1}{5}/$m->{-1}{6}, .4); #pre counter
      Metronome::Generic(\%main::out, 0x0a, $s, 128*$m->{-1}{5}/$m->{-1}{6}, .2); #main counter

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }
if ($#ARGV >= 1) { $Phr = 'rec'; } #goto MyLabelEnd;

#$s += StyleTrax::LiveStyle($m, $s, "$PhrDir/*$Phr*", -1, 2, 1); goto MyLabelEnd;

#$s += StyleTrax::LiveStyle($m, $s, "$PhrDir/*$Phr*", (Tools::GetChord($spt))[0], 1, 1, \&main::Var0, -1^0b10000001011, 0, 0, 0); goto MyLabelEnd;

#$s += StyleTrax::ChordStyle($m, $s, " 4( | 1/1:e a1 D G1 | ) ", \&main::Var0, -1^0b10000000111, 1.0, .5, 0); #

#for (my $t=11; $t<=15; $t++) { Edit::Copy($m, $t, $m, 16, 0xb);
# for (my $p=4; $p<=16; $p++) { $main::trks[$t+1][$p+1] = $main::trks[16+1][$p+1]; }
# }

#for (my $t=11; $t<=16; $t++) { $main::trks[$t+1][17+1] = Edit::Portamento(\%main::out, $t, 0/16, 0, Edit::GetInt(8, 16-$t)+40+3); }

#===============================================================================
sub u7 { return($_[0]/0x7f); }
sub s7 { if ($_[0] >= 0) { return($_[0]/0x3f); } else { return($_[0]/0x40); }}
sub k { my $o = 0; if ($#_ > 0) { $o = $_[1]; } return(u7($o+(Tools::GetChord($_[0]))[0])); }
#===============================================================================
sub Var0 { my ($m, $s, $l, $msk, $key, $chord, $inv, $vel, $vof, $ci, $so, $p0) = Tools::GetVarPars(@_); my $ScS = 0;

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

if ($msk>> 2&1) { MIDI::InsertText($m, 2, $s, 1, sprintf("%s", Tools::GetNoteName($key, $scale, $inv)), 5, " -> ", 1); }

#($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

my $cs0 = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs0) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($scale != 2) && ($scale != 3)) { $msk &= 0b00000010000000101; $scale = 3; } #unsupported scales -> mask melodic tracks

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

$Guitar::Tabs{3}{11} = [-1,  2,  4,  4,  3,  2]; my $gdly = '1/128';
my $gcd = Guitar::Chord($scale, $key, 0, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff down (notes up)
my $gcu = Guitar::Chord($scale, $key, 1, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff up (notes down)
my $gcM = Guitar::Chord($scale, $key, 1, ['  ', '  ', '  ', '  ', '  ', '  ']); #simultaneous
my $gcm = Guitar::Chord($scale, $key, 1, ['.5', '.5', '.5', '.5', '.5', '.5']); #simultaneous

my $BD = 36; my ($V, $v, $PanBD, $center, $left, $right) = ("1.0", ".75", $GS::NRPNx1c00+$BD, .5, 0, 1);

my %SymbolTable0 = ('B'=>"$BD\_$V", 'S'=>"38_$V", 'b'=>"$BD\_$v", 's'=>"38_$v", 'T'=>"% (<-1/128:36)",
	                'C'=>"$BD\_$V\_C$PanBD\_$center", 'c'=>"$BD\_$v\_C$PanBD\_$center",
	                'L'=>"$BD\_$V\_C$PanBD\_$left",   'l'=>"$BD\_$v\_C$PanBD\_$left",
	                'R'=>"$BD\_$V\_C$PanBD\_$right",  'r'=>"$BD\_$v\_C$PanBD\_$right");

my %SymbolTable1 = ('C'=>"42_$V", 'P'=>"44_$V", 'O'=>"46_$V", 'c'=>"42_$v", 'p'=>"44_$v", 'o'=>"46_$v", '9'=>"42_.9", '8'=>"42_.8", '7'=>"42_.7",
	                'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50',
	                '<'=>"% (<+1/128:44_$v)", '>'=>"% (<-1/128:44_$v)");

my %SymbolTable2 = ('.'=>'>', '%'=>'%', '0'=>'0', '1'=>'-1b', '2'=>'-2', '3'=>'-3', '4'=>'4', '6'=>'6', '7'=>'7', 'v'=>'-1', '^'=>'2');

my %SymbolTable3 = ('m'=>"$pu b:$gcm <:$pd", 'M'=>"$pu b:$gcM <:$pd", 'd'=>$gcd, 'u'=>$gcu, 'p'=>$pd, 'P'=>$pu, 'n'=>"$ano b:$pu", 's'=>"$aso b:$pu", 'D'=>"$pd b:$gcd", 'U'=>"$pd b:$gcu");

my ($ps0, $ps1, $bs0, $gs0) = ('', '', '', '');

#ps0 taken from PRAKT3_2.WRK
$ps0 = "|B...|s...|s...|s...|"; #if (int($so)%4==2) { $ps0 = "|B...|S...|B...|SS.S||B...|S...|B...|S.S.|"; }
$ps1 = "|p.p.|<p.p|>.p.|c.p.|";
$bs0 = "|0.0.|00.0|0.0.|0.0.|";
$gs0 = "|d...|d..u|d...|d...|"; if ($ci%4==3) { $gs0 = "|d...|d..u|d...|dudu|"; }

#MidiDebug::WrStr("$gs0\n");

my $bo = 2; if ($key%12 <= 2) { $bo++; }

if ($msk>> 2&1) { Edit::Seq($m,  2, $s, ($ScS<<16)|($key   +  0*12)&0xffff, $scale, "<$l/1:% $cs0", 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 3&1) { Edit::Seq($m,  3, $s, ($ScS<<16)|($key%12+$bo*12)&0xffff, $scale, "<1/16:%".Edit::PreProc0($bs0, \%SymbolTable2), 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 4&1) { Edit::Seq($m,  6, $s, ($ScS<<16)|(($key%12)+60-1*12)&0xffff, $scale, " <1/16:0 ", .7); }

if ($msk>> 4&1) { Edit::Seq($m, 16, $s, 40, 8, "$pd <1/16:%".Edit::PreProc0($gs0, \%SymbolTable3), 1.0*$vel, $vof, 0,0,1, 1,1, 1,-4/($m->{-1}{3}*4), $l, 3, {1=>15, 2=>14, 3=>13, 4=>12, 5=>11}); }

if ($msk>>10&1) { Edit::Seq($m, 10, $s, 0, 0, "<1/16:%".Edit::PreProc0($ps0, \%SymbolTable0), 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l, 0x03, {}, {38=>-0/128});
                  Edit::Seq($m, 10, $s, 0, 0, "<1/16:%".Edit::PreProc0($ps1, \%SymbolTable1), 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l, 0x03, {}, {});
				  }

return($l); }
#===============================================================================

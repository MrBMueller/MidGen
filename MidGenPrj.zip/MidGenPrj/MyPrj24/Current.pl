eval("use Misc; use RolandHp302; use KX; use Percussion; use StyleTrax; use Chord;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my $s = 0/1; my $m = \%main::out; #general output setup

GS::Reset(\%main::out, 0x00, $s+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x70, 0x70); #

$MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames("$main::SrcDir0/DeviceMaps/Hp503Tones0.txt")};

$MidiDebug::Prgs{0x01} = {-1 => 'SF201'};
$MidiDebug::Prgs{0x01}{0xc}{-1}{-1}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2"; # 7.586.050   Sun Mar 18 12:17:00 2001

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $s+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, $GM::RPN_0],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl', 0x00                                                                              ],  # 00
[1, '0x00', 0x00, 0x0,    0, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   1),  .8, 1.0,  0.0, 0.9, 0.0],  # 01 live
[1, '0x01', 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,   4),  .7, 1.0,  0.0, 0.5, 0.0],  # 02 harmonics/pad
[1, '0x02', 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0,      0,   38, 1.0, 1.0,  0.0, 0.5, 0.0],  # 03 bass
[1, '0x03', 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5, 200),  .6, 1.0,  0.0, 0.9, 0.0],  # 04
[1, '0x04', 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   1), 1.0, 1.0,  0.0, 0.9, 0.0],  # 05
[1, '0x05', 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  41), 1.0, 1.0,  0.0, 0.9, 0.0],  # 06
[1, '0x06', 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07', 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08', 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09', 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  47), 1.0, 1.0,  0.0, 0.5, 0.0],  # 0a percussion
[1, '0x0a', 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b', 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c', 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d', 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e', 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f', 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0]); # 10

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => '*1.0+0.0', $GM::CCx07 => '*.5+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

#$main::trks[0+15][1+12] = 1.0;

Edit::Seq($m, 1, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }
if ($#ARGV >= 1) { $Phr = 'rec'; } #goto MyLabelEnd;

      StyleTrax::LiveStyle($m, $s, "$PhrDir/*20160109234025*", -1, undef, 1); #Intro

$s += StyleTrax::ChordStyle($m, $s, " 1( 1/1:c . f1 . | 4A# . g2 csus2   ) ", \&main::Var0, -1^0b00000000100, 1.0, .5, 0); #Intro
$s += StyleTrax::ChordStyle($m, $s, " 1( 1/1:c . f1 . | 4A# . g2 csus2_5 ) ", \&main::Var0, -1^0b00000001100, 1.0, .5, 0); #Intro

foreach  (0..1) {
      StyleTrax::LiveStyle($m, $s, "$PhrDir/*20160109234025*", -1, undef, 1); #Intro

$s += StyleTrax::ChordStyle($m, $s, " 1( 1/1:c . f1 . | 4A# . g2 csus2 ) ", \&main::Var0, -1^0b10000001100, 1.0, .5, 0); #Intro


      StyleTrax::LiveStyle($m, $s, "$PhrDir/*20160109235848*", -1, undef, 4); #Verse
      StyleTrax::LiveStyle($m, $s, "$PhrDir/*20160110000726*", -1, undef, 5); #Verse-Echos

$s += StyleTrax::ChordStyle($m, $s, " 2( 1/1:c . . . | G#2 4A# c csus2 ) ", \&main::Var0, -1^0b10000001100, 1.0, .5, 0); #Verse


      StyleTrax::LiveStyle($m, $s, "$PhrDir/*20160110002925*", -1, undef, 5); #Bridge

$s += StyleTrax::ChordStyle($m, $s, " 1( 1/1:f1 G#2 f1 G#2 | c 4A# c_2 c_3 ) ", \&main::Var0, -1^0b10000001100, 1.0, .5, 1); #Bridge


$s += StyleTrax::ChordStyle($m, $s, " 2( 2/1:c G#2 | 4A# 1/1:c 4A# ) ", \&main::Var0, -1^0b10000001100, 1.0, .5, 4); #Chorus
}

foreach (sort {$a <=> $b} keys(%{$m})) { if ($_ != -1) { Edit::Seq($m, $_, 1/1, 0, 0, " 4/1:%_Cx101_1_0_0_1 "); }} #NoteOn  fade in
#foreach (sort {$a <=> $b} keys(%{$m})) { if ($_ != -1) { Edit::Seq($m, $_, 1/1, 0, 0, " 4/1:%_Cx102_1_0_0_1 "); }} #NoteOff fade in

foreach (sort {$a <=> $b} keys(%{$m})) { if ($_ != -1) { Edit::Seq($m, $_, $s, 0, 0, " <4/1:%_Cx101_1_0_1_0 "); }} #NoteOn  fade out
#foreach (sort {$a <=> $b} keys(%{$m})) { if ($_ != -1) { Edit::Seq($m, $_, $s, 0, 0, " <4/1:%_Cx102_1_0_1_0 "); }} #NoteOff fade out

#Edit::Seq($m, 0, $s, 0, 0, " <4/1:%_C$GS::MasterVolume\_1_0_1_0 "); #GS::MasterVolume fade out

#===============================================================================
sub Var0 { my ($m, $s, $l, $msk, $key, $chord, $inv, $vel, $vof, undef, undef, $p0) = Tools::GetVarPars(@_); my $ScS = 0;

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

#($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $chord);

my $cs = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($scale != 2) && ($scale != 3)) { $msk &= 0b00000010000000101; $scale = 3; } #unsupported scales -> mask melodic tracks

if ($msk>> 2&1) { MIDI::InsertText($m, 2, $s, 1, sprintf("%s_$ScS", Tools::GetNoteName($key, $scale, $inv)), 5, " -> ", 1); }

my $BD = 35; my ($V, $v, $PanBD, $center, $left, $right) = ("1.0", ".75", $GS::NRPNx1c00+$BD, .5, 0, 1);

my %SymbolTable0 = ('B'=>"$BD\_$V", 'S'=>"38_$V", 'b'=>"$BD\_$v", 's'=>"38_$v",
	                'C'=>"$BD\_$V\_C$PanBD\_$center", 'c'=>"$BD\_$v\_C$PanBD\_$center",
	                'L'=>"$BD\_$V\_C$PanBD\_$left",   'l'=>"$BD\_$v\_C$PanBD\_$left",
	                'R'=>"$BD\_$V\_C$PanBD\_$right",  'r'=>"$BD\_$v\_C$PanBD\_$right"
                    );

my %SymbolTable1 = ('C'=>"42_$V", 'P'=>"44_$V", 'O'=>"46_$V", 'c'=>"42_$v", 'p'=>"44_$v", 'o'=>"46_$v", '9'=>"42_.9", '8'=>"42_.8", '7'=>"42_.7",
	                'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50');

my %SymbolTable2 = ('0'=>'0', '2'=>'2', '4'=>'4', '6'=>'6', '7'=>'7', 'v'=>'-1', '^'=>'2');

my $ps0 = " |B...|B...|B...|B...| ";
my $ps1 = " |C.p.|p.p.|pp.p|p.p.| ";
my $bs0 = " |0.0.|7.77|0.0.|7.7.| ";

if ($p0==1) { $bs0 = " |0.7.|77.7|0.7.|7.0.| "; } #Bridge
if ($p0==2) { $bs0 = " |0.0.|0.0.|0.0.|0.0.| "; $ps1 = ""; } #Bridge
if ($p0==3) { $bs0 = " |0.0.|0.0.|0000|0000| "; $ps1 = " |HH.H|H.h.|M.m.|L.ll| "; } #Bridge Fill2
if ($p0==5) { $msk |= 0b10000000000; $ps0 = ""; $ps1 = " |..HH|.Hh.|M.m.|L.l.| "; } #Intro Percussion

if ($p0==4) { $bs0 = " |0.0.|0.v0|..0.|0000||v.0.|0.v0|..0.|v.0.| "; } #Chorus

$bs0 =~ s/\./>/g;

$ps0 = Edit::PreProc0($ps0, \%SymbolTable0); #base/snare
$ps1 = Edit::PreProc0($ps1, \%SymbolTable1); #hihat
$bs0 = Edit::PreProc0($bs0, \%SymbolTable2);

my $bo = 3; if ($key%12 > 0) { $bo--; }

if ($msk>> 2&1) { Edit::Seq($m,  2, $s, ($ScS<<16)|($key   +  0*12)&0xffff, $scale, " $l/1:$cs ", 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 3&1) { Edit::Seq($m,  3, $s, ($ScS<<16)|($key%12+$bo*12)&0xffff, $scale, " <1/16:% $bs0 ", .7*$vel, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>10&1) { Edit::Seq($m, 10, $s, 0, 0, " 1/16<:0_% $ps0 ", 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l);
                  Edit::Seq($m, 10, $s, 0, 0, " 1/16<:0_% $ps1 ", 1.0*$vel, $vof, 0,0,1, 1,1, 1,1, $l);
				  }

return($l); }
#===============================================================================

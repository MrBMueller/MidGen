eval("use Tools; use RolandHp302; use Metronome; use playsmf;");

use constant { u=>undef, p=>0x01 }; my ($m, $t, $B) = (\%main::out, 0/1, 1/1);

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>u, 4=>u}); %main::trks = (); #$B = $m->{-1}{5}/$m->{-1}{6}; $t = 0*$B;

my $PhrDir = $main::WrkDir0; if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }

#$t += playsmf::main($m, $t, -1, undef, "D:/TMP/MyTest0.mid", 0x7fefa189); $B = $m->{-1}{5}/$m->{-1}{6};
#$t += playsmf::main($m, $t, undef, -1);

#$t += playsmf::main($m, $t, 2/1, 0x300);
#$t += playsmf::main($m, $t, 2/1, 0x305);
#$t += playsmf::main($m, $t, 2/1, 0x20a);
#$t += playsmf::main($m, $t, 2/1, 0x300);
#$t += playsmf::main($m, $t, 2/1,  0x19);
#$t += playsmf::main($m, $t, 2/1,  0x19);

#goto MyLabelEnd;

$t += playsmf::main($m, $t, undef, undef, "$PhrDir/polka.mid", 0x7fefa489); $B = $m->{-1}{5}/$m->{-1}{6}; (undef, undef, $t, undef, undef, undef) = Edit::Quantize($t, $B); $t += 1*$B;
#$t += playsmf::main($m, $t, undef, undef, "$PhrDir/honkytnk.mid", 0x7fefa489); $B = $m->{-1}{5}/$m->{-1}{6}; $t += 1*$B;
#$t += playsmf::main($m, $t, undef, undef, "$PhrDir/modcntry.mid", 0x7fefa489); $B = $m->{-1}{5}/$m->{-1}{6}; $t += 1*$B;

#$t += playsmf::main($m, $t, -1, undef, "$PhrDir/modcntry.mid", 0x7fefa489); $B = $m->{-1}{5}/$m->{-1}{6};
#$t += playsmf::main($m, $t, 2/1, 0x200);
#$t += playsmf::main($m, $t, 1/1, 0x201);
#$t += playsmf::main($m, $t, 2/1, 0x300);

#goto MyLabelEnd;

foreach my $k0 (sort {$a <=> $b} keys(%{$m})) { if ($k0 == -1) { next(); }
 MIDI::InsertGeneric($m, $k0, 0*$B, 0, 0xff, 0x21, p);
 }

my $lt = (sort {$b <=> $a} keys(%{$m}))[0]+1; my $rt = $lt+1;

MIDI::InsertPrgChg($m, $lt, 0*$B, 0, 0xa, u,  48);
MIDI::InsertPrgChg($m, $rt, 0*$B, 0, 0xb, u,  11);

#MIDI::InsertGeneric($m, $lt, 0*$B, 0, 0xff, 0x21, 2);
#MIDI::InsertGeneric($m, $rt, 0*$B, 0, 0xff, 0x21, 3);

my ($L, $R) = (8.5*$B, $t-(1/2)*$B); for (my $i=1; $i<=11; $i++) { $t += Tools::CopyRegion($m, $t-(1/2)*$B, $L, $R-$L, $i-12*($i>6)) + (0/1)*$B; }

Metronome::GenericWoMain($m, 2, 0*$B, 1*$B, .4, u, u, 0, 1, 33, 9); #pre counter (cwpa9 doesnt like 1st beat when saving smf!?)
Metronome::Generic(      $m, 2, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33, 9); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" 2{ $B:%% MLabelx%x <:%%_c0_C$GM::CCx7a\_$GM::CCon } ", 0x18)); #duplicate since Cubase drops last event

playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 0,  9, 0x7fefa189,  0x15, 0x16,  36, 59, 1, 0, +12, 64, 0,  60, 127, 2, 0, -12, 127, 0,  60, 127, -2, -10, +12, 127, 0,  60, 127, -2, -20, -12, 127, 0);

#===============================================================================

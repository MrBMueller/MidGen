eval("use Misc; use RolandHp302; use Metronome; use Tools; use Chord; use Guitar; use playsmf; use HostSystem;");

#printf("%d\n", HostSystem::GetMidiOutPortID('loopMIDI Port 1'));

use constant { u=>undef, p=>undef }; my $m = \%main::out;

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my $B = $m->{-1}{5}/$m->{-1}{6}; my $t = 0*$B; $MIDI::ContCtlRes = 1/32; #general output setup

playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  9, 0x7fefa189,  0x15, 0x16,  36, 59, 1, 0, +12, 64, 0,  60, 127, 2, 0, -12, 127, 0,  0, 129, 3, -0, 0, 127, 0);

#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  8, 0x0ff); #rec

GS::Reset(\%main::out, 0x00, $t+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $t+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

#   Efx       c1     c2    Type    1    2    3    4    5    6    7    8    9   10
#my @Efx = (undef, undef, 0x0175);
my @Efx = (undef, undef, 0x0121); #Auto Wah
#my @Efx = (undef, undef, 0x0122); #Rotary
#my @Efx = (undef, undef, 0x012d); #Rotary2
#my @Efx = (undef, undef, 0x0300); #Rotary Multi

#RolandHp302::AssignEfx(\%main::out, 0x00, $t+2/4, 1, -0b0000000000000011, 0x7f, 0x7f, undef, 0x7f, 0, @RolandHp302::Phone);
#RolandHp302::AssignEfx(\%main::out, 0x00, $t+2/4, 1, -0b0000000000000011, 0x7f, 0x7f, undef, 0x7f, 0, @RolandHp302::Rotary);
RolandHp302::AssignEfx(\%main::out, 0x00, $t+2/4, 1, -0b0000000000000010, 0x7f, 0x7f, undef, 0x7f, 0, @Efx);

#GS::AssignBlock(\%main::out, 0x00, $t+3/4, 1, 0/4, undef, 0x40100f, 0, 0, 0, 0);

RolandHp302::ImportPatchNames(\%MidiDebug::Prgs, main::p, "$main::SrcDir0/DeviceMaps/Hp503Tones0.txt");

*prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $t+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a, $GM::RPN_0],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl',    p                                                                              ],  # 00
[1, '0x00',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,    prg(4, 1), 1.0, 1.0,  0.0, 0.7, 0.0],  # 01 left  - harmonics/pad
[1, '0x01',    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   prg(5, 41), 1.0, 1.0,  0.0, 0.7, 0.0],  # 02 right - melody
[1, '0x02',    3, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0, 1.0,  0.0, 0.5, 0.0],  # 03 bass
[1, '0x03',    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5, 109), 1.0, 1.0,  0.0, 0.4, 0.0],  # 04 rythm/chords/guitar
[1, '0x04',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05',    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,  120,  .8, 1.0,  0.0, 0.5, 0.0],  # 06
[1, '0x06',    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07',    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08',    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   prg(5, 47), 1.0, 1.0,  0.0, 0.5, 0.0],  # 0a percussion
[1, '0x0a',    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b',    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c',    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d',    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e',    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f',    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5, 109), 1.0, 1.0,  0.0, 0.5, 0.0],  # 10
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-9 => '*.75+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef; #$main::trks[$#main::trks][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

#MIDI::InsertText($m, 0x2, 0/1, 0, "loopMIDI Port 2", 0x9);

Edit::Seq($m,  1, $t+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control
Edit::Seq($m, 10, $t+3/4, 0, 0, " 1/4:36 "); #ready signal

$t += Metronome::GenericWoMain($m, 10, $t,   1*$B, .4, u, u, 0, 1, 33); #pre counter (cwpa9 doesnt like 1st beat when saving smf!?)
#      Metronome::Generic($m, 10, $t, 512*$B, .2, u, u, 0, 1, 33); #main counter

if ($B < 1/1) { $t += 1*$B; }

#MIDI::InsertGeneric($m, 0, $t, 0, 0xf7, 0xfc);

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | MLabelx%x MLabelx400 $B:%% MJump-4 | ", 0x17)) + 1*$B;

my $L = $t-(1/2)*$B;

for (my $i=0; $i<=11; $i++) {
 $t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0, -120) + 1*$B;
 $t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0, -120) + 1*$B;
 $t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 5, 0, 1.0, .5, 0, 0/1, 0, -120) + 1*$B;
 $t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 6, 0, 1.0, .5, 0, 0/1, 0, -120) + 1*$B;
 }

my $R = $t-(1/2)*$B;

#Edit::Sustain2NoteOff($m, 4, 1);

my $NextTrk = $#main::trks;
for (my $t=0; $t<=5; $t++) { Edit::Copy($m, 11+$t, $m, 16, 0xb);
 Edit::Sustain2NoteOff($m, 11+$t, 1);
 #$main::trks[11+$t+1][19+1] = Edit::Portamento($m, 11+$t, 0/16, 0, Edit::GetInt(8, 5-$t)+40+0, undef, 0x104, 4, undef, undef, undef, $NextTrk+$t);
 for (my $p=0; $p<=16+1; $p++) { if (($p != 2) && ($p != 4)) { $main::trks[11+$t+1][$p] = $main::trks[16+1][$p]; }}
 #for (my $p=0; $p<=3+1; $p++) { $main::trks[$NextTrk+$t+1][$p] = $main::trks[11+$t+1][$p]; } #$main::trks[$NextTrk+$t+1][1+1] = 'Mute';
 }

Metronome::Generic($m, 10, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" 2{ $B:%% MLabelx%x <:%%_C$GM::CCx7a\_$GM::CCon } ", 0x18)); #duplicate since Cubase drops last event

playsmf::PreProc($m);

#===============================================================================
sub Var0 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = (@_);

#MIDI::InsertGeneric($m, 0, $t, 0, 0xf7, 0xfa);

my $B = $m->{-1}{5}/$m->{-1}{6};

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

$Guitar::Tabs{3}{11} = [-1,  2,  4,  4,  3,  2]; my $gdly = '1/256'; my $gdly1 = '1/128';
my $gcd = Guitar::Chord($chord, $key, 0, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff down (notes up)
my $gcu = Guitar::Chord($chord, $key, 1, ['  ', '.9', '.8', '.7', '.6', '.5'], $gdly); #riff up (notes down)
my $gcM = Guitar::Chord($chord, $key, 1, ['  ', '  ', '  ', '  ', '  ', '  ']); #simultaneous
my $gcm = Guitar::Chord($chord, $key, 1, ['.5', '.5', '.5', '.5', '.5', '.5']); #simultaneous

my $gcd1 = Guitar::Chord($chord, $key, 0, ['.4', '.5', '.6', '.7', '.8', '.9'], $gdly); #riff down (notes up)
my $gcd2 = Guitar::Chord($chord, $key, 0, ['.3', '.4', '.5', '.6', '.7', '.8'], $gdly); #riff down (notes up)
my $gcu1 = Guitar::Chord($chord, $key, 1, ['.9', '.8', '.7', '.6', '.5', '.4'], $gdly1); #riff up (notes down)

my %Guitar = ('m'=>"$pu b:$gcm", 'M'=>"$pu b:$gcM <:$pd", 'd'=>"$pu b:$gcd", 'u'=>"$pu b:$gcu", 'p'=>$pd, 'P'=>$pu, 'n'=>"$ano b:$pu", 's'=>"$aso b:$pu",
              'D'=>"$pd b:$gcd", 'U'=>"$pd b:$gcu", 'V'=>"$pd b:$gcd1", 'v'=>"$pd b:$gcd2", '^'=>"$pd b:$gcu1");

my ($gs0) = ('');

#          00000000 01111111 11122222 22222333
#         |12345678|90123456|78901234|56789012|
#$gs0 .= " |D.......|d.....U.|D.u.D...|D.......| " x 2;
$gs0 .= " |D.......|D.....U.|D.U.D...|D.....U.| " x 2;
$gs0 .= " |D.....U.|d...D...|....D...|U.d.D...| " x 2;
#$gs0 .= " |D.......|D.....D.|U.......|D.......| " x 2;
#$gs0 .= " |D.....U.|m...D...|....D...|U.d.D...| " x 2;

#$gs0 = $gs0 x 4; #MidiDebug::WrStr($gcd); printf("\n");

Edit::Seq($m,  6, $t+0*$B, [$key%12+60-1*12, 0], 2, "1/4:0", 1.0);
Edit::Seq($m,  6, $t+2*$B, [$key%12+60-1*12, 0], 2, "1/4:0", 1.0);

$l = Edit::Seq($m, 16, $t, 40, 8, "<1/32:%".Edit::PreProc0($gs0, \%Guitar)."0:$pu", 1.0*$von, $vof, 0,0,1, 1,1, 1,-1/($m->{-1}{3}*4), undef, 3, {1=>15, 2=>14, 3=>13, 4=>12, 5=>11});

Edit::Seq($m, 0, $t, 0, 0, sprintf(" MLabelx%x $B:%% MLabel-1 $B:%% MLabelx%x MJump-5>> $B:%% MLabel-1 $B:%% MJump-4>> MJumpx%x ", (0<<12)|($chord<<8)|($inv<<4)|($key%12), (1<<12)|($chord<<8)|($inv<<4)|($key%12), (0<<12)|($chord<<8)|($inv<<4)|($key%12)));

return($l); }
#===============================================================================

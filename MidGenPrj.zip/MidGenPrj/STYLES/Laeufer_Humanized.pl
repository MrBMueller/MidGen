eval("use Misc; use RolandHp302; use KX; use Metronome; use StyleTrax; use Chord; use Guitar; use playsmf;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my ($m, $s) = (\%main::out, 0/1); $MIDI::ContCtlRes = 1/32; #general output setup

playsmf::OverrideCmdLineArgs($m, 0, $s, 0,  9, 0x7fefa189, 21, 22,  36, 59, 2, 0, 12, 0, 0,  60, 127, 1, 0, 0, 0, 0,  60, 127, -1, -10, 12, 0x7f, 0);
#playsmf::OverrideCmdLineArgs($m, 0, $s, 1, -1, 0x10000);

GS::Reset(\%main::out, 0x00, $s+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

use constant { u=>undef, p=>0x01, dv=>100/127, dr=>40/127, sp=>'5c' };

$MidiDebug::Prgs{main::p} = {RolandHp302::ImportPatchNames("$main::SrcDir0/DeviceMaps/Hp503Tones0.txt")};

$MidiDebug::Prgs{0x02} = {-1 => 'SF201'};
$MidiDebug::Prgs{0x02}{0xc}{-1}{-1}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2"; # 7.586.050   Sun Mar 18 12:17:00 2001

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $s+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a],
#s   name         port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl'      ,    p                                                                              ],  # 00
[1, '0x00'      ,    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5, 200), 1.0, 1.0,  0.0, 0.9, 0.0],  # 01 right - melody
[1, '0x01'      ,    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   1), 1.0, 1.0,  0.0, 0.7, 0.0],  # 02 left  - harmonics/pad
[1, '0x02 Mute2',    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 33-1, 1.0, 1.0,  0.0, 0.9, 0.0, .5, .5],  # 03 bass
[1, '0x03'      ,    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   1),  .5, 1.0,  0.0, 0.9, 0.0],  # 04
[1, '0x04 Mute4',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05'      ,    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06'      ,    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07'      ,    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08'      ,    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09 Mute2',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.9, 0.0],  # 0a percussion
[1, '0x0a'      ,    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b'      ,    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c'      ,    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d'      ,    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00,  .9, 1.0,  0.0, 0.9, 0.0],  # 0e
[1, '0x0e'      ,    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5, 129), 1.0, 1.0,  0.0, 0.9, 0.0],  # 0f
[1, '0x0f'      ,    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   32,  .6, 1.0,  0.0, 0.9, 0.0],  # 10
[1, '0x10'      ,    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,                                       ],  # 11
[1, '0x11'      ,    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0                                        ],  # 12
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#for (10..11) { $main::trks[2+1][$_] = $main::trks[1+1][$_]; } #left follows right patch

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => '*1.0+0.0', $GM::CCx07 => '*.5+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

#Edit::Seq($m,  0, $s+0/1, 0, 0, " | MLabel0 | "); #very 1st label

Edit::Seq($m, 16, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control
Edit::Seq($m, 10, $s+3/4, 0, 0, " 1/4:34 "); #ready signal

$s += Metronome::Generic($m, 10, $s,   1*$m->{-1}{5}/$m->{-1}{6}, .4); #pre counter
      Metronome::Generic($m, 10, $s, 512*$m->{-1}{5}/$m->{-1}{6}, .0); #main counter

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; } #goto MyLabelEnd;

#playsmf::OverrideCmdLineArgs($m, 0, 0/1, 1, 5, 0x7ff08fb0); #rec
#$s += StyleTrax::LiveStyle($m, $s, "$PhrDir/*rec*", 60, [2, 0, 1, 0, 0], [1, 0, 1, 0, 0], \&main::Var0, -1^0b10000011111, 0, 0, 0x0); #goto MyLabelEnd;
$s += StyleTrax::LiveStyle($m, $s, "$PhrDir/*$Phr*", 60, [2, 0, 1, 0, 0], [1, 0, 1, 0, 0], \&main::Var0, -1^0b10000011111, 0, 0, 0x0); #goto MyLabelEnd;

#$s += StyleTrax::ChordStyle($m, $s, " 4( 2( 1/1:4c ) 2( 1/1:4g2 ) 1/1:3G# 3A# (4c) > ) ", \&main::Var0, -1^0b10000001111, 1.0, .5, 0x0); #goto MyLabelEnd;

#MIDI::InsertSysEx($m, 0, $s+0/1, 0, @GM2::IdentityRequest);
#MIDI::InsertSysEx($m, 0, $s+1/4, 0, @GM2::IdentityRequest);
#MIDI::InsertSysEx($m, 0, $s+2/4, 0, @RolandHp302::IdentityRequest);

my $Labels = ''; #for (my $i=2; $i<=4; $i++) { for (my $j=0; $j<=11; $j++) { $Labels .= sprintf("Labelx%x", ($i<<8)+0x80+$j); }}

$s +=  1/1; $s += Edit::Seq($m, 0, $s, 0, 0, " | MLabelx17$Labels 1/1:% MJumpx17 | ");

$s +=  1/1; $s += main::Var1($m, $s, undef, -1^0b10000000001, 0, 0, 0, 1.0, .5, 0, 0/1, 0x19);
$s +=  1/1; $s += main::Var2($m, $s, undef, -1^0b10000000001, 0, 0, 0, 1.0, .5, 0, 0/1, 0x1a);

for (my $i=0; $i<=11; $i++) {
 $s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000111011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x0000, -120);
 $s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000111011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x0000, -100);
 $s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000000001, 60+$i, 4, 0, 1.0, .5, 0, 0/1, 0x0000, -140);
 }

for (my $i=0; $i<=11; $i++) {
 #$s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000011011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x1000);
 #$s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000011011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x1000);
 #$s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000000011, 60+$i, 4, 0, 1.0, .5, 0, 0/1, 0x1000);
 }

#MIDI::InsertTempo($m, 0, $s, 0, 120);

for (my $i=0; $i<=11; $i++) {
 #$s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000011011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x0080);
 #$s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000011011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x0080);
 #$s +=  1/1; $s += main::Var0($m, $s, 4/1, -1^0b10000000011, 60+$i, 4, 0, 1.0, .5, 0, 0/1, 0x0080);
 }

Edit::Randomize($m, 4, 0.05, 0.2, 0.4, 0, 1);

Edit::Seq($m, 16, MIDI::RoundInt(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4))+1/1, 0, 0, " 1/1:% MLabelx18 <:%_C$GM::CCx7a\_$GM::CCon ");

#===============================================================================
sub Var0 { my ($m, $s, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0, $p1) = Tools::GetVarPars(@_); if ((caller(1))[3] =~ /Live/) { ($von, $vof) = (1, .5); }

if ((defined($p1)) && ($p1 > 0)) { MIDI::InsertTempo( $m, 0, $s, 0, $p1); }

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

if ($msk>> 2&1) { MIDI::InsertText($m, 2, $s, 1, sprintf("%s", Tools::GetNoteName($key, $scale, $inv)), 5, " -> ", 1); }

my $ScS = 0; #($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

my $cs0 = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs0) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($scale != 2) && ($scale != 3)) { $msk &= 0b00000010000000101; $scale = 3; } #unsupported scales -> mask melodic tracks

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

my $BD = 36; my ($V, $v, $PanBD, $center, $left, $right) = ('1.0', '.75', $GS::NRPNx1c00+$BD, .5, 0, 1);

my %SymbolTable0 = ('A'=>"27_$V", 'B'=>"$BD\_$V", 'S'=>"38_$V", 'b'=>"$BD\_$v", 's'=>"38_$v", 'Q'=>"$BD\_$V (<-3/128:27)", 'T'=>"% (<-1/128:36)",
	                'C'=>"$BD\_$V\_C$PanBD\_$center", 'c'=>"$BD\_$v\_C$PanBD\_$center",
	                'L'=>"$BD\_$V\_C$PanBD\_$left",   'l'=>"$BD\_$v\_C$PanBD\_$left",
	                'R'=>"$BD\_$V\_C$PanBD\_$right",  'r'=>"$BD\_$v\_C$PanBD\_$right");

my %SymbolTable1 = ('C'=>"42_$V", 'P'=>"44_$V", 'O'=>"46_$V", 'c'=>"42_$v", 'p'=>"44_$v", 'o'=>"46_$v", '9'=>"42_.9", '8'=>"42_.8", '7'=>"42_.7",
	                'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50',
	                '<'=>"% (<+1/128:44_$v)", '>'=>"% (<-1/128:44_$v)");

my %SymbolTable2 = ('.'=>'>', '%'=>'%', '0'=>'0_1.0', '1'=>'1', '2'=>'2', '3'=>'3', '4'=>'4', '5'=>'5', '6'=>'6', '7'=>'7', 'V'=>'-3', 'v'=>'-1', '^'=>'2',
	                'R'=>'0_1.0', 'r'=>'0_.8', 'O'=>'7_1.0', 'o'=>'7_.8');

my ($ps0, $ps1, $bs0, $as0) = ('', '', '', '');

$ps0 = " |B.......|S.......|B.......|S....s..| ";

#$ps1 = " |Oc..o...|Oc..o.c.|Oc..o...|Oc..o.c.| ";

                   $bs0 = " |0....0..|2....2..|4....4..|5....5..| |7....7..|5....5..|4....4..|2..1.2..| ";
if ($scale == 3) { $bs0 = " |0....0..|2....2..|4....4..|6....6..| |7....7..|6....6..|4....4..|2..1.2..| "; }

#$as0 = " |0.2.|4.7.|7.4.|2.77| ";

my $asu = "^2 ^2 ^3"; my $asd = "v3 v2 v2";

my $bo = 2; if ($key%12 <= 2) { $bo++; } #MidiDebug::WrStr("$ci $so $p0 $gs0\n");

#if ($msk>> 1&1) { Edit::Seq($m,  1, $s, [$key   +   0*12, $ScS], $scale, "<1/1:% Cx104_2_1_0_1 ", 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l); }

#if ($msk>> 2&1) { Edit::Seq($m,  2, $s, [$key   +   0*12, $ScS], $scale, "<$l/1:% $cs0", 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l); }

#if ($msk>> 3&1) { Edit::Seq($m,  3, $s, [$key%12+ $bo*12, $ScS], $scale, "<1/32:%".Edit::PreProc0($bs0, \%SymbolTable2), 1.0, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 4&1) { Edit::Seq($m,  4, $s, ($ScS<<16)|($key-2*12)&0xffff, $scale, " 1/8:> 5{$asu} 5{$asd} v3 ", 1.0, $vof, 0,0,1, 1,1, 1,1, $l); }

#if ($msk>> 5&1) { Edit::Seq($m,  5, $s, [$key   +  -1*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($as0, \%SymbolTable2), .5*$von, $vof, 0,0,1, 1,1, 1,1, $l); }

#if ($msk>>10&1) { Edit::Seq($m, 10, $s, 0, 0, "<1/32:%".Edit::PreProc0($ps0, \%SymbolTable0), 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l);
#                  Edit::Seq($m, 10, $s, 0, 0, "<1/32:%".Edit::PreProc0($ps1, \%SymbolTable1),  .7*$von, $vof, 0,0,1, 1,1, 1,1, $l);
#				  }

my $entry = sprintf("x%x", 0x000|($chord<<8)|$p0|($key%12));
my $loop  = sprintf("x%x", 0x800|($chord<<8)|$p0|($key%12));

if ((caller(1))[3] !~ /Live/) { Edit::Seq($m, 0, $s, 0, 0, " MLabel$entry 2/1:% MLabel$loop 2/1:% MJump$entry 1/1:% "); }

return($l); }
#===============================================================================
sub Var1 { my ($m, $s, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = Tools::GetVarPars(@_);

$l = Edit::Seq($m, 18, $s, 0, 0, "<1/16:%".Edit::PreProc0("|HH.H|H.h.|M.mm|LLl.|", {'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50'}), 1.0*$von, $vof);

MIDI::InsertText($m, 0, $s   , 0, sprintf("Label0x%x", $p0), 0x6, " ", -1);
MIDI::InsertText($m, 0, $s+$l, 0, sprintf("Jump%d"  ,   -1), 0x6, " ", -1);

return($l); }
#===============================================================================
sub Var2 { my ($m, $s, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = Tools::GetVarPars(@_);

$l = Edit::Seq($m, 18, $s, 0, 0, "<1/16:%".Edit::PreProc0("|HH.H|H.h.|M.m.|L.ll|", {'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50'}), 1.0*$von, $vof);

MIDI::InsertText($m, 0, $s   , 0, sprintf("Label0x%x", $p0), 0x6, " ", -1);
MIDI::InsertText($m, 0, $s+$l, 0, sprintf("Jump%d"   ,  -2), 0x6, " ", -1);

return($l); }
#===============================================================================

eval("use RolandHp302; use playsmf;");

my $m = \%main::out;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); my ($t, $B) = (0/4, 4/4);

@main::InitParams = (undef, $t+0/4);

@main::trks = ([], []);

#playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x000000ff); #rec off
#playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x00000001); #rec input only
#playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x00008000); #rec all
#playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x00000000); #rec all w/o play

#MIDI::InsertSysEx($m, 0, $t+1/4, 0, @RolandHp302::IdentityRequest);
#MIDI::InsertGeneric($m, 0, $t+1/2, 0, 0xf7, 0xfa);

$t += Edit::Seq($m, 0, $t, 0, 0, " Cx7a_0 ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx17i 1*$B:% MJump-4 | ") + 1*$B;

$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx19 C7_0.5 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx99 C7_1.0 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx1a Cxa_0.0 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx9a Cxa_0.5 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx1b Cxa_1.0 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx9b Cxa_0.5 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx1c Cx104_0.0 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx9c Cx104_0.5 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx1d Cx104_1.0 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 1, $t, 0, 0, " | MLabelx9d Cx104_0.5 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx18 Cx7a_1 ");

$main::DummyNop = $B;

playsmf::PreProc($m);

#===============================================================================

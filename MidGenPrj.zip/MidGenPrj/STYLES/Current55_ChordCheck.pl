
use HostSystem; use Tools; use Misc; use RolandHp302; use Metronome; use playsmf; use Guitar; use GM;

#if (HostSystem::ProcessRunning("cwpa.exe") || HostSystem::ProcessRunning("Cubase.exe")) { printf("Sequencer running -> exit w/o smf overwrite.\n"); exit(0); }

use constant { u=>undef, p=>undef }; my $m = \%main::out;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my ($t, $B) = (0, 4/4);

#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  3, 3); #output device
#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  5, -1); #timeout

GS::Reset(\%main::out, 0x00, $t+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $t+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

RolandHp302::ImportPatchNames(\%MidiDebug::Prgs, main::p, "$main::SrcDir0/DeviceMaps/Hp503Tones0.txt"); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $t+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a, $GM::RPN_0],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl',    p                                                                              ],  # 00
[1, '0x00',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,    prg(4, 1), 1.0, 1.0,  0.0, 0.8, 0.0],  # 01 left  - harmonics/pad
[1, '0x01',    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.8, 0.0],  # 02 right - melody
[1, '0x02',    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 03 bass
[1, '0x03',    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5, 109), 1.0, 1.0,  0.0, 0.5, 0.0],  # 04 rythm/chords
[1, '0x04',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05',    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06',    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07',    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08',    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0a percussion
[1, '0x0a',    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b',    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c',    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d',    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e',    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f',    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 10
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-9 => '*.75+0.0'});
#Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef; $main::trks[$#main::trks][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

$t += Edit::Seq($m, 1, $t, 0, 0, " | 1/2:% %_C$GM::CCx7a\_$GM::CCoff "); #local control

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx17Labelxfff 1*$B:% MJump-4 | ") + 1*$B;

my $dly = '1/256'; my @vel = ('', '_.95', '_.90', '_.85', '_.80', '_.75', '_.70', '_.65');

my ($pd, $pu) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff");

my ($gs0) = ('');

#          00000000 01111111 11122222 22222333
#         |12345678|90123456|78901234|56789012|
#$gs0 .= " |D.......|D.....U.|D.U.D...|D.....U.| " x 1;
$gs0 .= " |D.....U.|d...D...|....D...|U.d.D...| " x 1;

foreach my $ChordType (sort({$a <=> $b} keys(%playsmf::ChordTypes))) { @notes = @{$playsmf::ChordTypes{$ChordType}}; my %notes = (); for (my $i=0; $i<=$#notes; $i++) { $notes{$notes[$i]}++; }

 for (my $i=0; $i<=$#notes; $i++) { $notes{12+$notes[$i]}++; }

 my $i = -1; my $cu = ''; foreach my $note (sort({$a <=> $b} keys(%notes))) {  $i++; if (length($cu)) { $cu .= " ($dly:%) "; } $cu .= sprintf("(b:%d%s)", $note, $vel[(        $i)%($#notes+1)]); } $cu = '_% [ '.$cu.' ]';
    $i = -1; my $cd = ''; foreach my $note (sort({$b <=> $a} keys(%notes))) {  $i++; if (length($cd)) { $cd .= " ($dly:%) "; } $cd .= sprintf("(b:%d%s)", $note, $vel[($#notes-$i)%($#notes+1)]); } $cd = '_% [ '.$cd.' ]';

 my %Guitar = ('d'=>"$pu b:$cu", 'u'=>"$pu b:$cd",
               'D'=>"$pd b:$cu", 'U'=>"$pd b:$cd");

 #MidiDebug::WrStr("<1/32:%".Edit::PreProc0($gs0, \%Guitar)."0:$pu"); printf("\n");
 for (0..11) { my $o = 0; if ($_ >= 6) { $o = 0; }
  $t += Edit::Seq($m, 4, $t, 48+$o+$_, 0, sprintf(" MLabelx%x ", $ChordType|$_)."<1/32:%".Edit::PreProc0($gs0, \%Guitar)."0:$pu MJump-4") + 1*$B;
  }
 }

Edit::Sustain2NoteOff($m, 4, 1);

Metronome::Generic($m, 10, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" $B:%% MLabelx%x <:%%_C$GM::CCx7a\_$GM::CCon ", 0x18)); #last label + local ctrl on

$main::DummyNop = 1*$B; #align all tracks EOT

#===============================================================================

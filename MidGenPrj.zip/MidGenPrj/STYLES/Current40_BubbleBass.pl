eval("use HostSystem; use Tools; use Misc; use RolandHp302; use Metronome; use playsmf; use Cubase;");

if (not(defined($Chord::c     ))) { eval("use Chord;"     ); }
if (not(defined($Arpeggio::a  ))) { eval("use Arpeggio;"  ); }
if (not(defined($Bass::b      ))) { eval("use Bass;"      ); }
if (not(defined($Percussion::p))) { eval("use Percussion;"); }

use constant { u=>undef, p=>undef }; my $m = \%main::out;

#if (HostSystem::ProcessRunning("cwpa.exe") | HostSystem::ProcessRunning("Cubase.exe")) { printf("sequencer running -> exit\n"); exit(0); }

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my $B = $m->{-1}{5}/$m->{-1}{6}; my $t = 0*$B; $MIDI::ContCtlRes = 1/32; #general output setup

playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  9, 0x7fefa189,  0x15, 0x16,  36, 59, 1, 0, +12, 64, 0,  60, 127, 2, 0, -12, 127, 0,  60, 127, -2, -10, +12, 127, 0,  60, 127, -2, -20, -12, 127, 0);

GS::Reset(\%main::out, 0x00, $t+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $t+1/4, 1, undef, 0x04, undef, 0x5f, 0x5f); #

RolandHp302::ImportPatchNames(\%MidiDebug::Prgs, main::p, "$main::SrcDir0/DeviceMaps/Hp503Tones0.txt"); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $t+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a, $GM::RPN_0],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl',    p                                                                              ],  # 00
[1, '0x00',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   prg(5,  9), 1.0, 1.0,  0.0, 0.7, 0.0],  # 01 left  layer 1 - harmonics/pad/chord
[1, '0x01',    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   prg(5, 10), 1.0, 1.0,  0.0, 0.7, 0.0],  # 02 right layer 1 - melody
[1, '0x02',    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0, 1.0,  0.0, 0.9, 0.9],  # 03 bass
[1, '0x03',    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27,  .6, 1.0,  0.0, 0.8, 0.0],  # 04 rythm/chords
[1, '0x04',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05',    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,  120, 1.0, 1.0,  0.0, 0.5, 0.0],  # 06
[1, '0x06',    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07',    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08',    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   prg(5, 47), 1.0, 1.0,  0.0, 0.9, 0.0],  # 0a percussion
[1, '0x0a',    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b',    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c',    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d',    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e',    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f',    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27, 1.0, 1.0,  0.0, 0.7, 0.0],  # 10
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .5], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .5], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .5], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-9 => '*.75+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef; $main::trks[$#main::trks][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

Edit::Seq($m,  1, $t+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control
Edit::Seq($m, 10, $t+3/4, 0, 0, " 1/4:36 "); #ready signal

$t += Metronome::GenericWoMain($m, 10, $t,   1*$B, .4, u, u, 0, 1, 33); #pre counter (cwpa9 doesnt like 1st beat when saving smf!?)
#      Metronome::Generic($m, 10, $t, 512*$B, .2, u, u, 0, 1, 33); #main counter

if ($B < 1/1) { $t += 1*$B; }

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | MLabelx%xLabelxfff $B:%% MJump-4 | ", 0x17)) + 1*$B;


$t += Var0($m, $t, 0b10000000000, 60, 4, 1) + 1*$B;

my $L = $t-(1/2)*$B;

$t += Var0($m, $t, ~0b110, 60, 2, 1) + 1*$B;
$t += Var0($m, $t, ~0b110, 60, 3, 1) + 1*$B;

my $R = $t-(1/2)*$B;

for (my $i=1; $i<=11; $i++) { $t += Tools::CopyRegion($m, $t-(1/2)*$B, $L, $R-$L, $i-12*($i>6), \@main::trks) + (0/1)*$B; }

Metronome::Generic($m, 10, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" $B:%% MLabelx%x <:%%_C$GM::CCx7a\_$GM::CCon ", 0x18)); #

#playsmf::PreProc($m); Cubase::Compatibility($m, 1*$B);

#===============================================================================
sub Var0 { my ($m, $t, $msk, $key, $scale, $v) = @_; my $t0 = $t; my ($l, $k) = (1/1, 0);

my %SymbolTable = ('o'=>$Chord::c, 'v'=>'.8_> (b:^2 b:^2-1)', '^'=>'.8_> (b:^2 b:^2+1)');

my %SymbolTable1 = ('0'=>"0", '2'=>"2", '7'=>"7");

my $cs = $Chord::c;
my $as = $Arpeggio::a;
my $bs = $Bass::b;
my $ps = $Percussion::p;
my $rs = " |x.x8|x..^|x.8.|x..v| "; $rs =~ s/\./>/g; $rs = Edit::PreProc0($rs, \%SymbolTable);

$bs = " |0070|0700|2002|0000| "; $bs =~ s/\./>/g; $bs = Edit::PreProc0($bs, \%SymbolTable1);

Edit::Seq($m, 0, $t, 0, 0, sprintf(" MLabelx%x ", $scale*0x100));

#if ($msk>> 1&1) { Edit::Seq($m,  1, $t, $key-0*12, $scale, " 1/_1_:$k\_$cs "  , 1.0*$v, .5, 0,0,1, 1,1, 1,1, $l); }
#if ($msk>> 2&1) { Edit::Seq($m,  2, $t, $key-0*12, $scale, " 1/_8_:$k\_$as "  , 1.0*$v, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 3&1) { Edit::Seq($m,  3, $t, $key-2*12, $scale, " 1/16:$k\_$bs "  ,  .5*$v, .5, 0,0,1, 1,1, 1,1, $l); }

#if ($msk>> 4&1) { Edit::Seq($m,  4, $t, $key-0*12, $scale, " 1/16<:$k\_% $rs ", 1.0*$v, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>10&1) { Edit::Seq($m, 10, $t,    0     ,      0, " 1/_4_:____$ps "  ,  .7*$v, .5, 0,0,1, 1,1, 1,-1/16, $l); }

$t += $l;

Edit::Seq($m, 0, $t, 0, 0, sprintf(" MJump-4 "));

return($t-$t0); }
#===============================================================================

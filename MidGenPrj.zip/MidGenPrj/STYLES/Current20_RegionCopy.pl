eval("use Misc; use RolandHp302; use KX; use Metronome; use StyleTrax; use Chord; use Guitar; use playsmf;");

use constant { u=>undef, p=>0x01, dv=>100/127, dr=>40/127, sp=>'5c' }; my $m = \%main::out;

if (($^O !~ /linux/i) && (`tasklist /FI \"IMAGENAME eq cwpa.exe\" 2>&1` =~ /cwpa\.exe/) || (`tasklist /FI \"IMAGENAME eq Cubase.exe\" 2>&1` =~ /Cubase\.exe/)) { printf("sequencer running -> exit\n"); exit(0); }

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my $B = $m->{-1}{5}/$m->{-1}{6}; my $t = 0*$B; $MIDI::ContCtlRes = 1/32; #general output setup

#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  2, 0x01, 0x00, 0x7fefa189, 0x0ff, -1, 1000, -1,  21, 22,  36, 59, 2, 0, 12, 64, 0,  60, 127, 1, 0, 0, 127, 0,  60, 127, -10, 0, 0x80+36, 0, 0,  60, 127, -1, 20, -12, 0, 0);
#playsmf::OverrideCmdLineArgs($m, 0, $t, 1, -1, 0x10000, 0x10101, 0x10909);

GS::Reset(\%main::out, 0x00, $t+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $t+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

RolandHp302::ImportPatchNames(\%MidiDebug::Prgs, main::p, "$main::SrcDir0/DeviceMaps/Hp503Tones0.txt");

$MidiDebug::Prgs{0x02} = {-1 => 'SF201'};
$MidiDebug::Prgs{0x02}{0xc}{ -1}{-1}{-1} = "D:/INSTR/COMMERC/8mbgm_21.sf2"; # 7.586.050   Sun Mar 18 12:17:00 2001
$MidiDebug::Prgs{0x02}{0xc}{0x0}{-1}{-1} = "D:/INSTR\\WavItGld/SynPads/Attpad_M.sf2";
$MidiDebug::Prgs{0x02}{0xc}{0x1}{-1}{-1} = "D:/INSTR\\WavItGld/SynPads/JMJPad_L.sf2";
$MidiDebug::Prgs{0x02}{0xc}{0x2}{-1}{-1} = "D:/INSTR\\WavItGld/BassSynt/EMUBas_M.sf2";
$MidiDebug::Prgs{0x02}{0xc}{0x9}{-1}{-1} = "D:/INSTR\\WavItGld/Drumkits/Beat.sf2";

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $t+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a],
#s   name         port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl'      ,    p                                                                              ],  # 00
[1, '0x00'      ,    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.7, 0.0],  # 01 right - melody
[1, '0x01'      ,    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,    prg(4, 1), 1.0, 1.0,  0.0, 0.7, 0.0],  # 02 left  - harmonics/pad
[1, '0x02'      ,    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0, 1.0,  0.0, 0.5, 0.0],  # 03 bass
[1, '0x03'      ,    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x01,  .8, 1.0,  0.0, 0.0, 0.0],  # 04 rythm/chords
[1, '0x04'      ,    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05'      ,    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06'      ,    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07'      ,    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08'      ,    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09'      ,    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, 0.0],  # 0a percussion
[1, '0x0a'      ,    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b'      ,    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c'      ,    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d'      ,    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e'      ,    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f'      ,    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 10
[1, '0x10 Mute1',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,                                       ],  # 11
[1, '0x11'      ,    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0                                        ],  # 12
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

Misc::SetGroupedTrkValues(\@main::trks, undef, {-9 => '*.75+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

Edit::Seq($m, 17, $t+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control
Edit::Seq($m, 10, $t+3/4, 0, 0, " 1/4:36 "); #ready signal

$t += Metronome::GenericWoMain($m, 10, $t,   1*$B, .4, u, u, 0, 1, 33); #pre counter (cwpa9 doesnt like 1st beat when saving smf!?)
#      Metronome::Generic($m, 10, $t, 512*$B, .2, u, u, 0, 1, 33); #main counter

if ($B < 1/1) { $t += 1*$B; }

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; } #goto MyLabelEnd;

#playsmf::OverrideCmdLineArgs($m, 0, 0/1, 1, 5, 0x7ff08fb0); #rec

$t += StyleTrax::LiveStyle($m, $t, "$PhrDir/*$Phr*", 60, 2, 1, \&main::Var0, -1^0b10000011111, 0, 0, 0x0) + 1*$B; #goto MyLabelEnd;

#$t += StyleTrax::ChordStyle($m, $t, " 4( 2( 1/1:4c ) 2( 1/1:4g2 ) 1/1:3G# 3A# (4c) > ) ", \&main::Var0, -1^0b10000001111, 1.0, .5, 0x0); #goto MyLabelEnd;

my $Labels = ''; #for (my $i=2; $i<=4; $i++) { for (my $j=0; $j<=11; $j++) { $Labels .= sprintf("Labelx%x", ($i<<8)+0x80+$j); }}

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx17$Labels $B:% MJump-4 | ") + 1*$B;

$t += main::Var1($m, $t, undef, -1^0b10000000001, 0, 0, 0, 1.0, .5, 0, 0/1, 0x19) + 1*$B;
$t += main::Var2($m, $t, undef, -1^0b10000000001, 0, 0, 0, 1.0, .5, 0, 0/1, 0x1a) + 1*$B;

$t += main::Var0($m, $t, undef, -1^0b10000000001, 60, 4, 0, 1.0, .5, 0, 0/1, 0, -140) + 1*$B; my $L = $t;
$t += main::Var0($m, $t, undef, -1^0b10000111011, 60, 2, 0, 1.0, .5, 0, 0/1, 0,  120) + 1*$B;
$t += main::Var0($m, $t, undef, -1^0b10000111011, 60, 2, 0, 1.0, .5, 0, 0/1, 1,   60) + 1*$B;
#$t += main::Var0($m, $t, undef, -1^0b10000111011, 60, 3, 0, 1.0, .5, 0, 0/1, 0, -100) + 1*$B;

my $R = $t-1*$B;

for (my $i=1; $i<=11; $i++) { $t += Tools::CopyRegion($m, $t, $L, $R-$L, $i-12*($i>6), \@main::trks) + 1*$B; }

#Edit::Randomize($m, 4, 0.01, 0.1, 0.1, 0, 1);

Metronome::Generic($m, 10, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33); #main counter

Edit::Seq($m, 17, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, " 2{ $B:% MLabelx18 <:%_C$GM::CCx7a\_$GM::CCon } "); #duplicate since Cubase drops last event

#===============================================================================
sub Var0 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0, $p1) = (@_); $msk ^= -1; if ((caller(1))[3] =~ /Live/) { ($von, $vof) = (1, .5); }

my $B = $m->{-1}{5}/$m->{-1}{6};

if ((defined($p1)) && ($p1 > 0)) { MIDI::InsertTempo( $m, 0, $t, 0, $p1); }

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

if ($msk>> 2&1) { MIDI::InsertText($m, 2, $t, 1, sprintf("%s", Tools::GetNoteName($key, $scale, $inv)), 5, " -> ", 1); }

my $ScS = 0; #($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

my $cs0 = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs0) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($scale != 2) && ($scale != 3)) { $msk &= 0b00000010000000101; $scale = 3; } #unsupported scales -> mask melodic tracks

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

my $BD = 36; my ($V, $v, $PanBD, $center, $left, $right) = ('1.0', '.75', $GS::NRPNx1c00+$BD, .5, 0, 1);

my %SymbolTable0 = ('A'=>"27_$V", 'B'=>"$BD\_$V", 'S'=>"38_$V", 'b'=>"$BD\_$v", 's'=>"38_$v", 'Q'=>"$BD\_$V (<-3/128:27)", 'T'=>"% (<-1/128:36)",
	                'C'=>"$BD\_$V\_C$PanBD\_$center", 'c'=>"$BD\_$v\_C$PanBD\_$center",
	                'L'=>"$BD\_$V\_C$PanBD\_$left",   'l'=>"$BD\_$v\_C$PanBD\_$left",
	                'R'=>"$BD\_$V\_C$PanBD\_$right",  'r'=>"$BD\_$v\_C$PanBD\_$right");

my %SymbolTable1 = ('C'=>"42_$V", 'P'=>"44_$V", 'O'=>"46_$V", 'c'=>"42_$v", 'p'=>"44_$v", 'o'=>"46_$v", '9'=>"42_.9", '8'=>"42_.8", '7'=>"42_.7",
	                'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50',
	                '<'=>"% (<+1/128:44_$v)", '>'=>"% (<-1/128:44_$v)");

my %SymbolTable2 = ('.'=>'>', '%'=>'%', '0'=>'0_1.0', '1'=>'1', '2'=>'2', '3'=>'3', '4'=>'4', '5'=>'5', '6'=>'6', '7'=>'7', 'V'=>'-3', 'v'=>'-1', '^'=>'2',
	                'R'=>'0_1.0', 'r'=>'0_.8', 'O'=>'7_1.0', 'o'=>'7_.8');

my %SymbolTable3 = ('.'=>'>', '%'=>'%', 'c'=>$cs0, 'v'=>"_> (b:^2 b:^1)", '^'=>"_> (b:^2 b:^3)");

my %Toms = ('A'=>"41_$V", 'B'=>"43_$V", 'C'=>"45_$V", 'D'=>"47_$V", 'E'=>"48_$V", 'F'=>"50_$V",
            'a'=>"41_$v", 'b'=>"43_$v", 'c'=>"45_$v", 'd'=>"47_$v", 'e'=>"48_$v", 'f'=>"50_$v");

my ($ps0, $ps1, $bs0, $as0, $cl0) = ('', '', '', '', '');

$ps0 = " |A.d.|b.d.|Ad.d|b.dd||A.C.|b.d.|Ad.d|b.dd| ";
$ps1 = " |C.p.|p.p.|pp.p|pp.p||C.p.|p.p.|pp.p|pp.p| ";
$bs0 = " |0.77|0.77|0077|0077||0.77|0.77|0077|0077| ";

$as0 = " |0.00|00.0|0.00|00.0||0.00|00.0|0.00|00.0| ";

my $bo = 2; if ($key%12 <= 5) { $bo++; } my @ls;

if ($msk>> 3&1) { push(@ls, my $t = Edit::Seq($m,  3, $t, [$key%12+ $bo*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($bs0, \%SymbolTable2), 1.0, $vof, 0,0,1, 1,1, 1,1, $l));
                  #push(@ls,         Edit::Seq($m,  3, $t, [$key%12+ $bo*12, $ScS], $scale, " $t:Cx4a_2_0_.6_.2_0 "                       , 1.0, $vof, 0,0,1, 1,1, 1,1, $l));
				  }

if ($msk>> 4&1) { push(@ls, Edit::Seq($m,  4, $t, [$key   +   ($bo-4)*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($cl0, \%SymbolTable2), .8*$von, $vof, 0,0,1, 1,1, 1,1, $l)); }
if ($msk>> 4&1) { push(@ls, Edit::Seq($m,  4, $t, [$key   +   ($bo-5)*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($cl0, \%SymbolTable2), .8*$von, $vof, 0,0,1, 1,1, 1,1, $l)); }
if ($msk>> 4&1) { push(@ls, Edit::Seq($m,  4, $t, [$key   +   ($bo-6)*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($cl0, \%SymbolTable2), .8*$von, $vof, 0,0,1, 1,1, 1,1, $l)); }

if ($msk>> 5&1) { push(@ls, Edit::Seq($m, 17, $t, [$key   +  0*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($as0, \%SymbolTable2), 1*$von, $vof, 0,0,1, 1,1, 1,1, $l)); }

if ($msk>>10&1) { push(@ls, Edit::Seq($m, 10, $t, 0, 0, "<1/16:%".Edit::PreProc0($ps0, \%Toms        ), 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l));
                  push(@ls, Edit::Seq($m, 10, $t, 0, 0, "<1/16:%".Edit::PreProc0($ps1, \%SymbolTable1), 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l));
				  }

$l = 0; foreach (@ls) { if ($_ > $l) { $l = $_; }}

if ($msk>> 2&1) { push(@ls, Edit::Seq($m,  2, $t, [$key   +   ($bo-2)*12, $ScS], $scale, "<$l/1:% $cs0", 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l)); }

my $Label = ($p0<<12)|($chord<<8)|($inv<<4); my $entry = '';
if ($chord == 2) { for (my $i=0; $i<= 1; $i++) { $entry .= sprintf("MLabelx%x ", $Label|($i<<8)|($key%12)); }}
if ($chord == 4) { for (my $i=0; $i<=11; $i++) { $entry .= sprintf("MLabelx%x ", $Label| $i              ); }}

my $JumpLabel = -4; if ($p0) { $JumpLabel = -1; }

if ((caller(1))[3] !~ /Live/) { Edit::Seq($m, 0, $t, 0, 0, " $entry [$B:% MLabelxfff] $l:% MJump$JumpLabel "); }

return($l); }
#===============================================================================
sub Var1 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = (@_); $msk ^= -1; if ((caller(1))[3] =~ /Live/) { ($von, $vof) = (1, .5); }

$l = Edit::Seq($m, 18, $t, 0, 0, "<1/16:%".Edit::PreProc0("|HH.H|H.h.|M.mm|LLl.|", {'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50'}), 1.0*$von, $vof);

MIDI::InsertText($m, 0, $t   , 0, sprintf("Label0x%x", $p0), 0x6, " ", -1);
MIDI::InsertText($m, 0, $t+$l, 0, sprintf("Jump%d"  ,   -1), 0x6, " ", -1);

return($l); }
#===============================================================================
sub Var2 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = (@_); $msk ^= -1; if ((caller(1))[3] =~ /Live/) { ($von, $vof) = (1, .5); }

$l = Edit::Seq($m, 18, $t, 0, 0, "<1/16:%".Edit::PreProc0("|HH.H|H.h.|M.m.|L.ll|", {'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50'}), 1.0*$von, $vof);

MIDI::InsertText($m, 0, $t   , 0, sprintf("Label0x%x", $p0), 0x6, " ", -1);
MIDI::InsertText($m, 0, $t+$l, 0, sprintf("Jump%d"   ,  -3), 0x6, " ", -1);

return($l); }
#===============================================================================

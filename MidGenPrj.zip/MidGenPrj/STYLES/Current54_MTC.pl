
use playsmf; use Sync;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0}); my ($m, $t, $B) = (\%main::out, 0, 4/4);

#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  3, 3); #output device
#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  5, -1); #timeout
#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  8, 0xff8077); #rec
#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  9, 0x8000); #INT

@main::InitParams = (undef, $t+0/4);

@main::trks = ([], []);

$t += Edit::Seq($m, 0, $t, 0, 0, " | 1*$B:% | MLabelx17i 1*$B:% MJump-4 | ") + 1*$B;

#MIDI::InsertTempo($m, 0, $t, 0, 120.0); MIDI::InsertText($m, 0, $t, 1, sprintf("Label0x19ir"), 0x6, '->'); $t += Sync::InsertMC($m, 0, $t, 4*$B, (2+0)*$B); MIDI::InsertText($m, 0, $t, 1, sprintf("Jump-4"), 0x6, '->'); $t += 1*$B;
#MIDI::InsertTempo($m, 0, $t, 0, 140.0); MIDI::InsertText($m, 0, $t, 1, sprintf("Label0x1air"), 0x6, '->'); $t += Sync::InsertMC($m, 0, $t, 4*$B, (2+8)*$B); MIDI::InsertText($m, 0, $t, 1, sprintf("Jump-4"), 0x6, '->'); $t += 1*$B;

MIDI::InsertText($m, 0, $t, 1, sprintf("Label0x19ir"), 0x6, '->'); $t += Sync::InsertMTC($m, 0, $t,  1*30); MIDI::InsertText($m, 0, $t, 1, sprintf("Jump-4"), 0x6, '->'); $t += 1*$B;
MIDI::InsertText($m, 0, $t, 1, sprintf("Label0x1air"), 0x6, '->'); $t += Sync::InsertMTC($m, 0, $t, -1*30); MIDI::InsertText($m, 0, $t, 1, sprintf("Jump-4"), 0x6, '->'); $t += 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx18 ");

$main::DummyNop = 1*$B; #align all tracks EOT

playsmf::PreProc($m);

#===============================================================================

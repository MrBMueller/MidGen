eval("use Misc; use RolandHp302; use KX; use Metronome; use StyleTrax; use Chord; use Guitar;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>90.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my ($m, $s) = (\%main::out, 0/1); #general output setup

GS::Reset(\%main::out, 0x00, $s+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x70, 0x70); #

use constant { u=>undef, p=>0x09, dv=>100/127, dr=>40/127, sp=>'5c' };

$MidiDebug::Prgs{main::p} = {RolandHp302::ImportPatchNames("$main::SrcDir0/DeviceMaps/Hp503Tones0.txt")};

$MidiDebug::Prgs{0x01} = {-1 => 'SF201'};
$MidiDebug::Prgs{0x01}{0xc}{-1}{-1}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2"; # 7.586.050   Sun Mar 18 12:17:00 2001

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $s+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, $GM::RPN_0, $GS::BPx02, $GS::BPx1d, $GS::BPx1e, $GS::cBPx16, $GS::cBPx17],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl',    p                                                                              ],  # 00
[1, '0x00',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  17), 1.0, 1.0,  0.0, 0.8, 0.0],  # 01 live
[1, '0x01',    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   1),  .7, 1.0,  0.0, 0.8, 0.0],  # 02 harmonics/pad
[1, '0x02',    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0,      0,   38, 1.0, 1.0,  0.0, 0.4, 0.0],  # 03 bass
[1, '0x03',    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,   1), 1.0, 1.0,  0.0, 0.5, 0.0],  # 04
[1, '0x04',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05',    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,  120, 1.0, 1.0,  0.0, 0.5, 0.0],  # 06
[1, '0x06',    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07',    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08',    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  47), 1.0, 1.0,  0.0, 0.4, 0.0],  # 0a percussion
[1, '0x0a',    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b',    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c',    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d',    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e',    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f',    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24, 1.0, 1.0,  0.0, 0.3, 0.0]); # 10

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  27 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #HQ
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #metronome
  34 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome bell
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD2 \ right
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1 / side within kit
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD1
  39 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #HC
  40 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD2
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH - pedal pressed    + stick \
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH - closure noise  w/o stick  > left site witin kit
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #OHH - regular position + stick /
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#for (10..11) { $main::trks[2+1][$_] = $main::trks[1+1][$_]; } #left follows right patch

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => '*1.0+0.0', $GM::CCx07 => '*.5+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

Edit::Seq($m, 1, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Metronome::Generic(      \%main::out, 0x0a, $s,   1*$m->{-1}{5}/$m->{-1}{6}, .4); #pre counter
      Metronome::GenericWoMain(\%main::out, 0x0a, $s, 256*$m->{-1}{5}/$m->{-1}{6}, .0); #main counter

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }
if ($#ARGV >= 1) { $Phr = 'rec'; } #goto MyLabelEnd;

#$s += StyleTrax::LiveStyle($m, $s, "$PhrDir/*$Phr*", 60-1, 2, 1, \&main::Var0, -1^0b10000001111, 0, 0, 1234); #goto MyLabelEnd;

#$s += StyleTrax::ChordStyle($m, $s, " 4( 2( 1/1:4c ) 2( 1/1:4g2 ) 1/1:3G# 3A# (4c) > ) ", \&main::Var0, -1^0b10000001111, 1.0, .5, 1234); #

Edit::Seq($m, 10, $s, 0, 0, " <1/4:34 ");

$s += Edit::Seq($m, 0, $s, 0, 0, " MLabelx17 1/1:% MJumpx17 % ");

for (my $i=0; $i<=11; $i++) {
 $s += main::Var0($m, $s, 3/1, -1^0b10000011011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x200+$i); $s += 1/1;
 $s += main::Var0($m, $s, 3/1, -1^0b10000011011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x300+$i); $s += 1/1;
 $s += main::Var0($m, $s, 3/1, -1^0b10000000011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x400+$i); $s += 1/1;
 }

$s += Edit::Seq($m, 1, int(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4))+2/1, 0, 0, " MLabelx18 <:%_C$GM::CCx7a\_$GM::CCon ");

#===============================================================================
sub Var0 { my ($m, $s, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = Tools::GetVarPars(@_); if ((caller(1))[3] =~ /Live/) { ($von, $vof) = (1, .5); }

#printf("$s $l : $key $chord $inv - $von $vof $ci $so $p0\n");

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

if ($msk>> 2&1) { MIDI::InsertText($m, 2, $s, 1, sprintf("%s", Tools::GetNoteName($key, $scale, $inv)), 5, " -> ", 1); }

my $ScS = 0; #($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

my $cs0 = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs0) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($scale != 2) && ($scale != 3)) { $msk &= 0b00000010000000101; $scale = 3; } #unsupported scales -> mask melodic tracks

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

my $BD = 36; my ($V, $v, $PanBD, $center, $left, $right) = ('1.0', '.75', $GS::NRPNx1c00+$BD, .5, 0, 1);

my %SymbolTable0 = ('B'=>"$BD\_$V", 'S'=>"38_$V", 'b'=>"$BD\_$v", 's'=>"38_$v", 'Q'=>"$BD\_$V (<-3/128:27)", 'T'=>"% (<-1/128:36)",
	                'C'=>"$BD\_$V\_C$PanBD\_$center", 'c'=>"$BD\_$v\_C$PanBD\_$center",
	                'L'=>"$BD\_$V\_C$PanBD\_$left",   'l'=>"$BD\_$v\_C$PanBD\_$left",
	                'R'=>"$BD\_$V\_C$PanBD\_$right",  'r'=>"$BD\_$v\_C$PanBD\_$right");

my %SymbolTable1 = ('C'=>"42_$V", 'P'=>"44_$V", 'O'=>"46_$V", 'c'=>"42_$v", 'p'=>"44_$v", 'o'=>"46_$v", '9'=>"42_.9", '8'=>"42_.8", '7'=>"42_.7",
	                'l'=>'41', 'L'=>'43', 'm'=>'45', 'M'=>'47', 'h'=>'48', 'H'=>'50',
	                '<'=>"% (<+1/128:44_$v)", '>'=>"% (<-1/128:44_$v)");

my %SymbolTable2 = ('.'=>'>', '%'=>'%', '0'=>'0', '1'=>'-1b', '2'=>'-2', '3'=>'-3', '4'=>'4', '6'=>'6', '7'=>'7', 'v'=>'-1', '^'=>'2');

my ($ps0, $ps1, $bs0, $as0) = ('', '', '', '');

#$ps0  = "|B...|S...|B...|S...|";
$ps0  = "|B...|B...|B...|B...|";

$ps1 = "|cccc|p..p|c..c|p..p|";

#$bs0 = "|0.77|0.77|0.0.|0000| |0.77|0.77|0.77|0.77| |0...|0.0.|0.00|0.77|";
$bs0 = "|0000|0..0|0000|0.0.|";

#$as0 = "|0.^.|4.^.|0.^.|4.^.|";

my %vb = (-1=>.7, -3=>1/16, -4=>1/1, -5=>{0/1=>2.0, 1/4=>1.25, 1/2=>1.5, 3/4=>1.25});

my $bo = 2; if ($key%12 <= 2) { $bo++; } #MidiDebug::WrStr("$ci $so $p0 $gs0\n");

if ($msk>> 2&1) { Edit::Seq($m,  2, $s, [$key   +   0*12, $ScS], $scale, " 1/1:% $cs0", 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 3&1) { Edit::Seq($m,  3, $s, [$key%12+ $bo*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($bs0, \%SymbolTable2), 1.0, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 4&1) { Edit::Seq($m,  4, $s, [$key   +   0*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($as0, \%SymbolTable2),  .8, $vof, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>10&1) { Edit::Seq($m, 10, $s, 0, 0, "<1/16:%".Edit::PreProc0($ps0, \%SymbolTable0), 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l, 0x03, {}, {38=>-0/128});
                  Edit::Seq($m, 10, $s, 0, 0, "<1/16:%".Edit::PreProc0($ps1, \%SymbolTable1), 1.0*$von, $vof, 0,0,1, 1,1, 1,1, $l, 0x03, {}, {});
				  }

MIDI::InsertText($m, 0, $s   +4/4, 0, sprintf("Label0x%x", $p0+0x00), 0x6, " ", -1);
MIDI::InsertText($m, 0, $s   +1/1, 0, sprintf("Label0x%x", $p0+0x10), 0x6, " ", -1);
MIDI::InsertText($m, 0, $s+$l-1/1, 0, sprintf("Jump0x%x" , $p0+0x10), 0x6, " ", -1);
#MIDI::InsertText($m, 0, $s+$l-1/4, 0, sprintf("Jump0x%x" , $p0+0x10), 0x6, " ", -1);

return($l); }
#===============================================================================

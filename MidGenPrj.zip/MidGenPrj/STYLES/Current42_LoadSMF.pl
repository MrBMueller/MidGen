
my $m = \%main::out;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); my ($t, $B) = (0, 4/4);

@main::InitParams = (undef, $t+0/4);

@main::trks = ([], []);

Edit::Seq($m, 0, $t, 0, 0, " | MLabelx17 1*$B:% MJumpx17 | 1*$B:% | MLabelx19 1*$B:% MJump-1 | 1*$B:% | MLabelx18 ");
Edit::Seq($m, 1, $t, 0, 0, " | 1*$B:%_C0_0               | =      | =                        | =      |           ");
Edit::Seq($m, 2, $t, 0, 0, " | 1*$B:%_C0_0               | =      | =                        | =      |           ");

#===============================================================================

eval("use Metronome; use GM; use STY; use playsmf; use RolandHp302;");

my $m = \%main::out; %{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>123.0, 5=>4, 6=>4}); my ($t, $B) = (0, $m->{-1}{5}/$m->{-1}{6});

my $MetronomeStart = $t;

playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x00ff80f0); #rec

playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 0, 9, 0x7fefa189); #INT

@main::InitParams = (undef, 0*$B);

@main::trks = ([-1], [1]);


MIDI::InsertSysEx($m, 0, $t+1*$B, 0, @RolandHp302::IdentityRequest);

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | 1/2*$B:%% 1/2*$B:%%_C$GM::CCx7a\_$GM::CCoff | MLabelx17 1*$B:%% MJump-4 | ")) + 1*$B;



Metronome::Generic($m, (sort {$b <=> $a} keys(%{$m}))[0]+1, $MetronomeStart, $t-$MetronomeStart, .3);

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | MLabelx18Labelx%x <:%%_C$GM::CCx7a\_$GM::CCon ", 0xfff));

#===============================================================================

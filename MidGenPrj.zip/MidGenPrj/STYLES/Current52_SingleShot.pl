
my $m = \%main::out;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); my ($t, $B) = (0, 4/4);

@main::InitParams = (undef, $t+0/4);

@main::trks = ([], []);

$t += Edit::Seq($m, 0, $t, 0, 0, " | <:%_Cx7a_0 ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelxbcLabelxbdLabelx17iLabelx1fffi 1*$B:% MJump-4 | ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx3ci 1*$B:60 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx3di 1*$B:67 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx103ci 1*$B<:60 67 MJump-1 | ") + 1*$B;
$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx103di 1*$B<:67 74 MJump-1 | ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | MLabelx18 ");

#===============================================================================

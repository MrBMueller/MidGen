eval("use Misc; use RolandHp302; use KX; use Metronome; use StyleTrax; use Chord; use Guitar; use playsmf; use Cubase;");

use constant { u=>undef, p=>undef }; my $m = \%main::out;

if ($^O !~ /linux/i) {
 if ((`tasklist /FI \"IMAGENAME eq cwpa.exe\" 2>&1` =~ /cwpa\.exe/) || (`tasklist /FI \"IMAGENAME eq Cubase.exe\" 2>&1` =~ /Cubase\.exe/)) { printf("sequencer running -> exit\n"); exit(0); }
 }

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>112.0, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord('C')), 8=>Misc::GetCopyright()}); my $B = $m->{-1}{5}/$m->{-1}{6}; my $t = 0*$B; $MIDI::ContCtlRes = 1/32; #general output setup

playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  9, 0x7fefa189,  0x15, 0x16,  36, 59, 1, 0, +12, 64, 0,  60, 127, 2, 0, +0, 127, 0,  60, 127, 2, 10, +12, 127, 0,  60, 127, 2, 20, -12, 127, 0);
#playsmf::OverrideCmdLineArgs($m, 0, $t, 1, -1, 0x10000, 0x10101, 0x10909);

GS::Reset(\%main::out, 0x00, $t+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $t+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

RolandHp302::ImportPatchNames(\%MidiDebug::Prgs, main::p, "$main::SrcDir0/DeviceMaps/Hp503Tones0.txt");

*prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $t+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a, $GM::RPN_0],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl',    p                                                                              ],  # 00
[1, '0x00',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   48,  .5, 1.0,  0.0, 0.7, 0.0],  # 01 left  - harmonics/pad
[1, '0x01',    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00,  .5, 1.0,  0.0, 0.7, 0.0],  # 02 right - melody
[1, '0x02',    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0, 1.0,  0.0, 0.5, 0.0],  # 03 bass
[1, '0x03',    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x01,  .8, 1.0,  0.0, 0.0, 0.0],  # 04 rythm/chords
[1, '0x04',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05',    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,  120,  .6, 1.0,  0.0, 0.5, 0.0],  # 06
[1, '0x06',    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07',    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08',    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, 0.0],  # 0a percussion
[1, '0x0a',    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b',    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c',    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d',    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e',    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f',    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   24,  .9, 1.0,  0.0, 0.5, 0.0],  # 10
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-9 => '*.75+0.0'});
#Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1+0][0] = undef; $main::trks[$#main::trks][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

#$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | MLabelxfff "));

Edit::Seq($m,  1, $t+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control
Edit::Seq($m, 10, $t+3/4, 0, 0, " 1/4:36 "); #ready signal

$t += Metronome::GenericWoMain($m, 10, $t,   1*$B, .4, u, u, 0, 1, 33); #pre counter (cwpa9 doesnt like 1st beat when saving smf!?)
#      Metronome::Generic($m, 10, $t, 512*$B, .2, u, u, 0, 1, 33); #main counter

if ($B < 1/1) { $t += 1*$B; }

#playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x7ff08fb0); #rec

#MIDI::InsertSysEx($m, 0, $t+0*$B, 0, @GM2::IdentityRequest);
#MIDI::InsertSysEx($m, 0, $t+0*$B, 0, @RolandHp302::IdentityRequest);

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | MLabelx400iLabelx14abiLabelx17i $B:%% MJump-4 | ")) + 1*$B;

my $L = $t-(1/2)*$B;

for (my $i=0; $i<=11; $i++) {
 $t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x0000) + 1*$B;
 #$t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x1000) + 1*$B;

 $t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x0000) + 1*$B;
 #$t += main::Var0($m, $t, undef, -1^0b10000111011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x1000) + 1*$B;

 $t += main::Var1($m, $t, undef, -1^0b10000111011, 60+$i, 2, 0, 1.0, .5, 0, 0/1, 0x0000) + 1*$B;
 $t += main::Var1($m, $t, undef, -1^0b10000111011, 60+$i, 3, 0, 1.0, .5, 0, 0/1, 0x0000) + 1*$B;
 }

my $R = $t-(1/2)*$B;

#for (my $i=1; $i<=11; $i++) { $t += Tools::CopyRegion($m, $t-(1/2)*$B, $L, $R-$L, $i-12*($i>6), \@main::trks) + (0/1)*$B; }

my $NextTrk = $#main::trks;
for (my $t=0; $t<=5; $t++) { if ($t < 5) { Edit::Copy($m, 11+$t, $m, 16, 0xb); } #Edit::Sustain2NoteOff($m, 11+$t, 1);
 $main::trks[11+$t+1][19+0] = Edit::Portamento($m, 11+$t, 0/16, 0, Edit::GetInt(8, 5-$t)+40+0, undef, 0x104, 4, undef, undef, undef, $NextTrk+$t);
 for (my $p=0; $p<=16+0; $p++) { if ($p != (4-1)) { $main::trks[11+$t+1][$p] = $main::trks[16+1][$p]; }}
 for (my $p=0; $p<=3+0; $p++) { $main::trks[$NextTrk+$t+1][$p] = $main::trks[11+$t+1][$p]; } $main::trks[$NextTrk+$t+1][1+0] = $main::trks[11+$t+1][1+0];
 }

#Edit::Randomize($m, 4, 0.01, 0.1, 0.1, 0, 1);

#Metronome::Generic($m, 10, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" 1{ $B:%% MLabelx%x <:%%_C$GM::CCx7a\_$GM::CCon } ", 0x18)); #duplicate since Cubase drops last event

Cubase::Compatibility($m, 1*$B);

#===============================================================================
sub Var0 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = (@_); $msk ^= -1;

my $B = $m->{-1}{5}/$m->{-1}{6};

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

my $ScS = 0; #($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

my $cs0 = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs0) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($chord != 2) && ($chord != 3)) { $msk &= 0b00000010000000011; $scale = 3; } #unsupported scales -> mask melodic tracks

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

$Guitar::Tabs{3}{11} = [-1,  2,  4,  4,  3,  2]; my $gdly = '1/128';
my $gcd = Guitar::Chord($scale, $key, 0, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff down (notes up)
my $gcu = Guitar::Chord($scale, $key, 1, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff up (notes down)
my $gcM = Guitar::Chord($scale, $key, 1, ['  ', '  ', '  ', '  ', '  ', '  ']); #simultaneous
my $gcm = Guitar::Chord($scale, $key, 1, ['.5', '.5', '.5', '.5', '.5', '.5']); #simultaneous

my %Guitar = ('m'=>"$pu b:$gcm", 'M'=>"$pu b:$gcM <:$pd", 'd'=>"$pu b:$gcd", 'u'=>"$pu b:$gcu", 'p'=>$pd, 'P'=>$pu, 'n'=>"$ano b:$pu", 's'=>"$aso b:$pu", 'D'=>"$pd b:$gcd", 'U'=>"$pd b:$gcu");

my ($ps0, $ps1, $bs0, $as0, $cl0, $gs0) = ('', '', '', '', '', '');

#         00000000 01111111 11122222 22222333
#        |12345678|90123456|78901234|56789012|
$gs0 = " |D.......|........|........|........| ";

#$gs0 = $gs0 x 2; #MidiDebug::WrStr($gcd); printf("\n");

if ($p0 && ($msk>> 4&1)) { Edit::Seq($m,  6, $t, [$key%12+60-1*12, $ScS], $scale, "1/4:0", 1.0); }

#'detuned' guitar dummy events across all strings -> force portamento function putting PB entries across all string notes across entire chord
if ($msk>> 4&1) { Edit::Seq($m, 16, $t, 39, 8, "<1/4<:% 1/16<:0 <:1 <:2 <:3 <:4 <:5 ", 1.0*$von, $vof, 0,0,1, 1,1, 1,1, undef, 3, {1=>15, 2=>14, 3=>13, 4=>12, 5=>11}); }

if ($msk>> 4&1) { Edit::Seq($m, 16, $t, 40, 8, "<1/32:%".Edit::PreProc0($gs0, \%Guitar), 1.0*$von, $vof, 0,0,1, 1,1, 1,-4/($m->{-1}{3}*4), $l, 3, {1=>15, 2=>14, 3=>13, 4=>12, 5=>11});
                  Edit::Seq($m, 16, $t, 40, 8, $pu);
                  }

my $Label = ($p0<<0)|($chord<<8)|($inv<<4)|($key%12); my $entry = sprintf("MLabelx%xi", $Label);

Edit::Seq($m, 0, $t, 0, 0, " $entry $B:% MJump-1 ");

return(1*$B); }
#===============================================================================
sub Var1 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = (@_); $msk ^= -1;

my $B = $m->{-1}{5}/$m->{-1}{6};

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

my $ScS = 0; #($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

my $cs0 = $Chord::chords{-1}{0}; if (exists($Chord::chords{$chord}{$inv})) { (undef, $cs0) = ($Chord::chords{$chord}{-2}, $Chord::chords{$chord}{$inv}); }

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($chord != 2) && ($chord != 3)) { $msk &= 0b00000010000000011; $scale = 3; } #unsupported scales -> mask melodic tracks

my ($pd, $pu, $ano, $aso) = ("C$GM::CCx40\_$GM::CCon", "C$GM::CCx40\_$GM::CCoff", "C$GM::CCx7b\_$GM::CCoff", "Cx78_$GM::CCoff");

$Guitar::Tabs{3}{11} = [-1,  2,  4,  4,  3,  2]; my $gdly = '1/64';
my $gcd = Guitar::Chord($scale, $key, 0, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff down (notes up)
my $gcu = Guitar::Chord($scale, $key, 1, ['.5', '.6', '.7', '.8', '.9', '  '], $gdly); #riff up (notes down)
my $gcM = Guitar::Chord($scale, $key, 1, ['  ', '  ', '  ', '  ', '  ', '  ']); #simultaneous
my $gcm = Guitar::Chord($scale, $key, 1, ['.5', '.5', '.5', '.5', '.5', '.5']); #simultaneous

my %Guitar = ('m'=>"$pu b:$gcm", 'M'=>"$pu b:$gcM <:$pd", 'd'=>"$pu b:$gcd", 'u'=>"$pu b:$gcu", 'p'=>$pd, 'P'=>$pu, 'n'=>"$ano b:$pu", 's'=>"$aso b:$pu", 'D'=>"$pd b:$gcd", 'U'=>"$pd b:$gcu");

my ($ps0, $ps1, $bs0, $as0, $cl0, $gs0) = ('', '', '', '', '', '');

#         00000000 01111111 11122222 22222333
#        |12345678|90123456|78901234|56789012|
$gs0 = " |U.......|........|........|........| ";

#$gs0 = $gs0 x 2; #MidiDebug::WrStr($gcd); printf("\n");

if ($msk>> 4&1) { Edit::Seq($m,  6, $t, [$key%12+60-1*12, $ScS], $scale, "1/8:% 1/4:0", 1.0); }

#'detuned' guitar dummy events across all strings -> force portamento function putting PB entries across all string notes across entire chord
if ($msk>> 4&1) { Edit::Seq($m, 16, $t, 39, 8, "<1/4<:% 1/16<:0 <:1 <:2 <:3 <:4 <:5 ", 1.0*$von, $vof, 0,0,1, 1,1, 1,1, undef, 3, {1=>15, 2=>14, 3=>13, 4=>12, 5=>11}); }

if ($msk>> 4&1) { Edit::Seq($m, 16, $t, 40, 8, "<1/32:%".Edit::PreProc0($gs0, \%Guitar), 1.0*$von, $vof, 0,0,1, 1,1, 1,-4/($m->{-1}{3}*4), $l, 3, {1=>15, 2=>14, 3=>13, 4=>12, 5=>11});
                  #Edit::Seq($m, 16, $t, 40, 8, $pu);
                  }

my $Label = ($p0<<0)|($chord<<8)|0x80|($inv<<4)|($key%12); my $entry = sprintf("MLabelx%xi", $Label);

Edit::Seq($m, 0, $t, 0, 0, " $entry $B:% MJump-1 ");

return(1*$B); }
#===============================================================================

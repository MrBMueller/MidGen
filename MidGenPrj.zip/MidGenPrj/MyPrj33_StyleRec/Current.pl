eval("use Tools; use RolandHp302; use Metronome; use playsmf; use StyleTrax; use Cubase;");

use constant { u=>undef, p=>0x01 }; my ($m, $t) = (\%main::out, 0/1);

if ($^O !~ /linux/i) { if ((`tasklist /FI \"IMAGENAME eq cwpa.exe\" 2>&1` =~ /cwpa\.exe/) || (`tasklist /FI \"IMAGENAME eq Cubase.exe\" 2>&1` =~ /Cubase\.exe/)) { printf("sequencer running -> exit\n"); exit(0); }}

%{$m} = (-1=>{0=>$main::OutFile, 1=>1, 3=>u, 4=>u}); %main::trks = ();

my $PhrDir = $main::WrkDir0; if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }

$t += playsmf::main($m, $t, 2/1, undef, "$PhrDir/MyTest0.mid", 0x7fefa189);
#$t += playsmf::main($m, $t, undef, undef, "$PhrDir/polka.mid", 0x7fefa489);
#$t += playsmf::main($m, $t, undef, undef, "$PhrDir/honkytnk.mid", 0x7fefa489);
#$t += playsmf::main($m, $t, undef, undef, "$PhrDir/modcntry.mid", 0x7fefa489);

my $B = $m->{-1}{5}/$m->{-1}{6}; my $FL = $t; my $lt = 1; #(sort {$b <=> $a} keys(%{$m}))[0]+1;

my $rt = $lt+1; #printf("$B $t $lt $rt\n");

#playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 1, 8, 0x7ff08fb0); #rec

#$t += playsmf::main($m, $t, 2/1, 0x300);
#$t += playsmf::main($m, $t, 2/1,     u);
#$t += playsmf::main($m, $t, 2/1, 0x305);
#$t += playsmf::main($m, $t, 2/1, 0x20a);
#$t += playsmf::main($m, $t, 2/1, 0x300);
#$t += playsmf::main($m, $t, 2/1,  0x19);
#$t += playsmf::main($m, $t, 2/1,  0x1a);

StyleTrax::LiveStyle($m, [$FL]     , "$PhrDir/*", 60, $lt  , $rt, \&main::Var0, 0b0, 0,   0);
StyleTrax::LiveStyle($m, [$FL+1/64], "$PhrDir/*", 60, undef, $rt, undef       , 0b0, 0, -12);
StyleTrax::LiveStyle($m, [$FL+2/64], "$PhrDir/*", 60, undef, $rt, undef       , 0b0, 0,  12);
%main::trks = (2=>{-4=>1});

Cubase::Compatibility($m, 1*$B);

goto MyLabelEnd;

my ($L, $R) = ($t-9.5*$B, $t+.5*$B); for (my $i=1; $i<=11; $i++) { $t += Tools::CopyRegion($m, $t+(1/2)*$B, $L, $R-$L, $i-12*($i>6)) + (0/1)*$B; }

Metronome::GenericWoMain($m, 2, 0*$B, 1*$B, .4, u, u, 0, 1, 33, 9); #pre counter (cwpa9 doesnt like 1st beat when saving smf!?)
Metronome::Generic(      $m, 2, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33, 9); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" 2{ $B:%% MLabelx%x <:%%_c0_C$GM::CCx7a\_$GM::CCon } ", 0x18)); #duplicate since Cubase drops last event

#===============================================================================
sub Var0 { my ($m, $t, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0, $p1) = @_;

#MIDI::InsertText($m, 0, $t, 0, sprintf("%d_%d_%d", $chord, $inv, $key), 0x6, " ", -1);

playsmf::main($m, $t, $l, ($chord<<8)|($inv<<4)|($key%12));

return($l); }
#===============================================================================

use Misc; use Tools; use GM2;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>100.00, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord(0, 'C')), 8=>Misc::GetCopyright()}); #general smf output setup (smf type, tempo, time/key signature, etc.)

my $m = \%main::out; my $B = $m->{-1}{5}/$m->{-1}{6}; my $t = 0*$B; # $B : bar/measure length; $t : time starts at zero

my $title = "Ballade pour Adeline"; #define conductor track name (usually score title)

#smf track setup
@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b], #table header - parameter (column) definition
#s   name   port   chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev    # col. description
[1, $title, undef                                                                         ],  # 00 conductor track
[1, "0x00", undef, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.5, 0.5],  # 01 treble
[1, "0x01", undef, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0, -0.5, 0.5]); # 02 bass

$t += 1*$B; #one bar

my $scale = 2; #scale definition (0: chromatic; 2: major; 3: minor)

#intro
      Edit::Seq($m, 1, $t, 60   , $scale, "| 4{1/16:% 4 7 8} | 4{% 4 9 4} |"); #treble
$t += Edit::Seq($m, 2, $t, 60-12, $scale, "| 4{ 1/4:7 }      | 4{.}       |"); #bass

#main part - repeat two times
for (0..1) {
      Edit::Seq($m, 1, $t, 60   , $scale, "| 1/4<:4 9 1/2<:4 9 1/8++<:4 9 1/32<:5 10 | 2{1/4<:5 10} 1/16:% 6{<:5 10} <:6 11 | 1/4<:6 11 1/2<:6 11 1/8+<:6 11 1/8-<:7 12 | 1/1<:4 9                |");
$t += Edit::Seq($m, 2, $t, 60-12, $scale, "| 1/8:0 ^4 3(^5 v5)                       | 1 ^4 3(^5 v5)                        | -3 ^4 ^5 v5 ^5 +1/4:^2                    | 1/8:0 ^4 2(^5 v5) ^5 -3 |");

      Edit::Seq($m, 1, $t, 60   , $scale, "| 2(1/4<:4 ^5) 1/16:% 6(1/16<:4 ^5) 1/16<:5 ^5 | 2(1/4<:5 ^5) 1/16:% 6(1/16<:5 ^5) 1/16<:6 ^5 | 1/4<:6 ^5 1/2<:6 ^5 1/8+<:6 ^5 1/16<:7 ^5 | 1/1<:4 ^5              |");
$t += Edit::Seq($m, 2, $t, 60-12, $scale, "| 1/8:0 ^4 3(^5 v5)                            | 1 ^4 3(^5 v5)                                | -3 ^4 ^5 v5 ^5 +1/4:^2                    | 1/8:0 ^4 2(^5 v5) 0 -1 |");

      Edit::Seq($m, 1, $t, 60   , $scale, "| 1/8:% 1/16<:14 ^2 9 <:13 ^2 9 <:12 ^2 9 1/8:% 1/16<:11 ^2 6 <:#10 ^2 6 <:9 ^2 6 | 1/4<:7 ^5 1/8<:6 ^5 v 1/16:v v5 ^4 v4 ^3 v5 ^2 v2 |");
$t += Edit::Seq($m, 2, $t, 60-12, $scale, "| 1/8:-2 ^4 ^5 v5 1/8:-5 ^4 ^5 v5                                                 | 1/16:-4 ^4 *2:^3 1/16:-3 ^4 *2:^3 1/4:0 /2:. v    |");

      Edit::Seq($m, 1, $t, 60   , $scale, "| 1/16:% 2{2 <:^5 ^2} 2 <:^3 ^2 2 % -1 <:^5 ^2 -1 <:^#4 ^2 -1 <:^3 ^2 -1 | 2/4 1/4<:0 ^5 1/8:v 1/16:v +1/8<:^ <:v4 ^ |");
$t += Edit::Seq($m, 2, $t, 60-12, $scale, "| 1/8:-2 ^4 ^5 v5 1/8:-5 ^4 ^5 v5                                        |     1/16:-4 ^2 ^2 +1/4:^3                 |");

      Edit::Seq($m, 1, $t, 60   , $scale, "| 4/4 1/8:% 1/16:0 ^ % 0 ^ ^2 2{1/32:% 1 ^2 ^} 2{% 3 ^ ^4} | 2{% 8 ^2 ^} 2{% 10 ^ ^4} 2{% 8 ^2 ^} 2{% 13 ^2 ^3} |");
      Edit::Seq($m, 1, $t, 60   , $scale, "|     1/1:%                                                | 1/8:4 . ^4 . 4 . ^7 .                              |");
$t += Edit::Seq($m, 2, $t, 60-12, $scale, "|     1/4:-3 ^7 1/8:. . ^4 .                               | 1/1:%                                              |");
}

#===============================================================================

use strict; use warnings; eval("use Misc; use RolandHp302; use Percussion; use Brainstorm;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

Misc::InsertCopyright(\%main::out);

GS::Reset(\%main::out, 0x00, $s, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x3f, 0x3f); #

my $mv = -0.3; @main::InitParams = (undef, 1/4); $MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames("$main::SrcDir0/DeviceMaps/Hp503Tones0.txt")};

*prg = \&RolandHp302::Patch; my @prg0 = prg(5,4); my @prg1 = prg(1,1);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol      exp   pan  rev  chr    # arr. setup
[1, 'Ctrl', 0x00                                                                                  ],  # 00
[1, '0x00', 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   9), 1.3+$mv, 1.0,  0.0, 0.9, 0.0],  # 01 live
[1, '0x01', 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   1),  .9+$mv, 1.0,  0.0, 0.7, 0.0],  # 02 harmonics/pad
[1, '0x02', 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(2,   6),  .8+$mv, 1.0,  0.0, 0.9, 0.0],  # 03 bass
[1, '0x03', 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 04 rythm/chords
[1, '0x04', 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05', 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06', 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07', 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08', 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09', 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  47), 1.2+$mv, 1.0,  0.0, 0.8, 0.0],  # 0a percussion
[1, '0x0a', 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b', 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c', 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d', 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e', 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f', 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0]); # 10

my %DrumMap0 = (
# key      key+  dur* vel* vel+  rel* rel+
   -2 => [   -7, -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
   35 => [undef, 1.0, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #BD2
   36 => [undef, 1.0, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .5], #BD1
   38 => [undef, 1.0, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8]  #SD1
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => 1.0, $GM::CCx07 => 1.0});
Misc::InsertInstrumentNames(\%main::out, \@main::trks, \%MidiDebug::Prgs, $s);
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

Edit::Seq($m, 1, undef, undef, undef, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

$s += Edit::Seq($m, 10, undef, undef, undef, $s, 60+2*12-1, 3, " 128(1/8:>_.9 .5 .5 .5 .9 .5 .5 .5) ", .5); goto MyLabelEnd;

eval("use Chord;"); my $c = $Chord::c; my $c1 = $Chord::c4; my $c2 = $Chord::c7;

if (1) { my $v = .7;
Edit::Seq($m, 2, undef, undef, undef, $s+0/1, 60-1-12, 3, " 2(| 1/1:0_$c | 2/1:-1_$c | 1/1:0_$c | 5_$c2 | 1/1:-1_$c | 1/1:4_$c2 |) ", .4);

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " <[1/8:2     1      0] | 1/1:4 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " <[1/8:2     1      0] | 1/4:4 1/8:3 2/1|:. ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " <[1/4:2 1/8:1 1/4:_0] | 1/1:4 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " <[1/4:2 1/8:1 1/4:_0] | 1/1:5 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " <[1/4:2 1/8:1 1/4:_0] | 1/1:3 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " <[1/4:1 1/8:0 1/4:-1] | 1/1:4 ", $v);

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " 1/8:_0     ^     ^ ! 1/1:4 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " 1/8:_0     ^     ^ ! 1/4:4 1/8:3 2/1|:. ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " 1/4:_0 1/8:^ 1/4:^ ! 1/1:4 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " 1/4:_0 1/8:^ 1/4:^ ! 1/1:5 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " 1/4:_0 1/8:^ 1/4:^ ! 1/1:3 ", $v);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-1+12, 3, " 1/4:-1 1/8:^ 1/4:^ ! 1/1:4 ", $v);

Edit::FitLength($m, 1); goto MyLabelEnd; }

#Brainstorm::InsertPhrase(\%main::out, 1, $s+0/1, ".", undef, 1/128, -1/128, 0, undef, 0, 1,0, 0,.5); #rec or play last in current dir

$s += Seq0($m, $s); goto MyLabelEnd;

#===============================================================================
sub Seq0 { my $m = shift(@_); my $s = shift(@_); my $start = $s;

eval("use Style4;");

#$s += Style0::Pause($m, $s, 1/1);

for (1..0) {
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 63, 3, 1.0, "$_", 0, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 71, 2, 1.0, "$_", 2, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 61, 2, 1.0, "$_", 0, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 70, 3, 1.0, "$_", 2, 0);
}

for (1..4) {
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+0, 3, 1.0, "$_", 0, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+5, 3, 1.0, "$_", 1, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+7, 3, 1.0, "$_", 2, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+0, 3, 1.0, "$_", 0, 0);
}

$s += Style0::Var0($m, $s, 1/1,  0, 0b0000000000000000^-1, 60+0, 3, 1.0, "", 0, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000001000000000^-1, 60+0, 3, 1.0, "", 0, 0);

for (1..4) {
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+0, 3, 1.0, "$_", 0, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+5, 3, 1.0, "$_", 1, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+7, 3, 1.0, "$_", 2, 0);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0000, 60+0, 3, 1.0, "$_", 0, 0);
}

return($s-$start); }
#===============================================================================

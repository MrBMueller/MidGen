eval("use GS;");

my $m = \%main::out; use constant { u=>undef };

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.0, 5=>4, 6=>4}); my $b = $m->{-1}{5}/$m->{-1}{6}; my $t = 0*$b; $MIDI::ContCtlRes = 1/32; #general output setup

@main::InitParams = (undef, $t+1/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a],
#s   name         port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, u],  # 00
[1, u],  # 01 right - melody
[1, u],  # 02 left  - harmonics/pad
[1, u],  # 03 bass
[1, u],  # 04 rythm/chords
[1, u],  # 05
[1, u],  # 06
[1, u],  # 07
[1, u],  # 08
[1, u],  # 09
[1, u],  # 0a percussion
[1, u],  # 0b
[1, u],  # 0c
[1, u],  # 0d
[1, u],  # 0e
[1, u],  # 0f
[1, u],  # 10
); #

GS::Reset(\%main::out, 0x00, $t+0/4, 1, 0x00);

#===============================================================================

eval("use Misc; use RolandHp302; use KX; use Percussion; use StyleTrax; use Chord;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>3, 6=>4, 7=>-(1+0x000), 8=>Misc::GetCopyright()}); my $s = 0/1; my $m = \%main::out; #general output setup

GS::Reset(\%main::out, 0x00, $s+0/4, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

$MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames("$main::SrcDir0/DeviceMaps/Hp503Tones0.txt")};

$MidiDebug::Prgs{0x01} = {-1 => 'SF201'};
$MidiDebug::Prgs{0x01}{0xc}{-1}{-1}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2"; # 7.586.050   Sun Mar 18 12:17:00 2001

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00); *prg = \&RolandHp302::Patch;

@main::InitParams = (undef, $s+1/4);

my $PBS = 13; my ($PB0,$PB1,$PB2,$PB3,$PB4,$PB5,$PB6,$PB7,$PB8,$PB9,$PB10,$PB11,$PB12,$PB13) = (0/$PBS,1/$PBS,2/$PBS,3/$PBS,4/$PBS,5/$PBS,6/$PBS,7/$PBS,8/$PBS,9/$PBS,10/$PBS,11/$PBS,12/$PBS,13/$PBS);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl', 0x00                                                                              ],  # 00
[1, '0x00', 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   3),  .8, 1.0,  0.0, 0.9, 0.0],  # 01 live
[1, '0x01', 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(4,   2),  .4, 1.0,  0.0, 0.7, 0.0],  # 02 harmonics/pad
[1, '0x02', 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38,  .6, 1.0,  0.0, 0.9, 0.0, .5, .5],  # 03 bass
[1, '0x03', 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27, 1.0, 1.0,  0.0, 0.0, 0.0],  # 04 rythm/chords
[1, '0x04', 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05', 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06', 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07', 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08', 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09', 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  47), 1.0, 1.0,  0.0, 0.9, 0.0],  # 0a percussion
[1, '0x0a', 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b', 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c', 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d', 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(1,   3),  .9, 1.0,  0.0, 0.9, 0.0],  # 0e
[1, '0x0e', 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  prg(5,  15), 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f', 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   8<<7,   48,  .9, 1.0,  0.0, 0.9, 0.0]); # 10

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .3], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .9], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .8], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => '*1.0+0.0', $GM::CCx07 => '*.5+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs);
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

#$main::trks[15][12+1] = 1.0;

Edit::Seq($m, 1, undef, undef, undef, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,     $main::out{-1}{5}/$main::out{-1}{6}, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128*$main::out{-1}{5}/$main::out{-1}{6}, .2); #main counter

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }
if ($#ARGV >= 1) { $Phr = 'rec'; }

for (1..3) {
 $s += Verse(  $m, $s,  0^0b00000000000000001, $_);
 $s += Refrain($m, $s,  0^0b00000000000000001, $_);
 }

my $v1 = "Ei nen Dra chen bau ich mir aus f�nf Leis ten und Pa pier. Ma le ihm mit Tu sche bunt ei nen rie sen gro ssen Mund.";

my $v2 = "Oh ren hat er wun der sch�n, wie zwei Fl� gel an zu sehn. Auch die Au gen feh len nicht und die Na se im Ge sicht.";

my $v3 = "Hin ten h�ngt ein Schw�n zel dran, dass er bes ser steu ern kann. Und so schwebt er an der Schnur ganz al lein im Blau en nur.";

my $Refrain = "Steig, mein Dra chen, stei ge � ber Baum und Zwei ge, � ber Dorf und Wald und Feld, gr�� von mir die gan ze Welt, die ga an ze Welt.";

Edit::AddLyric($m, 1, " $v1 $Refrain $v2 $Refrain $v3 $Refrain ");

Edit::SubstText($m, '�','ae', '�','AE', '�','oe', '�','OE', '�','ue', '�','UE', '�','ss');

#===============================================================================
sub Verse { my ($m, $s, $mute, $p0) = @_; my $start = $s;

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 65, 2, " | 2/4:% 1/8:-3 -3 | 1/4:0 0 1/8:1 4 | 1/2:2 1/8:1 4 | 1/8:2 0 1/4:1 1 |     1/2:0   "); #

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 65, 2, "         1/8:-3 -3 | 1/4:0 0 1/8:1 4 | 1/2:2 1/8:1 4 | 1/8:2 0 1/4:1 1 | 2/4 1/2:0 | "); #

return($s-$start); }
#===============================================================================
sub Refrain { my ($m, $s, $mute, $p0) = @_; my $start = $s;

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 65, 2, " | 1/8:4 4 5 5 | 1/4:4 2 | 1/8:4 4 5 5 | 1/4:4 2 | 1/8:1 1 4 4 | "); #

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 65, 2, " | 1/8:2 2 1/4:0 | 1/8:1 1 4 4 | 1/8:2 2 0 0 | 1/8:2 3 1/4:1 | 3/4 1/2:0 1/4:% "); #

return($s-$start); }
#===============================================================================


%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); #smf setup (filename, tyle, PPQ)

@main::trks = ([], []); #track setup (initial port, sysex, program, controller, general track attributes)

my $t = 1/1; #time

my $Track = 0;
my $BaseNote = 60; #sequence basenote (0) - middle C

#now the sequence (note: M = optional marker text events; '|' = optional visual bar delimiter w/o interpretation)

$t += Edit::Seq(\%main::out, $Track, $t, $BaseNote, 0, " | MChromatic 1/4:0 1 2 3 | 4 5 6 7 | 8 9 10 11 | ") + 1/1;
$t += Edit::Seq(\%main::out, $Track, $t, $BaseNote, 2, " | MMajor     1/4:0 1 2 3 | 4 5 6 7 |             ") + 1/1;
$t += Edit::Seq(\%main::out, $Track, $t, $BaseNote, 3, " | MMinor     1/4:0 1 2 3 | 4 5 6 7 |             ") + 1/1;

#===============================================================================

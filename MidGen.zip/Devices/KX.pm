use strict; use warnings; use MIDI; use AWE; use SF201; use GM2; package KX;

#regular CC definitions
our $CCx08 = 0x08; #balance

our $CCx47 = 0x47; #resonance (filter Q)       - default 0x00
our $CCx48 = 0x48; #release
our $CCx49 = 0x49; #attack
our $CCx4a = 0x4a; #brightness (filter cutoff) - default 0x7f

#centered CC definitions
our $cCCx08 = 0x20000 | $CCx08;
our $cCCx47 = 0x20000 | $CCx47;
our $cCCx48 = 0x20000 | $CCx48;
our $cCCx49 = 0x20000 | $CCx49;
our $cCCx4a = 0x20000 | $CCx4a;

our $SynthVolume = $GM2::MasterVolume;

return(1);
#===============================================================================
sub SetSynthVolume { return(GM2::MasterVolume(@_)); }
#===============================================================================
sub LoadSoundFonts { my $h0 = shift(@_);
my $device = 0; if ($#_ >= 0) { $device = shift(@_); } if (not defined($device)) { $device = 0; }
my $flags  = 0; if ($#_ >= 0) { $flags  = shift(@_); }

my %LoadList; my %cfg; my %cfg1;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) {
 if (ref($h0->{$k0}) =~ 'HASH') { foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  if (ref($h0->{$k0}{$k1}) =~ 'HASH') { foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if (ref($h0->{$k0}{$k1}{$k2}) =~ 'HASH') { foreach my $k3 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}{$k2}}) {
	if ((exists($h0->{$k0}{$k1}{$k2}{$k3}{-1})) && (ref($h0->{$k0}{$k1}{$k2}{$k3}{-1}) !~ 'HASH') && ($h0->{$k0}{$k1}{$k2}{$k3}{-1} =~ /.sf2$/i)) {
     $LoadList{$k3} = $h0->{$k0}{$k1}{$k2}{$k3}{-1}; $LoadList{$k3} =~ s/\\/\//g; $cfg{scalar(keys(%cfg))} = $LoadList{$k3}; $cfg1{$k2} = $LoadList{$k3};
	 }
    }}
   }}
  }}
 }

my @MyAttrs0 = stat("/sdcard/TimidityAE/timidity/timidity.cfg"); my $MySize0 = -1; if ($#MyAttrs0 >= 0) { $MySize0 = $MyAttrs0[7]; }
if ($MySize0 >= 0) {
 if ((scalar(keys(%cfg)) <= 0) || not(exists($LoadList{-1})) && not(exists($LoadList{0}))) { printf("KX::LoadSoundFonts() : 0;\n");
  open(my_file0, "/sdcard/TimidityAE/timidity/timidity.cfg"); while (<my_file0>) { chomp($_); $_ =~ s/.*\"(.*)\".*/$1/g; $cfg{0} = $_; last(); } close(my_file0); }
 open(my_file0, ">/sdcard/TimidityAE/timidity/timidity.cfg"); close(my_file0);
 foreach my $i (sort {$a <=> $b} (keys(%cfg))) { my $name = $cfg{$i}; $name =~ s/^[a-z]:/\/sdcard/gi; my @attrs = stat($name);
  my ($lt, $sz) = ("undef", ""); if ($#attrs >= 9) { $lt = localtime($attrs[9]); $sz = PrintDec($attrs[7]); }
  open(my_file0, ">>/sdcard/TimidityAE/timidity/timidity.cfg"); printf(my_file0 "soundfont \"$name\"\n"); close(my_file0);
  printf("%d %-80s %s%s\n", $i, $cfg{$i}, $lt, $sz);
  }
 }

@MyAttrs0 = stat("$main::WrkDir0/sfz.fxp"); $MySize0 = -1; if ($#MyAttrs0 >= 0) { $MySize0 = $MyAttrs0[7]; }
if ($MySize0 == 7800) {
 open(my_file1, "+<$main::WrkDir0/sfz.fxp"); binmode(my_file1); sysseek(my_file1, 0xe20, 0);
 for (my $c = 0x0; $c <= 0xf; $c++) {
  my $n = ""; if (exists($cfg1{-1})) { $n = $cfg1{-1}; } if (exists($cfg1{$c})) { $n = $cfg1{$c}; } $n =~ s/\//\\/g;
  printf(my_file1 $n); printf(my_file1 "\x00" x (0x104-length($n)));
  }
 close(my_file1); }

@MyAttrs0 = stat("$main::WrkDir0/sf2load.exe"); $MySize0 = -1; if ($#MyAttrs0 >= 0) { $MySize0 = $MyAttrs0[7]; } if ($MySize0 <= 0) { return(0); }

if (exists($LoadList{-1})) { if (not(exists($LoadList{0}))) { $LoadList{0} = $LoadList{-1}; } delete($LoadList{-1}); }

my @lines = split("\n", `$main::WrkDir0/sf2load.exe -nt -n $device -L`); my %LoadedList; my $matches = 0; my $err = 0;
for (my $i=0; $i<=$#lines; $i++) {
 if ($lines[$i] =~ /\[\s*(\d+)\s*\]\s*(.*)\(\s*(.*)\s*\)/) { my $Bank = $1; $LoadedList{$Bank}{0} = $3; $LoadedList{$Bank}{1} = $2; $LoadedList{$Bank}{2} = 0; $LoadedList{$Bank}{0} =~ s/\\/\//g; $LoadedList{$Bank}{1} =~ s/\s+$//;
  if ((exists($LoadList{$Bank})) && ($LoadList{$Bank} =~ $LoadedList{$Bank}{0})) { $LoadedList{$Bank}{2}++; $matches++; }
  my @attrs = stat($LoadedList{$Bank}{0}); $LoadedList{$Bank}{3} = localtime($attrs[9]); $LoadedList{$Bank}{4} = PrintDec($attrs[7]);
  } elsif ($lines[$i] =~ /\[\s*(\d+)\s*\]\s*\*(.*)\s+(\d+)/) { my $Bank = $1; } elsif ($lines[$i] =~ /error/i) { $err++; }
 }

foreach my $k (sort {$a <=> $b} keys %LoadedList) { printf("%d %d %-80s %s%s \'%s\'\n", $k, $LoadedList{$k}{2}, $LoadedList{$k}{0}, $LoadedList{$k}{3}, $LoadedList{$k}{4}, $LoadedList{$k}{1}); }

if ((exists($LoadedList{0})) && ($LoadedList{0}{2} == 0)) { delete($LoadedList{0}); } if ($err) { return(0); }

if ((scalar(keys(%LoadList)) != scalar(keys(%LoadedList))) || ($matches != scalar(keys(%LoadList)))) {

 my $ClrBnk0 = ""; if (exists($LoadList{0})) { $ClrBnk0 = " -c 0"; } system("$main::WrkDir0/sf2load.exe -nt -n $device -C$ClrBnk0");

 foreach my $k (sort {$a <=> $b} keys %LoadList) { system(sprintf("$main::WrkDir0/sf2load.exe -nt -n $device %d \"%s\"", $k, $LoadList{$k})); }
 }

if ($flags) { ReadSoundFonts($h0, $device, $flags) } return(0); }
#===============================================================================
sub ReadSoundFonts { my $h0 = shift(@_);
my $device = 0; if ($#_ >= 0) { $device = shift(@_); } if (not defined($device)) { $device = 0; }
my $flags  = 1; if ($#_ >= 0) { $flags  = shift(@_); }

if ($^O =~ /linux/i) { return(0); } my @MyAttrs0 = stat("$main::WrkDir0/sf2load.exe"); my $MySize0 = -1; if ($#MyAttrs0 >= 0) { $MySize0 = $MyAttrs0[7]; } if ($MySize0 <= 0) { return(0); }

my @lines = split("\n", `$main::WrkDir0/sf2load.exe -nt -n $device -L`); my %LoadedList;
for (my $i=0; $i<=$#lines; $i++) {
 if     ($lines[$i] =~ /\[\s*(\d+)\s*\]\s*(.*)\(\s*(.*)\s*\)/) { my $Bank = $1; $LoadedList{$Bank}{0} = $3; $LoadedList{$Bank}{1} = $2; $LoadedList{$Bank}{0} =~ s/\\/\//g; $LoadedList{$Bank}{1} =~ s/\s+$//;
  my @attrs = stat($LoadedList{$Bank}{0}); $LoadedList{$Bank}{3} = localtime($attrs[9]); }
  elsif ($lines[$i] =~ /\[\s*(\d+)\s*\]\s*\*(.*)\s+(\d+)/    ) { my $Bank = $1; $LoadedList{$Bank}{0} = $2; $LoadedList{$Bank}{1} = sprintf("%s %d", $2, $Bank); $LoadedList{$Bank}{3} = ""; }
 }

foreach my $k (sort {$a <=> $b} keys %LoadedList) { if ($flags & 2) { printf("\n"); }
 if (($flags & 0x05) == 0x05) { $h0->{$device}{0xc}{-1}{$k}{-1} = ""; }
 if (($flags & 0x09) == 0x09) { if (length($h0->{$device}{0xc}{-1}{$k}{-1})) { $h0->{$device}{0xc}{-1}{$k}{-1} .= "/"; } $h0->{$device}{0xc}{-1}{$k}{-1} .= $LoadedList{$k}{0}; }
 if (($flags & 0x11) == 0x11) { if (length($h0->{$device}{0xc}{-1}{$k}{-1})) { $h0->{$device}{0xc}{-1}{$k}{-1} .= "/"; } $h0->{$device}{0xc}{-1}{$k}{-1} .= $LoadedList{$k}{3}; }
 if (($flags & 0x21) == 0x21) { if (length($h0->{$device}{0xc}{-1}{$k}{-1})) { $h0->{$device}{0xc}{-1}{$k}{-1} .= "/"; } $h0->{$device}{0xc}{-1}{$k}{-1} .= $LoadedList{$k}{1}; }
 my @lines = split("\n", `$main::WrkDir0/sf2load.exe -nt -n $device -p $k`);
 for (my $i=0; $i<=$#lines; $i++) {
  if ($lines[$i] =~ /\[\s*(\d+)\s*\]\s*(.*)\s*/) { my $PNum = $1; my $PName = $2; $PName =~ s/[\x00-\x1f,\x7f-\xff]//g; $PName =~ s/\s+$//;
   if ($flags & 1) { $h0->{$device}{0xc}{-1}{$k}{$PNum} = $PName; }
   if ($flags & 2) { printf("%3d %-80s %-24s \'%-20s\' %3d '%-20s'\n", $k, $LoadedList{$k}{0}, $LoadedList{$k}{3}, $LoadedList{$k}{1}, $PNum, $PName); }
   }
  }
 }

return(0); }
#===============================================================================
sub GetFileNames {
my $dir0 = "."; if ($#_ >= 0) { $dir0 = shift(@_); }
my $flt0 = "";  if ($#_ >= 0) { $flt0 = shift(@_); }

opendir(my_dir0, $dir0);
foreach my $fname0 (readdir(my_dir0)) { my @attrs = stat("$dir0/$fname0"); if (($#attrs < 0) || ($fname0 =~ /^\.$/) || ($fname0 =~ /^\.\.$/)) { next; } my $mtime = localtime($attrs[9]);

 if (($attrs[2] & 0x8000) > 0) {
  if ($fname0 =~ /$flt0$/gi) { my $str = sprintf("\$MidiDebug::Prgs{0x00}{0xc}{-1}{\$Bank}{-1} = \"$dir0/$fname0\";");
   my $fill = 150 - length($str); $str .= " " x $fill;

   printf("$str#%s   $mtime\n", PrintDec($attrs[7]));
   }
  }
  else { printf("\n"); GetFileNames("$dir0/$fname0", $flt0); }

 }
#closedir(my_dir0);
return(0); }
#===============================================================================
sub PrintDec { my $v = shift(@_);

my $f = "%3d";
my $m = "    "; if (int($v/1000000)) { $m = sprintf("$f.", int($v/1000000)     ); $f = "%03d"; }
my $k = "    "; if (int($v/   1000)) { $k = sprintf("$f.", int($v/   1000)%1000); $f = "%03d"; }

return(sprintf("$m$k$f", $v%1000)); }
#===============================================================================

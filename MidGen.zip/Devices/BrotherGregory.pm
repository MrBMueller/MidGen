use strict; use warnings; package BrotherGregory;

#regular CC definitions
our $CCx01 =  0x01; #vibrato
our $CCx05 =  0x05; #portamento (glide speed -      lower left  knob)
our $CCx07 =  0x07; #volume
our $CCx0b =  0x0b; #pitch      (Tonhoehe    - horizontal pad slider)
our $CCx0c =  0x0c; #delay                            (bottom slider)
our $CCx0d =  0x0d; #head size  (Stimmlage   -      lower right knob)

#pith bend
our $PB    = 0x104; #vowel      (Klangfarbe  - vertical   pad slider)

#centered definitions
our $cPB = 0x20000 | $PB;

return(1);
#===============================================================================

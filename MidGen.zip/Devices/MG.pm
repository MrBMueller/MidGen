use strict; use warnings; package MG;

#not a real device, but defines MidGen specific values

#init header columns
our $m1  =  -1; #status (0 mute, 1 default/normal, 2 solo)
our $m2  =  -2; #name
our $m3  =  -3; #port
our $m4  =  -4; #chn
our $m5  =  -5; #bank
our $m6  =  -6; #prg
our $m7  =  -7; #key+ (  0)
our $m8  =  -8; #vel+ (0.0)
our $m9  =  -9; #vel* (1.0)
our $m10 = -10; #rel+ (0.0)
our $m11 = -11; #rel* (1.0)
our $m12 = -12; #dur* (1.0)
our $m13 = -13; #instrument name

return(1);
#===============================================================================

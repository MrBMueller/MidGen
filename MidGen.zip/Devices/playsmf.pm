use strict; use warnings; use MIDI; package playsmf;

our @DefArgs = (0, 0, -1, 0, 0, -1, -1, 0, 0x0ff, 0x00008000, 0x15, 0x16); our @args = @DefArgs;

our ($Sync, $EntryLabel, $ExitLabel, $SyncNum) = ($args[9], $args[10], $args[11], 0);

our ($f, $PPQ) = ('', undef);
our (%test1, %Labels, %IntLabels, @Labels, %LabelsR, @k1s, %t2i) = ((), (), (), (), (), (), ());

our ($ReturnLabel0, $ReturnLabel1) = ($EntryLabel, $EntryLabel);

our ($FirstLabel, $LastLabel) = (undef, undef);

our %Pending;
our $i = 0;

our %ChordTypes = (
0x120 => [0], #plain

0x100 => [0,   7], 0x110 => [0, -5], #quint (perfect 5th)

0x200 => [0,   4,   7], 0x220 => [0,   4,  -5], 0x210 => [0,  -8,  -5], #major
0x300 => [0,   3,   7], 0x320 => [0,   3,  -5], 0x310 => [0,  -9,  -5], #minor

0x400 => [0,   2,   7], 0x420 => [0,   2,  -5], 0x410 => [0, -10,  -5], #sus2/4
0x500 => [0,   3,   6], 0x520 => [0,   3,  -6], 0x510 => [0,  -9,  -6], #diminished
0x600 => [0,   4,   8], 0x620 => [0,   4,  -4], 0x610 => [0,  -8,  -4], #augmented

0x700 => [0,   4,   7,  11], 0x730 => [0,   4,   7,  -1], 0x720 => [0,   4,  -5,  -1], 0x710 => [0,  -8,  -5,  -1], #maj7
0x800 => [0,   3,   7,  10], 0x830 => [0,   3,   7,  -2], 0x820 => [0,   3,  -5,  -2], 0x810 => [0,  -9,  -5,  -2], #m7
0x900 => [0,   4,   7,  10], 0x930 => [0,   4,   7,  -2], 0x920 => [0,   4,  -5,  -2], 0x910 => [0,  -8,  -5,  -2], #7
0xa00 => [0,   3,   7,  11], 0xa30 => [0,   3,   7,  -1], 0xa20 => [0,   3,  -5,  -1], 0xa10 => [0,  -9,  -5,  -1], #mmaj7
);

return(1);
#===============================================================================
sub OverrideCmdLineArgs { my ($m, $t, $s, $ep) = (shift(@_), shift(@_), shift(@_), shift(@_)); if ($#_ < 0) { push(@_, 0); }

my @as = (); foreach (@_) { push(@as, ($_>>24)&0xff); push(@as, ($_>>16)&0xff); push(@as, ($_>>8)&0xff); push(@as, ($_>>0)&0xff); }

MIDI::InsertGeneric($m, $t, $s, $ep, 0xff, 0x7f, 0x00, 0x2b, 0x4d, 0x00, @as);

return(0); }
#==============================================================================#
sub OverrideCutCmdLineArgs { if ($#_ > 3 && $_[4] != -1) { playsmf::OverrideCmdLineArgs($_[0], $_[1], $_[2], $_[3], $_[4]); } return(playsmf::OverrideCmdLineArgs(@_)); }
#==============================================================================#
sub FillCtrlMap { my $m = shift(@_);

my $t  =     0; if ($#_ >= 0) { $t  = shift(@_); }
my $s  =     0; if ($#_ >= 0) { $s  = shift(@_); }
my $ep =     1; if ($#_ >= 0) { $ep = shift(@_); }

my $M  =     0; if ($#_ >= 0) { $M  = shift(@_); }
my $T  = undef; if ($#_ >= 0) { $T  = shift(@_); } if (not(defined($T))) { $T = 0x3fff; }

my $se =   0xb; if ($#_ >= 0) { $se = shift(@_); }
my $sc = undef; if ($#_ >= 0 && $se == 0xb) { $sc = shift(@_); } my @sc = ($sc); if (not(defined($sc))) { @sc = (0x00); if ($se == 0xb) { @sc = (0x40, 0x42, 0x43); }}
my $sl =  0x00; if ($#_ >= 0) { $sl = shift(@_); }
my $sh =  0x7f; if ($#_ >= 0) { $sh = shift(@_); }

my $te =   0x0; if ($#_ >= 0) { $te = shift(@_); }
my $tc =  0x00; if ($#_ >= 0 && $te == 0xb) { $tc = shift(@_); }
my $tl =  0x00; if ($#_ >= 0) { $tl = shift(@_); }
my $th =  0x00; if ($#_ >= 0) { $th = shift(@_); }

foreach my $sc (@sc) {

                             my $a = $T<<17 | ($se & 7)<<14 | $sl<<7 | $sc; my $b = $T<<17 | ($se & 7)<<14 | $sh<<7 | $sc; my $c = 0x1<<7;
if ($se == 0xc || $se == 0xe) { $a = $T<<17 | ($se & 7)<<14 | $sl<<0 | $sc;    $b = $T<<17 | ($se & 7)<<14 | $sh<<0 | $sc;    $c = 0x1<<0; }

my $d = $tc<<24 | $te<<20 | $tl;
my $e =                     $th;

if ($te > 0xf) { $d = $te>>8 | ($te<<16)&0xff0000; $e = $d; }

#printf("%08x %08x %08x %08x %08x\n", $a, $b, $c, $d, $e);

my @a = ($a, $b, $c, $d, $e);

my @as = (); foreach (@a) { push(@as, ($_>>24)&0xff); push(@as, ($_>>16)&0xff); push(@as, ($_>>8)&0xff); push(@as, ($_>>0)&0xff); }

foreach (@_) { push(@as, $_); }

MIDI::InsertGeneric($m, $t, $s, $ep, 0xff, 0x7f, 0x00, 0x2b, 0x4d, 0x01+$M, @as);
}

return(0); }
#===============================================================================
sub OverrideDefDev { my ($m, $t, $s, $ep, $p, $d) = (shift(@_), shift(@_), shift(@_), shift(@_), 0, ""); if ($#_ >= 0) { $p = shift(@_); } if ($#_ >= 0) { $d = shift(@_); }

my @tmp0 = split('', $d); my @a = (); for (my $i=0; $i<=$#tmp0; $i++) { push(@a, ord($tmp0[$i])); }

MIDI::InsertGeneric($m, $t, $s, $ep, 0xff, 0x7f, 0x00, 0x2b, 0x4d, 0x04+$p, @a);

return(0); }
#==============================================================================#
sub PreProc { my ($m) = @_; my ($t0, $t1) = (undef, undef); my %marker;

foreach my $k0 (sort {$a <=> $b} keys %{$m}) { if ($k0 == -1) { next(); } if (not(defined($t0))) { $t0 = $k0; } if (not(defined($t1)) || $k0 > $t1) { $t1 = $k0; }
 foreach my $k1 (sort {$a <=> $b} keys %{$m->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$m->{$k0}{$k1}}) {
   if ($m->{$k0}{$k1}{$k2}{0} == 0xff && $m->{$k0}{$k1}{$k2}{1} == 0x06) { my $i = 2; while (exists($m->{$k0}{$k1}{$k2}{$i})) { $marker{$k1} .= chr($m->{$k0}{$k1}{$k2}{$i++}); }}
   if ($m->{$k0}{$k1}{$k2}{0} == 0xff && $m->{$k0}{$k1}{$k2}{1} == 0x09 && scalar(keys(%{$m->{$k0}{$k1}}))<=1) { MIDI::InsEvent($m, $k0, $k1, 0, 1, {0=>0xf7, 1=>0xf4, 2=>0x12, 3=>0x34}); }
   if ($m->{$k0}{$k1}{$k2}{0} == 0xff && $m->{$k0}{$k1}{$k2}{1} == 0x21 && scalar(keys(%{$m->{$k0}{$k1}}))<=1) { MIDI::InsEvent($m, $k0, $k1, 0, 1, {0=>0xf7, 1=>0xf4, 2=>0x12, 3=>0x34}); }
   }
  }
 }

foreach my $k1 (sort {$a <=> $b} keys(%marker)) {
 if ($marker{$k1} =~ /Jump.*Jump/       ) { MIDI::InsEvent($m, $t0  , $k1, 0, 0, {0=>0xf7, 1=>0xf4, 2=>0x12, 3=>0x34}); }
 if ($marker{$k1} =~ /Label.*Jump-[123]/) { MIDI::InsEvent($m, $t1+1, $k1, 0, 1, {0=>0xf7, 1=>0xf4, 2=>0x12, 3=>0x34}); }
 }

return(0); }
#===============================================================================
sub IntLabel { my ($i) = @_; my $z = 0; $i &= 0xfff;

for (my $b = 0x00; $b <= 0x80; $b += 0x80) { if ($i >= ($b|0x00) && $i <= ($b|0x7f)) { $z |= 1; }

 for (my $a = 0x100; $a <= 0x100; $a += 0x100) { for (my $c = 0x00; $c <= 0x10; $c += 0x10) { if ($i >= ($a|$b|$c|0x0) && $i <= ($a|$b|$c|0xb)) { $z |= 1; }}}
 for (my $a = 0x120; $a <= 0x120; $a += 0x100) { for (my $c = 0x00; $c <= 0x00; $c += 0x10) { if ($i >= ($a|$b|$c|0x0) && $i <= ($a|$b|$c|0xb)) { $z |= 1; }}}
 for (my $a = 0x100; $a <= 0x600; $a += 0x100) { for (my $c = 0x00; $c <= 0x20; $c += 0x10) { if ($i >= ($a|$b|$c|0x0) && $i <= ($a|$b|$c|0xb)) { $z |= 1; }}}
 for (my $a = 0x700; $a <= 0xa00; $a += 0x100) { for (my $c = 0x00; $c <= 0x30; $c += 0x10) { if ($i >= ($a|$b|$c|0x0) && $i <= ($a|$b|$c|0xb)) { $z |= 1; }}}
 }

return($z); }
#===============================================================================
sub MidiFile_load { my ($m, $f) = @_; if (not(defined($f))) { return(0); } my %test0 = (); if (ref($f) =~ /HASH/) { %test0 = %{$f}; $f = $test0{-1}{0}; } else { printf("playsmf::MidiFile_load(\"$f\");\n"); %test0 = MIDI::Read($f); }

foreach my $i (2..$#_) { if (defined($_[$i])) { $playsmf::args[7+$i] = $_[$i]; }}

($playsmf::f, $playsmf::PPQ) = ($f, undef);
(%playsmf::test1, %playsmf::Labels, %playsmf::IntLabels, @playsmf::Labels, %playsmf::LabelsR, @playsmf::k1s, %playsmf::t2i) = ((), (), (), (), (), (), ());

$playsmf::PPQ = $test0{-1}{3};

if  (not(exists($m->{-1}{3})) || not(defined($m->{-1}{3})))                           { $m->{-1}{3} = $test0{-1}{3}; }
if ((not(exists($m->{-1}{4})) || not(defined($m->{-1}{4}))) && exists($test0{-1}{4})) { $m->{-1}{4} = $test0{-1}{4}; }
if ((not(exists($m->{-1}{5})) || not(defined($m->{-1}{5}))) && exists($test0{-1}{5})) { $m->{-1}{5} = $test0{-1}{5}; }
if ((not(exists($m->{-1}{6})) || not(defined($m->{-1}{6}))) && exists($test0{-1}{6})) { $m->{-1}{6} = $test0{-1}{6}; }

if (($test0{-1}{3} != $m->{-1}{3}) || exists($test0{-1}{4}) && $test0{-1}{4} != $m->{-1}{4}) { Edit::QuantizeTrk(\%test0, undef, 0, 0, 0, $m->{-1}{4}/$test0{-1}{4}, $m->{-1}{3}); }

foreach my $k0 (sort {$a <=> $b} keys(%test0)) { if ($k0 == -1) { next(); }
 foreach my $k1 (sort {$a <=> $b} keys(%{$test0{$k0}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$test0{$k0}{$k1}})) { my %e = %{$test0{$k0}{$k1}{$k2}}; my $L = scalar(keys(%e));
   if ($e{0} == 0xff) { $L--;
    if ($e{1} == 0x06) { my ($txt, $i) = ('', 2); while (exists($e{$i})) { $txt .= chr($e{$i++}); }
     while ($txt =~ /Label\s*(0x[0-9a-fA-F]*|[-0-9]*)/gi) { my $v = eval($1); if (length($1) <= 0) { $v = -1; } if ($v >= 0 && ($v&0xfff) != 0xfff) { $playsmf::Labels{$v} = $k1; }}
     }
    if ($e{1} == 0x7f) { $L--;
     if ($L >= 8 && ($e{2}<<24 | $e{3}<<16 | $e{4}<<8 | $e{5}) == 0x002b4d00) { my $A = $e{6}<<24 | $e{7}<<16 | $e{8}<<8 | $e{9}; $A = $A>>31?-($A^0xffffffff)-1:$A; my $s = $#playsmf::args+1;
      if ($A < 0) { $A += $s+1; } if ($A > $s) { $A = $s; } my $t = $A+(($L-8)>>2); if ($t < $#playsmf::DefArgs+1) { $t = $#playsmf::DefArgs+1; } if ($L <= 8) { $#playsmf::args = $t-1; }
      for (my $t=8; ($t+3)<$L; $t += 4) { my $D = $e{$t+2}<<24 | $e{$t+3}<<16 | $e{$t+4}<<8 | $e{$t+5}; $D = $D>>31?-($D^0xffffffff)-1:$D; if ($A >= 0) { $playsmf::args[$A] = $D; } $A++; }
      }
     }
    }
   %{$playsmf::test1{$k1}{$k0}} = %{$test0{$k0}{$k1}};
   }
  }
 }

$playsmf::Sync = $playsmf::args[9]; $playsmf::EntryLabel = $playsmf::args[10]; $playsmf::ExitLabel = $playsmf::args[11];

my $Entry = (sort {$a <=> $b} keys(%playsmf::test1))[0]; my $Exit = (sort {$b <=> $a} keys(%playsmf::test1))[0];

my %PILs = (); my $PrevJump = $Entry; my $LatestInt = $Entry; my $LatestJump = $Entry;

my $PJs = 0; my %PLs = ();
foreach my $k1 (sort {$a <=> $b} keys(%playsmf::test1)) {
 foreach my $k0 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}{$k0}})) {

   if (($playsmf::test1{$k1}{$k0}{$k2}{0} == 0xff) && ($playsmf::test1{$k1}{$k0}{$k2}{1} == 0x06)) { my ($txt, $i) = ('', 2); while (exists($playsmf::test1{$k1}{$k0}{$k2}{$i})) { $txt .= chr($playsmf::test1{$k1}{$k0}{$k2}{$i++}); }

	while ($txt =~ /(Label|Jump)\s*(0x[0-9a-fA-F]*|[-0-9]*)([ir]*)/gi) { my ($KW, $v, $flags) = ($1, eval($2), $3); if (length($2) <= 0) { if ($KW =~ /Label/) { $v = -1; } else { $v = -4; }}

	 if ($KW =~ /Label/) {

	  if ($v >= 0 && IntLabel($v)) {
	   if ($k1 != $LatestInt) { foreach (sort {$a <=> $b} keys(%PILs)) { $playsmf::IntLabels{$_} = [$PrevJump, $LatestInt, $LatestJump, $k1, $PILs{$_}]; } %PILs = (); $PrevJump = $LatestJump; }
       $PILs{$v} = $flags; $LatestInt = $k1;
       }

	   if ($v < 0 || ($v & 0xfff) == 0xfff) { $v = (defined($playsmf::LastLabel)?$playsmf::LastLabel:0) & ~0xfff | $v & 0xfff;
       while ($v & 0xfff && (exists($playsmf::Labels{$v}) || IntLabel($v))) { $v--; } if (exists($playsmf::Labels{$v}) || IntLabel($v)) { printf("warning: autolabel overflow!\n"); }}
       $playsmf::Labels{$v} = $k1; if (($#Labels < 0) || ($k1 > $playsmf::Labels{$Labels[$#Labels]})) { push(@Labels, $v); } if ($PJs) { $PJs = 0; %PLs = (); } $PLs{$v}++; $playsmf::LastLabel = $v;
       }
	  else { if ($v <= -4) { $v = $Labels[$#Labels-(-1*$v-4)]; } $playsmf::test1{$k1}{-1}{1} = $v; foreach (sort {$a <=> $b} keys(%PLs)) { $playsmf::LabelsR{$_} = $v; } $PJs++; $LatestJump = $k1; }

	 }
	}

   if (not(defined($playsmf::FirstLabel))) { $playsmf::FirstLabel = $playsmf::LastLabel; }

   if ((($playsmf::test1{$k1}{$k0}{$k2}{0} & ($playsmf::args[9] >> 16)) == ($playsmf::args[9] & 0xff)) && (($playsmf::test1{$k1}{$k0}{$k2}{1} & ($playsmf::args[9] >> 24)) == ($playsmf::args[9]>>8 & 0x7f))) { $SyncNum++;
    if (not(exists($playsmf::test1{$k1}{-1}{1}))) { $playsmf::test1{$k1}{-1}{1} = -9; }
	if (($playsmf::args[9] & 0x8000) <= 0) { delete($playsmf::test1{$k1}{$k0}{$k2}); if (scalar(keys(%{$playsmf::test1{$k1}{$k0}})) <= 0) { delete($playsmf::test1{$k1}{$k0}); }}
	}

   if ((($playsmf::test1{$k1}{$k0}{$k2}{0} >> 4) == 0x9) && (($k1 + $playsmf::test1{$k1}{$k0}{$k2}{3}) > $Exit)) { $Exit = $k1 + $playsmf::test1{$k1}{$k0}{$k2}{3}; }
   }
  }
 $playsmf::test1{$k1}{-1}{0} = $playsmf::args[10]; if ($#Labels >= 0) { $playsmf::test1{$k1}{-1}{0} = $Labels[$#Labels]; }
 }

foreach (sort {$a <=> $b} keys(%PILs)) { if ($LatestJump < $LatestInt) { $LatestJump = $LatestInt; if ($LatestJump < $Exit) { $LatestJump = $Exit; }} $playsmf::IntLabels{$_} = [$PrevJump, $LatestInt, $LatestJump, $Exit, $PILs{$_}]; }

if (not(defined($playsmf::FirstLabel))) { $playsmf::FirstLabel = $playsmf::args[10]; } if (not(defined($playsmf::LastLabel))) { $playsmf::LastLabel = $playsmf::args[11]; }

$playsmf::Labels{$playsmf::args[10]} = $Entry; $playsmf::Labels{$playsmf::args[11]} = $Exit+1;

foreach my $l (sort {$a <=> $b} keys(%playsmf::Labels)) { if (not(exists($playsmf::LabelsR{$l}))) { $playsmf::LabelsR{$l} = 0; }}

my $LabelNum = (sort {$b <=> $a} keys(%playsmf::Labels))[0]+1; if ((($LabelNum-1) & 0xfff) >= 0x100) { $LabelNum = ($LabelNum-1) | 0xfff; }

for (my $i=0; $i<$LabelNum; $i++) { my $j = ($i>>8)&0xf; my $k = ($i>>4)&0x3; my $l = $i&0xf;
 if ($j >= 1 && $j <= 0xa && $l >= 1 && $l <= 0xb && !exists($playsmf::Labels{$i}) && exists($playsmf::Labels{$i&~0xf})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0xf}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0xf}; }
 }

for (my $i=0; $i<$LabelNum; $i++) { my $j = ($i>>8)&0xf; my $k = ($i>>4)&0x3; my $l = $i&0xf;
 if     ($j >= 1 && $j <=   1 && $k >= 1 && $k <= 1 && !exists($playsmf::Labels{$i}) && exists($playsmf::Labels{$i&~0x30})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0x30}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0x30}; }
  elsif ($j >= 2 && $j <= 0xa && $k >= 1 && $k <= 3 && !exists($playsmf::Labels{$i}) && exists($playsmf::Labels{$i&~0x30})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0x30}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0x30}; }
 }

for (my $i=0; $i<$LabelNum; $i++) { my $j = ($i>>8)&0xf; my $k = ($i>>4)&0x3; my $l = $i&0xf;
 if     (($j == 0x3 || $j == 0x4 || $j == 0x6 || $j == 0x7 || $j == 0x9) && !exists($playsmf::Labels{$i}) && exists($playsmf::Labels{$i&~0xf00|0x200})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0xf00|0x200}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0xf00|0x200}; }
  elsif (($j == 0x2 || $j == 0x5              || $j == 0x8 || $j == 0xa) && !exists($playsmf::Labels{$i}) && exists($playsmf::Labels{$i&~0xf00|0x300})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0xf00|0x300}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0xf00|0x300}; }
 }

for (my $i=0; $i<$LabelNum ; $i++) { if (!exists($playsmf::Labels{$i}) && exists($playsmf::Labels{$i&0xfff})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&0xfff}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&0xfff}; }}

@playsmf::k1s = sort {$a <=> $b} keys(%playsmf::test1); for (my $i=0; $i<=$#playsmf::k1s; $i++) { $playsmf::t2i{$playsmf::k1s[$i]} = $i; } $playsmf::t2i{$playsmf::Labels{$playsmf::ExitLabel}} = $#playsmf::k1s+1; %playsmf::Pending = (); $playsmf::i = 0;

return(0); }
#===============================================================================
sub main { my ($m, $t, $Length, $Label, $f) = (shift(@_), shift(@_), shift(@_), shift(@_), shift(@_)); playsmf::MidiFile_load($m, $f, @_);

$t *= $m->{-1}{3}*4; if (defined($Length)) { $Length *= $playsmf::PPQ*4; }

if (defined($Label)) { if (exists($playsmf::LabelsR{$Label})) { if ($playsmf::LabelsR{$Label} >= 0) { $ReturnLabel1 = $ReturnLabel0 = $Label; } else { $ReturnLabel1 = $playsmf::test1{$playsmf::k1s[$i]}{-1}{0}; }} else { $Label = undef; }}

my ($k1, $k1d, $md) = (undef, 0, 0);

while ($i <= $#playsmf::k1s) { if (defined($k1) && ($playsmf::k1s[$i] > $k1)) { $k1d += $playsmf::k1s[$i]-$k1; } if (defined($Length) && ($Length >= 0) && ($k1d >= $Length)) { last(); } $k1 = $playsmf::k1s[$i]; my $k1c = $t+$k1d;

 if (defined($Length) && exists($playsmf::test1{$k1}{-1}{1})) {

  if     (defined($Label))                   { $i = $playsmf::t2i{$playsmf::Labels{$Label}}; $Label = undef;      foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #IRQ
   elsif ($playsmf::test1{$k1}{-1}{1} >=  0) { $i = $playsmf::t2i{$playsmf::Labels{$playsmf::test1{$k1}{-1}{1}}}; foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #jmp
   elsif ($playsmf::test1{$k1}{-1}{1} >= -1) { $i = $playsmf::t2i{$playsmf::Labels{$ReturnLabel1}};               foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #ret0
   elsif ($playsmf::test1{$k1}{-1}{1} >= -3) { $i = $playsmf::t2i{$playsmf::Labels{$ReturnLabel0}};               foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #ret1
  }

 foreach my $k0 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}})) { if ($k0 == -1) { next(); }
  foreach my $k2 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}{$k0}})) {
   my $k0c = $k0; if (($playsmf::test1{$k1}{$k0}{$k2}{0} == 0xff) && ($playsmf::test1{$k1}{$k0}{$k2}{1} == 0x06)) { $k0c = 0; }
   my $k2c = 0; if (scalar(keys(%{$m->{$k0c}{$k1c}}))) { $k2c = (sort {$b <=> $a} keys(%{$m->{$k0c}{$k1c}}))[0]+1; }
   %{$m->{$k0c}{$k1c}{$k2c}} = %{$playsmf::test1{$k1}{$k0}{$k2}};
   if (($m->{$k0c}{$k1c}{$k2c}{0} >> 4) == 0x9) { $Pending{$k0c<<11 | ($m->{$k0c}{$k1c}{$k2c}{0} & 0xf)<<7 | $m->{$k0c}{$k1c}{$k2c}{1}} = [$k1c, $k2c]; if ($k1d + $m->{$k0c}{$k1c}{$k2c}{3} > $md) { $md = $k1d + $m->{$k0c}{$k1c}{$k2c}{3}; }}
   }
  }
 $i++;
 }

if (not(defined($Length)) && $md > $k1d) { $k1d = $md; } return($k1d/($playsmf::PPQ*4)); }
#===============================================================================

use strict; use warnings; use MIDI; package playsmf;

our ($Sync, $EntryLabel, $ExitLabel) = (0x7fefa189, 0x15, 0x16);

our ($f, $PPQ) = ('', undef);
our (%test1, %Labels, @Labels, %LabelsR, @k1s, %t2i) = ((), (), (), (), (), ());

our ($ReturnLabel0, $ReturnLabel1) = ($EntryLabel, $EntryLabel);

our ($FirstLabel, $LastLabel) = (undef, undef);

our %Pending;
our $i = 0;

our %ChordTypes = (
0x120 => [0], #plain

0x100 => [0,   7], 0x110 => [0, -5], #quint (perfect 5th)

0x200 => [0,   4,   7], 0x210 => [0,   4,  -5], 0x220 => [0,  -8,  -5], #major
0x300 => [0,   3,   7], 0x310 => [0,   3,  -5], 0x320 => [0,  -9,  -5], #minor

0x400 => [0,   2,   7], 0x410 => [0,   2,  -5], 0x420 => [0, -10,  -5], #sus2/4
0x500 => [0,   3,   6], 0x510 => [0,   3,  -6], 0x520 => [0,  -9,  -6], #diminished
0x600 => [0,   4,   8], 0x610 => [0,   4,  -4], 0x620 => [0,  -8,  -4], #augmented

0x700 => [0,   4,   7,  11], 0x730 => [0,   4,   7,  -1], 0x710 => [0,   4,  -5,  -1], 0x720 => [0,  -8,  -5,  -1], #maj7
0x800 => [0,   3,   7,  10], 0x830 => [0,   3,   7,  -2], 0x810 => [0,   3,  -5,  -2], 0x820 => [0,  -9,  -5,  -2], #m7
0x900 => [0,   4,   7,  10], 0x930 => [0,   4,   7,  -2], 0x910 => [0,   4,  -5,  -2], 0x920 => [0,  -8,  -5,  -2], #7
0xa00 => [0,   3,   7,  11], 0xa30 => [0,   3,   7,  -1], 0xa10 => [0,   3,  -5,  -1], 0xa20 => [0,  -9,  -5,  -1], #mmaj7
);

return(1);
#===============================================================================
sub OverrideCmdLineArgs { my ($m, $t, $s, $ep) = (shift(@_), shift(@_), shift(@_), shift(@_));

my @as = (); foreach (@_) { push(@as, ($_>>24)&0xff); push(@as, ($_>>16)&0xff); push(@as, ($_>>8)&0xff); push(@as, ($_>>0)&0xff); }

MIDI::InsertGeneric($m, $t, $s, $ep, 0xff, 0x7f, 0x00, 0x2b, 0x4d, 0x00, @as);

return(0); }
#===============================================================================
sub PreProc { my ($m) = @_; my $t0 = undef; my $t1 = (sort {$b <=> $a} keys(%{$m}))[0]+1; my %marker;

foreach my $k0 (sort {$a <=> $b} keys %{$m}) { if ($k0 == -1) { next(); }
 foreach my $k1 (sort {$a <=> $b} keys %{$m->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$m->{$k0}{$k1}}) {
   if (($m->{$k0}{$k1}{$k2}{0} == 0xff) && ($m->{$k0}{$k1}{$k2}{1} == 0x06)) {
    if (not(defined($t0)) || $k0 < $t0) { $t0 = $k0; }
    my $i = 2; while (exists($m->{$k0}{$k1}{$k2}{$i})) { $marker{$k1} .= chr($m->{$k0}{$k1}{$k2}{$i++}); }
	}
   }
  }
 }

foreach my $k1 (sort {$a <=> $b} keys(%marker)) {
 if ($marker{$k1} =~ /Jump.*Jump/       ) { MIDI::InsEvent($m, $t0, $k1, 0, 0, {0=>0xf7, 1=>0xf8}); }
 if ($marker{$k1} =~ /Label.*Jump-[123]/) { MIDI::InsEvent($m, $t1, $k1, 0, 1, {0=>0xf7, 1=>0xf8}); }
 }

return(0); }
#===============================================================================
sub MidiFile_load { my ($m, $f, $Sync, $EntryLabel, $ExitLabel) = @_; if (not(defined($f))) { return(0); } printf("playsmf::MidiFile_load(\"$f\");\n");

if (defined($Sync      )) { $playsmf::Sync       = $Sync;       } else { $Sync = $playsmf::Sync; }
if (defined($EntryLabel)) { $playsmf::EntryLabel = $EntryLabel; }
if (defined($ExitLabel )) { $playsmf::ExitLabel  = $ExitLabel;  }

($playsmf::f, $playsmf::PPQ) = ($f, undef);
(%playsmf::test1, %playsmf::Labels, @playsmf::Labels, %playsmf::LabelsR, @playsmf::k1s, %playsmf::t2i) = ((), (), (), (), (), ());

my %test0 = MIDI::Read($f); $playsmf::PPQ = $test0{-1}{3};

if (not(exists($m->{-1}{3})) || not(defined($m->{-1}{3}))) { $m->{-1}{3} = $test0{-1}{3}; }
if (not(exists($m->{-1}{4})) || not(defined($m->{-1}{4}))) { $m->{-1}{4} = $test0{-1}{4}; }
if (not(exists($m->{-1}{5})) || not(defined($m->{-1}{5}))) { $m->{-1}{5} = $test0{-1}{5}; }
if (not(exists($m->{-1}{6})) || not(defined($m->{-1}{6}))) { $m->{-1}{6} = $test0{-1}{6}; }

if (($test0{-1}{3} != $m->{-1}{3}) || ($test0{-1}{4} != $m->{-1}{4})) { Edit::QuantizeTrk(\%test0, undef, 0, 0, 0, $m->{-1}{4}/$test0{-1}{4}, $m->{-1}{3}); }

foreach my $k0 (sort {$a <=> $b} keys(%test0)) { if ($k0 == -1) { next(); }
 foreach my $k1 (sort {$a <=> $b} keys(%{$test0{$k0}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$test0{$k0}{$k1}})) { %{$playsmf::test1{$k1}{$k0}} = %{$test0{$k0}{$k1}}; }
  }
 }

my $PJs = 0; my %PLs = ();
foreach my $k1 (sort {$a <=> $b} keys(%playsmf::test1)) {
 foreach my $k0 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}{$k0}})) {

   if (($playsmf::test1{$k1}{$k0}{$k2}{0} == 0xff) && ($playsmf::test1{$k1}{$k0}{$k2}{1} == 0x06)) { my ($txt, $i) = ('', 2); while (exists($playsmf::test1{$k1}{$k0}{$k2}{$i})) { $txt .= chr($playsmf::test1{$k1}{$k0}{$k2}{$i++}); }
    while ($txt =~ /(Label|Jump)(0x[0-9a-fA-F]+|[-0-9]+)/gi) { my ($KW, $v) = ($1, eval($2));

	 if ($KW =~ /Label/) { if (($v & 0xfff) == 0xfff) { while (exists($playsmf::Labels{$v})) { $v--; }} $playsmf::Labels{$v} = $k1; if (($#Labels < 0) || ($k1 > $playsmf::Labels{$Labels[$#Labels]})) { push(@Labels, $v); } if ($PJs) { $PJs = 0; %PLs = (); } $PLs{$v}++; $playsmf::LastLabel = $v; }
	  else               { if ($v <= -4)              { $v = $Labels[$#Labels-(-1*$v-4)]; }             $playsmf::test1{$k1}{-1}{1} = $v; foreach (sort {$a <=> $b} keys(%PLs)) { $playsmf::LabelsR{$_} = $v; } $PJs++; }

	 }
	}

   if (not(defined($playsmf::FirstLabel))) { $playsmf::FirstLabel = $playsmf::LastLabel; }

   if ((($playsmf::test1{$k1}{$k0}{$k2}{0} & ($Sync >> 16)) == ($Sync & 0xff)) && (($playsmf::test1{$k1}{$k0}{$k2}{1} & ($Sync >> 24)) == ($Sync>>8 & 0x7f))) {
    if (not(exists($playsmf::test1{$k1}{-1}{1}))) { $playsmf::test1{$k1}{-1}{1} = -9; }
	if (($Sync & 0x8000) <= 0) { delete($playsmf::test1{$k1}{$k0}{$k2}); if (scalar(keys(%{$playsmf::test1{$k1}{$k0}})) <= 0) { delete($playsmf::test1{$k1}{$k0}); }}
	}
   }
  }
 $playsmf::test1{$k1}{-1}{0} = $playsmf::EntryLabel; if ($#Labels >= 0) { $playsmf::test1{$k1}{-1}{0} = $Labels[$#Labels]; }
 }

if (not(defined($playsmf::FirstLabel))) { $playsmf::FirstLabel = $playsmf::EntryLabel; } if (not(defined($playsmf::LastLabel))) { $playsmf::LastLabel = $playsmf::ExitLabel; }

$playsmf::Labels{$playsmf::EntryLabel} = (sort {$a <=> $b} keys(%playsmf::test1))[0]; $playsmf::Labels{$playsmf::ExitLabel} = (sort {$b <=> $a} keys(%playsmf::test1))[0]+1;

foreach my $l (sort {$a <=> $b} keys(%playsmf::Labels)) { if (not(exists($playsmf::LabelsR{$l}))) { $playsmf::LabelsR{$l} = 0; }}

my $LabelNum = (sort {$b <=> $a} keys(%playsmf::Labels))[0]+1;

for (my $i=0; $i<$LabelNum; $i++) { my $j = ($i>>8)&0xf; my $k = ($i>>4)&0x3; my $l = $i&0xf;
 if (($j >= 1) && ($j <= 4) && ($l >= 1) && ($l <= 0xb) && exists($playsmf::Labels{$i&~0xf}) && !exists($playsmf::Labels{$i})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0xf}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0xf}; }
 }

for (my $i=0; $i<$LabelNum; $i++) { my $j = ($i>>8)&0xf; my $k = ($i>>4)&0x3; my $l = $i&0xf;
 if     (($j >= 1) && ($j <= 1) && ($k >= 1) && ($k <= 1) && exists($playsmf::Labels{$i&~0x30}) && !exists($playsmf::Labels{$i})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0x30}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0x30}; }
  elsif (($j >= 2) && ($j <= 4) && ($k >= 1) && ($k <= 2) && exists($playsmf::Labels{$i&~0x30}) && !exists($playsmf::Labels{$i})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&~0x30}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&~0x30}; }
 }

for (my $i=0; $i<$LabelNum ; $i++) { if (exists($playsmf::Labels{$i&0xfff}) && !exists($playsmf::Labels{$i})) { $playsmf::Labels{$i} = $playsmf::Labels{$i&0xfff}; $playsmf::LabelsR{$i} = $playsmf::LabelsR{$i&0xfff}; }}

@playsmf::k1s = sort {$a <=> $b} keys(%playsmf::test1); for (my $i=0; $i<=$#playsmf::k1s; $i++) { $playsmf::t2i{$playsmf::k1s[$i]} = $i; } $playsmf::t2i{$playsmf::Labels{$playsmf::ExitLabel}} = $#playsmf::k1s+1; %playsmf::Pending = (); $playsmf::i = 0;

return(0); }
#===============================================================================
sub main { my ($m, $t, $Length, $Label, $f, $Sync, $EntryLabel, $ExitLabel) = @_; playsmf::MidiFile_load($m, $f, $Sync, $EntryLabel, $ExitLabel);

$t *= $m->{-1}{3}*4; if (defined($Length)) { $Length *= $playsmf::PPQ*4; }

if (defined($Label)) { if (exists($playsmf::LabelsR{$Label})) { if ($playsmf::LabelsR{$Label} >= 0) { $ReturnLabel1 = $ReturnLabel0 = $Label; } else { $ReturnLabel1 = $playsmf::test1{$playsmf::k1s[$i]}{-1}{0}; }} else { $Label = undef; }}

my ($k1, $k1d, $md) = (undef, 0, 0);

while ($i <= $#playsmf::k1s) { if (defined($k1) && ($playsmf::k1s[$i] > $k1)) { $k1d += $playsmf::k1s[$i]-$k1; } if (defined($Length) && ($Length >= 0) && ($k1d >= $Length)) { last(); } $k1 = $playsmf::k1s[$i]; my $k1c = $t+$k1d;

 if (defined($Length) && exists($playsmf::test1{$k1}{-1}{1})) {

  if     (defined($Label))                   { $i = $playsmf::t2i{$playsmf::Labels{$Label}}; $Label = undef;      foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #IRQ
   elsif ($playsmf::test1{$k1}{-1}{1} >=  0) { $i = $playsmf::t2i{$playsmf::Labels{$playsmf::test1{$k1}{-1}{1}}}; foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #jmp
   elsif ($playsmf::test1{$k1}{-1}{1} >= -1) { $i = $playsmf::t2i{$playsmf::Labels{$ReturnLabel1}};               foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #ret0
   elsif ($playsmf::test1{$k1}{-1}{1} >= -3) { $i = $playsmf::t2i{$playsmf::Labels{$ReturnLabel0}};               foreach my $p (sort {$a <=> $b} keys(%Pending)) { my $k0 = $p>>11; my ($k1c, $k2c) = @{$Pending{$p}}; my $max = ($k1c-$t)+$m->{$k0}{$k1c}{$k2c}{3}; if ($max > $k1d) { $m->{$k0}{$k1c}{$k2c}{3} -= $max - $k1d; }} %Pending = (); $k1 = undef; next(); } #ret1
  }

 foreach my $k0 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}})) { if ($k0 == -1) { next(); }
  foreach my $k2 (sort {$a <=> $b} keys(%{$playsmf::test1{$k1}{$k0}})) {
   my $k0c = $k0; if (($playsmf::test1{$k1}{$k0}{$k2}{0} == 0xff) && ($playsmf::test1{$k1}{$k0}{$k2}{1} == 0x06)) { $k0c = 0; }
   my $k2c = 0; if (scalar(keys(%{$m->{$k0c}{$k1c}}))) { $k2c = (sort {$b <=> $a} keys(%{$m->{$k0c}{$k1c}}))[0]+1; }
   %{$m->{$k0c}{$k1c}{$k2c}} = %{$playsmf::test1{$k1}{$k0}{$k2}};
   if (($m->{$k0c}{$k1c}{$k2c}{0} >> 4) == 0x9) { $Pending{$k0c<<11 | ($m->{$k0c}{$k1c}{$k2c}{0} & 0xf)<<7 | $m->{$k0c}{$k1c}{$k2c}{1}} = [$k1c, $k2c]; if ($k1d + $m->{$k0c}{$k1c}{$k2c}{3} > $md) { $md = $k1d + $m->{$k0c}{$k1c}{$k2c}{3}; }}
   }
  }
 $i++;
 }

if (not(defined($Length)) && $md > $k1d) { $k1d = $md; } return($k1d/($playsmf::PPQ*4)); }
#===============================================================================

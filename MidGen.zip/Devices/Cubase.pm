use strict; use warnings; package Cubase; return(1);
#===============================================================================
sub Compatibility { my ($m, $d) = @_;

#avoid channel 'All'
foreach my $k0 (sort {$a <=> $b} keys %{$m}) { if ($k0 == -1) { next(); } my $c = 0;
 foreach my $k1 (sort {$b <=> $a} keys %{$m->{$k0}}) {
  foreach my $k2 (sort {$b <=> $a} keys %{$m->{$k0}{$k1}}) {
   if ($m->{$k0}{$k1}{$k2}{0} <= 0xef) { $c = 1; }
   if     (($m->{$k0}{$k1}{$k2}{0} == 0xff) && ($m->{$k0}{$k1}{$k2}{1} == 0x04) && $c) { delete($m->{$k0}{$k1}{$k2}); }
    elsif (($m->{$k0}{$k1}{$k2}{0} == 0xff) && ($m->{$k0}{$k1}{$k2}{1} == 0x21) && $c) { delete($m->{$k0}{$k1}{$k2}); }
   }
  if (scalar(keys(%{$m->{$k0}{$k1}})) <= 0) { delete($m->{$k0}{$k1}); }
  }
 }

if (defined($d)) { $main::DummyNop = $d; } #delay end-of-track meta event to prevent missing last events

return(0); }
#===============================================================================

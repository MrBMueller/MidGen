use strict; use warnings; use MIDI; package XGlite;

my $ManId = 0x43; #Yamaha

our @Reset  = ($ManId, 0x10, 0x4c, 0x00, 0x00, 0x7e, 0x00);

return(1);
#===============================================================================

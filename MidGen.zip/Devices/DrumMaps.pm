use strict; use warnings; use GS; package DrumMaps;

#               key+  dur* vel* vel+  rel* rel+
our @Generic = (+000, 1.0, 1.0, +0.0, 1.0, +0.0); #pass thru - no change

#                         default  metronome BD2       BD1        SD1
my %KeyMap            = (-1=>+000, 33=>  34, 35=>  35, 36=>   36, 38=>   38); #key+
my %DurationMap       = (-1=> 1.0,                     36=>-1/16, 38=>-1/16); #dur*
my %VelocityOffsetMap = (-1=>+0.0, 33=>+0.0, 35=>+0.0, 36=> -0.2, 38=> +0.0); #vel+

our @test = (\%KeyMap, \%DurationMap, 1.0, \%VelocityOffsetMap, 1.0, +0.0);

our %ReverseKeyMap     = (-1=>+000); for (my $i = 0x00; $i<=0x7f; $i++) { $ReverseKeyMap{$i} = 0x7f-$i; }

our %DrumMap0 = (
#key      s   key+    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0], #default
  33 => [ 1,    34, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0,   -.1, undef,  -0.9,    .1], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0,    .1, undef,   0.9,    .9]  #SD1
);

return(1);
#===============================================================================

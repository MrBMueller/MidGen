use strict; use warnings; use MIDI; use GM; use XGlite; package YamahaPSRE363;

our %Patches;

return(1);
#===============================================================================
sub MasterTuning {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $n     = undef; if ($#_ >= 0) { $n     = shift(@_); } if (not defined($n    )) { $n     =   -1; } #
my $mm    = undef; if ($#_ >= 0) { $mm    = shift(@_); } if (not defined($mm   )) { $mm    = 0x00; } #
my $ll    = undef; if ($#_ >= 0) { $ll    = shift(@_); } if (not defined($ll   )) { $ll    = 0x00; } #
my $cc    = undef; if ($#_ >= 0) { $cc    = shift(@_); } if (not defined($cc   )) { $cc    = 0x00; } #

my ($N0, $N1) = ($n, $n); if ($n < 0) { ($N0, $N1) = (0x0, 0xf); } for (my $n = $N0; $n <= $N1; $n++) { MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x43, 0x10 | $n, 0x27, 0x30, 0x00, 0x00, $mm, $ll, $cc); }

return(0); }
#===============================================================================
sub ReverbType {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $n     = undef; if ($#_ >= 0) { $n     = shift(@_); } if (not defined($n    )) { $n     =   -1; } #
my $mm    = undef; if ($#_ >= 0) { $mm    = shift(@_); } if (not defined($mm   )) { $mm    = 0x00; } #
my $ll    = undef; if ($#_ >= 0) { $ll    = shift(@_); } if (not defined($ll   )) { $ll    = 0x00; } #

my ($N0, $N1) = ($n, $n); if ($n < 0) { ($N0, $N1) = (0x0, 0xf); } for (my $n = $N0; $n <= $N1; $n++) { MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x43, 0x10 | $n, 0x4c, 0x02, 0x01, 0x00, $mm, $ll); }

return(0); }
#===============================================================================
sub ChorusType {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $n     = undef; if ($#_ >= 0) { $n     = shift(@_); } if (not defined($n    )) { $n     =   -1; } #
my $mm    = undef; if ($#_ >= 0) { $mm    = shift(@_); } if (not defined($mm   )) { $mm    = 0x00; } #
my $ll    = undef; if ($#_ >= 0) { $ll    = shift(@_); } if (not defined($ll   )) { $ll    = 0x00; } #

my ($N0, $N1) = ($n, $n); if ($n < 0) { ($N0, $N1) = (0x0, 0xf); } for (my $n = $N0; $n <= $N1; $n++) { MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x43, 0x10 | $n, 0x4c, 0x02, 0x01, 0x20, $mm, $ll); }

return(0); }
#===============================================================================
sub ImportPatchNames { my %RetVal;
my ($h0, $p) = (undef, -2); if (($#_ >= 1) && (ref($_[0]) =~ 'HASH')) { $h0 = shift(@_); $p = shift(@_); }
my $fname  = undef; if ($#_ >= 0) { $fname = shift(@_); } if (not(defined($fname))) { $fname = "$main::SrcDir0/DeviceMaps/YamahaPSRE363.txt"; }
my $pname  = undef; if ($#_ >= 0) { $pname = shift(@_); } if (not(defined($pname))) { $pname = "PSR-E363"; } $RetVal{-1} = $pname;

if (not(defined($p))) { $p = -1; } if ($p < -1) { $p = undef; }

if ((defined($p)) && (not(exists($h0->{$p}{-1})))) { $h0->{$p}{-1} = $RetVal{-1}; }

my @MyAttrs0 = stat($fname);
open(my_file1, $fname); my $group = "";
while (<my_file1>) { my $line = $_; $line =~ s/\n|\r//g; $line =~ s/^\s*//g; $line =~ s/\s*$//g; if (length($line) <= 0) { next(); } #printf("$line\n");

 my $No = -1; my $ToneName = ""; my $MSB = -1; my $LSB = -1; my $PC = -1;

 if ($line =~ /^(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(.*)$/) { $No = $1; $MSB = $2; $LSB = $3; $PC = $4-1; $ToneName = $5; }

 $ToneName =~ s/^\s*//g; $ToneName =~ s/\s*$//g;

 if ($No < 0) { $group = $line; next(); }
 
 #$RetVal{0xc}{-1}{($MSB<<7)+$LSB}{ -1} = sprintf("PSR");
 $RetVal{0xc}{-1}{($MSB<<7)+$LSB}{$PC} = sprintf("%s-%d-%s", $group, $No, $ToneName);

 #if ((defined($p)) && (not(exists($h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}     )))) { $h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{ -1} = sprintf("PSR"); }
 if ((defined($p)) && (not(exists($h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{$PC})))) { $h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{$PC} = sprintf("%s-%d-%s", $group, $No, $ToneName); }

 $YamahaPSRE363::Patches{$No} = [($MSB<<7)+$LSB, $PC];

 #printf("0x%04x, 0x%02x %-7s %3d %s\n", ($MSB<<7)+$LSB, $PC, $group, $No, $ToneName);
 }
close(my_file1);

return(%RetVal); }
#===============================================================================
sub Patch { my $t = shift(@_); my @RetVal = (0x0000, 0x00);

if (exists($YamahaPSRE363::Patches{$t})) { @RetVal = @{$YamahaPSRE363::Patches{$t}}; }
 else { printf("YamahaPSRE363::Patch(%d); #doesnt exist!\n", $t); }

return(@RetVal); }
#===============================================================================

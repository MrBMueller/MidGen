use strict; use warnings; use MIDI; package KawaiCN33; #stage piano

#regular CC definitions
our $CCx07 = 0x07; #volume
our $CCx0b = 0x0b; #expression
our $CCx40 = 0x40; #sustain pedal
our $CCx42 = 0x42; #sostenuto pedal
our $CCx43 = 0x43; #soft pedal

return(1);
#===============================================================================
sub SysEx {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $ch    =  0x00; if ($#_ >= 0) { $ch    = shift(@_); } #channel 0x00-0x0f
my $fn    =  0x10; if ($#_ >= 0) { $fn    = shift(@_); } #function code 0x10, 0x30
my $d1    =  0x00; if ($#_ >= 0) { $d1    = shift(@_); } #data1
my $d2    =  0x00; if ($#_ >= 0) { $d2    = shift(@_); } #data2
my $d3    = undef; if ($#_ >= 0) { $d3    = shift(@_); } #data3

my @data = (); if (defined($d3)) { @data = ($d3); }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x40, $ch, $fn, 0x04, 0x02, $d1, $d2, @data);

return(0.050*$tc); } #return approx. processing time in s
#===============================================================================

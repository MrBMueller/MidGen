use strict; use warnings; use MIDI; package GM;

our $CCoff = 0.0; #switch controller off (0x00)
our $CCon  = 1.0; #switch controller on  (0x7f)

#regular CC definitions
our $CCx00 = 0x00; #bank select
our $CCx01 = 0x01; #modulation
our $CCx07 = 0x07; #volume
our $CCx0a = 0x0a; #panorama
our $CCx0b = 0x0b; #expression
our $CCx40 = 0x40; #sustain - off/on switch controller, right pedal
our $CCx79 = 0x79; #reset all controller
our $CCx7a = 0x7a; #local control off/on
our $CCx7b = 0x7b; #all notes off

#extented MSB/LSB CC definitions
our $eCCx00 = 0x0200 | $CCx00;
our $eCCx01 = 0x0200 | $CCx01;
our $eCCx07 = 0x0200 | $CCx07;
our $eCCx0a = 0x0200 | $CCx0a;
our $eCCx0b = 0x0200 | $CCx0b;

#centered CC definitions
our  $cCCx0a = 0x20000 |  $CCx0a;
our $ecCCx0a = 0x20000 | $eCCx0a;

#RPN definitions
our $RPN_0 = 0x4000; #PBS
our $RPN_1 = 0x4001; #master fine tune
our $RPN_2 = 0x4002; #master coarse tune
our $RPN_n = 0x7fff; #null (reset RPN address)

our $cRPN_1  = 0x20000 | $RPN_1;
our $cRPN_2  = 0x20000 | $RPN_2;

#PitchBend
our $PB  = 0x0104;
our $cPB = 0x20000 | $PB;

#program (patch) change
our $PC  = 0x0105;

return(1);
#===============================================================================
sub Reset {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7e, 0x7f, 0x09, 0x01);

return(0.050*$tc); } #return approx. processing time
#===============================================================================

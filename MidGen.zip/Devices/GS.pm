use strict; use warnings; use MIDI; use GM; package GS;

#regular CC definitions
our $CCx05 = 0x05; #portamento time

our $CCx41 = 0x41; #portamento on/off
our $CCx42 = 0x42; #sostenuto  on/off (mid  pedal - doesnt always exist)
our $CCx43 = 0x43; #soft       on/off (left pedal)

our $CCx54 = 0x54; #portamento control
our $CCx5b = 0x5b; #effect send 1 (reverb)
our $CCx5d = 0x5d; #effect send 3 (chorus)
our $CCx7a = 0x7a; #local control off/on

#NRPNs below take centered MSB values (0x0e .. 0x40 .. 0x72) ignorng LSB
our $NRPNx0108 = 0x8000 | (0x01 << 7) | 0x08; #vibrato rate
our $NRPNx0109 = 0x8000 | (0x01 << 7) | 0x09; #vibrato depth (<=0 -> off/default; >0 -> depth)
our $NRPNx010a = 0x8000 | (0x01 << 7) | 0x0a; #vibrato delay (-1 -> zero delay)

our $NRPNx0120 = 0x8000 | (0x01 << 7) | 0x20; #TVF (time variant filter) cutoff
our $NRPNx0121 = 0x8000 | (0x01 << 7) | 0x21; #TVF (time variant filter) resonance

our $NRPNx0163 = 0x8000 | (0x01 << 7) | 0x63; #TVF/A (time variant filter/amplifier) attack
our $NRPNx0164 = 0x8000 | (0x01 << 7) | 0x64; #TVF/A (time variant filter/amplifier) decay
our $NRPNx0166 = 0x8000 | (0x01 << 7) | 0x66; #TVF/A (time variant filter/amplifier) release

#individual drum settings (notes: add drum instrument key; data MSB values as below; data LSB ignored)
our $NRPNx1800 = 0x8000 | (0x18 << 7) + 0x00; #drum pitch coarse (0x00       .. [0x40] .. 0x7f)
our $NRPNx1a00 = 0x8000 | (0x1a << 7) + 0x00; #drum TVA level    (0x00       ..           0x7f)
our $NRPNx1c00 = 0x8000 | (0x1c << 7) + 0x00; #drum pan          (0x00, 0x01 .. [0x40] .. 0x7f)
our $NRPNx1d00 = 0x8000 | (0x1d << 7) + 0x00; #drum reverb       (0x01       ..           0x7f)
our $NRPNx1e00 = 0x8000 | (0x1e << 7) + 0x00; #drum chorus       (0x01       ..           0x7f)

our $cNRPNx1800  = 0x20000 | $NRPNx1800;
our $cNRPNx1c00  = 0x20000 | $NRPNx1c00;

our $NRPN_n = 0xbfff; #null (reset NRPN address)

#system parameter
our $MasterVolume   = 0x400; $MIDI::CtlCallBackRefs{$MasterVolume  } = \&GS::MasterVolume;
our $MasterPan      = 0x401; $MIDI::CtlCallBackRefs{$MasterPan     } = \&GS::MasterPan;
our $MasterFineTune = 0x402; $MIDI::CtlCallBackRefs{$MasterFineTune} = \&GS::MasterFineTune;

#block (part) parameter
our $BlockParam = 0x500; for (0x02..0x1e) { $MIDI::CtlCallBackRefs{$BlockParam+$_} = \&GS::BlockParam7bit; }

$MIDI::CtlCallBackRefs{$BlockParam+0x00} = \&GS::BlockParam14bit;
$MIDI::CtlCallBackRefs{$BlockParam+0x17} = \&GS::BlockPitchOffsetFine;

our $BPx00 = $BlockParam + 0x00; #bank, program
our $BPx02 = $BlockParam + 0x02; #receive channel (0-15 ch, 16 off)
our $BPx13 = $BlockParam + 0x13; #mono/poly mode (0,1)
our $BPx15 = $BlockParam + 0x15; #rythm (0..2: off, map #1, map #2)
our $BPx16 = $BlockParam + 0x16; #key shift (-24..0..24)
our $BPx17 = $BlockParam + 0x17; #pitch fine tune (-120..0..120)
our $BPx19 = $BlockParam + 0x19; #level/volume (0..127)
our $BPx1a = $BlockParam + 0x1a; #velocity sense depth  (0..64..127)
our $BPx1b = $BlockParam + 0x1b; #velocity sense offset (0..64..127)
our $BPx1c = $BlockParam + 0x1c; #pan (0,1..0..127: random, left..center..right)
our $BPx1d = $BlockParam + 0x1d; #key range low
our $BPx1e = $BlockParam + 0x1e; #key range high

our $cBPx16  = 0x20000 | $BPx16;
our $cBPx17  = 0x20000 | $BPx17;
our $cBPx1a  = 0x20000 | $BPx1a;
our $cBPx1b  = 0x20000 | $BPx1b;
our $cBPx1c  = 0x20000 | $BPx1c;

#drum map parameter
our $DrumMapParam = 0x800; for (0x000..0x7ff) { $MIDI::CtlCallBackRefs{$DrumMapParam+$_} = \&GS::DrumMapParam; }

our $DM0 = $DrumMapParam + (0 << 7); #drum map #0
our $DM1 = $DrumMapParam + (8 << 7); #drum map #1

#map #0 parameter
our $DM0x1 = $DM0 + ((1-1) << 7); #play note number = NRPNx1800
our $DM0x2 = $DM0 + ((2-1) << 7); #level            = NRPNx1a00
our $DM0x4 = $DM0 + ((4-1) << 7); #pan              = NRPNx1c00
our $DM0x5 = $DM0 + ((5-1) << 7); #reverb           = NRPNx1d00
our $DM0x6 = $DM0 + ((6-1) << 7); #chorus           = NRPNx1e00

our $cDM0x1  = 0x20000 | $DM0x1;
our $cDM0x4  = 0x20000 | $DM0x4;

#map #1 parameter
our $DM1x1 = $DM1 + ((1-1) << 7); #play note number = NRPNx1800
our $DM1x2 = $DM1 + ((2-1) << 7); #level            = NRPNx1a00
our $DM1x4 = $DM1 + ((4-1) << 7); #pan              = NRPNx1c00
our $DM1x5 = $DM1 + ((5-1) << 7); #reverb           = NRPNx1d00
our $DM1x6 = $DM1 + ((6-1) << 7); #chorus           = NRPNx1e00

our $cDM1x1  = 0x20000 | $DM1x1;
our $cDM1x4  = 0x20000 | $DM1x4;

#                    C   C#    D   D#    E    F   F#   G   G#    A   A#    B
our @ScaleEqual = (  0,   0,   0,   0,   0,   0,   0,  0,   0,   0,   0,   0);
our @ScaleJust  = (  0,  -8,   4,  16, -14,  -2, -10,  2,  14, -16,  14, -12);
our @ScaleArab  = ( -6,  45,  -2, -12, -51,  -8,  43, -4,  47,   0, -10, -49);
our @ScaleArab1 = (  0,  50,   0,   0, -50,   0,   0,  0, -50,   0,   0, -50);

return(1);
#===============================================================================
sub Reset {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  = 0x00; } #Mode 0x00 (GS), 0x7f (GM);

GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x7f, $val0);

return(0.050*$tc); } #return approx. processing time
#===============================================================================
sub System {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } #if (not defined($val0 )) { $val0  =  0.0; } #-1.0 ... 1.0 MasterFineTune
my $val1  = undef; if ($#_ >= 0) { $val1  = shift(@_); } #if (not defined($val1 )) { $val1  =  1.0; } # 0.0 ... 1.0 MasterVolume
my $val2  = undef; if ($#_ >= 0) { $val2  = shift(@_); } #if (not defined($val2 )) { $val2  =    0; } # -24 ... 24  MasterCoarseTune
my $val3  = undef; if ($#_ >= 0) { $val3  = shift(@_); } #if (not defined($val3 )) { $val3  =  0.0; } #-1.0 ... 1.0 MasterPan

if (defined($val0)) { $val0 = int((($val0+1.0)/2)*0x0800); if ($val0 > 0x07e8) { $val0 = 0x07e8; } if ($val0 < 0x0018) { $val0 = 0x0018; }
 GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x00, ($val0>>12)&0xf, ($val0>>8)&0xf, ($val0>>4)&0xf, ($val0>>0)&0xf);
 $start += 0.040*$tc; }

if (defined($val1)) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x04, int($val1*0x7f)); $start += 0.040*$tc; }

if (defined($val2)) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x05, $val2+0x40); $start += 0.040*$tc; }

if (defined($val3)) { $val3 = int((($val3+1.0)/2)*0x0080); if ($val3 > 0x007f) { $val3 = 0x007f; }
 GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x06, $val3); $start += 0.040*$tc; }

return($start-$s); }
#===============================================================================
sub Reverb {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
#0 0x04 0x00-0x07 Macro (Room 1, 2, 3, Hall 1, 2, Plate, Delay, Panning Delay)
#1 0x04 0x00-0x07 Character
#2 0x00 0x00-0x07 Pre-LPF
#3 0x40 0x00-0x7f Level
#4 0x40 0x00-0x7f Time
#5 0x00 0x00-0x7f Delay Feedback
#6 0x00 0x00-0x7f Send Level to Chorus

#GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x01, 0x30, @_);

for (my $i=0; $i<=$#_; $i++) {
 if (defined($_[$i])) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x01, 0x30+$i, $_[$i]); $start += 0.040*$tc; }
 }

return($start-$s); }
#===============================================================================
sub Chorus {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
#0 0x02 0x00-0x07 Macro (Type 1, 2 ,3 ,4 , Feedback, Flanger, Delay, Delay Feedback)
#1 0x00 0x00-0x07 Pre-LPF
#2 0x40 0x00-0x7f Level
#3 0x08 0x00-0x7f Feedback
#4 0x50 0x00-0x7f Delay
#5 0x03 0x00-0x7f Rate
#6 0x13 0x00-0x7f Depth
#7 0x00 0x00-0x7f Send Level to Reverb

#GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x01, 0x38, @_);

for (my $i=0; $i<=$#_; $i++) {
 if (defined($_[$i])) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x01, 0x38+$i, $_[$i]); $start += 0.040*$tc; }
 }

return($start-$s); }
#===============================================================================
sub AssignBlock {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =       0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =         0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =         1; }
my $dly   = undef; if ($#_ >= 0) { $dly   = shift(@_); } if (not defined($dly  )) { $dly   =      1/64; } #
my $chn   = undef; if ($#_ >= 0) { $chn   = shift(@_); } if (not defined($chn  )) { $chn   =   -0xffff; } #undef, 0x0..0xf
my $adr   = undef; if ($#_ >= 0) { $adr   = shift(@_); } if (not defined($adr  )) { $adr   =  0x401000; } #

#           0  1  2  3  4  5  6  7  8  9  10  11  12  13  14  15   #channel/part (default assignment - see GS spec)
my @BLUT = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15); #physical block (address)

if    ($chn < 0) { $chn = abs($chn); }
 else            { $chn = 1 << $chn; }

for (my $c=0; $c<=$#BLUT; $c++) {
 if ($chn & 1) { GS::DT1SysEx($h0, $trk, $start, $ep, ($adr>>16)&0x7f, ($adr>>8)&0x7f | $BLUT[$c], ($adr>>0)&0x7f, @_); $start += $dly; }
 $chn >>= 1;
 }

return($start-$s); }
#===============================================================================
sub AssignBlockMap { my $m = shift(@_); my $t = shift(@_); my $s = shift(@_); my $ep = shift(@_); my $d = shift(@_); my $h0 = shift(@_);

my @mh = @{$h0->{-1}};
foreach my $block (sort {$a <=> $b} keys %{$h0}) { my @row  = @{$h0->{$block}};
 for (my $i = 0; $i <= $#row; $i++) { my $ctl = $mh[$i]; my $val = $row[$i];
  if (($block >= 0) && (defined($ctl)) && (defined($val))) {
   my $adr0 = ($ctl >>  0) & 0xff;
   my $adr1 = ($ctl >>  8) & 0xff;
   my $adr2 = ($ctl >> 16) & 0xff;
   my $l    = ($ctl >> 24) & 0xff;
   my @dat; for (my $i=0; $i<$l; $i++) { unshift(@dat, $val&0xff); $val = $val >> 8; }
   GS::DT1SysEx($m, $t, $s, $ep, $adr2, $adr1 | $block, $adr0, @dat); $s += $d;
   }
  }
 }

return(0); }
#===============================================================================
sub DT1SysEx { #Roland Data Transfer (Data set 1)
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }

my @SysEx = (0x41, 0x10, 0x42, 0x12); #ManId (Roland), DeviceId (17), ModelId (GS), CommandId (DT1)

my $sum = 0; for (my $i=0; $i<=$#_; $i++) { if (defined($_[$i])) { push(@SysEx, $_[$i]); $sum += $_[$i]; }} push(@SysEx, (128-($sum%128))&0x7f);

MIDI::InsertSysEx($h0, $trk, $start, $ep, @SysEx);

return(0); }
#===============================================================================
sub RQ1SysEx { #Roland Data Request
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $a     = undef; if ($#_ >= 0) { $a     = shift(@_); } if (not defined($a    )) { $a     =  0x0; }
my $s     = undef; if ($#_ >= 0) { $s     = shift(@_); } if (not defined($s    )) { $s     =  0x0; }

#ManId (Roland), DeviceId (17), ModelId (GS), CommandId (RQ1), addr, size
my @SysEx = (0x41, 0x10, 0x42, 0x11, ($a>>16)&0x7f, ($a>>8)&0x7f, ($a>>0)&0x7f, ($s>>16)&0x7f, ($s>>8)&0x7f, ($s>>0)&0x7f);

my $sum = 0; for (my $i=4; $i<=$#SysEx; $i++) { $sum += $SysEx[$i]; } push(@SysEx, (128-($sum%128))&0x7f);

MIDI::InsertSysEx($h0, $trk, $start, $ep, @SysEx);

return(0); }
#===============================================================================
#callback subs (may also be used by direct calls)
#===============================================================================
sub MasterFineTune {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   = 0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =   0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =   1; }
my $ch    = undef; if ($#_ >= 0) { $ch    = shift(@_); } if (not defined($ch   )) { $ch    =   0; }
my $ctl   = undef; if ($#_ >= 0) { $ctl   = shift(@_); } if (not defined($ctl  )) { $ctl   =   0; }
my $v0    = undef; if ($#_ >= 0) { $v0    = shift(@_); } if (not defined($v0   )) { $v0    = 0.0; }
my $v1    = undef; if ($#_ >= 0) { $v1    = shift(@_); }

my $init = 0; if ((defined($v1)) && ($v1 < 0)) { $init++; } #callback init

if (defined($v1)) { $v0 >>= 3; $v1 >>= 3;            } #callback
 else             { $v0 = int((($v0+1.0)/2)*0x0800); } #direct

                    if ($v0 > 0x7e8) { $v0 = 0x7e8; } if ($v0 < 0x018) { $v0 = 0x018; }  #callback/direct
if (defined($v1)) { if ($v1 > 0x7e8) { $v1 = 0x7e8; } if ($v1 < 0x018) { $v1 = 0x018; }} #callback

if ((not(defined($v1))) || ($init) || ($v0 != $v1)) {
 GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x00, ($v0>>12)&0xf, ($v0>>8)&0xf, ($v0>>4)&0xf, ($v0>>0)&0xf);
 }

return(0); }
#===============================================================================
sub MasterVolume {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   = 0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =   0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =   1; }
my $ch    = undef; if ($#_ >= 0) { $ch    = shift(@_); } if (not defined($ch   )) { $ch    =   0; }
my $ctl   = undef; if ($#_ >= 0) { $ctl   = shift(@_); } if (not defined($ctl  )) { $ctl   =   0; }
my $v0    = undef; if ($#_ >= 0) { $v0    = shift(@_); } if (not defined($v0   )) { $v0    = 0.0; }
my $v1    = undef; if ($#_ >= 0) { $v1    = shift(@_); }

my $init = 0; if ((defined($v1)) && ($v1 < 0)) { $init++; } #callback init

if (defined($v1)) { $v0 >>= 7; $v1 >>= 7; } #callback
 else             { $v0 = int($v0*0x7f);  } #direct

                    if ($v0 > 0x7f) { $v0 = 0x7f; } if ($v0 < 0x00) { $v0 = 0x00; }  #callback/direct
if (defined($v1)) { if ($v1 > 0x7f) { $v1 = 0x7f; } if ($v1 < 0x00) { $v1 = 0x00; }} #callback

if ((not(defined($v1))) || ($init) || ($v0 != $v1)) {
 GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x04, $v0);
 }

return(0); }
#===============================================================================
sub MasterPan {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   = 0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =   0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =   1; }
my $ch    = undef; if ($#_ >= 0) { $ch    = shift(@_); } if (not defined($ch   )) { $ch    =   0; }
my $ctl   = undef; if ($#_ >= 0) { $ctl   = shift(@_); } if (not defined($ctl  )) { $ctl   =   0; }
my $v0    = undef; if ($#_ >= 0) { $v0    = shift(@_); } if (not defined($v0   )) { $v0    = 0.0; }
my $v1    = undef; if ($#_ >= 0) { $v1    = shift(@_); }

my $init = 0; if ((defined($v1)) && ($v1 < 0)) { $init++; } #callback init

if (defined($v1)) { $v0 >>= 7; $v1 >>= 7;            } #callback
 else             { $v0 = int((($v0+1.0)/2)*0x0080); } #direct

                    if ($v0 > 0x7f) { $v0 = 0x7f; } if ($v0 < 0x00) { $v0 = 0x00; }  #callback/direct
if (defined($v1)) { if ($v1 > 0x7f) { $v1 = 0x7f; } if ($v1 < 0x00) { $v1 = 0x00; }} #callback

if ((not(defined($v1))) || ($init) || ($v0 != $v1)) {
 GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x00, 0x06, $v0);
 }

return(0); }
#===============================================================================
sub BlockParam7bit { my ($h0, $trk, $start, $ep, $ch, $ctl, $v0, $v1) = @_; $ctl -= $GS::BlockParam;

#           0  1  2  3  4  5  6  7  8  9  10  11  12  13  14  15   #channel/part (default assignment - see GS spec)
my @BLUT = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15); #physical block (address)

if ($v0>>7 != $v1>>7) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x10 | $BLUT[$ch], $ctl, $v0>>7); }

return(0); }
#===============================================================================
sub BlockParam14bit { my ($h0, $trk, $start, $ep, $ch, $ctl, $v0, $v1) = @_; $ctl -= $GS::BlockParam;

#           0  1  2  3  4  5  6  7  8  9  10  11  12  13  14  15   #channel/part (default assignment - see GS spec)
my @BLUT = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15); #physical block (address)

GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x10 | $BLUT[$ch], $ctl, $v0>>7, $v0&0x7f);

return(0); }
#===============================================================================
sub DrumMapParam { my ($h0, $trk, $start, $ep, $ch, $ctl, $v0, $v1) = @_; $ctl -= $GS::DrumMapParam;

if ($v0>>7 != $v1>>7) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x41, (($ctl>>6)&0x10)+(($ctl>>7)&0x07)+1, $ctl&0x7f, $v0>>7); }

return(0); }
#===============================================================================
sub BlockPitchOffsetFine { my ($h0, $trk, $start, $ep, $ch, $ctl, $v0, $v1) = @_; $ctl -= $GS::BlockParam;

#           0  1  2  3  4  5  6  7  8  9  10  11  12  13  14  15   #channel/part (default assignment - see GS spec)
my @BLUT = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15); #physical block (address)

my $init = 0; if ($v1 < 0) { $init++; }

#centered 8-bit values [0x08 .. 0x80 .. 0xf8] = [8 .. 128 .. 248] => [-120 .. 0 .. 120]
$v0 >>= 6; if ($v0 > 0xf8) { $v0 = 0xf8; } if ($v0 < 0x08) { $v0 = 0x08; }
$v1 >>= 6; if ($v1 > 0xf8) { $v1 = 0xf8; } if ($v1 < 0x08) { $v1 = 0x08; }

if (($init) || ($v0 != $v1)) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x10 | $BLUT[$ch], $ctl, ($v0>>4)&0xf, ($v0>>0)&0xf); }

return(0); }
#===============================================================================
sub ScaleTuning {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =     0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =       0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =       1; }
my $part  = undef; if ($#_ >= 0) { $part  = shift(@_); } if (not defined($part )) { $part  = -0xffff; } #undef, 0x0..0xf
my $key   = undef; if ($#_ >= 0) { $key   = shift(@_); } if (not defined($key  )) { $key   =       0; } #0..11 semitones

#           0  1  2  3  4  5  6  7  8  9  10  11  12  13  14  15   #channel
my @PLUT = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15); #part assignment (see GS spec)

if    ($part < 0) { $part = abs($part); }
 else             { $part = 1 << $part; }

my @tmp; for (my $i=0; $i<=$#_; $i++) { $tmp[($i+$key)%12] = 0x40 + $_[$i]; } #value range [-64..0..63]

for (my $c=0; $c<=$#PLUT; $c++) {
 if ($part & 1) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x10+$PLUT[$c], 0x40, @tmp); $start += 0.040*$tc; }
 $part >>= 1;
 }

return($start-$s); }
#===============================================================================

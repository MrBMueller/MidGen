use strict; use warnings; use MIDI; package KorgC35; #concert piano

#regular CC definitions
our $CCx07 = 0x07; #volume
our $CCx40 = 0x40; #sustain (damper) pedal
our $CCx42 = 0x42; #sostenuto pedal
our $CCx43 = 0x43; #soft pedal
our $CCx7a = 0x7a; #local control off/on
our $CCx7b = 0x7b; #all notes off

#selected channel and patch values (front panel)
our $SelC =  0x0; #selected channel
our $SelP = 0x00; #selected patch

#program patch order (front panel left to right buttons)
our $Px00 = 0x00; #piano
our $Px01 = 0x01; #electric piano
our $Px02 = 0x02; #harpsichord
our $Px03 = 0x03; #vibes
our $Px04 = 0x04; #organ
our $Px05 = 0x05; #strings

#channel patch assignments (example for selected channel 0)
our $Cx0P = $SelC + $SelP; #always selected by front panel
our $Cx1P = $SelC + $Px00; #
our $Cx2P = $SelC + $Px01; #
our $Cx3P = $SelC + $Px02; #
our $Cx4P = $SelC + $Px03; #
our $Cx5P = $SelC + $Px04; #
our $Cx6P = $SelC + $Px05; #

return(1);
#===============================================================================

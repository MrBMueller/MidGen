use strict; use warnings; use MIDI; package MMC; return(1);
#===============================================================================
sub Stop {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  = 0x60; } #fps (24)
my $val1  = undef; if ($#_ >= 0) { $val1  = shift(@_); } if (not defined($val1 )) { $val1  = 0x00; } #min
my $val2  = undef; if ($#_ >= 0) { $val2  = shift(@_); } if (not defined($val2 )) { $val2  = 0x00; } #sec
my $val3  = undef; if ($#_ >= 0) { $val3  = shift(@_); } if (not defined($val3 )) { $val3  = 0x00; } #frame
my $val4  = undef; if ($#_ >= 0) { $val4  = shift(@_); } if (not defined($val4 )) { $val4  = 0x00; } #sub-frame

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x01); #stop
MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x44, 0x06, 0x01, $val0, $val1, $val2, $val3, $val4); #set locator

return(0); }
#===============================================================================
sub Play {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x02);

return(0); }
#===============================================================================
sub Rec {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x06);

return(0); }
#===============================================================================
sub GoTo {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =    0; } my $sec = (($start+$val0)*4*60)/$h0->{-1}{4};

MMC::Stop($h0, $trk, $start, $ep, $h0->{-1}{3}, int($sec/60), int($sec)%60, int(($sec-int($sec))*$h0->{-1}{3}), 0);

MMC::Play($h0, $trk, $start, $ep);

return(0); }
#===============================================================================

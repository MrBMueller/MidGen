use strict; use warnings; package Helper; return(1);
#===============================================================================
sub Guitar {
my $key0 = 0;  if ($#_ >= 0) { $key0 = shift(@_); }
my $note = 0;  if ($#_ >= 0) { $note = shift(@_); } if (defined($note)) { if ($note < 0) { $note = 12-(abs($note)%12); } $note = $note % 12; }
my $rev  = 0;  if ($#_ >= 0) { $rev  = shift(@_); } #play reverse
my $vel  = ''; if ($#_ >= 0) { $vel  = shift(@_); }
my $dly  = ''; if ($#_ >= 0) { $dly  = shift(@_); }
my $ctl  = ''; if ($#_ >= 0) { $ctl  = shift(@_); }
my $rval = "_% [ "; my $mval = "( ";

#physical            top                 bot
#freq                bass               treble
#                     E   A   D   G   B   E
my %tabs = (0=>{ 0=>[ 0,  0,  0,  0,  0,  0]},
			2=>{ 0=>[-1,  3,  2,  0,  1,  0],
				 1=>[-1,  3,  2,  0,  1,  0],
				 2=>[-1, -1,  0,  1,  3,  2],
				 3=>[-1, -1, -1,  3,  4,  3],
				 4=>[ 0,  2,  2,  1,  0,  0],
				 5=>[ 1,  3,  3,  2,  1,  1],
				 6=>[ 1,  3,  3,  2,  1,  1],
				 7=>[ 3,  2,  0,  0,  0,  3],
				 8=>[ 3,  2,  0,  0,  0,  3],
				 9=>[-1,  0,  2,  2,  2,  0],
				10=>[-1, -1, -1,  3,  3,  1],
				11=>[-1, -1, -1,  4,  4,  2]},
			3=>{ 0=>[-1,  3,  5,  5,  4, -1],
				 1=>[-1,  3,  5,  5,  4, -1],
				 2=>[-1, -1,  0,  2,  3,  1],
				 3=>[-1, -1,  0,  2,  3,  1],
				 4=>[ 0,  2,  2,  0,  0,  0],
				 5=>[ 1,  3,  3,  1,  1,  1],
				 6=>[ 1,  3,  3,  1,  1,  1],
				 7=>[-1, -1,  5,  3,  3,  3],
				 8=>[-1, -1,  5,  3,  3,  3],
				 9=>[-1,  0,  2,  2,  1,  0],
				10=>[-1,  0,  2,  2,  1,  0],
				11=>[-1, -1, -1,  4,  3,  2]});

my @shift1 = (); if (ref($key0) =~ /ARRAY/i) {@shift1 = @{$key0}; } else { @shift1 = @{$tabs{$key0}{$note%scalar(keys(%{$tabs{$key0}}))}}; }

my %vels = (); if (ref($vel) =~ /ARRAY/i) { my @a = @{$vel}; for (my $i=0; $i<=$#a; $i++) { $vels{$i} = $a[$i]; }} else { for (my $i=0; $i<=5; $i++) { $vels{$i} = $vel; }}
my %dlys = (); if (ref($dly) =~ /ARRAY/i) { my @a = @{$dly}; for (my $i=0; $i<=$#a; $i++) { $dlys{$i} = $a[$i]; }} else { for (my $i=0; $i<=4; $i++) { $dlys{$i} = $dly; }}
my %ctls = (); if (ref($ctl) =~ /ARRAY/i) { my @a = @{$ctl}; for (my $i=0; $i<=$#a; $i++) { $ctls{$i} = $a[$i]; }} else { for (my $i=0; $i<=5; $i++) { $ctls{$i} = $ctl; }}

my $start = -1; my $length = -1; for (my $i=0; $i<=$#shift1; $i++) { if ($shift1[$i] > -1) { if ($start < 0) { $start = $i; } $length++; }}

my $a = $start; my $b = $a+$length; my $c = 0; my $d = 5-$length; if ($rev) { $d = 5; }

for (my $i=0; $i<=$#shift1; $i++) { my $string = $i; if ($rev) { $string = 5 - $string; }

 if ($shift1[$string] > -1) { my $sign = '#' x $shift1[$string];

  my $vol = $vels{$d}; $vol =~ s/\s*//g; if (length($vol)) { $vol = "_".$vol; }
  my $ctl = $ctls{$d}; $ctl =~ s/\s*//g; if (length($ctl)) { $ctl =~ s/\_+/\_/g; my @tmp = split("_", $ctl); if ($#tmp <= 3) { $tmp[$#tmp+1] = $tmp[$#tmp]; } $ctl = "_".join("_", @tmp); }

  $rval .= sprintf("(b:%s%d$vol$ctl) ", $sign, $string); if ($c < $length) { $dlys{$c} =~ s/\s*//g; if (length($dlys{$c})) { $rval .= sprintf("(%s:%%) ", $dlys{$c}); }}

  $mval .= sprintf("0:%s%d ", $sign, $string);

  $a++; $b--; $c++; if ($rev) { $d--; } else { $d++; }
  }

 }

return($mval.")", $rval."]"); }
#===============================================================================
sub MergeGroove0 {
my $TimeLine0 = ""; if ($#_ >= 0) { $TimeLine0 = shift(@_); } $TimeLine0 =~ s/^\s*//gi; $TimeLine0 =~ s/\s*$//gi; my @Times0 = split(/\s+/, $TimeLine0);
my $TimeLine1 = ""; if ($#_ >= 0) { $TimeLine1 = shift(@_); } $TimeLine1 =~ s/^\s*//gi; $TimeLine1 =~ s/\s*$//gi; my @Times1 = split(/\s+/, $TimeLine1);
my $EvntLine  = ""; if ($#_ >= 0) { $EvntLine  = shift(@_); } $EvntLine  =~ s/^\s*//gi; $EvntLine  =~ s/\s*$//gi; my @Evnts0 = split(/\s+/, $EvntLine );
my $RetVal    = ""; my $cnt = $#Times0; if ($#Times1 > $cnt) { $cnt = $#Times1; } if ($#Evnts0 > $cnt) { $cnt = $#Evnts0; }

my @Evnts1 = @_;

for (my $i=0; $i<=$cnt; $i++) {

 if ($i > $#Times0) { push(@Times0, "."); }
 if ($i > $#Times1) { push(@Times1, "."); }
 if ($i > $#Evnts0) { push(@Evnts0, "."); }
 if ($i > $#Evnts1) { push(@Evnts1, "" ); }

 if ($Times0[$i] =~ /^\.$/) { $Times0[$i] = "";            }
 if ($Times1[$i] =~ /^\.$/) { $Times1[$i] = $Times1[$i-1]; }
 if ($Evnts0[$i] =~ /^\.$/) { $Evnts0[$i] = ">";           }
 if ($Evnts1[$i] =~ /^$/  ) { $Evnts1[$i] = $Evnts1[$i-1]; }

 if (eval($Times1[$i]) == 0) { $RetVal .= sprintf(        "%s:%s%s "                , $Times0[$i],              $Evnts0[$i], $Evnts1[$i]                          ); }
  else                       { $RetVal .= sprintf("%s<:%% -%s:%s%s (%s:%%) +%s<:%% ", $Times0[$i], $Times1[$i], $Evnts0[$i], $Evnts1[$i], $Times1[$i], $Times1[$i]); }
 }

$RetVal =~ s/\s*$//gi; return($RetVal); }
#===============================================================================
sub MergeGroove1 {
my $TimeLine0 = ""; if ($#_ >= 0) { $TimeLine0 = shift(@_); } $TimeLine0 =~ s/^\s*//gi; $TimeLine0 =~ s/\s*$//gi; my @Times0 = split(/\s+/, $TimeLine0);
my $TimeLine1 = ""; if ($#_ >= 0) { $TimeLine1 = shift(@_); } $TimeLine1 =~ s/^\s*//gi; $TimeLine1 =~ s/\s*$//gi; my @Times1 = split(/\s+/, $TimeLine1);
my $EvntLine  = ""; if ($#_ >= 0) { $EvntLine  = shift(@_); } $EvntLine  =~ s/^\s*//gi; $EvntLine  =~ s/\s*$//gi; my @Evnts0 = split(/\s+/, $EvntLine );
my $RetVal    = "";

my @Evnts1 = @_;

for (my $i=0; $i<=$#Times0-2; $i++) {

 if ($i > $#Times0) { push(@Times0, "."); }
 if ($i > $#Times1) { push(@Times1, "."); }
 if ($i > $#Evnts0) { push(@Evnts0, "."); }
 if ($i > $#Evnts1) { push(@Evnts1, "" ); }

 if ($Times0[$i] =~ /^\.$/) { $Times0[$i] = $Times0[$i-1]; } if ($Times0[$i] =~ /^</) { $Times0[$i] .= "<"; }
 if ($Times1[$i] =~ /^\.$/) { $Times1[$i] = $Times1[$i-1]; }
 if ($Evnts0[$i] =~ /^\.$/) { $Evnts0[$i] = ">";           }
 if ($Evnts1[$i] =~ /^$/  ) { $Evnts1[$i] = $Evnts1[$i-1]; }

 $RetVal .= sprintf("[(%s:%%) %s:%s%s] ", $Times0[$i], $Times1[$i], $Evnts0[$i], $Evnts1[$i]);
 }

$RetVal .= sprintf("[%s:%% 0:>] %s:%%", $Times0[$#Times0-1], $Times0[$#Times0]); return("(".$RetVal.")"); }
#===============================================================================
sub MergeGroove2 {
my $TimeLine0 = ""; if ($#_ >= 0) { $TimeLine0 = shift(@_); } $TimeLine0 =~ s/^\s*//gi; $TimeLine0 =~ s/\s*$//gi; my @Times0 = split(/\s+/, $TimeLine0);
my $TimeLine1 = ""; if ($#_ >= 0) { $TimeLine1 = shift(@_); } $TimeLine1 =~ s/^\s*//gi; $TimeLine1 =~ s/\s*$//gi; my @Times1 = split(/\s+/, $TimeLine1);
my $EvntLine  = ""; if ($#_ >= 0) { $EvntLine  = shift(@_); } $EvntLine  =~ s/^\s*//gi; $EvntLine  =~ s/\s*$//gi; my @Evnts0 = split(/\s+/, $EvntLine );
my $RetVal    = "";

my @Evnts1 = @_;

for (my $i=0; $i<=$#Times0-1; $i++) {

 if ($i > $#Times0) { push(@Times0, "."); }
 if ($i > $#Times1) { push(@Times1, "."); }
 if ($i > $#Evnts0) { push(@Evnts0, "."); }
 if ($i > $#Evnts1) { push(@Evnts1, "" ); }

 if ($Times0[$i] =~ /^\.$/) { $Times0[$i] = $Times0[$i-1]; } if ($Times0[$i] =~ /^</) { $Times0[$i] .= "<"; }
 if ($Times1[$i] =~ /^\.$/) { $Times1[$i] = $Times1[$i-1]; }
 if ($Evnts0[$i] =~ /^\.$/) { $Evnts0[$i] = ">";           }
 if ($Evnts1[$i] =~ /^$/  ) { $Evnts1[$i] = $Evnts1[$i-1]; }

 $RetVal .= sprintf("[(%s:%%) %s:%s%s] ", $Times0[$i], $Times1[$i], $Evnts0[$i], $Evnts1[$i]);
 }

$RetVal .= sprintf(" %s:%%", $Times0[$#Times0]); return("(".$RetVal.")"); }
#===============================================================================

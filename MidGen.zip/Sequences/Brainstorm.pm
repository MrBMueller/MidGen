use strict; use warnings; package Brainstorm; return(1);
#===============================================================================
sub InsertPhrase {
my $m  = shift(@_);
my $T  =   0x01; if ($#_ >= 0) { $T   = shift(@_); }
my $t  =      0; if ($#_ >= 0) { $t   = shift(@_); } my ($rv0, $rv1) = (0, 0); if (!defined($T)) { return($rv0, $rv1); }
my $d  =    "."; if ($#_ >= 0) { $d   = shift(@_); }
my $f  =  undef; if ($#_ >= 0) { $f   = shift(@_); } if ($d =~ /\*/) { if ($d =~ /^(.*)[\/\\]\*?(.*)$/) { $d = $1; $f = $2; } else { $f = $d; $d = '.'; } $f =~ s/^\**//; $f =~ s/\**$//; if (!length($f)) { $f = undef; }}
my $q  =   1/64; if ($#_ >= 0) { $q   = shift(@_); }
my $lq =    -$q; if ($#_ >= 0) { $lq  = shift(@_); }
my $lc =      0; if ($#_ >= 0) { $lc  = shift(@_); }
my $p1 =  undef; if ($#_ >= 0) { $p1  = shift(@_); }
my $tr =      0; if ($#_ >= 0) { $tr  = shift(@_); }
my $v0s =     1; if ($#_ >= 0) { $v0s = shift(@_); }
my $v0o =     0; if ($#_ >= 0) { $v0o = shift(@_); }
my $v1s =     1; if ($#_ >= 0) { $v1s = shift(@_); }
my $v1o =     0; if ($#_ >= 0) { $v1o = shift(@_); }
my $plq =     0; if ($#_ >= 0) { $plq = shift(@_); }
my $syc =     1; if ($#_ >= 0) { $syc = shift(@_); }
my $tp  =   0x9; if ($#_ >= 0) { $tp  = shift(@_); }

my $p = undef; opendir(my_dir0, "$d/."); foreach my $fname (sort {$b cmp $a} readdir(my_dir0)) { if ($fname =~ /MyMid(\d+).mid$/i) { $p = $d."/".$fname; if (!defined($f) || ($p =~ /$f/)) { last(); }}} closedir(my_dir0);

if (defined($f) && defined($p) && ($p !~ /$f/)) { $p = undef; }

if (defined($p)) { my %test1 = MIDI::Read($p); if (($test1{-1}{3} != $m->{-1}{3}) || ($test1{-1}{4} != $m->{-1}{4})) { Edit::QuantizeTrk(\%test1, undef, 0, 0, 0, $m->{-1}{4}/$test1{-1}{4}, $m->{-1}{3}); }

 my ($Ts, $Bs, $Ks) = ((sort {$b <=> $a} keys(%test1))[0], -1, -1); if (exists($test1{-1}{5}) && exists($test1{-1}{6})) { $Bs = $test1{-1}{5}/$test1{-1}{6}; } if (exists($test1{-1}{7})) { $Ks = $test1{-1}{7}; }
 #printf("$Bs $Ks\n");

 my ($c1, $k1a, $st0, $st1) = (0, 0, undef, undef); my %sts;
 foreach my $k1 (sort {$a <=> $b} keys %{$test1{$Ts}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$test1{$Ts}{$k1}}) {
   if (($test1{$Ts}{$k1}{$k2}{0} >> 4 == 0xb) && ($test1{$Ts}{$k1}{$k2}{1} == 0x0f) && ($test1{$Ts}{$k1}{$k2}{2} == 0x40)) { $sts{$k1}{$k2}{0} = [$c1, $k1a]; ($c1, $k1a) = (0, 0); } else { $k1a += $k1; $c1++; if (!defined($st1) || ($k1 > $st1)) { $st1 = $k1; }}
   if (($test1{$Ts}{$k1}{$k2}{0} >> 4 == 0x9) && (($k1+$test1{$Ts}{$k1}{$k2}{3}) > $st1)) { $st1 = $k1+$test1{$Ts}{$k1}{$k2}{3}; }
   if (($test1{$Ts}{$k1}{$k2}{0} == 0xff) && ($test1{$Ts}{$k1}{$k2}{1} == 0x03)) { delete($test1{$Ts}{$k1}{$k2}); }
   }
  }

 ($c1, $k1a) = (0, 0);
 foreach my $k1 (sort {$b <=> $a} keys %{$test1{$Ts}}) {
  foreach my $k2 (sort {$b <=> $a} keys %{$test1{$Ts}{$k1}}) {
   if (($test1{$Ts}{$k1}{$k2}{0} >> 4 == 0xb) && ($test1{$Ts}{$k1}{$k2}{1} == 0x0f) && ($test1{$Ts}{$k1}{$k2}{2} == 0x40)) { $sts{$k1}{$k2}{1} = [$c1, $k1a]; ($c1, $k1a) = (0, 0); } else { $k1a += $k1; $c1++; $st0 = $k1; }
   }
  }

 my ($B, $P, $L) = (0, 0, 0); if (exists($m->{-1}{5}) && exists($m->{-1}{6})) { $B = $m->{-1}{5}/$m->{-1}{6}; } if (defined($st0)) { $L = abs($st1-$st0)/($m->{-1}{3}*4); }

 if (scalar(keys(%sts)) >= 2) { $P = (((sort {$b <=> $a} keys(%sts))[0]-(sort {$a <=> $b} keys(%sts))[0]) / (scalar(keys(%sts))-1)) / ($test1{-1}{3}*4); my $st = undef;
  foreach my $k1 (sort {$a <=> $b} keys(%sts)) {
   foreach my $k2 (sort {$a <=> $b} keys(%{$sts{$k1}})) {
    my $a0 = 2; if ($sts{$k1}{$k2}{0}[0]) { $a0 = abs(($k1-$sts{$k1}{$k2}{0}[1]/$sts{$k1}{$k2}{0}[0])/($test1{-1}{3}*4))/$P; }
    my $a1 = 2; if ($sts{$k1}{$k2}{1}[0]) { $a1 = abs(($k1-$sts{$k1}{$k2}{1}[1]/$sts{$k1}{$k2}{1}[0])/($test1{-1}{3}*4))/$P; }
	if (!defined($st) && (($a0 < 2) || ($a1 < .9))) { $st = $k1; if ($a0 < .1) { $test1{$Ts}{$st=$st0}{(sort {$a <=> $b} keys(%{$test1{$Ts}{$st0}}))[0]-1} = $test1{$Ts}{$k1}{$k2}; delete($test1{$Ts}{$k1}{$k2}); }} else { delete($test1{$Ts}{$k1}{$k2}); }
    }
   } %sts = (); if (defined($st)) { $sts{$st}++; }
  }

 if (!scalar(keys(%sts)) && $L && ($plq < 0)) { my $R = abs($plq)/$L;
  Edit::QuantizeTrk(\%test1, undef, 0, 0, 0, $R); $m->{-1}{4} *= $R;
  my $k1 = (sort {$a <=> $b} keys(%{$test1{$Ts}}))[0]; my $k2 = (sort {$a <=> $b} keys(%{$test1{$Ts}{$k1}}))[0];
  $test1{$Ts}{$k1}{$k2-1} = {0=>0xb0, 1=>0x0f, 2=>0x40};
  }

 ($st0, $st1) = (undef, undef);
 foreach my $k1 (sort {$a <=> $b} keys %{$test1{$Ts}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$test1{$Ts}{$k1}}) {
   if (($test1{$Ts}{$k1}{$k2}{0} >> 4 == 0xb) && ($test1{$Ts}{$k1}{$k2}{1} == 0x0f) && ($test1{$Ts}{$k1}{$k2}{2} == 0x40)) { if (!defined($st0)) { $st0 = $k1/($m->{-1}{3}*4); }}
   if (!defined($st1) && (!defined($tp) || (($tp < 0) && (($test1{$Ts}{$k1}{$k2}{0} >> 4) != abs($tp))) || (($tp >= 0) && (($test1{$Ts}{$k1}{$k2}{0} >> 4) == abs($tp)))) && (!defined($p1) || eval($test1{$Ts}{$k1}{$k2}{1}.$p1))) { $st1 = $k1/($m->{-1}{3}*4); }
   }
  }
 if (!defined($st0)) { $st1 = $st0 = 0; } if (!defined($st1)) { $st1 = $st0; }

 $rv0 = $st1-$st0; $rv1 = Edit::Copy($m, $T, \%test1, $Ts, $tp, undef, $p1, 1, $t+$rv0, undef, $tr, $v0s, $v0o, $v1s, $v1o); if (($q != 0) || ($lq != 0)) { Edit::QuantizeTrk($m, $T, $q, $lq, $lc); }

 foreach my $k1 (sort {$a <=> $b} keys %{$m->{$T}}) { my $st0 = 0;
  foreach my $k2 (sort {$a <=> $b} keys %{$m->{$T}{$k1}}) {
   if (($m->{$T}{$k1}{$k2}{0} >> 4 == 0xb) && ($m->{$T}{$k1}{$k2}{1} == 0x0f) && ($m->{$T}{$k1}{$k2}{2} == 0x40)) { if ($st0) { delete($m->{$T}{$k1}{$k2}); } $st0++; }
   }
  }
 } elsif (defined($syc)) { Edit::Seq($m, $syc, $t, 0, 0, " 1/1:Cx0f_.5 "); }

$rv1 += $rv0;

my ($psl, $psc, $psh, undef, undef, undef) = Edit::Quantize($rv0, $plq); if ($plq < 0) { $rv0 = $psc; } if ($plq > 0) { $rv0 = $psl; }
my ($pll, $plc, $plh, undef, undef, undef) = Edit::Quantize($rv1, $plq); if ($plq < 0) { $rv1 = $plc; } if ($plq > 0) { $rv1 = $plh; }

return($rv0, $rv1); }
#===============================================================================

use strict; use warnings; package Style0; if (not(defined(&Tools::GetVarHead))) { eval("use Tools;"); }

if (not(defined($Chord::c))) { eval("use Chord;"); }
if (not(defined($Ctrl::P ))) { eval("use Ctrl;" ); }

return(1);
#===============================================================================
sub Pause { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_); return($l); }
#===============================================================================
sub Var0 { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_); $msk ^= -1;

my $cs = $Chord::c;

my $p12 = Ctrl::PrgChange(12); #'paninaro'
my $p13 = Ctrl::PrgChange(13); #'oh-o-oh'

my $p3  = Ctrl::PrgChange0( 3); #PANBSSNARE
my $p14 = Ctrl::PrgChange0(14); #PETBASSDRUMB

my %SymbolTable1 = ('o'=>"0_$p14", 's'=>"0_.8_$p3"); #%SymbolTable1 = ('o'=>"0_$p14 b:%_Cxa_.1", 's'=>"0_.8_$p3 b:%_Cxa_.9");

my $ps = " |x...|s...|x.8.|s...| "; $ps =~ s/\./>/g; $ps = Edit::PreProc0($ps, \%SymbolTable1);

if ($msk>>1&1) { Edit::Seq($m,  2, undef, undef, undef, $s, $key-0*12, $scale, " 1/8:$k > > 1/16:> 1/8:> 1/4-1/16:> 1/16:> > v ^ ", .6*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>2&1) { Edit::Seq($m,  3, undef, undef, undef, $s, $key+1*12, $scale, " 1/_1_:$k\_$cs ",  .3*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>3&1) { Edit::Seq($m,  4, undef, undef, undef, $s,        55,      0, " 1/16<:0_% $ps ",  1.0*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>4&1) { Edit::Seq($m,  5, undef, undef, undef, $s, $key-0*12,      0, " $p12 3/4:0 $p13 1/4+1/1:> ", 1.0*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }

return($l); }
#===============================================================================
sub BassTrail { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_); #$msk ^= -1;

if ($msk>>1&1) { Edit::Seq($m,  2, undef, undef, undef, $s, $key-0*12, $scale, " <1/4<:% 1/16:2 > 1 > ", .6*$v); }

return($l); }
#===============================================================================
sub Timpani { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_); #$msk ^= -1;

if ($msk>>1&1) { Edit::Seq($m,  7, undef, undef, undef, $s, $key-0*12, $scale, " 1/8:0 1/4:0 1/16:> . 1/2:3 ", 1.0*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }

return($l); }
#===============================================================================

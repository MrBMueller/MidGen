use strict; use warnings; package Examples0; return(1);
#===============================================================================
sub CircleOf5th { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

my $t = " 1/8:. 7{^} "; #1/1 - full 7 tone scale
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-8*7, 2, " 15{0:^4_B ($t)} "); #circle of 5th dur
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60-8*7, 3, " 15{0:^4_B ($t)} "); #circle of 5th moll

return(0); }
#===============================================================================
sub CircleOf5th_Print { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

my $t = " 1/8:> 7{^} "; #1/1 - full 7 tone scale
Edit::Seq($m, 1, undef, undef, undef, $s, 60+0, 2, " (0:b1_B_LDb $t) (0:b-2_B_LAb $t) (0:b2_B_LEb $t) (0:b-1_B_LBb $t) (0:3_B_LF $t) 2(0:0_B_LC $t) (0:4_B_LG $t) (0:1_B_LD $t) (0:_-2_B_LA  $t) (0:_2_B_LE  $t) (0:_-1_B_LB  $t) (0:#3_B_LF# $t) ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x3);
Edit::Seq($m, 2, undef, undef, undef, $s, 60-3, 3, " (0:b1_B_Lbb $t) (0:_-2_B_Lf  $t) (0:_2_B_Lc  $t) (0:_-1_B_Lg  $t) (0:3_B_Ld $t) 2(0:0_B_La $t) (0:4_B_Le $t) (0:1_B_Lb $t) (0:#-2_B_Lf# $t) (0:#2_B_Lc# $t) (0:#-1_B_Lg# $t) (0:#3_B_Ld# $t) ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x0);

return(0); }
#===============================================================================
sub ArpExample1 { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

my $a1 = "1/8:. ^2 ^2 v2"; #1/2
my $a2 = "1/8:. ^3 ^2 v2"; #1/2
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60+0,  3, "2(2($a1) 2($a2) 2(0:v $a1) 2($a1))", 1.0);
$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60+12, 3, "2(2($a1) 2($a2) 2(0:v $a1) 2($a1))", 1.0);

return(0); }
#===============================================================================
sub SeqExample1 { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60, 2, " 1/4:. ^ v ^ |~4( 1{1/4:4 v2 . %} {^ v2 . %} {0 ^ ^ ^} {^ . . %} ) 1/4:0 ^ ^ ^ ");

$s += Edit::Seq($m, 1, undef, undef, undef, $s, 60, 2, "1{1/4:4 v2 . %} {^ v2 . %} {0 ^ ^ ^} {^ . . %} ", 1.0, .5, {0=>-12, 1=>+24}, 0, 10);

$s += Edit::Seq($m, {-1=>1, 0=>2, 1=>3}, undef, undef, undef, $s, 60, 2, "1{1/4:4 v2 . %} {^ v2 . %} {0 ^ ^ ^} {^ . . %} ", 1.0, .5, 0, 0, 0, -0.1, 1/32, 0.8);

return($s); }
#===============================================================================
sub SeqExample2 { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

my $s1 = "1/8:. /2:^7 ."; #1/4
Edit::Seq($m, 4, undef, undef, undef, $s, 60-2*12, 3, " 2{2{4{0:0 $s1}} 4{0:3 $s1} 2{0:-2 $s1} 2{0:-1 $s1}} ", 1.0); #Bass

Edit::Seq($m, 10, undef, undef, undef, $s, 0, 0, " 8{1/4:36 ^2 <1/16:. 1/8:v2 . ^2 %}", {36=>1.0, 38=>0.8}, .5, 0, 0, 0, 0, 1/16, 0.7); #Base/Snare drums
Edit::Seq($m, 10, undef, undef, undef, $s, 0, 0, " 8{4{ 1/16:44 . . 42}} ", {42=>0.9, 44=>0.8, 46=>0.9}); #HighHats

Edit::Seq($m, 3, undef, undef, undef, $s, 60, 3, " 2{ 1:0_Cx47_2_1_0.3_0.5 _Cx47_1_1_0.8 +3_ /2:-2 ^ } ", 1.0, .5, undef, undef); #Pad

Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " 2{ 2:Cx103_2_1_0.0_0.2 2:Cx103_1_1_0.5 } "); #tempo  - works only in trk0

return(0); }
#===============================================================================
sub Pat0 {
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $b = 60; if ($#_ >= 0) { $b = shift(@_); }
my $k =  3; if ($#_ >= 0) { $k = shift(@_); }

#my $seq1 = " |x.4.|x..5|x.5.|x585| ";
my $seq1 = " |x585|x.3.|x.3.|x.3.| ";
$s +=  Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s, 60-12*2, 3, " 0:0   1/16<:% 4( $seq1 ) "); #
$s +=  Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s, 60-12*2, 3, " 0:-1  1/16<:% 1( $seq1 ) "); #
$s +=  Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s, 60-12*2, 3, " 0:-2  1/16<:% 1( $seq1 ) "); #
$s +=  Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s, 60-12*2, 3, " 0:-1  1/16<:% 1( $seq1 ) "); #
$s +=  Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s, 60-12*2, 3, " 0:0   1/16<:% 4( $seq1 ) "); #

Edit::Seq(\%main::out, 0x01, undef, undef, undef, $start, 60, 3, " 4/1:0 1/1:-1 1/1:-2 1/1:-1 4/1:0 ", .3, .5, undef, undef); #goto fin;

Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+7 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+6 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+5 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+4 1/16<:% |....|x>>>|>>>>|>>>>||xx..|x.x.|x...|xx.x||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+3 1/16<:% |....|....|....|....||...x|....|....|....||x>>>|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+2 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|x>>>||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:+1 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:0  1/16<:% |x>>>|....|....|....||....|....|....|....||....|x>>>|....|....||x>>>|>>>>|>>>>|>>>>| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-1 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-2 1/16<:% |....|....|....|....||....|....|....|....||....|....|x>>>|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-3 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-4 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-5 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-6 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);
Edit::Seq(\%main::out, 0x02, undef, undef, undef, $start, 84, 3, " 0:-7 1/16<:% |....|....|....|....||....|....|....|....||....|....|....|....||....|....|....|....| ", .9);

fin: return($s-$start); }
#===============================================================================
sub Pat1 {
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $b = 60; if ($#_ >= 0) { $b = shift(@_); }
my $k =  3; if ($#_ >= 0) { $k = shift(@_); }

$main::out{-1}{4} = 80; 

#percussion
Edit::Seq(\%main::out, 0x0a, undef, undef, undef, $s+0/128, 39, 0, " 1/32<:% 7( |x...|5.5.|x.8.|6.3.| ) "); #HC
Edit::Seq(\%main::out, 0x0a, undef, undef, undef, $s+1/128, 36, 0, " 1/32<:% 7( |x...|....|....|....| ) "); #BD
Edit::Seq(\%main::out, 0x0a, undef, undef, undef, $s+2/128, 35, 0, " 1/32<:% 7( |....|....|8...|....| ) "); #BD (acoustic)

Edit::Seq(\%main::out, 0x01, undef, undef, undef, $s, 60, 3, " 4/2:0 1/2:-3 1/2:-4 1/2:-3 ", .3, .5, undef, undef); #pad

#bass
my $s1 = " 1/32<:% |....|x.9.|8.7.|6.5.| ";
my $s2 = " 1/32<:% |x>..|....|....|....| ";

     Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s+0/128, 60-1*12, 3, " 0:0 4($s1) 0:-3 1($s1) 0:-4 1($s1) 0:-3 1($s1) ", .5); #
$s+= Edit::Seq(\%main::out, 0x08, undef, undef, undef, $s+0/128, 60-2*12, 3, " 0:0 4($s2) 0:-3 1($s2) 0:-4 1($s2) 0:-3 1($s2) ", .5); #

fin: return($s-$start); }
#===============================================================================
sub Var0 { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $b = 60; if ($#_ >= 0) { $b = shift(@_); }
my $k =  3; if ($#_ >= 0) { $k = shift(@_); }

my @crdline = (4/1, 3, 0,  1/1, 3, -7,  1/1, 3, -5,  4/1, 3, 0);

for (my $i = 0; $i <= int($#crdline/3); $i++) {
 $s += Edit::Seq($m, 0x05, undef, undef, undef, $s, 60+$crdline[$i*3+2], $crdline[$i*3+1], " 1/8:> /2:^2 . *2:^2 v2 ", 1,.5, 0,0,0, 0,0,1, 1,1,1,1, $crdline[$i*3+0]);
 }

$s = $start;
for (my $i = 0; $i <= int($#crdline/3); $i++) {
 $s += Edit::Seq($m, 0x08, undef, undef, undef, $s, 60-3*12+$crdline[$i*3+2], $crdline[$i*3+1], " 1/8:> /2:^7 . ", 1,.5, 0,0,0, 0,0,1, 1,1,1,1, $crdline[$i*3+0]);
 }

fin: return($s-$start); }
#===============================================================================
sub GuitarExample { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); }

my $gn = 0; my $notes = 0;
($gn, undef, undef, undef, $notes) = Edit::GetGuitarChord(0, 0);
#$s += Edit::Seq($m, 6, undef, undef, undef, $s, 40+$gn, 8, " 4(1/8:$notes $notes\{v} $notes\{^} $notes\{v} %) 1:% 0:0 $notes\{^} ",1,.5,0,0,0,0,0,1,1,1,1,32);
$s += Edit::Seq($m, 6, undef, undef, undef, $s, 40+$gn, -1, " 4(1/8:$notes $notes\{v} $notes\{^} $notes\{v} %) 1:% 0:0 $notes\{^} ",1,.5,0,0,0,0,0,1,1,1,1,32);

($gn, undef, undef, undef, $notes) = Edit::GetGuitarChord(3, 0);
$s += Edit::Seq($m, 6, undef, undef, undef, $s, 40+$gn, -1, " 4(1/8:$notes $notes\{v} $notes\{^} $notes\{v} %) 1:% 0:0 $notes\{^} ",1,.5,0,0,0,0,0,1,1,1,1,32);

($gn, undef, undef, undef, $notes) = Edit::GetGuitarChord(3, 7);
$s += Edit::Seq($m, 6, undef, undef, undef, $s, 40+$gn, -1, " 4(1/8:$notes $notes\{v} $notes\{^} $notes\{v} %) 1:% 0:0 $notes\{^} ",1,.5,0,0,0,0,0,1,1,1,1,32);

($gn, undef, undef, undef, $notes) = Edit::GetGuitarChord(3, 0);
$s += Edit::Seq($m, 6, undef, undef, undef, $s, 40+$gn, -1, " 4(1/8:$notes $notes\{v} $notes\{^} $notes\{v} %) 1:% 0:0 $notes\{^} ",1,.5,0,0,0,0,0,1,1,1,1,32);

return(0); }
#===============================================================================
sub MergeGrooveExample { my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); }

my $t1 = " 1/8    1/16    1/16 ";
my $e1 = " >_1.0  >_.5    >_.9 ";

my $p1 = Edit::MergeGroove($t1, $e1, '.', '.'); $p1 = "$p1 0:v7 $p1";

Edit::Seq($m, 4, undef, undef, undef, $s , 60-12*1, 3, " 4( 4($p1) 0:v4 2($p1) 0:^ 2($p1) ) ");

return(0); }
#===============================================================================

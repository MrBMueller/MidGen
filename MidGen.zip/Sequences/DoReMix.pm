use strict; use warnings; package DoReMix; return(1);
#===============================================================================
sub InsertPhrase {
my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s; my $PrgChgStart = undef;
my $p =     0; if ($#_ >= 0) { $p = shift(@_); }
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $bnk = undef; if ($#_ >= 0) { $bnk = shift(@_); }
my $pgm = undef; if ($#_ >= 0) { $pgm = shift(@_); }
my $q =    1/64; if ($#_ >= 0) { $q   = shift(@_); }

my %test1 = MIDI::Read($p); Edit::QuantizeTrk(\%test1, undef, $q, -$q, 0, 1, $m->{-1}{3});

if (scalar(keys %test1) > 3) { printf("Info: $p has %d tracks.\n", scalar(keys %test1)-1); }

my $SrcTrk = (sort {$a <=> $b} keys %test1)[2];

while ((not defined($l)) || ($l > 0)) {
 (my $cstart, my $clength) = Edit::Copy($m, $t, \%test1, $SrcTrk, 0x9, undef, undef, 0, $s-1/1, $l); if (not defined($PrgChgStart)) { $PrgChgStart = $cstart; }
 (undef, my $near, undef, undef, undef, undef) = Edit::Quantize($clength, 1/1);
 $s += $near; if (not defined($l)) { $l = 0; } $l -= $near;
 }

MIDI::InsertPrgChg($m, $t, $PrgChgStart, 0, undef, $bnk, $pgm);

return($s-$start); }
#===============================================================================

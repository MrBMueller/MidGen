use strict; use warnings; package Meta;

our $L = "<:%_L"; #lyric
our $M = "<:%_M"; #marker

#usage example
#MidiDebug::WrStr(" $Meta::L\Qtext\E \n");
#MidiDebug::WrStr(" $Meta::M\Qtext\E \n");

return(1);
#===============================================================================

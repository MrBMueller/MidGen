use strict; use warnings; package Ctrl; eval("use GM;");

our $P  = "<:%_C$GM::CCx40\_$GM::CCon";  #sustain pedal on
our $Po = "<:%_C$GM::CCx40\_$GM::CCoff"; #sustain pedal off

our $PanCenter       = "C$GM::CCx0a\_1_0.0";        #center pan

our $PanSwing        = "C$GM::CCx0a\_2_1_0_1";      #free pan swing

our $PanSwingAligned = "C$GM::CCx0a\_2_0_.5_.5_0";  #pan swing aligned to notes

our $NoteOnFadeI     = "Cx101_1_0_0_1";             #linear fade in
our $NoteOfFadeI     = "Cx102_1_0_0_1";             #linear fade in
our $NoteOnFadeO     = "Cx101_1_0_1_0";             #linear fade out
our $NoteOfFadeO     = "Cx102_1_0_1_0";             #linear fade out

return(1);
#===============================================================================
sub BnkChange0 { return("C$GM::eCCx00\_" . shift(@_)/0x3fff); }
#===============================================================================
sub PrgChange0 { return("C$GM::PC\_"     . shift(@_)/0x007f); }
#===============================================================================
sub BnkChange { return("<:%_" . BnkChange0( shift(@_))); }
#===============================================================================
sub PrgChange { return("<:%_" . PrgChange0(shift(@_))); }
#===============================================================================
sub PatchChange { return(PrgChange($_[1]) . " " . BnkChange($_[0])); }
#===============================================================================
sub Fade { my ($m, $s, $l) = (shift(@_), shift(@_), shift(@_));
my $c = 0x101; if ($#_ >= 0) { $c = shift(@_); }
my $f =     1; if ($#_ >= 0) { $f = shift(@_); }

if (not(defined($s))) { $s = MIDI::GetStartTime($m, undef)/($m->{-1}{3}*4); if ($l < 0) { $s = MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4); }}

my ($d, $v) = ('', '0_1'); if ($l < 0) { ($d, $v, $l) = ('<', '1_0', abs($l)); }

if (($c >= 0x304) && ($c <= 0x3fff) || ($c == 0x103))
      {                                                          Edit::Seq($m, 0 , $s, 0, 0, " $d$l:%_C$c\_$f\_0_$v ");   }
 else { foreach (sort {$a <=> $b} keys(%{$m})) { if ($_ != -1) { Edit::Seq($m, $_, $s, 0, 0, " $d$l:%_C$c\_$f\_0_$v "); }}}

return(0); }
#===============================================================================

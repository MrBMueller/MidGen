use strict; use warnings; package Guitar;

use constant { x=>-1, X=>-1, o=>0, O=>0 };

#6/12-string guitar tablatures (front view: neck up, corpus down)
#physical             top            bot   -- (if neck left / corpus right)
#freq                 bass          treble
#                      E  A  D  G  B  E
#                      0  1  2  3  4  5
our %Tabs = (-1=>{ 0=>[x, x, x, x, x, x]},
              0=>{ 0=>[0, 0, 0, 0, 0, 0]},

              2=>{ 0=>[x, 3, 2, 0, 1, 0],
                   1=>[x, 4, 3, 1, 2, 1],
                   2=>[x, x, 0, 2, 3, 2],
                   3=>[x, x, 1, 3, 4, 3],
                   4=>[0, 2, 2, 1, 0, 0],
                   5=>[1, 3, 3, 2, 1, 1],
                   6=>[2, 4, 4, 3, 2, 2],
                   7=>[3, 2, 0, 0, 0, 3],
                   8=>[4, 6, 6, 5, 4, 4],
                   9=>[x, 0, 2, 2, 2, 0],
                  10=>[x, 1, 3, 3, 3, 1],
                  11=>[x, 2, 4, 4, 4, 2]},

              3=>{ 0=>[x, 3, 5, 5, 4, 3],
                   1=>[x, 4, 6, 6, 5, 4],
                   2=>[x, x, 0, 2, 3, 1],
                   3=>[x, x, 1, 3, 4, 2],
                   4=>[0, 2, 2, 0, 0, 0],
                   5=>[1, 3, 3, 1, 1, 1],
                   6=>[2, 4, 4, 2, 2, 2],
                   7=>[3, 1, 0, 0, 3, 3],
                   8=>[4, 6, 6, 4, 4, 4],
                   9=>[x, 0, 2, 2, 1, 0],
                  10=>[x, 1, 3, 3, 2, 1],
                  11=>[x, 2, 4, 4, 3, 2]},

              5=>{ 0=>[x, 3, 4, 5, 4, x],  #Cdim
                   1=>[x, 4, 5, 6, 5, x],  #C#
                   2=>[x, x, 0, 1, 3, 1],  #D
                   3=>[x, x, 1, 2, 4, 2],  #D#
                   4=>[0, 1, 2, 0, x, x],  #E
                   5=>[1, 2, 3, 1, 0, x],  #F
                   6=>[2, 3, 4, 2, x, x],  #F#
                   7=>[x, x, 5, 3, 2, 3],  #G
                   8=>[x, x, 6, 4, 3, 4],  #G#
                   9=>[x, 0, 1, 2, 1, x],  #A
                  10=>[x, 1, 2, 3, 2, 0],  #A#
                  11=>[x, 2, 3, 4, 3, x]}, #B

              6=>{ 0=>[x, x, x, x, x, x],
                   1=>[x, x, x, x, x, x],
                   2=>[x, x, x, x, x, x],
                   3=>[x, x, x, x, x, x],
                   4=>[x, x, x, x, x, x],
                   5=>[x, x, x, x, x, x],
                   6=>[x, x, x, x, x, x],
                   7=>[x, x, x, x, x, x],
                   8=>[x, x, x, x, x, x],
                   9=>[x, x, x, x, x, x],
                  10=>[x, x, x, x, x, x],
                  11=>[x, x, x, x, x, x]}
);

return(1);
#===============================================================================
sub Chord {
my $key0 = 0;  if ($#_ >= 0) { $key0 = shift(@_); }
my $note = 0;  if ($#_ >= 0) { $note = shift(@_); } if (defined($note)) { if ($note < 0) { $note = 12-(abs($note)%12); } $note = $note % 12; }
my $rev  = 0;  if ($#_ >= 0) { $rev  = shift(@_); } #play reverse
my $vel  = ''; if ($#_ >= 0) { $vel  = shift(@_); }
my $dly  = ''; if ($#_ >= 0) { $dly  = shift(@_); }
my $TrkLt  = undef; if (($#_ >= 0) && (ref($_[0]) =~ /HASH/i)) { $TrkLt = shift(@_); }
my ($rval, $mval) = ("", "");

if (not(exists($Guitar::Tabs{$key0}))) { $key0 = -1; }

my @shift1 = (); if (ref($key0) =~ /ARRAY/i) { @shift1 = @{$key0}; } else { @shift1 = @{$Guitar::Tabs{$key0}{$note%scalar(keys(%{$Guitar::Tabs{$key0}}))}}; }

my @vels; if (ref($vel) =~ /ARRAY/i) { @vels = @{$vel}; } else { for (my $i=0; $i<=$#shift1; $i++) { push(@vels, $vel); }}
my @dlys; if (ref($dly) =~ /ARRAY/i) { @dlys = @{$dly}; } else { for (my $i=0; $i<=$#shift1; $i++) { push(@dlys, $dly); }}

my ($v0, $v1) = ($vels[0], $vels[$#vels]); $v0 = eval($v0); $v1 = eval($v1); if (not(defined($v0))) { $v0 = 1; } if (not(defined($v1))) { $v1 = 1; }
my ($d0, $d1) = ($dlys[0], $dlys[$#dlys]); $d0 = eval($d0); $d1 = eval($d1); if (not(defined($d0))) { $d0 = 1; } if (not(defined($d1))) { $d1 = 1; }

for (my $i=0; $i<=$#vels; $i++) { $vels[$i] =~ s/\s*//g; if (length($vels[$i])) { $vels[$i] = "_".$vels[$i]; }}
for (my $i=0; $i<=$#dlys; $i++) { $dlys[$i] =~ s/\s*//g; }

for (my $i=0; $i<=$#shift1; $i++) { if (not(defined($shift1[$i]))) { $shift1[$i] = -1; } if ($shift1[$i] <= -1) { if ($rev) { if ($v0 > $v1) { pop(@vels); } if ($d0 > $d1) { pop(@dlys); }}}}

my @Strings; my @Signs; my @Vels; my @Dlys; my @DlyAcc = ("");
for (my $i=0; $i<=$#shift1; $i++) { if ($shift1[$i] > -1) {
 if (!$rev) { push(@Strings,         $i ); } else { unshift(@Strings,         $i ); }
 if (!$rev) { push(@Signs  , $shift1[$i]); } else { unshift(@Signs  , $shift1[$i]); }
 #if (!$rev) { unshift(@Vels, pop(@vels)); unshift(@Dlys, pop(@dlys)); } else { push(@Vels, pop(@vels)); push(@Dlys, pop(@dlys)); }
 #if (!$rev) { push(@Vels, shift(@vels)); push(@Dlys, shift(@dlys)); } else { unshift(@Vels, shift(@vels)); unshift(@Dlys, shift(@dlys)); }
 unshift(@Vels, pop(@vels)); unshift(@Dlys, pop(@dlys));
 push(@DlyAcc, sprintf("%s+%s", $DlyAcc[$#DlyAcc], $Dlys[$#Dlys]));
 }}
pop(@DlyAcc);

foreach (@Strings) { my ($string, $sign, $vel, $dly, $DlyAcc) = ($_, shift(@Signs), pop(@Vels), pop(@Dlys), pop(@DlyAcc));

 my $Trk = ""; if (exists($TrkLt->{$_})) { $Trk = sprintf("_t%d", $TrkLt->{$_}); }
 $rval .= sprintf("(b:%d%s%s%s) ", $_, '#' x $sign, $Trk, $vel); if (($#Signs >= 0) && (length($dly))) { $rval .= sprintf("(%s:%%) ", $dly); }
 $mval .= sprintf( "0:%d%s%s "   , $_, '#' x $sign, $Trk);
 }

return("( ".$mval.")", "_% [ ".$rval."]"); }
#===============================================================================

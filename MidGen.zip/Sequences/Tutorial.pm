use strict; use warnings; package Tutorial; return(1);
#===============================================================================
sub Example1 {
my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $b = 60; if ($#_ >= 0) { $b = shift(@_); }

my $ChordType0 = "(<:> <:^2 ^2)"; #micro sequence
my $ChordType1 = "(b:^2 b:^2)";
my $t = "(1/8:> 7{^})"; #micro sequence

my @Sequences = (

#general
" 1/1:0 ", "single event",

" 1/1:0 1/1:1 1/2:2 1/2:3 1/4:4 1/4:5 1/8:6 1/8:7 ", "sequence example",
" 1/1:0 1 1/2:2 3 1/4:4 5 1/8:6 7 ", "time can be omitted if it doesnt change between consecutive events",

#basics
" 1/4:0 1 2 3 4 5 6 7 ", "absolute notation using numbers",
" 1/4:0 -1 -2 -3 -4 -5 -6 -7 ", "negative numbers are allowed",
" 1/4:0 ^7 v6 ^5 v4 ^3 v2 ^ ", "relative up ^ and down v notation",
" 1/4:0 ^0 v0 > ", "relative zero notation (^0 = v0 = >)",
" 1/4:0 % 1 % 2 % 3 % ", "rest notation %",
" 1/4:0 b1 2 #3 #4 5 b6 7 ",     "flats and sharps using b and #",
" 1/4:0 bb1 2 ##3 ##4 5 bb6 7 ", "multiple flats and sharps",

#repeats
" 1/4:0 ^ . . 7 v . . ", "atomic note repeat",
" 1/4:0 ^ = = 7 v = = ", "atomic operation repeat",

" 2{ 1/4:0 1 2 3 } ",        "sequence repeat expansion",
" 1/4:0 1 3{ 2 3 } ",        "sequence repeat expansion",

" 1/4:0 1 3{ ^ ^ } ",     "sequence repeat expansion",
" 1/4:0 1 3( ^ ^ ) ",     "sequence true repeat notation",

" 2(1/4:0 1 3( ^ ^ )) ",     "nested expansions and repeats",

#loops
" [1/1:0] [1/2:^2] ^2 ",     "go back in time",
" [1/1:0] 2[^2] ",     "sequence looping",

#misc.
" 1/1:0 1/2:^ 1/4:^ 1/8:^ 1/16:^ 1/32:^ ",     "regular timing notation using fractions",
" 1:0 .5:^ .25:^ .125:^ 1/16:^ 1/32:^ ",     "timing notation using floating point values",
" 1/2+:0 ",     "extended timing (dotted notes)",
" 1/2+1/4:0 ",     "",
" 1/1+1/2:0 ",     "timing notation using equations",
" 3{ 1/3:0 } ",     "3x1/3 = triplets",

" 1/2++:0 ",     "time extension (multiple dots)",
" 1/2+1/4+1/8:0 ",     "",
" 1/1--:0 ",     "time reduction",
" 1/1-1/2-1/4:0 ",     "",
" (3{2/2/3:^}) (3{2/4/3:^}) (3{2/8/3:^}) (3{2/16/3:^}) ",     "triplet notation using repeats and time equations",
" 1/1:0 % 1/2:^ % 1/4:^ % 1/8:^ % 1/16:^ % 1/32:^ % ",     "timing notation with pauses",

" 1/4+:0 |1/1:^ ",     "time alignment",
" 1/4+:^ |1/2:% 1/8+:^ |2/1:% 1/2+:^ ",     "",

" 1/1:0 1/2<:^ 1/4:^4 ",     "going back in time after event got inserted",
" 1/1:0 <1/2:^ 1/4:^4 ",     "going back in time before event get inserted",
" 1/1:0 <1/2<:^ 1/4:^4 ",    "going back in time before and after event",
" 1/1:0 <<:^ 1/4:^4 ",       "going back in time before and after event",
" 1/1:0 r:^ 1/4:^4 ",        "shortcut if time doesnt change",

" 1/1:0 1/1<:^2 1/4:^4 ",     "going back in time after event got inserted",
" 1/1:0 <:^2 1/4:^4 ",        "shortcut if time doesnt change",
" 1/1:0 <1/1:^2 1/4:^4 ",     "going back in time before event get inserted",
" 1/1:0 b:^2 1/4:^4 ",        "shortcut if time doesnt change",

" 1/1<:0 1/1<:^2 1/1:^2 ",     "chord using post-backtimes",
" 1/1:0 <1/1:^2 <1/1:^2 ",     "chord using pre-backtimes",
" 1/1<:0 <:^2 ^2 ",     "chord using post-backtime shortcuts",
" 1/1:0 b:^2 b:^2 ",    "chord using pre-backtime shortcuts",

" 1/1<:0_% $ChordType0 1/2<:^4_% $ChordType0 1/2<:^2_% $ChordType0 ",     "chord notation usage model1",
" 1/1:0 $ChordType1 1/2:^4 $ChordType1 1/2:^2 $ChordType1 ",              "chord notation usage model2",

" 1/4:0_1.0 ^ ^_*.25 ^ ^_*2.5 ^ ^_.5 ^ ",     "velocity control (set, damp or boost)",
" | (3/4 4(1/4:^ ^ ^) | 2/4 2(1/4:^ ^)) | 1/4:0 ^ ^ ^ | ",     "visual bars | and time signatures",

" (0_B_S2 ($t) -2_B_S3 ($t)) ",     "scale and key signatures1",
" (1_B_S2 ($t) #2_B_S3 ($t)) ",     "scale and key signatures2",
);

for (my $i=0; $i<=int($#Sequences/2); $i++) {
 if (length($Sequences[$i*2+1])) { MIDI::InsertText($m, 0x00, $s, 0, $Sequences[$i*2+1]); }
 $s += Edit::Seq($m, 1, undef, undef, undef, $s, 60, 2, $Sequences[$i*2+0], 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x7); #
 (undef, undef, $s, undef, undef, undef) = Edit::Quantize($s, 1/1); $s += 1/1;
 }

fin: return($s-$start); }
#===============================================================================
sub Scales {
my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $b = 60; if ($#_ >= 0) { $b = shift(@_); }

my $up = "1/4:0 ^ ^ ^ ^ ^ ^ ^ "; my $down = "> v v v v v v v";

my @Sequences = (

60+0, 0, " 1/4:0 12{^} ", "12 tone chromatic",

60+0, 1, " 1/4:0 2{^} ", "quints",

60+0, 2, " $up ", "major",
60+0, 3, " $up ", "minor",

60+0, 4, " $up $down ", "minor melodic",

60+0, 5, " $up ", "minor harmonic",
60+0, 6, " $up ", "minor gypsy/arabic",

60+0, 7, " 1/2:0 ^ ", "oct",

60+4, 8, " 1/8:0 ^ ^ ^ ^ ^  ", "6 string guitar",

60+0, 9, " 1/8:0 ^ ^ ^ ^ ^  ", "pentatonic major",
60+0,10, " 1/8:0 ^ ^ ^ ^ ^  ", "pentatonic minor",
);

for (my $i=0; $i<=int($#Sequences/4); $i++) {
 if (length($Sequences[$i*4+3])) { MIDI::InsertText($m, 0x00, $s, 0, $Sequences[$i*4+3]); }
 $s += Edit::Seq($m, 1, undef, undef, undef, $s, $Sequences[$i*4+0], $Sequences[$i*4+1], $Sequences[$i*4+2], 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x7); #
 (undef, undef, $s, undef, undef, undef) = Edit::Quantize($s, 1/1); $s += 1/1;
 }

fin: return($s-$start); }
#===============================================================================
sub InsertTextTestCase {
my $m = shift(@_);
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

MIDI::InsertText($m, 0x01, $s, 1, "1st", 0x05); #1st
MIDI::InsertText($m, 0x01, $s, 1, "2nd", 0x05); #2nd
MIDI::InsertText($m, 0x01, $s, 1, "3rd", 0x05); #3rd

MIDI::InsertText($m, 0x01, $s, 0, "Append1st", 0x05, "_"); #append to 1st
MIDI::InsertText($m, 0x01, $s, 1, "AppendLast", 0x05, "_"); #append to last

fin: return($s-$start); }
#===============================================================================
sub Regr0 { #check limit with overlap events
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 3, " 2/1<:0 1/4:% 2/1<:^2 1/4:% 2/1:^2 <2/4<:% ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, 3/1, 0x3); #

return($s-$start); }
#===============================================================================
sub Regr1 { #going back in time with overlap events
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, $t, undef, undef, undef, $s+10/1, 60, 3, " <2/1:0 <1/4<:% <2/1:^2 <1/4<:% <2/1:^2 ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x3); #

return($s-$start); }
#===============================================================================
sub Regr2 { #check individual note length correction
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 0, " 1/4:0 11{^} ", 1.0, .5, 0,0,0,0,0,1,1,1,1, {60=>1.0, 61=>.5, 62=>-1/32, 63=>-1/16, 64=>2.0}, undef, 0x3); #

return($s-$start); }
#===============================================================================
sub Regr3 { #check inversion and direction bounce
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/4:. ^ v ^ |~4( 1{1/4:4 v2 . %} {^ v2 . %} {0 ^ ^ ^} {^ . . %} ) 1/4:0 ^ ^ ^ ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x7); #

return($s-$start); }
#===============================================================================
sub Regr4 { #switch controller + set controller values
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

my $PedOff = "C64"; my $PedOn = "C64_1";
my $PanLeft = "Cxa_1_-1.0"; my $PanCenter = "CxA_1_0.0"; my $PanRight = "C10_1_1.0";

$s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 2*4(1/4:0_$PedOn 1/4:0_$PedOff) ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x3); #
$s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 16(1/8:0_$PanLeft 0_$PanCenter 0_$PanRight 0_$PanCenter) ", 1.0, .5, 0,0,0,0,0,1,1,1,1, 1, undef, 0x3); #

return($s-$start); }
#===============================================================================
sub Regr5 { #check portamento
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

MIDI::InsertText($m, 0x00, $s, 0, "-2 push    "); $s += Edit::Seq($m, $t+0, undef, undef, 73, $s, 60+1*12, 2, "| 1/4:4 v2 *2:. | /2:^ v2 *2:. | /2:0 ^ ^ ^ | ^ . *2:. |") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "-1 pull    "); $s += Edit::Seq($m, $t+1, undef, undef, 73, $s, 60+1*12, 2, "| 1/4:4 v2 *2:. | /2:^ v2 *2:. | /2:0 ^ ^ ^ | ^ . *2:. |") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, " 0 flat    "); $s += Edit::Seq($m, $t+2, undef, undef, 73, $s, 60+1*12, 2, "| 1/4:4 v2 *2:. | /2:^ v2 *2:. | /2:0 ^ ^ ^ | ^ . *2:. |") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, " 1 melt    "); $s += Edit::Seq($m, $t+3, undef, undef, 73, $s, 60+1*12, 2, "| 1/4:4 v2 *2:. | /2:^ v2 *2:. | /2:0 ^ ^ ^ | ^ . *2:. |") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, " 2 melt all"); $s += Edit::Seq($m, $t+4, undef, undef, 73, $s, 60+1*12, 2, "| 1/4:4 v2 *2:. | /2:^ v2 *2:. | /2:0 ^ ^ ^ | ^ . *2:. |") + 1/1; #

#portamento modi (-2 push to note, -1 pull to note, 0 flat notes without melting, 1 flat/melt notes but keep equals seperate, 2 flat/melt all notes)
$main::trks{$t+0}{0x4000} = Edit::Portamento($m, 1+0, 1/16, -2, undef, undef, 0x104, 4);
$main::trks{$t+1}{0x4000} = Edit::Portamento($m, 1+1, 1/16, -1, undef, undef, 0x104, 4);
$main::trks{$t+2}{0x4000} = Edit::Portamento($m, 1+2, 1/16,  0, undef, undef, 0x104, 4);
$main::trks{$t+3}{0x4000} = Edit::Portamento($m, 1+3, 1/16,  1, undef, undef, 0x104, 4);
$main::trks{$t+4}{0x4000} = Edit::Portamento($m, 1+4, 1/16,  2, undef, undef, 0x104, 4);

#$main::trks[$t+1][12] = Edit::Portamento($m, 1+0, 1/16, -2, undef, undef, 0x104, 4);
#$main::trks[$t+2][12] = Edit::Portamento($m, 1+1, 1/16, -1, undef, undef, 0x104, 4);
#$main::trks[$t+3][12] = Edit::Portamento($m, 1+2, 1/16,  0, undef, undef, 0x104, 4);
#$main::trks[$t+4][12] = Edit::Portamento($m, 1+3, 1/16,  1, undef, undef, 0x104, 4);
#$main::trks[$t+5][12] = Edit::Portamento($m, 1+4, 1/16,  2, undef, undef, 0x104, 4);

return($s-$start); }
#===============================================================================
sub Regr6 { #cont. controller
my $m = shift(@_);
my $t =  1; if ($#_ >= 0) { $t = shift(@_); }
my $s =  0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

MIDI::InsertText($m, 0x00, $s, 0, "linear up                      "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__1_1_-1__1 ") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "linear down                    "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__1_1__1_-1 ") + 1/1; #

MIDI::InsertText($m, 0x00, $s, 0, "sinus, full swing positive     "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__2_1__0__1 ") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "sinus, full swing negative     "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104_-2_1__0__1 ") + 1/1; #

MIDI::InsertText($m, 0x00, $s, 0, "sinus, half swing positive     "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__3_1__0__1 ") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "sinus, half swing negative     "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104_-3_1__0__1 ") + 1/1; #

MIDI::InsertText($m, 0x00, $s, 0, "half sinus up                  "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__4_1_-1__1 ") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "half sinus down                "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__4_1__1_-1 ") + 1/1; #

MIDI::InsertText($m, 0x00, $s, 0, "sigmoid up                     "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__5_1_-1__1 ") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "sigmoid down                   "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__5_1__1_-1 ") + 1/1; #

MIDI::InsertText($m, 0x00, $s, 0, "sinus, neg. offset, half swing "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__2_1__-.5__.5 ") + 1/1; #
MIDI::InsertText($m, 0x00, $s, 0, "sinus, neg. offset, inverted   "); $s += Edit::Seq($m, $t, undef, undef, undef, $s, 60, 2, " 1/1:0_Cx104__2_1__-.5_-.5 ") + 1/1; #

return($s-$start); }
#===============================================================================
sub Regr7 { #cont. controller part ii
my $m = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); }

Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 32( 1/1:Cx40 ) "); #ctl w/o param - set to non-centered 0

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 32( 1/1:Cx40_1 Cx40_0 ) "); #ctl with one param - set to non-centered value

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 32( 1/1:Cx0a_1_0 ) "); #ctl with two params - center, value

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 0:Cx0a_1_1_0 1/1:Cx0a_1_1_1 1/2:Cx0a_1_1_0 1/4:Cx0a_1_1_-1 "); #ctl with 3 params - pwl

#Fn1 linear
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__1_0_0_1 ) "); #linear non-centered full swing
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_-1_0_0_1 ) "); #linear non-centered invers full swing

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_1_1_0__1 ) "); #linear centered half swing up
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_1_1_0_-1 ) "); #linear centered half swing down

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_-1_1_0__1 ) "); #linear centered inverse half swing up
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_-1_1_0_-1 ) "); #linear centered inverse half swing down

#Fn2 full sinus [0,2pi]
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__2_0_.5_.5 ) "); #sinus non-centered full swing (offset .5, amp .5)
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_-2_0_.5_.5 ) "); #sinus non-centered inverse full swing (offset .5, amp .5)

#Fn3 half sin [0,pi]
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__3_0_0_1 ) "); #half sinus non-centered full swing
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a_-3_0_0_1 ) "); #half sinus non-centered inverse full swing

#Fn4 half sin [-pi/2,pi/2]
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__4_0_0_1 ) "); #half sinus non-centered full swing up
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__4_0_1_0 ) "); #half sinus non-centered full swing down

#sigmoid
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__5_0_0_1 ) "); #sigmoid non-centered full swing up
#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( 1/1:Cx0a__5_0_1_0 ) "); #sigmoid non-centered full swing down

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( Mup 1/1:Cx0a__5_0_0_1 Mdown Cx0a__5_0_1_0 ) "); #sigmoid non-centered full swing up/down

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8( Mup 1/1:Cx0a__5_0_0_1_0 Mdown Cx0a__5_0_1_0_0 ) "); #sigmoid non-centered full swing up/down aligned

return(0); }
#===============================================================================

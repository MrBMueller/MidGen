use strict; use warnings; package Arpeggio; eval("use Interval;");

our $a = "_> (^$Interval::Third ^$Interval::Third v$Interval::Third)";

our $a0 = "_% (r:% 2(/8:> ^$Interval::Third ^$Interval::Third v$Interval::Third))";

our $a1 = "_% (r:% 4(/8:> /2:^$Interval::Octave .))";

our $a0ii = "_% (r:% 2(/8:v$Interval::Sixth ^$Interval::Third ^$Interval::Fourth v$Interval::Fourth))";

our $a7 = "_% (r:% 2(/8:> ^$Interval::Fifth ^$Interval::Third v$Interval::Third))";

return(1);
#===============================================================================

use strict; use warnings; package Style0; if (not(defined(&Tools::GetVarHead))) { eval("use Tools;"); }

if (not(defined($Chord::c     ))) { eval("use Chord;"     ); }
if (not(defined($Arpeggio::a  ))) { eval("use Arpeggio;"  ); }
if (not(defined($Bass::b      ))) { eval("use Bass;"      ); }
if (not(defined($Percussion::p))) { eval("use Percussion;"); }

return(1);
#===============================================================================
sub Pause { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_); return($l); }
#===============================================================================
sub Var0 { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_);

my %SymbolTable = ('o'=>$Chord::c, 'v'=>'.8_> (b:^2 b:^2-1)', '^'=>'.8_> (b:^2 b:^2+1)');

my $cs = $Chord::c;
my $as = $Arpeggio::a;
my $bs = $Bass::b;
my $ps = $Percussion::p;
my $rs = " |x.x8|x..^|x.8.|x..v| "; $rs =~ s/\./>/g; $rs = Edit::PreProc0($rs, \%SymbolTable);

if ($msk>>0&1) { Edit::Seq($m,  1, undef, undef, undef, $s, $key-0*12, $scale, " 1/_8_:$k\_$as ", 1.0*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }
if ($msk>>1&1) { Edit::Seq($m,  2, undef, undef, undef, $s, $key-2*12, $scale, " 1/_8_:$k\_$bs ",  .5*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }
if ($msk>>2&1) { Edit::Seq($m,  3, undef, undef, undef, $s, $key-0*12, $scale, " 1/_1_:$k\_$cs ",  .3*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }
if ($msk>>3&1) { Edit::Seq($m,  4, undef, undef, undef, $s, $key-0*12, $scale, " 1/16<:$k\_% $rs ", .2*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }
if ($msk>>9&1) { Edit::Seq($m, 10, undef, undef, undef, $s,    0     ,      0, " 1/_4_:____$ps ",  .2*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,-1/16, $l); }

return($l); }
#===============================================================================
sub Var1 { my ($m, $s, $l, $k, $msk, $key, $scale, $v) = Tools::GetVarHead((caller(0))[3], @_);

my $cs = $Chord::c;

if ($msk>>0&1) { Edit::Seq($m,  1, undef, undef, undef, $s, $key-1*12, $scale, " 1/32:% 2/1:$k\_$cs ", 1.0*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }
if ($msk>>0&1) { Edit::Seq($m,  1, undef, undef, undef, $s, $key-0*12, $scale, " 1/16:% 2/1:$k\_$cs ", 1.0*$v, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, $l); }

return($l); }
#===============================================================================

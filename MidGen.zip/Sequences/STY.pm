use strict; use warnings; use MIDI; package STY;

our ($f, $Entry, $First, $Exit, %test1, %Marker, @k1s, %t2i, %Patches, %CASM) = ('', undef, undef, undef, (), (), (), (), (), ());

return(1);
#===============================================================================
sub Read { my ($m, $f) = @_;

($STY::f, %STY::test1, %STY::Marker) = ($f, (), ()); my %test0 = MIDI::Read($STY::f); %STY::CASM = STY::ReadCASM(\%test0);

if ( not(exists($m->{-1}{3})) || not(defined($m->{-1}{3}))                          ) { $m->{-1}{3} = $test0{-1}{3}; }
if ((not(exists($m->{-1}{4})) || not(defined($m->{-1}{4}))) && exists($test0{-1}{4})) { $m->{-1}{4} = $test0{-1}{4}; }
if ((not(exists($m->{-1}{5})) || not(defined($m->{-1}{5}))) && exists($test0{-1}{5})) { $m->{-1}{5} = $test0{-1}{5}; }
if ((not(exists($m->{-1}{6})) || not(defined($m->{-1}{6}))) && exists($test0{-1}{5})) { $m->{-1}{6} = $test0{-1}{6}; }

if (exists($m->{-1}{4}) && (($test0{-1}{3} != $m->{-1}{3}) || ($test0{-1}{4} != $m->{-1}{4}))) { Edit::QuantizeTrk(\%test0, undef, 0, 0, 0, $m->{-1}{4}/$test0{-1}{4}, $m->{-1}{3}); }

foreach my $k0 (sort {$a <=> $b} keys(%test0)) { if ($k0 == -1) { next(); } ($Patches{$k0}{0}, $Patches{$k0}{1}, $Patches{$k0}{2}) = (-1, -1, -1);
 foreach my $k1 (sort {$a <=> $b} keys(%{$test0{$k0}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$test0{$k0}{$k1}})) { %{$test1{$k1}{$k0}} = %{$test0{$k0}{$k1}}; }
  }
 }

my ($MarkerCnt, $cMarker) = (-1, ''); $Marker{$MarkerCnt}{$cMarker}{0} = $Entry = (sort {$a <=> $b} keys(%test1))[0]; $Exit = (sort {$b <=> $a} keys(%test1))[0];

foreach my $k1 (sort {$a <=> $b} keys(%test1)) {
 foreach my $k0 (sort {$a <=> $b} keys(%{$test1{$k1}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$test1{$k1}{$k0}})) {

   if ($test1{$k1}{$k0}{$k2}{0} == 0xff) {

    if ($test1{$k1}{$k0}{$k2}{1} <= 0x07) { my ($txt, $i) = ('', 2); while (exists($test1{$k1}{$k0}{$k2}{$i}) && $test1{$k1}{$k0}{$k2}{$i}) { $txt .= chr($test1{$k1}{$k0}{$k2}{$i++}); }
	 foreach my $k3 (sort {$a <=> $b} keys(%{$test1{$k1}{$k0}{$k2}})) { if ($k3 >=2) { delete($test1{$k1}{$k0}{$k2}{$k3}); }}
	 $txt =~ s/^\s*//gi; $txt =~ s/\s*$//gi; $txt =~ s/\s+/ /g; my @tmp0 = split('', $txt); for (my $i=0; $i<=$#tmp0; $i++) { $test1{$k1}{$k0}{$k2}{$i+2} = ord($tmp0[$i]); }
 
	 if ($test1{$k1}{$k0}{$k2}{1} == 0x06) {
	  $Marker{$MarkerCnt}{$cMarker}{1} = $k1; $MarkerCnt++; $cMarker = $txt; #printf("$txt\n");
      $Marker{$MarkerCnt}{$cMarker}{0} = $k1;
	  if (not(defined($First)) && $k1 > $Entry) { $First = $k1; }
      }

	 }
	}

   if ((($test1{$k1}{$k0}{$k2}{0} >> 4) == 0xb) && ($test1{$k1}{$k0}{$k2}{1} == 0x00)) { $Patches{$k0}{0} = $test1{$k1}{$k0}{$k2}{2}; }
   if ((($test1{$k1}{$k0}{$k2}{0} >> 4) == 0xb) && ($test1{$k1}{$k0}{$k2}{1} == 0x20)) { $Patches{$k0}{1} = $test1{$k1}{$k0}{$k2}{2}; }
   if ((($test1{$k1}{$k0}{$k2}{0} >> 4) == 0xc)                                      ) { $Patches{$k0}{2} = $test1{$k1}{$k0}{$k2}{1}; }

   if ((($test1{$k1}{$k0}{$k2}{0} >> 4) == 0x9) && (($k1 + $test1{$k1}{$k0}{$k2}{3}) > $Exit)) { $Exit = $k1 + $test1{$k1}{$k0}{$k2}{3}; }
   }
  }
 }

$Marker{$MarkerCnt}{$cMarker}{1} = $Exit; if (defined($Exit) && not(exists($test1{$Exit}))) { %{$test1{$Exit}{0}{0}} = (0=>0xff, 1=>0x06, 2=>0x45, 3=>0x4f, 4=>0x46); }

@STY::k1s = sort {$a <=> $b} keys(%STY::test1); for (my $i=0; $i<=$#STY::k1s; $i++) { $STY::t2i{$STY::k1s[$i]} = $i; }

return(0); }
#===============================================================================
sub CopyMarker { my ($m, $t, $f, $Marker, $Label, $NTT) = @_; my $s = $t;

if (defined($f)) { STY::Read($m, $f); }

my ($L, $R) = (undef, undef);
if (defined($Marker) && length($Marker)) { $Marker =~ s/^\s*//g; $Marker =~ s/\s*$//g; $Marker =~ s/\s+/ /g;
 foreach my $c (sort {$a <=> $b} keys(%Marker)) {
  foreach my $m (sort {$a cmp $b} keys(%{$Marker{$c}})) {
   if (($m =~ /$Marker/gi) && not(defined($L))) { ($L, $R) = ($Marker{$c}{$m}{0}, $Marker{$c}{$m}{1}); }
   }
  }
 } else { ($L, $R) = ($Entry, $First); }

if (not(defined($L)) || not(defined($R)) || $R <= $L) { return(0); }

$t = MIDI::RoundInt($t*$m->{-1}{3}*4);

for (my $i=$STY::t2i{$L}; $i<$STY::t2i{$R} || $R==$Exit && $i<=$STY::t2i{$R}; $i++) { my $k1 = $STY::k1s[$i]; my $k1c = $t+($k1-$L);
 foreach my $k0 (sort {$a <=> $b} keys(%{$test1{$k1}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$test1{$k1}{$k0}})) { my $k2c = 0; if (scalar(keys(%{$m->{$k0}{$k1c}}))) { $k2c = (sort {$b <=> $a} keys(%{$m->{$k0}{$k1c}}))[0]+1; }

   if (defined($NTT) && exists($NTT->{$k0}) && not(defined($NTT->{$k0}))) { next(); }

   if ((($STY::test1{$k1}{$k0}{$k2}{0} >> 4) == 0x9) && ((($STY::test1{$k1}{$k0}{$k2}{0} & 0xf) != 9) && ($Patches{$k0}{0} != 0x7f) || defined($NTT) && exists($NTT->{$k0}))) { my $key = $STY::test1{$k1}{$k0}{$k2}{1};

    if (defined($NTT)) {
     if     (exists($NTT->{$k0})) { if (exists($NTT->{$k0}{$key%12})) { $key += $NTT->{$k0}{$key%12}; } elsif (exists($NTT->{$k0}{-1})) { $key += $NTT->{$k0}{-1}; }}
	  elsif (exists($NTT->{ -1})) { if (exists($NTT->{ -1}{$key%12})) { $key += $NTT->{ -1}{$key%12}; } elsif (exists($NTT->{ -1}{-1})) { $key += $NTT->{ -1}{-1}; }}
     }

	if ($key < 0 || $key > 127) { next(); }

	%{$m->{$k0}{$k1c}{$k2c}} = %{$STY::test1{$k1}{$k0}{$k2}}; $m->{$k0}{$k1c}{$k2c}{1} = $key;
	}
    else { %{$m->{$k0}{$k1c}{$k2c}} = %{$STY::test1{$k1}{$k0}{$k2}}; }

   }
  }
 }

my $l = ($R-$L)/($m->{-1}{3}*4);

if (defined($Label)) { my $r = '';
 if     ($Marker =~ /Fill/  ) { MIDI::InsertText($m, 0, $s+$l, 1, sprintf("Jump-1"             ), 0x6, '->'); }
  elsif ($Marker =~ /Ending/) { MIDI::InsertText($m, 0, $s+$l, 1, sprintf("Jump0x%x"   , 0x17  ), 0x6, '->'); $r = 'r'; }
  else                        { MIDI::InsertText($m, 0, $s+$l, 1, sprintf("Jump-4"             ), 0x6, '->'); }
                                MIDI::InsertText($m, 0, $s   , 1, sprintf("Label0x%x$r", $Label), 0x6, '->');
 }

return($l); }
#===============================================================================
sub ReadCASM { my ($m) = @_;

my ($fname, $fsize, $pos0) = ($m->{-1}{0}, $m->{-1}{-2}, $m->{-1}{-3});

open(my_file1, $m->{-1}{0}); my $p0 = sysseek(my_file1, $m->{-1}{-3}, 0);

my %CASM; my @Sdec = (); my ($NextSec0, $NextSec1) = (undef, undef);

while (($pos0+8) <= $fsize)
 {
 sysread(my_file1, my $byte, 1); $pos0++; my $ChunkType  = $byte;
 sysread(my_file1,    $byte, 1); $pos0++;    $ChunkType .= $byte;
 sysread(my_file1,    $byte, 1); $pos0++;    $ChunkType .= $byte;
 sysread(my_file1,    $byte, 1); $pos0++;    $ChunkType .= $byte;

 sysread(my_file1,    $byte, 1); $pos0++; my $length =                  ord($byte);
 sysread(my_file1,    $byte, 1); $pos0++;    $length = ($length << 8) + ord($byte);
 sysread(my_file1,    $byte, 1); $pos0++;    $length = ($length << 8) + ord($byte);
 sysread(my_file1,    $byte, 1); $pos0++;    $length = ($length << 8) + ord($byte);

 #printf("$fname, $fsize, '$ChunkType' %5x %4x %5d", $pos0, $length, $length);

 my @a = ();

 if     ($ChunkType =~ /^(CASM|OTSc|FNRc|MHhd)$/     ) { ($NextSec0, $NextSec1) = ($pos0 + $length,           undef); }
  elsif ($ChunkType =~ /^(CSEG)$/                    ) { (           $NextSec1) = (                 $pos0 + $length); }
  elsif ($ChunkType =~ /^(Sdec|Ctab|Ctb2|MTrk|FNRP)$/) { for (my $i=0; $i<$length && $pos0<$fsize; $i++) { sysread(my_file1, my $byte, 1); $pos0++; push(@a, ord($byte)); }}
  elsif (defined($NextSec1)) { $pos0 = $NextSec1; sysseek(my_file1, $pos0, 0); $NextSec1 = undef; }
  elsif (defined($NextSec0)) { $pos0 = $NextSec0; sysseek(my_file1, $pos0, 0); $NextSec0 = undef; }
  else { last(); }

 if ($ChunkType =~ /^Sdec$/       ) { my $n = ""; for (my $i=0; $i<=$#a; $i++) { $n .= chr($a[$i]); } @Sdec = split(',', $n); }
 if ($ChunkType =~ /^(Ctab|Ctb2)$/) { my $n = ""; for (my $i=1; $i<=  8; $i++) { $n .= chr($a[$i]); }
  foreach (@Sdec) { if (exists($CASM{$_}{$a[0]})) { printf("CASM: '$_' %x already exists!?\n", $a[0]); }
   push(@{$CASM{$_}{$a[0]}}, $n); for (my $i=9; $i<=$#a; $i++) { push(@{$CASM{$_}{$a[0]}}, $a[$i]); }
   }
  }

 #printf("\n");
 }

close(my_file1);

if ($fsize-$pos0 != 0) { printf("STY::ReadCASM($fname); # %d byte(s) left! FilePos: 0x%04x;\n", ($fsize-$pos0), $pos0); }

return(%CASM); }
#===============================================================================

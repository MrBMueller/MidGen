use strict; use warnings; package Bass;

our $b = "_> (/2:^7 .)"; #2 time units

our $b0 = $b;

return(1);
#===============================================================================

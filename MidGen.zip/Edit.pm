use strict; use warnings; use MIDI; package Edit;

our %Scales = ( 0 => { 0=>1, 1=>1, 2=>1, 3=>1, 4=>1, 5=>1, 6=>1, 7=>1, 8=>1, 9=>1, 10=>1, 11=>1 }, # chromatic
                1 => { 0=>7, 1=>5 },                                                               # quint
                2 => { 0=>2, 1=>2, 2=>1, 3=>2, 4=>2, 5=>2, 6=>1 },                                 # major
                3 => { 0=>2, 1=>1, 2=>2, 3=>2, 4=>1, 5=>2, 6=>2 },                                 # minor (pure/aeolic)
                4 => { 0=>2, 1=>1, 2=>2, 3=>2, 4=>2, 5=>2, 6=>1 },                                 # minor (melodic)
                5 => { 0=>2, 1=>1, 2=>2, 3=>2, 4=>1, 5=>3, 6=>1 },                                 # minor (harmonic)
                6 => { 0=>1, 1=>3, 2=>1, 3=>2, 4=>1, 5=>3, 6=>1 },                                 # minor (gypsy/arabic)
                7 => { 0=>12 },                                                                    # oct
                8 => { 0=>5, 1=>5, 2=>5, 3=>4, 4=>5 },                                             # 6 string guitar
                9 => { 0=>2, 1=>2, 2=>3, 3=>2, 4=>3 },                                             # pentatonic major
               10 => { 0=>3, 1=>2, 2=>2, 3=>3, 4=>2 });                                            # pentatonic minor

our %ScaleSel = (4 => {-1 => 3});

our %Co5th; our %crds;
for (my $j=2; $j<=3; $j++) { my $d = 0; if ($j >= 3) { $d = -3; }
 for (my $i=0; $i < Edit::GetInt(0); $i++) {
  my $q = $d % Edit::GetInt(0); if ($q > int(Edit::GetInt(0)/2)) { $q -= Edit::GetInt(0); }
  if (($j >= 3) && ($q >= int(Edit::GetInt(0)/2))) { $q *= -1; }
  $Edit::Co5th{$j}{$i} = $q; $d += Edit::GetInt(0, 7);
  }
 for (my $i=0; $i < Edit::GetInt($j); $i++) { my $d = Edit::GetInt($j, $i+2)-Edit::GetInt($j, $i); if ($d >= 4) { $d = 2; } $Edit::crds{$j}{$i} = $d; }
 }

$Edit::Co5th{ 4} = $Edit::Co5th{3}; $Edit::crds{ 4} = $Edit::crds{3};
$Edit::Co5th{ 5} = $Edit::Co5th{3}; $Edit::crds{ 5} = $Edit::crds{3};
$Edit::Co5th{ 6} = $Edit::Co5th{3}; $Edit::crds{ 6} = $Edit::crds{3};

$Edit::Co5th{ 9} = $Edit::Co5th{2}; $Edit::crds{ 9} = {0=>2, 1=>3, 2=>3, 3=>2, 4=>3};
$Edit::Co5th{10} = $Edit::Co5th{3}; $Edit::crds{10} = {0=>3, 1=>2, 2=>2, 3=>3, 4=>2};

return(1);
#===============================================================================
sub GetInt {
my $scale   = undef; if ($#_ >= 0) { $scale = shift(@_); } else { return(scalar(keys(%Edit::Scales))); }
my $dist0   = undef; if ($#_ >= 0) { $dist0 = shift(@_); }  #prim; sec; terz; quart; quint; sext; sept; oct;
my $dist1   = undef; if ($#_ >= 0) { $dist1 = shift(@_); }  #last dist
my $retval0 = 0;

if ((defined($dist0)) && (defined($dist1))) { my $d = 0; if ($dist0 - $dist1 < 0) { $d--; } elsif ($dist0 - $dist1 > 0) { $d++; }
 if (exists($Edit::ScaleSel{$scale}{$d})) { $scale = $Edit::ScaleSel{$scale}{$d}; }} #switch scale dependent on direction

my %scales1; my $last = 0;
foreach my $key1 (sort({$a <=> $b} keys(%{$Edit::Scales{$scale}}))) {
 $scales1{$key1} = $Edit::Scales{$scale}{$key1} + $last; $last = $scales1{$key1};
 }

my $keys = scalar(keys(%scales1));

if (not defined($dist0)) { $retval0 = $keys; } else {
 my $sign0 = 1; if ($dist0 < 0) { $sign0 = -1; $dist0 = abs($dist0); }

 my $octave0 = int($dist0 / $keys); my $dist2 = $dist0 % $keys;

 if ($dist2 > 0) { $dist2--; $retval0 = $scales1{$dist2}; if ($sign0 < 0) { $retval0 = $scales1{$keys-2-$dist2} - $last; }}

 $retval0 += $sign0 * $octave0 * $last;
 }

return($retval0); }
#-------------------------------------------------------------------------------
sub seq {
my $h0    = shift(@_);
my $trk   =     0; if ($#_ >= 0) { $trk   = shift(@_); }
my $ch    = undef; if ($#_ >= 0) { $ch    = $_[0]; if (not(defined($ch))) { shift(@_); }} #\
                   if ($#_ >= 0) {                 if (not(defined($ch))) { shift(@_); }} # > MIDI ch/bnk/prg control - not used anymore
                   if ($#_ >= 0) {                 if (not(defined($ch))) { shift(@_); }} #/
my $start =     0; if ($#_ >= 0) { $start = shift(@_); } my $Istart = $start; my $shd = undef; my $EventPtr = 0;
my $base  =     0; if ($#_ >= 0) { $base  = shift(@_); } my $NoteOfs = 0; if (ref($base) =~ /ARRAY/i) { ($base, $NoteOfs) = @{$base}; } else { $NoteOfs = $base>>16; $base &= 0xffff; if ($NoteOfs >= 0x8000) { $NoteOfs = sprintf("%d", $NoteOfs | -1<<16); } if ($base >= 0x8000) { $base = sprintf("%d", $base | -1<<16); }} my $Ibase = $base;
my $scale =     0; if ($#_ >= 0) { $scale = shift(@_); } my $Iscale = $scale;
my $Line  =    ""; if ($#_ >= 0) { $Line  = shift(@_); } $Line = Edit::PreProc0($Line); if ($Line !~ /!/g) {$Line = "! ".$Line; } $Line .= " 0:%";
my $VOn   =     1; if ($#_ >= 0) { $VOn   = shift(@_); } my %VOnLUT;
my $VOf   =    .5; if ($#_ >= 0) { $VOf   = shift(@_); } my %VOfLUT;
                   if ($#_ >= 0) { if (not(defined($ch))) { shift(@_); }} #\
                   if ($#_ >= 0) { if (not(defined($ch))) { shift(@_); }} # > MIDI chord control (went directly to MIDI::InsertChord() - not used anymore)
                   if ($#_ >= 0) { if (not(defined($ch))) { shift(@_); }} #/
my $Rpt   =     0; if ($#_ >= 0) { $Rpt   = shift(@_); } my %RptLUT; #\
my $Dly   =     0; if ($#_ >= 0) { $Dly   = shift(@_); } my %DlyLUT; # > MIDI echo effect (goes directly to MIDI::InsertNote())
my $Dmp   =     1; if ($#_ >= 0) { $Dmp   = shift(@_); } my %DmpLUT; #/
my $dir0  =     1; if ($#_ >= 0) { $dir0  = shift(@_); } my $Idir0 = $dir0;
my $inv0  =     1; if ($#_ >= 0) { $inv0  = shift(@_); } my $Iinv0 = $inv0;
my $tempo =     1; if ($#_ >= 0) { $tempo = shift(@_); }
my $Lcr   =     1; if ($#_ >= 0) { $Lcr   = shift(@_); } my %LcrLUT;
my $limit = undef; if ($#_ >= 0) { $limit = shift(@_); } my $Mute = 0;
my $PFlgs =  0x03; if ($#_ >= 0) { $PFlgs = shift(@_); } my $EventLyric = ""; my $LyricTime = $start;
my $TrkLt = undef; if ($#_ >= 0) { $TrkLt = shift(@_); }
my $StoLt = undef; if ($#_ >= 0) { $StoLt = shift(@_); } my %StoLUT; for (0..127) { if (exists($StoLt->{$_})) { $StoLUT{$_} = $StoLt->{$_}; } else { $StoLUT{$_} = 0; }}

$Line =~ s/{/{ /g; $Line =~ s/}/ } /g; $Line =~ s/\[/[ /g; $Line =~ s/\]/ ] /g; $Line =~ s/\(/( /g; $Line =~ s/\)/ ) /g;
$Line = Edit::ResolveRepeats($Line); $Line = Edit::ResolveRepeats($Line, '['); $Line = Edit::ResolveRepeats($Line, '(');
$Line =~ s/\|+/\|/g; $Line =~ s/\|\s/ /g; $Line =~ s/\|$/ /g; $Line =~ s/\_+/\_/g; $Line =~ s/!/ ! /g;
$Line =~ s/^\s+//g; $Line =~ s/\s+/ /g; $Line =~ s/\s+$//g; my @Events = split(/\s+/, $Line);

my $GrooveSnap = 1/16; my $GrooveLength = 1/1; my %GrooveBoosts;
if ((ref($VOn) =~ 'HASH') && (exists($VOn->{-3}))) { $GrooveSnap   =   $VOn->{-3};  }
if ((ref($VOn) =~ 'HASH') && (exists($VOn->{-4}))) { $GrooveLength =   $VOn->{-4};  }
if ((ref($VOn) =~ 'HASH') && (exists($VOn->{-5}))) { %GrooveBoosts = %{$VOn->{-5}}; }

my %GrooveBoostsQ; foreach my $k0 (sort {$a <=> $b} keys %GrooveBoosts) { my (undef, $qn, undef, undef, undef, undef) = Edit::Quantize($k0, $GrooveSnap); $GrooveBoostsQ{$qn} = $GrooveBoosts{$k0}; }

if (ref($VOn) =~ 'HASH') { for (my $i=0; $i<=0x7f; $i++) { $VOnLUT{$i} =    1; if (exists($VOn->{$i})) { $VOnLUT{$i} = $VOn->{$i}; } elsif (exists($VOn->{-1})) { $VOnLUT{$i} = $VOn->{-1}; }}}
 else                    { for (my $i=0; $i<=0x7f; $i++) { $VOnLUT{$i} = $VOn;                                                                                                               }}

if (ref($VOf) =~ 'HASH') { for (my $i=0; $i<=0x7f; $i++) { $VOfLUT{$i} =   .5; if (exists($VOf->{$i})) { $VOfLUT{$i} = $VOf->{$i}; } elsif (exists($VOf->{-1})) { $VOfLUT{$i} = $VOf->{-1}; }}}
 else                    { for (my $i=0; $i<=0x7f; $i++) { $VOfLUT{$i} = $VOf;                                                                                                               }}

if (ref($Rpt) =~ 'HASH') { for (my $i=0; $i<=0x7f; $i++) { $RptLUT{$i} =    0; if (exists($Rpt->{$i})) { $RptLUT{$i} = $Rpt->{$i}; } elsif (exists($Rpt->{-1})) { $RptLUT{$i} = $Rpt->{-1}; }}}
 else                    { for (my $i=0; $i<=0x7f; $i++) { $RptLUT{$i} = $Rpt;                                                                                                               }}

if (ref($Dly) =~ 'HASH') { for (my $i=0; $i<=0x7f; $i++) { $DlyLUT{$i} =    0; if (exists($Dly->{$i})) { $DlyLUT{$i} = $Dly->{$i}; } elsif (exists($Dly->{-1})) { $DlyLUT{$i} = $Dly->{-1}; }}}
 else                    { for (my $i=0; $i<=0x7f; $i++) { $DlyLUT{$i} = $Dly;                                                                                                               }}

if (ref($Dmp) =~ 'HASH') { for (my $i=0; $i<=0x7f; $i++) { $DmpLUT{$i} =    1; if (exists($Dmp->{$i})) { $DmpLUT{$i} = $Dmp->{$i}; } elsif (exists($Dmp->{-1})) { $DmpLUT{$i} = $Dmp->{-1}; }}}
 else                    { for (my $i=0; $i<=0x7f; $i++) { $DmpLUT{$i} = $Dmp;                                                                                                               }}

if (ref($Lcr) =~ 'HASH') { for (my $i=0; $i<=0x7f; $i++) { $LcrLUT{$i} =    1; if (exists($Lcr->{$i})) { $LcrLUT{$i} = $Lcr->{$i}; } elsif (exists($Lcr->{-1})) { $LcrLUT{$i} = $Lcr->{-1}; } if ($LcrLUT{$i} =~ /^-/) { $LcrLUT{$i} = "0+".abs($LcrLUT{$i}); }}}
 else                    { for (my $i=0; $i<=0x7f; $i++) { $LcrLUT{$i} = $Lcr;                                                                                                                if ($LcrLUT{$i} =~ /^-/) { $LcrLUT{$i} = "0+".abs($LcrLUT{$i}); }}}

while ((not(defined($limit))) || (abs($start-$Istart) < $limit)) { my $SeqStart = $start; $base = $Ibase; $scale = $Iscale; $VOn = 1; $VOf = 1; $dir0 = $Idir0; $inv0 = $Iinv0;
my @Times = ("."); my @Evnts = ("."); my $LastValTm = "0"; my $LastValOp = "%";
my $CurTempo = $tempo; my $CurrentTime = 0/$CurTempo; my $CurTime0 = 0; my $CurTime2 = $CurrentTime;
my $flgs = 0; my $CurrentNote = 0; my $LastNote = $CurrentNote; my ($ctrk, $cchn) = (undef, undef);

my $GrpFlgs = 0; my @stack0; my @stack1; my @stack2; my %CtlrLastVals = (-2=>0.0, -1=>0.0);

my $TmSg = -1; if (defined($h0->{-1}{5})) { $TmSg = ($h0->{-1}{5}<<16)+$h0->{-1}{6}; } my $LTmSg = $TmSg;
my $LKySg = 0x80; if (exists($Edit::Co5th{$scale}{$base%Edit::GetInt(0)})) { $LKySg = $Edit::Co5th{$scale}{$base%Edit::GetInt(0)}; }

for (my $i=$EventPtr; $i<=$#Events; $i++) { my $PrevGrpFlgs = $GrpFlgs; my $fs = 0; my $fts = undef; my $fscl = undef; my @ctl = (); my $frpt = 0; my $marker = ""; my $lyric = "";

 if ($PFlgs & 0x04) {
  if ($Events[$i] =~ /[}\)\]]/) { if (!($Mute&2)) { MIDI::InsertText($h0, $trk, $LyricTime, 0, $Events[$i], 0x05, ''); }} else { $EventLyric .= $Events[$i]; }
  }

 if ($Events[$i] =~ /[{\(\[]$/) { push(@stack0, $GrpFlgs); } if ($Events[$i] =~ /[}\)\]]$/) { $GrpFlgs = pop(@stack0); }
 if ($Events[$i] =~ /[\[]$/   ) { push(@stack2, $start  ); } if ($Events[$i] =~ /[\]]$/   ) { $start   = pop(@stack2); }

 if ($Events[$i] =~ /\($/) { push(@stack1, [$Times[$#Times], $Evnts[$#Evnts], $LastValTm, $LastValOp, $CurTempo, $CurrentTime, $CurTime0, $CurTime2, $flgs, $CurrentNote, $VOn, $VOf, $base, $scale, $TmSg, $ctrk, $cchn]);                  }
 if ($Events[$i] =~ /\)$/) {               ($Times[$#Times], $Evnts[$#Evnts], $LastValTm, $LastValOp, $CurTempo, $CurrentTime, $CurTime0, $CurTime2, $flgs, $CurrentNote, $VOn, $VOf, $base, $scale, $TmSg, $ctrk, $cchn) = @{pop(@stack1)}; }

 if ($Events[$i] =~ /<.*[{\(\[]$/) { $GrpFlgs ^= 1; } if ($Events[$i] =~ /\|.*[{\(\[]$/) { $GrpFlgs ^= 2; }
 if ($Events[$i] =~ /v.*[{\(\[]$/) { $GrpFlgs ^= 4; } if ($Events[$i] =~  /~.*[{\(\[]$/) { $GrpFlgs ^= 8; }

 if (($GrpFlgs^$PrevGrpFlgs)&2) {
  if (($i+1 <= $#Events) && ($Events[$i+1] =~ /\|.*[{\(\[]$/)) { $dir0 *= -1; }
   elsif                    ($Events[$i  ] =~     /[}\)\]]$/)  { $dir0  =  1; }
  }

 if (($GrpFlgs^$PrevGrpFlgs)&8) {
  if (($i+1 <= $#Events) && ($Events[$i+1] =~  /~.*[{\(\[]$/)) { $inv0 *= -1; }
   elsif                    ($Events[$i  ] =~     /[}\)\]]$/)  { $inv0  =  1; }
  }

 if (($GrpFlgs^$PrevGrpFlgs)&1) { $dir0 = 1; if (($GrpFlgs & 1) > 0) { $dir0 = -1; }}
 if (($GrpFlgs^$PrevGrpFlgs)&4) { $inv0 = 1; if (($GrpFlgs & 4) > 0) { $inv0 = -1; }}

 if (($Events[$i] =~ /!/) && (not(defined($shd)))) { $shd = $Istart-$start; $Istart = $start; $SeqStart = $start; $EventPtr = $i+1; }

 if ($Events[$i] =~ /[{}\(\)\[\]!]$/) { next; }

 $Events[$i] =~ s/:$/:./g; $Events[$i] =~ s/^:/.:/g; my @EventSplit = split(":", $Events[$i]);

 for (my $j=0; $j<=$#EventSplit; $j++) { if (length($EventSplit[$j]) <= 0 ) { $EventSplit[$j] = "."; }}

 my $DefTime = '.'; my $RevTime = ''; if ($dir0 < 0) { $DefTime = ''; $RevTime = '<'; }
 if      ($#EventSplit <= 0) { push(@Times, $RevTime.$DefTime      .$RevTime); push(@Evnts, $EventSplit[0]); }
  elsif  ($#EventSplit <= 1) { push(@Times, $RevTime.$EventSplit[0].$RevTime); push(@Evnts, $EventSplit[1]); }

 my $p0 = -1;
 if     ($Times[$#Times] =~ /^\.$/) { $Times[$#Times] = $Times[$#Times-1]; $p0++; }
  elsif ($Times[$#Times] =~ /^=$/ ) { $Times[$#Times] = $LastValTm;               }
  else                              { $LastValTm = $Times[$#Times];               }

 my $p1 = -1;
 if     ($Evnts[$#Evnts] =~ /^\.$/) { $Evnts[$#Evnts] = $Evnts[$#Evnts-1]; $p1++; }
  elsif ($Evnts[$#Evnts] =~ /^=$/ ) { $Evnts[$#Evnts] = $LastValOp;               }
  else                              { $LastValOp = $Evnts[$#Evnts];               }

 if (($p0 < 0) || ($Times[$#Times] =~ /^=$/ )) { my $val = $LastValTm; $val =~ s/x/0x/gi; $val =~ s/_//g; my $sign = 0;

  if    ($val =~ /\|/    ) { $val =~ s/\|//; $sign |= 0x2; }
  while ($val =~ /[<>]/  ) {
  if    ($val =~ /^<(.+)/) { $val = $1;      $sign ^= 0x1; }
  if    ($val =~ /(.+)<$/) { $val = $1;      $sign ^= 0x4; }
  if    ($val =~ /^<$/   ) { $val = '';      $sign ^= 0x4; }}
  if    ($val =~ /^b$/   ) { $val = '';      $sign |= 0x1; }
  if    ($val =~ /^r$/   ) { $val = '';      $sign |= 0x5; }

  my @ds; while ($val =~ /(.*)([+-])$/) { $val = $1; my $d = $2; push(@ds, $d); }

  if     ($val =~ /^([\*\/+-].+)/) { $CurrentTime = eval($CurrentTime.$1);    } #modify previous
   elsif ($val =~ /^[*]$/        ) { $CurrentTime *= 2;                       } #modify previous
   elsif ($val =~ /^[\/]$/       ) { $CurrentTime /= 2;                       } #modify previous
   elsif (length($val)           ) { $CurrentTime = eval($val); $sign |= 0x8; } #set new

  my $AddTime = 0; for (my $d=$#ds; $d>=0; $d--) { my $t = $CurrentTime/(2**($#ds-$d+1)); $AddTime = eval($AddTime.$ds[$d].$t); } $CurrentTime += $AddTime; if ($sign&0x8) { $CurrentTime /= $CurTempo; }

  if ($sign & 0x2) { my (undef, undef, undef, $fd, undef, $cd) = Edit::Quantize($start-$SeqStart, $CurrentTime); $CurrentTime = $cd; if ($sign & 0x1) { $CurrentTime = $fd; }}
  if ($sign & 0x1) { $CurTime0 = 0 - abs($CurrentTime); $CurTime2 = abs($CurrentTime); }
   else            { $CurTime0 = 0;                     $CurTime2 = abs($CurrentTime); }
  if ($sign & 0x4) {                                    $CurTime2 = 0;                 }
  }

 if (($p1 < 0) || ($Evnts[$#Evnts] =~ /^=$/ )) { my $val = $LastValOp; $val =~ s/x/0x/gi;

  $val =~ s/^C/%_C/; @ctl = split('_C', $val); $val = shift(@ctl); my @ValSplit = split('_', $val);

  if ($CurrentTime == 0) { $flgs |= 0x01; } #default pause if no progressive time

  for (my $p=0; $p<=$#ValSplit; $p++) { my $fsd = 1; if ($ValSplit[$p] =~ /^([\^v])i(.*)/) { $ValSplit[$p] = $1.$2; $fsd *= -1; }
   if ($ValSplit[$p] !~ /^[ML]/) { while ($ValSplit[$p] =~ /^(.*)([\#b])(.*)/) { my ($t1, $t2, $t3) = ($1, $2, $3); if ($t2 =~ /^\#/) { $fs++; } else { $fs--; } $ValSplit[$p] = $t1.$t3; if ($ValSplit[$p] =~ /^$/g) { $ValSplit[$p] = ">"; }}}
   if     ($ValSplit[$p] =~ /^%$/           ) { $flgs |= 0x01; } #nop/pause
    elsif ($ValSplit[$p] =~ /^>$/           ) { $flgs &= 0x0e; } #continue
    elsif ($ValSplit[$p] =~ /^B$/           ) { $flgs |= 0x02;                                         if ($#ValSplit<=0) { $flgs |= 0x08; $CurTime0 = 0; $CurTime2 = 0; }} #flag base  change
    elsif ($ValSplit[$p] =~ /^S(.*)$/       ) { $flgs |= 0x04; if (length($1)>0) { $fscl = eval($1); } if ($#ValSplit<=0) { $flgs |= 0x08; $CurTime0 = 0; $CurTime2 = 0; }} #flag scale change
    elsif ($ValSplit[$p] =~ /^(\d+)\/(\d+)$/) { $fts = (eval($1)<<16) + eval($2);                      if ($#ValSplit<=0) { $flgs |= 0x08; $CurTime0 = 0; $CurTime2 = 0; }} #flag time  change
    elsif ($ValSplit[$p] =~ /^M(.*)$/       ) { $marker = $1;                                          if ($#ValSplit<=0) { $flgs |= 0x08; $CurTime0 = 0; $CurTime2 = 0; }} #set marker
    elsif ($ValSplit[$p] =~ /^L(.*)$/       ) { $lyric  = $1;                                          if ($#ValSplit<=0) { $flgs |= 0x08; $CurTime0 = 0; $CurTime2 = 0; }} #set lyric
    elsif ($ValSplit[$p] =~ /^T(.*)$/       ) { $CurTempo = eval($1); } #set tempo
    elsif ($ValSplit[$p] =~ /^t(.*)$/       ) { $ctrk     = eval($1); } #set track
    elsif ($ValSplit[$p] =~ /^c(.*)$/       ) { $cchn     = eval($1); } #set channel
    elsif ($ValSplit[$p] =~ /^e(.*)$/       ) { $frpt = 0; if (length($1)>0) { $frpt = eval($1); }} #force echo
    elsif ($ValSplit[$p] =~ /^r(.*)$/       ) { my $t = $1;            if ($t =~ /^([\*\/+-].*)/) { $VOf = eval($VOf.$t); } else { $VOf = eval($t); }}
    elsif ($ValSplit[$p] =~ /\./            ) { my $t = $ValSplit[$p]; if ($t =~ /^([\*\/+-].*)/) { $VOn = eval($VOn.$t); } else { $VOn = eval($t); }}
    elsif ($ValSplit[$p] =~ /^\^(.*)$/      ) { $flgs &= 0x0e; my $t = $1; if (length($t) <= 0) { $t = 1; } $LastNote = $CurrentNote; $CurrentNote += eval($t)*$inv0;              }
    elsif ($ValSplit[$p] =~ /^v(.*)$/       ) { $flgs &= 0x0e; my $t = $1; if (length($t) <= 0) { $t = 1; } $LastNote = $CurrentNote; $CurrentNote -= eval($t)*$inv0; $fs *= $fsd; }
    elsif (length($ValSplit[$p])            ) { $flgs &= 0x0e;                                              $LastNote = $CurrentNote; $CurrentNote  = eval($ValSplit[$p])*$inv0; }
   }
  }

 $start += $CurTime0; my $note = $base + Edit::GetInt($scale, $NoteOfs+$CurrentNote, $NoteOfs+$LastNote) + $fs;
 my $note1 = abs($CurrentNote) % Edit::GetInt($scale); if ($CurrentNote < 0) { $note1 = (Edit::GetInt($scale) - $note1) % Edit::GetInt($scale); }

 if ($flgs & 0x002) { $base  = $note; $CurrentNote = 0; $LastNote = $CurrentNote;                  } #change base  to current note
 if ($flgs & 0x004) { $scale = $Edit::crds{$scale}{$note1}; if (defined($fscl)) { $scale = $fscl; }} #change scale to current chord
 my $KySg = 0x80; if (exists($Edit::Co5th{$scale}{$base%Edit::GetInt(0)})) { $KySg = $Edit::Co5th{$scale}{$base%Edit::GetInt(0)}; } if (defined($fts)) { $TmSg = $fts; }
 if (length($EventLyric) && ($i < $#Events)) { $lyric = $EventLyric; } $EventLyric = "";

 my (undef, $StartQGL, undef, undef, undef, undef) = Edit::Quantize(abs($start-$SeqStart)-$GrooveLength/2, $GrooveLength);
 my (undef, $StartQG,  undef, undef, undef, undef) = Edit::Quantize(abs($start-$SeqStart), $GrooveSnap);
 my $GrooveDT = abs($StartQG-$StartQGL); if ($GrooveDT >= $GrooveLength) { $GrooveDT = 0; }
 my $VelBoost = 1; if (exists($GrooveBoostsQ{$GrooveDT})) { $VelBoost = $GrooveBoostsQ{$GrooveDT}; }

 $Mute = 0; my $EventStart = $start; my $EventLengthN = abs($CurrentTime); $EventLengthN = eval($EventLengthN.'*'.$LcrLUT{$note&0x7f}); my $EventLengthC = $EventLengthN;
 if ($LcrLUT{$note&0x7f} =~ /^0[+-]/) { $EventLengthC = abs($CurrentTime); }

 if (defined($limit)) { my $LimDiff = $limit-($start-$Istart);
  if ($LimDiff <= 0) { $Mute = 0xf; } else { if ($LimDiff < $EventLengthN) { $EventLengthN = $LimDiff; } if ($LimDiff < $EventLengthC) { $EventLengthC = $LimDiff; }}
  }

 $LyricTime = $EventStart; #set lyric always to real note EventStart (earliest in time) regardless of direction

 if ((!($Mute&1)) && ($PFlgs & 0x02) && ((defined($fts)) || ($TmSg != $LTmSg))) { MIDI::InsertTimeSig($h0, 0x00, $start, 1, $TmSg>>16, $TmSg&0xffff); $LTmSg = $TmSg; }
 if ((!($Mute&1)) && ($PFlgs & 0x01) && (($flgs & 0x006) || ($KySg != $LKySg))) { MIDI::InsertKeySig( $h0, 0x00, $start, 1, $KySg);                   $LKySg = $KySg; }

 my $Trk = $trk; if (defined($ctrk)) { $Trk = $ctrk; }

 while ((!($Mute&4)) && ($#ctl >= 0)) { my @Ctl = split("_", pop(@ctl));
  if ($#Ctl == 0) { $Ctl[1] = 0; } if ($#Ctl == 1) { $Ctl[2] = $Ctl[1]; $Ctl[1] = 0; } if ($#Ctl == 2) { $Ctl[4] = $Ctl[2]; $Ctl[3] = $Ctl[2]; $Ctl[2] = $Ctl[1]; $Ctl[1] = 1; }
  if (($EventLengthC != 0) && ($#Ctl == 3) && (exists($CtlrLastVals{$Ctl[0]}))) { $Ctl[4] = $Ctl[3]; $Ctl[3] = $CtlrLastVals{$Ctl[0]}; }
  $Ctl[1] *= $inv0; (my $LastVal, undef) = MIDI::InsertCtlr($h0, $Trk, $EventStart+$StoLUT{$note&0x7f}, 0, $cchn, $EventLengthC, undef, @Ctl); $CtlrLastVals{$Ctl[0]} = $LastVal;
  }

 if ((!($Mute&8)) && (($flgs & 0x09) == 0)) {
  if ((not(defined($ctrk))) && (exists($TrkLt->{$CurrentNote}))) { $Trk = $TrkLt->{$CurrentNote}; }
  MIDI::InsertNote($h0, $Trk, $EventStart+$StoLUT{$note&0x7f}, 1, $cchn, $EventLengthN, $note, $VOnLUT{$note&0x7f}*$VOn*$VelBoost, $VOfLUT{$note&0x7f}*$VOf, $RptLUT{$note&0x7f}+$frpt, $DlyLUT{$note&0x7f}, $DmpLUT{$note&0x7f});
  }

 if ((!($Mute&1)) && (length($marker))) { MIDI::InsertText($h0, 0x00, $start    , 1, $marker, 0x06, " "); }
 if ((!($Mute&2)) && (length($lyric ))) { MIDI::InsertText($h0, $trk, $LyricTime, 0, $lyric , 0x05, " "); }

 $flgs &= 0x01; $start += $CurTime2; $CurTime0 = 0; $CurTime2 = abs($CurrentTime);
 }
if ((not(defined($limit))) || ($start == $Istart)) { last(); }}

my $rv = $start-$Istart; if (defined($limit)) { $rv = $limit; } return($shd, $rv); }
#-------------------------------------------------------------------------------
sub Seq { my %m = (-1=>{3=>$_[0]->{-1}{3}, 4=>$_[0]->{-1}{4}}); my ($d, $l) = (0, 0);

my ($s, $line) = (2, 5); if (not(defined($_[2]))) { ($s, $line) = (5, 8); }

my @a; foreach (@_) { push(@a, $_); }

$a[0] = \%m; if ($_[$line] =~ /!/g) { ($d, undef) = Edit::seq(@a); } $a[0] = $_[0]; $a[$s] += $d;
                                      (undef, $l) = Edit::seq(@a);

return($l); }
#-------------------------------------------------------------------------------
sub ResolveRepeats {
my $str1 = shift(@_);
my $a    = '{'; if ($#_ >= 0) { $a = shift(@_); } my $b = '}'; if ($a =~ /\(/) { $b = ')'; } if ($a =~ /\[/) { $b = ']'; }

my $s = '\\'; my $c = $s.$a; my $d = $s.$b; $str1 =~ s/$c/$a /g; $str1 =~ s/$d/ $b /g; $str1 = "$a $str1 $b";

my @my_split1 = split(" ", $str1); my $RepLev0 = 0; my $SubVal0 = ""; my @Rpts0; my @Rpts1; my @Rpts2; my @Rpts3;
for (my $i = 0; $i <= $#my_split1; $i++)
 {
 my $flg = ""; if ($my_split1[$i] =~ /^([<|v~]*)(.*)$c/) { if (length($1)) { $flg = $1; } $my_split1[$i] = '1'.$a; if (length($2)) { $my_split1[$i] = eval($2).$a; }}
 if ($my_split1[$i] =~ /^(.*)$c/) { push(@Rpts0, $RepLev0); push(@Rpts1, 1); push(@Rpts2, $SubVal0); push(@Rpts3, ""); $SubVal0 = ""; push(@Rpts0, ++$RepLev0); push(@Rpts1, $1); push(@Rpts2, $SubVal0); push(@Rpts3, $flg); next; }
 if ($my_split1[$i] =~ /$d$/    ) { push(@Rpts0, $RepLev0); push(@Rpts1, 1); push(@Rpts2, $SubVal0); push(@Rpts3, ""); $SubVal0 = "";              $RepLev0--;                                                                next; }
 $SubVal0 .= " " . $my_split1[$i];
 }
push(@Rpts0, $RepLev0); push(@Rpts1, 1); push(@Rpts2, $SubVal0); push(@Rpts3, "");
push(@Rpts0,       -1); push(@Rpts1, 1); push(@Rpts2,       ""); push(@Rpts3, "");

my $PrevLevel = -1; my %LevStarts0;
for (my $i=0; $i<=$#Rpts0; $i++)
 {
 if ($Rpts0[$i] > $PrevLevel) { $LevStarts0{$Rpts0[$i]} = $i; }
 if ($Rpts0[$i] < $PrevLevel)
  {
  my $flg0 = $Rpts3[$LevStarts0{$PrevLevel}];

  my $val0 = ""; for (my $j=$LevStarts0{$PrevLevel}; $j<=($i-1); $j++) { $val0 .= " " . $Rpts2[$j]; $Rpts2[$j] = ""; }

  my $val1 = ""; for (my $j=0; $j<$Rpts1[$LevStarts0{$PrevLevel}]; $j++) { $val1 .= " $flg0$a $val0 $b "; }

  $Rpts1[$LevStarts0{$PrevLevel}] = 1; $Rpts2[$LevStarts0{$PrevLevel}] = $val1;
  }
 $PrevLevel = $Rpts0[$i];
 }

$Rpts2[0] =~ s/\s+/ /gi; $Rpts2[0] =~ s/^\s*$c\s*$c\s*(.*)\s*$d\s*$d\s*$/$1/gi; $Rpts2[0] =~ s/\s*$//gi; return($Rpts2[0]); }
#-------------------------------------------------------------------------------
sub PreProc0 { my $Line = shift(@_); my $e = '>'; if ($#_ >= 0) { $e = shift(@_); } my %eLUT; if (ref($e) =~ 'HASH') { %eLUT = %{$e}; } else { $eLUT{'o'} = $e; }

if (not(exists($eLUT{'.'}))) { $eLUT{'.'} =        '.'; }

if (not(exists($eLUT{'o'}))) { $eLUT{'o'} =        '>'; } $eLUT{'o'} = '_'.$eLUT{'o'};
if (not(exists($eLUT{'O'}))) { $eLUT{'O'} = $eLUT{'o'}; }

if (not(exists($eLUT{'b'}))) { $eLUT{'b'} = 'b'.$eLUT{'o'}; }
if (not(exists($eLUT{'#'}))) { $eLUT{'#'} = '#'.$eLUT{'o'}; }

if (not(exists($eLUT{'vx'}))) { $eLUT{'vx'} = "1.0"; } if (not(exists($eLUT{'x'}))) { $eLUT{'x'} = $eLUT{'vx'}.$eLUT{'o'}; }
if (not(exists($eLUT{'vX'}))) { $eLUT{'vX'} = "1.0"; } if (not(exists($eLUT{'X'}))) { $eLUT{'X'} = $eLUT{'vX'}.$eLUT{'o'}; }

for (my $i = 0; $i <= 9; $i++) { if (not(exists($eLUT{'v'.$i}))) { $eLUT{'v'.$i} = '.'.$i; } if (not(exists($eLUT{$i}))) { $eLUT{$i} = $eLUT{'v'.$i}.$eLUT{'o'}; }}

while ($Line =~ /\|([^\s]+)\|/) { my $seq = $1; $seq =~ s/[\|\_]//g; my $r = ""; my $cnt0 = 0; my $cnt1 = 0;  my $p = ""; my $e = $eLUT{'o'};
 my $t = ''; if ($seq =~ /^(\.*)(.*)/) { $t = $1; $seq = $2; } $seq =~ s/\./$eLUT{'.'}/gi; $seq = $t.$seq;
 for (my $i=0; $i<length($seq); $i++) { my $c = substr($seq, $i, 1);
  if      ($c =~ /\./  )                          {                                             if ($cnt1) { $r .= " *$cnt1:$e /$cnt1<:%"; } $cnt0++; $cnt1=0;                 }
   elsif (($c =~ /[^>]/) || (exists($eLUT{'>'}))) { if ($cnt0) { $r .= " *$cnt0:% /$cnt0<:%"; } if ($cnt1) { $r .= " *$cnt1:$e /$cnt1<:%"; } $cnt0=0; $cnt1=1; $e = $eLUT{$c}; }
   elsif  ($p =~ /\./  )                          { if ($cnt0) { $r .= " *$cnt0:% /$cnt0<:%"; } if ($cnt1) { $r .= " *$cnt1:$e /$cnt1<:%"; } $cnt0=0; $cnt1=1;                 }
   else                                           { if ($cnt0) { $r .= " *$cnt0:% /$cnt0<:%"; }                                                       $cnt1++;                 }
  $p = $c; }
 if ($cnt0) { $r .= " *$cnt0:% /$cnt0<:%"; } if ($cnt1) { $r .= " *$cnt1:$e /$cnt1<:%"; }
 $Line =~ s/\|([^\s]+)\|/$r /; }

return($Line); }
#-------------------------------------------------------------------------------
sub Quantize {
my $val  = shift(@_);
my $snap =         0; if ($#_ >= 0) { $snap = shift(@_); } if ($snap == 0) { return($val, $val, $val, 0, 0, 0); } else { $snap = abs($snap); }

my $floor = int($val/$snap)*$snap; my $ceil = $floor;

if ($floor != $val) { $ceil = $floor + $snap; if ($val < 0) { $ceil = $floor; $floor = $ceil - $snap; }}

my $fdiff = abs($val-$floor); my $cdiff = abs($val-$ceil); my $nearest = $floor; if ($cdiff <= $fdiff) { $nearest = $ceil; }

return($floor, $nearest, $ceil, $fdiff, $nearest-$val, $cdiff); }
#-------------------------------------------------------------------------------
sub QuantizeTrk {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $sq  =            0; if ($#_ >= 0) { $sq  = shift(@_); } #note on quantize resolution
my $lq  =            0; if ($#_ >= 0) { $lq  = shift(@_); } #length quantize resolution
my $lc  =            0; if ($#_ >= 0) { $lc  = shift(@_); } #length correction off/on (note on compensation)
my $tcr =            1; if ($#_ >= 0) { $tcr = shift(@_); } #tempo correction
my $tpq = $h0->{-1}{3}; if ($#_ >= 0) { $tpq = shift(@_); } #target ticks per quarter note

my $gstart = undef; my $gend = $gstart;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my %new;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { my $start = $k1/($h0->{-1}{3}*4)*$tcr; my $csq = $sq; my $clq = $lq;

   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $dur = $h0->{$k0}{$k1}{$k2}{3}/($h0->{-1}{3}*4)*$tcr;

    #my $QSnap = 1/64; my $QLength = 1/1;
    #my (undef, $QG,  undef, undef, undef, undef) = Edit::Quantize($dur, $QSnap); if ($QG >= $QLength) { $QG = $QLength; } #0..length
	#my $FIn = int(log(int(1/$QSnap)+1)/log(2)) - int(log(int($QG/$QSnap)+1)/log(2)); #log(n+1) since log(0) not defined
	#$csq = 1/((2**($FIn*1+0))*4);
	#$clq = 1/((2**($FIn*1+0))*2);

    (my $floor, $start, undef   , my $dfloor, my $dnear, undef) = Edit::Quantize($start, $csq); if ($csq < 0) { $start = $floor; }

	if ($lc) { if ($csq < 0) { $dur += $dfloor; } else { $dur -= $dnear; }} if ($dur <= 0) { $dur = 0; }

	(   $floor, $dur  , my $ceil, undef     , undef    , undef) = Edit::Quantize($dur  , $clq); if ($clq < 0) { $dur   = $floor; } if ($dur <= 0) { $dur = $ceil; }

	$h0->{$k0}{$k1}{$k2}{3} = MIDI::RoundInt($dur*$tpq*4); if (not(defined($gstart))) { $gstart = $start; $gend = $gstart; } if (($start+$dur) > $gend) { $gend = $start+$dur; }
    }

   $new{MIDI::RoundInt($start*$tpq*4)}{scalar(keys(%{$new{MIDI::RoundInt($start*$tpq*4)}}))} = $h0->{$k0}{$k1}{$k2};
   }
  }
 %{$h0->{$k0}} = %new;
 }

$h0->{-1}{3} = $tpq; my $rv0 = undef; my $rv1 = 0; if (defined($gstart)) { $rv0 = $gstart; $rv1 = $gend-$gstart; } return($rv0, $rv1); }
#-------------------------------------------------------------------------------
sub QuantizeTrkChords {
my $h0  = shift(@_);
my $trk =     undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $sp  =     undef; if ($#_ >= 0) { $sp  = shift(@_); } if (not(defined($sp))) { $sp = 0x80; } #split
my $f0  =     undef; if ($#_ >= 0) { $f0  = shift(@_); } if (not(defined($f0))) { $f0 = 1/32; } #ignore every note shorter than this (dreckfuhler)
my $f1  =     undef; if ($#_ >= 0) { $f1  = shift(@_); } if (not(defined($f1))) { $f1 =  1/4; } #consider notes belonging to the same chord if their distance is smaller than this
my $q   =     undef; if ($#_ >= 0) { $q   = shift(@_); } if (not(defined($q ))) { $q  =  1/2; } #quantize setting
my $lq  =     undef; if ($#_ >= 0) { $lq  = shift(@_); } if (not(defined($lq))) { $lq =   $q; } #dur quantize setting
my $lc  =     undef; if ($#_ >= 0) { $lc  = shift(@_); } if (not(defined($lc))) { $lc =    0; } #length correction

my $gstart = undef; my $gend = $gstart;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my $LastStart = undef; my $GroupStart = undef; my @medians;

 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { my $start = $k1/($h0->{-1}{3}*4);
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $key = $h0->{$k0}{$k1}{$k2}{1}; my $dur = $h0->{$k0}{$k1}{$k2}{3}/($h0->{-1}{3}*4);
    if (($key < $sp) && ($dur > $f0)) {

     if (not(defined($GroupStart))) { $GroupStart = $start; }

     if ((defined($LastStart)) && (abs($start - $LastStart) > $f1)) {
       (undef, my $MedianNear, undef, undef, undef, undef) = Edit::Quantize($GroupStart+($LastStart-$GroupStart)/2, $q);
       push(@medians, $MedianNear); $GroupStart = $start;
       }

     $LastStart = $start;
     }
    }
   }
  }

 if (defined($GroupStart)) { (undef, my $MedianNear, undef, undef, undef, undef) = Edit::Quantize($GroupStart+($LastStart-$GroupStart)/2, $q); push(@medians, $MedianNear); }

 #for (my $i=0; $i<=$#medians; $i++) { MIDI::InsertText($h0, 0, $medians[$i], 0, sprintf("$i"), 6, " -> ", 1); } #next;

 $LastStart = undef; $GroupStart = undef; my %new;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { my $start = $k1/($h0->{-1}{3}*4); my $qstart = $start;
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { my $f = 1;

   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $key = $h0->{$k0}{$k1}{$k2}{1}; my $dur = $h0->{$k0}{$k1}{$k2}{3}/($h0->{-1}{3}*4);
    if (($key < $sp) && ($dur > $f0)) {

     if (not(defined($GroupStart))) { $GroupStart = shift(@medians); }

     if ((defined($LastStart)) && (abs($start - $LastStart) > $f1)) { $GroupStart = shift(@medians); } $LastStart = $start;

     $qstart = $GroupStart; if ($lc) { $dur -= $qstart-$start; } if ($dur <= 0) { $dur = 0; }
     (my $floor, $dur, my $ceil, undef, undef, undef) = Edit::Quantize($dur, $lq); if ($lq < 0) { $dur = $floor; } if ($dur <= 0) { $dur = $ceil; }

     if (not(defined($gstart))) { $gstart = $qstart; $gend = $gstart; } if (($qstart+$dur) > $gend) { $gend = $qstart+$dur; }

	 } else { $f = 0; }
	$h0->{$k0}{$k1}{$k2}{3} = int($dur*$h0->{-1}{3}*4);
    }
   if ($f) { $new{MIDI::RoundInt($qstart*$h0->{-1}{3}*4)}{scalar(keys(%{$new{MIDI::RoundInt($qstart*$h0->{-1}{3}*4)}}))} = $h0->{$k0}{$k1}{$k2}; }
   }
  }
 %{$h0->{$k0}} = %new;
 }

my $rv0 = undef; my $rv1 = 0; if (defined($gstart)) { $rv0 = $gstart; $rv1 = $gend-$gstart; } return($rv0, $rv1); }
#-------------------------------------------------------------------------------
sub Copy {
my $h0 =    shift(@_);                                #target midi
my $t0 =    shift(@_);                                #target track
my $h1 =    shift(@_);                                #source midi
my $t1 =    undef; if ($#_ >= 0) { $t1 = shift(@_); } #source track
my $tp =    undef; if ($#_ >= 0) { $tp = shift(@_); } #event type filter (-0xf .. -0x8 or 0x8 .. 0xf)
my $ch =    undef; if ($#_ >= 0) { $ch = shift(@_); } #chanel filter
my $p1 =    undef; if ($#_ >= 0) { $p1 = shift(@_); } #p1 filter
my $sc =        0; if ($#_ >= 0) { $sc = shift(@_); } #start corr.
my $so =        0; if ($#_ >= 0) { $so = shift(@_); } #start time offset
my $lm =    undef; if ($#_ >= 0) { $lm = shift(@_); } #limit
my $tr =        0; if ($#_ >= 0) { $tr = shift(@_); } #transpose
my $v0s =       1; if ($#_ >= 0) { $v0s = shift(@_); } #vel0*
my $v0o =       0; if ($#_ >= 0) { $v0o = shift(@_); } #vel0+
my $v1s =       1; if ($#_ >= 0) { $v1s = shift(@_); } #vel1*
my $v1o =       0; if ($#_ >= 0) { $v1o = shift(@_); } #vel1+
my $rev =   undef; if ($#_ >= 0) { $rev = shift(@_); } if ((defined($rev)) && (not(defined($so)))) { $so = -MIDI::GetEndTime($h1, $t1)/($h1->{-1}{3}*4); } #reverse time

my ($p1s, %p1h) = (undef, ()); if (ref($p1) =~ /HASH/i) { %p1h = %{$p1}; } else { $p1s = $p1; }

$so *= $h0->{-1}{3}*4; if (defined($lm)) { $lm *= $h0->{-1}{3}*4; } my $start = undef; my $end = $start;
foreach my $k0 (sort( {$a <=> $b} (keys(%{$h1})))) { if (($k0 == -1) || (defined($t1)) && ($k0 != $t1)) { next(); }
 foreach my $k1 (sort( {$a <=> $b} (keys(%{$h1->{$k0}})))) {
  my $p1 = $p1s; foreach (sort {$a <=> $b} (keys(%p1h))) { if ($_ <= $k1) { $p1 = $p1h{$_}; } else { last(); }}
  my @e = sort( {$a <=> $b} (keys(%{$h1->{$k0}{$k1}}))); if ((not(defined($tp))) || (defined($tp)) && ($tp != 9)) { @e = sort( {$b <=> $a} (keys(%{$h1->{$k0}{$k1}}))); }
  foreach my $k2 (@e) { my ($f, $dur, $ky, $v0, $v1) = (0, 0, undef, undef, undef);

   if ($h1->{$k0}{$k1}{$k2}{0} >> 4 == 9) {
	$dur = $h1->{$k0}{$k1}{$k2}{3};
	$ky  = $h1->{$k0}{$k1}{$k2}{1}; $ky += $tr;
	$v0  = $h1->{$k0}{$k1}{$k2}{2};                    $v0 = int($v0*$v0s+0x80*$v0o); if ($v0 <= 0x00) { $v0 = 0x01; } if ($v0 > 0x7f) { $v0 = 0x7f; }
	$v1  = $h1->{$k0}{$k1}{$k2}{4}; if ($v1 <= 0x7f) { $v1 = int($v1*$v1s+0x80*$v1o); if ($v1 <= 0x00) { $v1 = 0x00; } if ($v1 > 0x7f) { $v1 = 0x7f; }}
	if ($ky >> 7) { $f = -1; }
	}

   if ((not(defined($tp))) || (($tp < 0) && (($h1->{$k0}{$k1}{$k2}{0} >>  4) != abs($tp  ))) || (($tp >= 0) && (($h1->{$k0}{$k1}{$k2}{0} >>  4) == abs($tp)))) { $f++; }

   if ((not(defined($ch))) || (($ch < 0) && (($h1->{$k0}{$k1}{$k2}{0} & 0xf) != abs($ch+1))) || (($ch >= 0) && (($h1->{$k0}{$k1}{$k2}{0} & 0xf) == abs($ch)))) { $f++; }

   if ((not(defined($p1))) || (eval($h1->{$k0}{$k1}{$k2}{1}.$p1))) { $f++; }

   if ($f >= 3) { if (not(defined($start))) { $start = $k1; $end = $start; }

	if ((not defined($lm)) || ($k1-$start < $lm)) {

	 if ((defined($lm)) && (($k1-$start)+$dur >= $lm)) { $dur = (($k1-$start)+$dur) - $lm; }

	 if ($k1+$dur > $end) { $end = $k1+$dur; }

     my $InsTime = $k1-$start*$sc+$so; if (defined($rev)) { $InsTime = $dur*$rev-$InsTime; } $InsTime = MIDI::RoundInt($InsTime);
	 my $InsEvnt = scalar(keys(%{$h0->{$t0}{$InsTime}}));
	 if ($InsEvnt) {                           $InsEvnt = (sort( {$b <=> $a} keys(%{$h0->{$t0}{$InsTime}})))[0]+1;
	  if ($h1->{$k0}{$k1}{$k2}{0} >> 4 != 9) { $InsEvnt = (sort( {$a <=> $b} keys(%{$h0->{$t0}{$InsTime}})))[0]-1; }}
	 %{$h0->{$t0}{$InsTime}{$InsEvnt}} = %{$h1->{$k0}{$k1}{$k2}};
     if ($h1->{$k0}{$k1}{$k2}{0} >> 4 == 9) {
	  $h0->{$t0}{$InsTime}{$InsEvnt}{3} = int($dur);
	  $h0->{$t0}{$InsTime}{$InsEvnt}{1} = $ky;
	  $h0->{$t0}{$InsTime}{$InsEvnt}{2} = $v0;
	  $h0->{$t0}{$InsTime}{$InsEvnt}{4} = $v1;
	  }
	 }
	}
   }
  }
 }

my $rv0 = undef; my $rv1 = 0; if (defined($start)) { $rv0 = ($start-$start*$sc+$so)/($h0->{-1}{3}*4); $rv1 = ($end-$start)/($h0->{-1}{3}*4); } return($rv0, $rv1); }
#-------------------------------------------------------------------------------
sub Randomize {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $sr  =            0; if ($#_ >= 0) { $sr  = shift(@_); } #start
my $dr  =            0; if ($#_ >= 0) { $dr  = shift(@_); } #duration
my $vr0 =            0; if ($#_ >= 0) { $vr0 = shift(@_); } #velocity
my $vr1 =            0; if ($#_ >= 0) { $vr1 = shift(@_); } #velocity
my $p0  =            0; if ($#_ >= 0) { $p0  = shift(@_); } #start distribution type (full/half+/- gaussian)
my $p1  =        '>=0'; if ($#_ >= 0) { $p1  = shift(@_); } #p1 filter

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my %new;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { my $start = $k1/($h0->{-1}{3}*4);
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) && (eval($h0->{$k0}{$k1}{$k2}{1}.$p1))) { my $dur = $h0->{$k0}{$k1}{$k2}{3}/($h0->{-1}{3}*4); my $v0 = $h0->{$k0}{$k1}{$k2}{2}; my $v1 = $h0->{$k0}{$k1}{$k2}{4}&0x7f;

    my $dc = 1; if ($sr < 0) { $dc = $dur; } my $so = rand()-0.5; if ($p0) { $so = abs($so)*$p0; } $start += abs($sr) * $so * $dc;

	$dur *= (1.0-rand()*$dr);

	$v0 = int($v0*(1.0-rand()*$vr0)); if ($v0 <= 0x00) { $v0 = 0x01; } if ($v0 > 0x7f) { $v0 = 0x7f; }
	$v1 = int($v1*(1.0-rand()*$vr1)); if ($v1 <= 0x00) { $v1 = 0x00; } if ($v1 > 0x7f) { $v1 = 0x7f; }

	$h0->{$k0}{$k1}{$k2}{3} = int($dur*$h0->{-1}{3}*4);
	$h0->{$k0}{$k1}{$k2}{2} = $v0;
	$h0->{$k0}{$k1}{$k2}{4} = $v1;

	if (($sr != 0) && ($dur == 0)) { delete($h0->{$k0}{$k1}{$k2}); next(); }
    }

   $new{int($start*$h0->{-1}{3}*4)}{scalar(keys(%{$new{int($start*$h0->{-1}{3}*4)}}))} = $h0->{$k0}{$k1}{$k2};
   }
  }
 %{$h0->{$k0}} = %new;
 }

return(0); }
#-------------------------------------------------------------------------------
sub Fade {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $Time  = 1/1; if ($#_ >= 0) { $Time  = shift(@_); }
my $InOut = 1.0; if ($#_ >= 0) { $InOut = shift(@_); }

my $FadeStart = MIDI::GetEndTime($h0, $trk)/($h0->{-1}{3}*4)-$Time; my $v0 = 1; my $v1 = 0; if ($InOut <= 0) { $FadeStart = MIDI::GetStartTime($h0, $trk)/($h0->{-1}{3}*4); $v0 = 0; $v1 = 1; }

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 MIDI::InsertCtlr($h0, $k0, $FadeStart, 0, undef, $Time, undef, 0x101, 1, 0, $v0, $v1);
 MIDI::InsertCtlr($h0, $k0, $FadeStart, 0, undef, $Time, undef, 0x102, 1, 0, $v0, $v1);
 }

return(0); }
#-------------------------------------------------------------------------------
sub Portamento {
my $h0             = shift(@_);
my $trk            =     undef; if ($#_ >= 0) { $trk            = shift(@_); } #track (undef = all tracks)
my $PortamentoTime =         0; if ($#_ >= 0) { $PortamentoTime = shift(@_); }
my $DelNotes       =         0; if ($#_ >= 0) { $DelNotes       = shift(@_); } my $FlatNotes = 1; my $Push = 0; if ($DelNotes < -1) { $Push++; } if ($DelNotes < 0) { $DelNotes = 0; $FlatNotes--; }
my $BaseNote       =     undef; if ($#_ >= 0) { $BaseNote       = shift(@_); }
my $PBS            =     undef; if ($#_ >= 0) { $PBS            = shift(@_); }
my $Ctl            =    0x0104; if ($#_ >= 0) { $Ctl            = shift(@_); }
my $Fn             =         1; if ($#_ >= 0) { $Fn             = shift(@_); }
my $CutPT          =     undef; if ($#_ >= 0) { $CutPT          = shift(@_); }
my $DurFlt         =     undef; if ($#_ >= 0) { $DurFlt         = shift(@_); }
my $CtlRes         =     undef; if ($#_ >= 0) { $CtlRes         = shift(@_); }
my $CtlTrk         =     undef; if ($#_ >= 0) { $CtlTrk         = shift(@_); }
my $t0             =     undef; if ($#_ >= 0) { $t0             = shift(@_); }
my $f0             =     undef; if ($#_ >= 0) { $f0             = shift(@_); }
my $ReTrigger      =     undef; if ($#_ >= 0) { $ReTrigger      = shift(@_); }

my @k1s;
if (defined($t0) && exists($h0->{$t0})) {
 foreach my $k1 (sort( {$a <=> $b} keys(%{$h0->{$t0}}))) {
  foreach my $k2 (sort( {$a <=> $b} keys(%{$h0->{$t0}{$k1}}))) {
   if (defined($f0) && $h0->{$t0}{$k1}{$k2}{0} == ($f0>>8) && $h0->{$t0}{$k1}{$k2}{1} == ($f0&0xff)) {
    my ($txt, $i) = ('', 2); while (exists($h0->{$t0}{$k1}{$k2}{$i})) { $txt .= chr($h0->{$t0}{$k1}{$k2}{$i++}); }
    if (defined($ReTrigger) && $txt =~ $ReTrigger) { push(@k1s, $k1); }
    }
   }
  }
 }

my $LoNote = 128; my $HiNote = -1; my $MaxNoteDiff = 0;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my $LastNote = undef;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $Note = $h0->{$k0}{$k1}{$k2}{1};
    if ($Note < $LoNote) { $LoNote = $Note; }
    if ($Note > $HiNote) { $HiNote = $Note; }
	if ((defined($LastNote)) && (abs($Note-$LastNote) > $MaxNoteDiff)) { $MaxNoteDiff = abs($Note-$LastNote); } $LastNote = $Note;
    }
   }
  }
 }

my $APBS = int((($HiNote-$LoNote)+1)/2); my $ABaseNote = $HiNote-$APBS;

if (not(defined($BaseNote))) { $BaseNote = $ABaseNote; } elsif (not(defined($PBS))) { $APBS = abs($HiNote-$BaseNote); if (abs($LoNote-$BaseNote)>$APBS) { $APBS = abs($LoNote-$BaseNote) }}
if (not(defined($PBS))) { $PBS = $APBS; if ($FlatNotes < 1) { $PBS = $MaxNoteDiff; }}

my %PBLut; for (my $i=0; $i<=$PBS; $i++) { $PBLut{$i} = 0; if ($PBS) { $PBLut{$i} = $i/$PBS; } $PBLut{-$i} = -$PBLut{$i}; }

my $LastStart = undef; my $LastDur = undef; my $LastNote = undef; my $LastK1 = undef; my $LastK2 = undef; my $LastPB = undef; my ($p0, $mk1, $cnt) = (0, undef, 0);
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my $CtlrTrk = $k0; if (defined($CtlTrk)) { $CtlrTrk = $CtlTrk; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { while ($#k1s >= $p0 && $k1s[$p0] <= $k1) { $mk1 = $k1s[$p0++]; $cnt++; }
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $Ch = $h0->{$k0}{$k1}{$k2}{0}&0xf; my $Note = $h0->{$k0}{$k1}{$k2}{1}; my $Dur = $h0->{$k0}{$k1}{$k2}{3};

    my $pt = $PortamentoTime; if ($pt < 0) { $pt = ($Dur/($h0->{-1}{3}*4))*abs($pt); } if ($pt > ($Dur/($h0->{-1}{3}*4))) { $pt = $Dur/($h0->{-1}{3}*4); if (defined($CutPT)) { $pt = $CutPT; }}

    if ((defined($DurFlt)) && (($Dur/($h0->{-1}{3}*4)) < $DurFlt)) { $pt = 0; }

	if ($FlatNotes) { $h0->{$k0}{$k1}{$k2}{1} = $BaseNote; } else { $BaseNote = $Note; } my $s = $k1/($h0->{-1}{3}*4); my $PBEnd = $Note-$BaseNote;

    my $PBStart = $PBEnd; if (defined($LastNote)) { $PBStart = $LastNote-$BaseNote; if ($Push) { $h0->{$k0}{$k1}{$k2}{1} = $LastNote; ($PBStart, $PBEnd) = (-$PBEnd, -$PBStart); }}

    if     (!$cnt && (defined($LastPB)) && ($pt == 0) &&                         ($PBEnd == $LastPB)) {}
     elsif (!$cnt && (defined($LastPB)) && ($pt  > 0) && ($PBStart == $PBEnd) && ($PBEnd == $LastPB)) {}
     else { $s += MIDI::InsertCtlr($h0, $CtlrTrk, $s, 0, $Ch, $pt, $CtlRes, $Ctl, $Fn, 1, $PBLut{$PBStart}, $PBLut{$PBEnd}); $cnt = 0; }

    if ((not(defined($LastStart))) || ($LastStart+$LastDur < $k1) || (($Note == $LastNote) && ($DelNotes < 2))) { $LastK1 = $k1; $LastK2 = $k2; }
	 elsif ($DelNotes) { my $StartTimeDiff = 0; if ($k1-$LastK1 < $h0->{$k0}{$LastK1}{$LastK2}{3}) { $StartTimeDiff = $h0->{$k0}{$LastK1}{$LastK2}{3}-($k1-$LastK1); }
	  $h0->{$k0}{$LastK1}{$LastK2}{3} += $h0->{$k0}{$k1}{$k2}{3}-$StartTimeDiff; delete($h0->{$k0}{$k1}{$k2}); }

	$LastStart = $k1; $LastDur = $Dur; $LastNote = $Note; $LastPB = $PBEnd;
    }

   }
  if (scalar(keys(%{$h0->{$k0}{$k1}})) <= 0) { delete($h0->{$k0}{$k1}); }
  }
 if (scalar(keys(%{$h0->{$k0}})) <= 0) { delete($h0->{$k0}); }
 }

if ($HiNote < 0) { $PBS = undef; } return($PBS); }
#-------------------------------------------------------------------------------
sub FitLength {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $nlf =        undef; if ($#_ >= 0) { $nlf = shift(@_); } #note length filter
my $lc  =          1.0; if ($#_ >= 0) { $lc  = shift(@_); } my $flg = 1; if ($lc < 0) { $flg--; } $lc = abs($lc); #note length correction

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my $LastNoteOnTime = undef;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { if (not(defined($LastNoteOnTime))) { $LastNoteOnTime = $k1; }
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) {

    if ($k1 > $LastNoteOnTime) {
     foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$LastNoteOnTime}}) {
      if ($h0->{$k0}{$LastNoteOnTime}{$k2}{0} >> 4 == 9) { my $duri = $h0->{$k0}{$LastNoteOnTime}{$k2}{3}; my $dur = $duri / ($h0->{-1}{3}*4);
       if ((not(defined($nlf)) || eval($dur.$nlf)) && (($flg) || ($LastNoteOnTime+$duri < $k1))) { $h0->{$k0}{$LastNoteOnTime}{$k2}{3} = int(($k1 - $LastNoteOnTime)*$lc); }
       }
      }
     $LastNoteOnTime = $k1;
     }

    }
   }
  }
 }

return(0); }
#-------------------------------------------------------------------------------
sub MergeNotes { my ($h0, $k0) = @_; my $t = 0/1; if ($#_ >= 2) { $t = $_[2]; }

my %LastNotes;
foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
 foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
  if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $Note = $h0->{$k0}{$k1}{$k2}{1}; my $Dur = $h0->{$k0}{$k1}{$k2}{3};

   if (exists($LastNotes{$Note})) { my ($LastK1, $LastK2) = @{$LastNotes{$Note}};
	if ($LastK1+$h0->{$k0}{$LastK1}{$LastK2}{3}+$t*$h0->{-1}{3}*4 >= $k1) {
	 $h0->{$k0}{$LastK1}{$LastK2}{3} = ($k1-$LastK1)+$Dur; delete($h0->{$k0}{$k1}{$k2});
	 } else { $LastNotes{$Note} = [$k1, $k2]; }
	} else { $LastNotes{$Note} = [$k1, $k2]; }

   }
  }
 if (scalar(keys(%{$h0->{$k0}{$k1}})) <= 0) { delete($h0->{$k0}{$k1}); }
 }
if (scalar(keys(%{$h0->{$k0}})) <= 0) { delete($h0->{$k0}); }

return(undef); }
#-------------------------------------------------------------------------------
sub DeleteNotes { my ($h0, $k0) = @_; my $t = 0/1; if ($#_ >= 2) { $t = $_[2]; }

foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
 foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
  if (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) && ($h0->{$k0}{$k1}{$k2}{3} <= $t*$h0->{-1}{3}*4)) { delete($h0->{$k0}{$k1}{$k2}); }
  }
 if (scalar(keys(%{$h0->{$k0}{$k1}})) <= 0) { delete($h0->{$k0}{$k1}); }
 }
if (scalar(keys(%{$h0->{$k0}})) <= 0) { delete($h0->{$k0}); }

return(undef); }
#-------------------------------------------------------------------------------
sub AccentNotes { my ($h0, $k0, $s, $l, $NoteFilter, $o, $ValDef, $GrooveLength, $GrooveSnap, $GrooveVals) = @_;

my %GrooveValsQ; foreach my $k0 (sort {$a <=> $b} keys %{$GrooveVals}) { my (undef, $qn, undef, undef, undef, undef) = Edit::Quantize($k0, $GrooveSnap); $GrooveValsQ{$qn} = $GrooveVals->{$k0}; }

foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { my $start = $k1/($h0->{-1}{3}*4);
 foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
  if (((not(defined($s))) || ($start >= $s) && ((not(defined($l))) || ($start < $s+$l))) && ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) && ((not(defined($NoteFilter))) || ($h0->{$k0}{$k1}{$k2}{1} == $NoteFilter)))
   {
   my ($k, $v) = ($h0->{$k0}{$k1}{$k2}{1}, $h0->{$k0}{$k1}{$k2}{2}/0x7f);

   my (undef, $StartQGL, undef, undef, undef, undef) = Edit::Quantize(abs($start)-$GrooveLength/2, $GrooveLength);
   my (undef, $StartQG,  undef, undef, undef, undef) = Edit::Quantize(abs($start), $GrooveSnap);
   my $GrooveDT = abs($StartQG-$StartQGL); if ($GrooveDT >= $GrooveLength) { $GrooveDT = 0; }
   my $Val = $ValDef; if (exists($GrooveValsQ{$GrooveDT})) { $Val = $GrooveValsQ{$GrooveDT}; }

   if ($o) { $v *= $Val; } else { $k += $Val; }

   $v *= 0x7f; if ($v <= 0x00) { $v = 0x01; } if ($v > 0x7f) { $v = 0x7f; }
   ($h0->{$k0}{$k1}{$k2}{1}, $h0->{$k0}{$k1}{$k2}{2}) = ($k, int($v+.5));
   }
  }
 }

return(undef); }
#-------------------------------------------------------------------------------
sub Sustain2NoteOff { my ($h0, $k0, $d) = @_;

if (not(defined($d))) { $d = 1; }

my $Sustain = 0; my %Latest;
foreach my $k1 (sort {$a <=> $b} keys(%{$h0->{$k0}})) {
 foreach my $k2 (sort {$a <=> $b} keys(%{$h0->{$k0}{$k1}})) {

  if (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0xb) && ($h0->{$k0}{$k1}{$k2}{1} == 0x40)) { $Sustain = $h0->{$k0}{$k1}{$k2}{2} >> 6;
   if (!$Sustain) { foreach my $note (sort {$a <=> $b} keys(%Latest)) { my ($lk1, $lk2) = @{$Latest{$note}}; $h0->{$k0}{$lk1}{$lk2}{3} = $k1-$lk1; } %Latest = (); }
   if ($d) { delete($h0->{$k0}{$k1}{$k2}); next(); }
   }

  if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) { my $note = $h0->{$k0}{$k1}{$k2}{1};
   if (exists($Latest{$note})) { my ($lk1, $lk2) = @{$Latest{$note}}; $h0->{$k0}{$lk1}{$lk2}{3} = $k1-$lk1; }
   if ($Sustain) { $Latest{$h0->{$k0}{$k1}{$k2}{1}} = [$k1, $k2]; }
   }
  }
 }

return(undef); }
#-------------------------------------------------------------------------------
sub AddLyric {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $s   =        undef; if ($#_ >= 1) { $s   = shift(@_); }
my $lyr =           ""; if ($#_ >= 0) { $lyr = shift(@_); } my @Lyrics = split(" ", $lyr);

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { if ((defined($s)) && ($k1/($h0->{-1}{3}*4) < $s)) { next(); }
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) && ($#Lyrics >= 0)) { MIDI::InsertText($h0, $k0, $k1/($h0->{-1}{3}*4), 0, shift(@Lyrics), 0x05); }

   }
  }
 }

return(0); }
#-------------------------------------------------------------------------------
sub AddLyricString {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $lyr =          " "; if ($#_ >= 0) { $lyr = shift(@_); } my @Lyrics = split('', $lyr);

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x05)) {
    for (my $i = 0; $i <= $#Lyrics; $i++) { $h0->{$k0}{$k1}{$k2}{scalar(keys(%{$h0->{$k0}{$k1}{$k2}}))} = ord($Lyrics[$i]); }
	}

   }
  }
 }

return(0); }
#-------------------------------------------------------------------------------
sub Lyric2Text {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x05)) { $h0->{$k0}{$k1}{$k2}{1} = 0x01; }

   }
  }
 }

return(0); }
#-------------------------------------------------------------------------------
sub SubstText { my $h0 = shift(@_); if ($#_ < 0) { @_ = ('�','ae', '�','AE', '�','oe', '�','OE', '�','ue', '�','UE', '�','ss'); }

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if ($k0 == -1) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} >= 0x01) && ($h0->{$k0}{$k1}{$k2}{1} <= 0x09)) {
    my $i = 2; my $txt = ""; while (exists($h0->{$k0}{$k1}{$k2}{$i})) { $txt .= chr($h0->{$k0}{$k1}{$k2}{$i}); delete($h0->{$k0}{$k1}{$k2}{$i}); $i++; }

    for (my $i=0; $i<=$#_; $i+=2) { my ($s0, $s1) = ($_[$i], $_[$i+1]); $txt =~ s/$s0/$s1/g; }

    my @tmp0 = split('', $txt); for (my $i=0; $i<=$#tmp0; $i++) { $h0->{$k0}{$k1}{$k2}{$i+2} = ord($tmp0[$i]); }
	}

   }
  }
 }

return(0); }
#===============================================================================

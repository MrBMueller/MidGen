#!/tool/pandora/bin/perl5.10.0 -w
use strict; use warnings; $| = 1; use Cwd; our $WrkDir0 = Cwd::getcwd();

my @MyTmpSplit0 = split(/[\/\\]/, Cwd::abs_path($0)); if ($#MyTmpSplit0 > 0) { delete($MyTmpSplit0[$#MyTmpSplit0]); } our $SrcDir0 = join("/", @MyTmpSplit0);

our $PrjFile = "$main::SrcDir0/Projects/Current.pl"; my @PrjAttrs = stat($PrjFile); if ($#PrjAttrs < 0) { $PrjFile = "$main::SrcDir0/Projects/Default.pl"; } if (($#ARGV >= 0) && ($ARGV[0] =~ /\.p[lm]$/i)) { $PrjFile = $ARGV[0]; }

@MyTmpSplit0 = split(/[\/\\]/, Cwd::abs_path($main::PrjFile)); $main::PrjFile = $MyTmpSplit0[$#MyTmpSplit0]; delete($MyTmpSplit0[$#MyTmpSplit0]); our $PrjDir0 = join("/", @MyTmpSplit0);

push(@INC, ($main::WrkDir0, $main::PrjDir0, $main::SrcDir0, "$main::SrcDir0/Devices", "$main::SrcDir0/Sequences")); eval("use MIDI; use Edit; use MidiDebug;");

our $InFile = "$main::PrjDir0/$PrjFile"; our $OutFile = "$main::WrkDir0/MyTest0.mid";

our $SrcDrive = ''; if ($main::SrcDir0 =~ /^([A-Z]:)[\/\\]/i) { $main::SrcDrive = $1; }
our $PrjDrive = ''; if ($main::PrjDir0 =~ /^([A-Z]:)[\/\\]/i) { $main::PrjDrive = $1; }
our $WrkDrive = ''; if ($main::WrkDir0 =~ /^([A-Z]:)[\/\\]/i) { $main::WrkDrive = $1; }

our %out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); our $DummyNop = 0; #default general output setup

our %trks = (); our @trks = ([-1, -2, -3, -4, -5, -6, 0x07, 0x0b, 0x2000a, 0x5b, 0x47, 0x4a, 0x4000, 0x20104]); our @InitParams = ();

if (($#ARGV >= 0) && ($ARGV[$#ARGV] =~ /\.(mid|smf)$/i)) { my %test1 = MIDI::Read($ARGV[$#ARGV]); MidiDebug::PrintInfo(\%test1); MIDI::Write(\%test1, $main::OutFile); exit(0); }

do($main::InFile); MyLabelEnd:

if ($#main::trks > 0) { %main::trks = (); my @h = @{$main::trks[0]};
 for (my $t=1; $t<=$#main::trks; $t++) { my @trk = @{$main::trks[$t]}; for (my $c=0; $c<=$#trk; $c++) { if (($c <= $#h) && (defined($h[$c]))) { $main::trks{$t-1}{$h[$c]} = $trk[$c]; }}}
 }

MIDI::Init(\%main::out, \%main::trks, @InitParams); MIDI::RemoveOverlap(\%main::out); MidiDebug::PrintInfo(\%main::out); MIDI::Write(\%main::out, undef, $main::DummyNop); exit(0);
#===============================================================================

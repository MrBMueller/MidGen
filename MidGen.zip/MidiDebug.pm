use strict; use warnings; package MidiDebug; our $OutPath = "./"; our %Prgs; $Prgs{-1} = {ImportCubaseParseFile("$main::SrcDir0/DeviceMaps/Default.txt", "Def")};

#$Prgs{0x00} = {}; DeepCloneHash($Prgs{-1}, $Prgs{0x00}); #$Prgs{0x00}{-1} = "P00";
#$Prgs{0x01} = {}; DeepCloneHash($Prgs{-1}, $Prgs{0x01}); #$Prgs{0x01}{-1} = "P01";

return(1);
#===============================================================================
sub DeepCloneHash { my $h0 = shift(@_); my $h1 = shift(@_);

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) {
 if (ref($h0->{$k0}) eq 'HASH') { $h1->{$k0} = {}; DeepCloneHash($h0->{$k0}, $h1->{$k0}); }
  else                          { $h1->{$k0} = $h0->{$k0}; }
 }

}
#===============================================================================
sub ImportCubaseParseFile {
my $fname  = ""; if ($#_ >= 0) { $fname      = shift(@_); }
my %RetVal = (); if ($#_ >= 0) { $RetVal{-1} = shift(@_); } #PortName

my @NoteLut = ('C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B');

$RetVal{0xc}{ -1}{-1}{-1} = sprintf("-1"); #bankname (channel x, bank x)
#$RetVal{0xc}{0x9}{-1}{-1} = sprintf("-1"); #bankname (channel 9, bank x)
for (my $i=0; $i <= 0x7f; $i++) {
 $RetVal{0xb}{$i}              = sprintf("%d", $i);                             #ctrl  name
 $RetVal{0xc}{ -1}{-1}{$i}     = sprintf("%d", $i);                             #patch name (channel x, bank x)
 #$RetVal{0xc}{0x9}{-1}{$i}     = sprintf("%d", $i);                             #patch name (channel 9, bank x)
 $RetVal{0x9}{ -1}{-1}{-1}{$i} = sprintf("%d %s", int($i/12), $NoteLut[$i%12]); #key   name (channel x, bank x, patch x)
 $RetVal{0x9}{0x9}{-1}{-1}{$i} = sprintf("%d", $i);                             #key   name (channel 9, bank x, patch x)
 }

$RetVal{0xb}{0x00} = 'BankSelectMSB';
$RetVal{0xb}{0x01} = 'Modulation';
$RetVal{0xb}{0x07} = 'Volume';
$RetVal{0xb}{0x0a} = 'Pan';
$RetVal{0xb}{0x0b} = 'Expression';
$RetVal{0xb}{0x20} = 'BankSelectLSB';
$RetVal{0xb}{0x21} = 'ModulationLSB';
$RetVal{0xb}{0x27} = 'VolumeLSB';
$RetVal{0xb}{0x2a} = 'PanLSB';
$RetVal{0xb}{0x2b} = 'ExpressionLSB';
$RetVal{0xb}{0x5b} = 'Reverb';
$RetVal{0xb}{0x5d} = 'Chorus';
$RetVal{0xb}{0x79} = 'Reset All Controllers';

my @MyAttrs0 = stat($fname); if ($#MyAttrs0 < 0) { return(%RetVal); }
open(my_file1, $fname); my $ch = -1; my $prg = -1;
while (<my_file1>) { my $Bank = 0x0000; my $key = -1; my $name = "";

 if ($_ =~ /\[\s*mode\s*(-?\d+)\s*\]\s*(.*)/) { $ch = $1-1; $name = $2; }

 if ($_ =~ /\[\s*p\d+\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\]\s*(.*)/) {
  if ($2 >= 0) { $Bank = ($Bank & 0x007f) | ($2<<7); }
  if ($3 >= 0) { $Bank = ($Bank & 0x3f80) | ($3<<0); }
  $prg = $1; $name = $4;
  $RetVal{0xc}{$ch}{$Bank}{$prg} = $name;
  }

 if ($_ =~ /\[\s*p\d+\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\]\s*(.*)/) { $Bank = $2; $prg = $1; $name = $3; $RetVal{0xc}{$ch}{$Bank}{$prg} = $name; }

 if ($_ =~ /\[\s*k\s*(-?\d+)\s*\]\s*(.*)/) { $key = $1-1; $name = $2; $RetVal{0x9}{$ch}{$Bank}{$prg}{$key} = $name; }
 }
close(my_file1);

return(%RetVal); }
#-------------------------------------------------------------------------------
sub PrintInfo {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)

my $GStartTime = undef; my $GStopTime = undef; my $GTempo = -120; my $GCopyright = undef; my $TrkCnt = -1;

my $trks = -1; if (exists($h0->{-1}{2})) { $trks = $h0->{-1}{2}; } my $ts = ""; if (exists($h0->{-1}{-1})) { $ts = $h0->{-1}{-1}; } printf("'%s' ($ts) %d %d $trks\n", $h0->{-1}{0}, $h0->{-1}{3}, $h0->{-1}{1});

my ($n, $d) = (4, 4); if (exists($h0->{-1}{5})) { $n = $h0->{-1}{5}; } if (exists($h0->{-1}{6})) { $d = $h0->{-1}{6}; }

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 if ($k0 != int($k0)) { printf("%s $k0\n", (caller(0))[3]); } #datatype sanity check (int)
 printf("%2d %2d", ++$TrkCnt, $k0);
 my $Events = 0; my ($TName, $TName1) = (undef, undef); my $StartTime = undef; my $StopTime = undef; my $Port = -1; my $DName = ''; my $Ch = -1; my $BankMSB = -1; my $BankLSB = -1; my $Prg = -1; my %Chns;
 my $Vol = -1; my $Pan = -1; my $Exp = -1;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  if ($k1 != int($k1)) { printf("%s $k0 $k1\n", (caller(0))[3]); } #datatype sanity check (int)
  if ((not defined($StartTime)) || ($k1 < $StartTime)) { $StartTime = $k1; }
  if ((not defined($StopTime )) || ($k1 > $StopTime )) { $StopTime  = $k1; }
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { $Events++; my $Event = $h0->{$k0}{$k1}{$k2}{0}>>4; my $Chn = $h0->{$k0}{$k1}{$k2}{0}&0xf;
   if ($k2 != int($k2)) { printf("%s $k0 $k1 $k2\n", (caller(0))[3]); } #datatype sanity check (int)

   foreach my $k3 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}{$k2}}) {
    if (                     $k3  != int(                     $k3 )) { printf("%s $k0 $k1 $k2 $k3\n"   , (caller(0))[3]                           ); } #datatype sanity check (int)
    if ($h0->{$k0}{$k1}{$k2}{$k3} != int($h0->{$k0}{$k1}{$k2}{$k3})) { printf("%s $k0 $k1 $k2 $k3 %d\n", (caller(0))[3], $h0->{$k0}{$k1}{$k2}{$k3}); } #datatype sanity check (int)
	}

   if (($Event >= 0x8) && ($Event <= 0xe)) { $Chns{$Chn}++; if ($Ch < 0) { $Ch = $Chn; }}

   if (($Event == 0x9) && (scalar(keys(%{$h0->{$k0}{$k1}{$k2}}))>3)) { my $l = $h0->{$k0}{$k1}{$k2}{3}; if ($k1+$l > $StopTime) { $StopTime = $k1+$l; }}

   if (($Event == 0xb) && ($Chn == $Ch) && ($h0->{$k0}{$k1}{$k2}{1} == 0x00) && ($BankMSB < 0)) { $BankMSB = $h0->{$k0}{$k1}{$k2}{2}; }
   if (($Event == 0xb) && ($Chn == $Ch) && ($h0->{$k0}{$k1}{$k2}{1} == 0x20) && ($BankLSB < 0)) { $BankLSB = $h0->{$k0}{$k1}{$k2}{2}; }

   if (($Event == 0xb) && ($Chn == $Ch) && ($h0->{$k0}{$k1}{$k2}{1} == 0x07) && ($Vol < 0)) { $Vol = $h0->{$k0}{$k1}{$k2}{2}; }
   if (($Event == 0xb) && ($Chn == $Ch) && ($h0->{$k0}{$k1}{$k2}{1} == 0x0a) && ($Pan < 0)) { $Pan = $h0->{$k0}{$k1}{$k2}{2}; }
   if (($Event == 0xb) && ($Chn == $Ch) && ($h0->{$k0}{$k1}{$k2}{1} == 0x0b) && ($Exp < 0)) { $Exp = $h0->{$k0}{$k1}{$k2}{2}; }

   if (($Event == 0xc) && ($Chn == $Ch) && ($Prg < 0)) { $Prg = $h0->{$k0}{$k1}{$k2}{1}; }

   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x21) && ($Port < 0)) { $Port = $h0->{$k0}{$k1}{$k2}{2}; }

   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x51) && ($GTempo < 0)) {
    $GTempo = 60000000/(($h0->{$k0}{$k1}{$k2}{2}<<16) + ($h0->{$k0}{$k1}{$k2}{3}<<8) + $h0->{$k0}{$k1}{$k2}{4});
    }

   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x01)) { if (not(defined($TName1))) { $TName1 = '';
    my $i = 2; while (exists($h0->{$k0}{$k1}{$k2}{$i})) { $TName1 .= chr($h0->{$k0}{$k1}{$k2}{$i}); $i++; }}
    }
   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x02)) { if (not(defined($GCopyright))) { $GCopyright = ''; }
    my $i = 2; while (exists($h0->{$k0}{$k1}{$k2}{$i})) { $GCopyright .= chr($h0->{$k0}{$k1}{$k2}{$i}); $i++; }
    }
   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x03)) { if (not(defined($TName))) { $TName = ''; }
    my $i = 2; while (exists($h0->{$k0}{$k1}{$k2}{$i})) { $TName .= chr($h0->{$k0}{$k1}{$k2}{$i}); $i++; }
    }
   if (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x09) && !length($DName)) {
    my $i = 2; while (exists($h0->{$k0}{$k1}{$k2}{$i})) { $DName .= chr($h0->{$k0}{$k1}{$k2}{$i}); $i++; } $DName .= ':';
    }

   }
  }

 if (not(defined($TName))) { $TName = $TName1; } if (defined($TName)) { $TName = "'".$TName."'"; } else { $TName = ''; } my $Bank = 0x0000;
 if ((not defined($GStartTime)) || (defined($StartTime)) && ($StartTime < $GStartTime)) { $GStartTime = $StartTime; }
 if ((not defined($GStopTime )) || (defined($StopTime )) && ($StopTime  > $GStopTime )) { $GStopTime  = $StopTime;  }
 my $BMSBN = "--"; if ($BankMSB >= 0) { $Bank = ($Bank&0x007f) | ($BankMSB<<7); $BMSBN = sprintf("%02x", $BankMSB); }
 my $BLSBN = "--"; if ($BankLSB >= 0) { $Bank = ($Bank&0x3f80) | ($BankLSB<<0); $BLSBN = sprintf("%02x", $BankLSB); }
 my $PrgN  = "--"; if ($Prg  >= 0) { $PrgN  = sprintf("%02x", $Prg ); }
 my $ChN   =  "-"; if ($Ch   >= 0) { $ChN   = sprintf("%x",   $Ch  ); }
 my $PortN = "--"; if ($Port >= 0) { $PortN = sprintf("%02x", $Port); }
 my $VolN  =  "----"; if ($Vol  >= 0) { $VolN  = sprintf("%1.2f", $Vol/127 ); }
 my $ExpN  =  "----"; if ($Exp  >= 0) { $ExpN  = sprintf("%1.2f", $Exp/127 ); }
 my $PanN  =  " ---"; if ($Pan  >= 0) { $PanN  = ""; if ($Pan >= 64) { $PanN = " "; } $PanN .= sprintf("%1.1f", (($Pan/127)-0.5)*2); }

 my $PrtName = $Prgs{-1}{-1}; if (exists($Prgs{$Port}{-1})) { $PrtName = $Prgs{$Port}{-1}; } my $BName = $Prgs{-1}{0xc}{-1}{-1}{-1}; my $PName = $Prgs{-1}{0xc}{-1}{-1}{$Prg};

 if     (exists($Prgs{$Port}{0xc}{$Ch}{$Bank}{  -1})) { $BName = $Prgs{$Port}{0xc}{$Ch}{$Bank}{  -1}; }
  elsif (exists($Prgs{$Port}{0xc}{$Ch}{   -1}{  -1})) { $BName = $Prgs{$Port}{0xc}{$Ch}{   -1}{  -1}; }
  elsif (exists($Prgs{$Port}{0xc}{ -1}{$Bank}{  -1})) { $BName = $Prgs{$Port}{0xc}{ -1}{$Bank}{  -1}; }
  elsif (exists($Prgs{$Port}{0xc}{ -1}{   -1}{  -1})) { $BName = $Prgs{$Port}{0xc}{ -1}{   -1}{  -1}; }
  elsif (exists($Prgs{   -1}{0xc}{$Ch}{$Bank}{  -1})) { $BName = $Prgs{   -1}{0xc}{$Ch}{$Bank}{  -1}; }
  elsif (exists($Prgs{   -1}{0xc}{$Ch}{   -1}{  -1})) { $BName = $Prgs{   -1}{0xc}{$Ch}{   -1}{  -1}; }
  elsif (exists($Prgs{   -1}{0xc}{ -1}{$Bank}{  -1})) { $BName = $Prgs{   -1}{0xc}{ -1}{$Bank}{  -1}; }

 if     (exists($Prgs{$Port}{0xc}{$Ch}{$Bank}{$Prg})) { $PName = $Prgs{$Port}{0xc}{$Ch}{$Bank}{$Prg}; }
  elsif (exists($Prgs{$Port}{0xc}{$Ch}{   -1}{$Prg})) { $PName = $Prgs{$Port}{0xc}{$Ch}{   -1}{$Prg}; }
  elsif (exists($Prgs{$Port}{0xc}{$Ch}{   -1}{  -1})) {                                               }
  elsif (exists($Prgs{$Port}{0xc}{ -1}{$Bank}{$Prg})) { $PName = $Prgs{$Port}{0xc}{ -1}{$Bank}{$Prg}; }
  elsif (exists($Prgs{$Port}{0xc}{ -1}{   -1}{$Prg})) { $PName = $Prgs{$Port}{0xc}{ -1}{   -1}{$Prg}; }
  elsif (exists($Prgs{   -1}{0xc}{$Ch}{$Bank}{$Prg})) { $PName = $Prgs{   -1}{0xc}{$Ch}{$Bank}{$Prg}; }
  elsif (exists($Prgs{   -1}{0xc}{$Ch}{   -1}{$Prg})) { $PName = $Prgs{   -1}{0xc}{$Ch}{   -1}{$Prg}; }
  elsif (exists($Prgs{   -1}{0xc}{$Ch}{   -1}{  -1})) {                                               }
  elsif (exists($Prgs{   -1}{0xc}{ -1}{$Bank}{$Prg})) { $PName = $Prgs{   -1}{0xc}{ -1}{$Bank}{$Prg}; }

 my $PrgName = "$DName$PrtName:$BName:$PName"; if ($Prg < 0) { $PrgName =~ s/^(.*):(.*):(.*)$/$1:$2/gi; if (($BankMSB < 0) && ($BankLSB < 0)) { $PrgName =~ s/^(.*):(.*)$/$1/gi; }}
 $PrgName =~ s/[:]*$//gi; $PrgName = "'$PrgName'"; $PrgName =~ s/^''$//gi;

 if (defined($StopTime)) { $StopTime = abs($StopTime-$StartTime); }
 printf(" %10s %10s %5d %-30s %s %2d %s %s%s %s %s %s %s %s\n", ATime2MBT($StartTime, $h0->{-1}{3}, $n, $d), ATime2MBT($StopTime, $h0->{-1}{3}, $n, $d), $Events, $TName, $PortN, scalar(keys(%Chns)), $ChN, $BMSBN, $BLSBN, $PrgN, $VolN, $ExpN, $PanN, $PrgName);
 }

if (defined($GCopyright)) { $GCopyright = " '".$GCopyright."'"; } else { $GCopyright = ''; }
my $length = 0; if (defined($GStartTime)) { $length = int(((abs($GStopTime-$GStartTime)/$h0->{-1}{3})/abs($GTempo))*60); $GStopTime = abs($GStopTime-$GStartTime); }
printf("%s %s %.2f %d:%02d$GCopyright\n", ATime2MBT($GStartTime, $h0->{-1}{3}, $n, $d), ATime2MBT($GStopTime, $h0->{-1}{3}, $n, $d), $GTempo, int($length/60), $length%60);
ListView($h0, $trk); return(0); }
#-------------------------------------------------------------------------------
sub ListView {
my $h0  = shift(@_);
my $trk =     undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)

my $HDepth = 0;
if ((ref($h0) eq 'HASH') && (scalar(keys %{$h0})>0)) {
 my $l0 = (sort({$a <=> $b} keys(%{$h0})))[-1]; $HDepth++;
 if ((ref($h0->{$l0}) eq 'HASH') && (scalar(keys %{$h0->{$l0}})>0)) {
  my $l1 = (sort({$a <=> $b} keys(%{$h0->{$l0}})))[-1]; $HDepth++;
  if ((ref($h0->{$l0}{$l1}) eq 'HASH') && (scalar(keys %{$h0->{$l0}{$l1}})>0)) {
   my $l2 = (sort({$a <=> $b} keys(%{$h0->{$l0}{$l1}})))[-1]; $HDepth++;
   if ((ref($h0->{$l0}{$l1}{$l2}) eq 'HASH') && (scalar(keys %{$h0->{$l0}{$l1}{$l2}})>0)) {
	my $l3 = (sort({$a <=> $b} keys(%{$h0->{$l0}{$l1}{$l2}})))[-1]; $HDepth++;
    }
   }
  }
 }
$HDepth = 4;

open(my $out, ">&STDOUT");

my %h1; my ($res, $n, $d) = (0x60, 4, 4); my $fname = ""; my $mname = ""; my $ts = ""; my $type = -1; my $tracks = -1; my $TrkCnt = -1;
if ($HDepth == 1) { $h1{0}{0}{0} = $h0; $h0 = \%h1; undef($trk); $fname = "Evnt_"; }
if ($HDepth == 2) { $h1{0}{0}    = $h0; $h0 = \%h1; undef($trk); $fname = "Time_"; }
if ($HDepth == 3) { $h1{0}       = $h0; $h0 = \%h1; undef($trk); $fname = "Trck_"; }
if ($HDepth == 4) {
 if (exists($h0->{-1}{-1})) { $ts     = $h0->{-1}{-1}; }
 if (exists($h0->{-1}{ 0})) { $mname  = $h0->{-1}{ 0}; }
 if (exists($h0->{-1}{ 1})) { $type   = $h0->{-1}{ 1}; }
 if (exists($h0->{-1}{ 2})) { $tracks = $h0->{-1}{ 2}; }
 if (exists($h0->{-1}{ 3})) { $res    = $h0->{-1}{ 3}; }
 if (exists($h0->{-1}{ 5})) { $n      = $h0->{-1}{ 5}; }
 if (exists($h0->{-1}{ 6})) { $d      = $h0->{-1}{ 6}; }}

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 $TrkCnt++; open(STDOUT, sprintf(">$OutPath$fname%02d.txt", $k0)); if ($TrkCnt == 0) { $mname =~ s/%/%%/g; printf("#'$mname' ($ts) $res $type $tracks\n"); } my $Port = -1; my $Bank = 0x0000; my $Prg = -1;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { my $Event = $h0->{$k0}{$k1}{$k2}{0}>>4; my $Ch = $h0->{$k0}{$k1}{$k2}{0}&0xf;

   printf("%08d (%10s): %3d:", $k1, ATime2MBT($k1, $res, $n, $d), $k2); my $str = "";
   foreach my $k3 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}{$k2}}) { if (length($str)) { $str .= sprintf(" "); } $str .= sprintf("%02x", $h0->{$k0}{$k1}{$k2}{$k3}); }
   printf(" {%-20s}", $str);

   if (($Event == 8) || ($Event == 9)) { my $key = $h0->{$k0}{$k1}{$k2}{1}; my $val = $h0->{$k0}{$k1}{$k2}{2};
    printf(" Note %2d %3d %5d %s", $Ch, $key, $val, GetAsciiVal($val));
    if (scalar(keys(%{$h0->{$k0}{$k1}{$k2}}))>3) { my $RelVel = $h0->{$k0}{$k1}{$k2}{4}; if ($RelVel >= 0x100) { $RelVel = -2; } elsif ($RelVel >= 0x80) { $RelVel = -1; }
	 printf(" (%10s) %3d", ATime2MBT($h0->{$k0}{$k1}{$k2}{3}, $res, $n, $d), $RelVel);
	 }
    if     (exists($Prgs{$Port}{0x9}{$Ch}{$Bank}{$Prg}{$key})) { printf(" '%s'", $Prgs{$Port}{0x9}{$Ch}{$Bank}{$Prg}{$key}); }
     elsif (exists($Prgs{$Port}{0x9}{$Ch}{   -1}{  -1}{$key})) { printf(" '%s'", $Prgs{$Port}{0x9}{$Ch}{   -1}{  -1}{$key}); }
     elsif (exists($Prgs{$Port}{0x9}{ -1}{   -1}{  -1}{$key})) { printf(" '%s'", $Prgs{$Port}{0x9}{ -1}{   -1}{  -1}{$key}); }
     elsif (exists($Prgs{   -1}{0x9}{$Ch}{$Bank}{$Prg}{$key})) { printf(" '%s'", $Prgs{   -1}{0x9}{$Ch}{$Bank}{$Prg}{$key}); }
     elsif (exists($Prgs{   -1}{0x9}{$Ch}{   -1}{  -1}{$key})) { printf(" '%s'", $Prgs{   -1}{0x9}{$Ch}{   -1}{  -1}{$key}); }
     else                                                      { printf(" '%s'", $Prgs{   -1}{0x9}{ -1}{   -1}{  -1}{$key}); }
    }

   if ($Event == 0xb) { my $ctl = $h0->{$k0}{$k1}{$k2}{1}; my $val = $h0->{$k0}{$k1}{$k2}{2};
    if ($ctl == 0x00) { $Bank = ($Bank&0x007f) | ($val<<7); }
    if ($ctl == 0x20) { $Bank = ($Bank&0x3f80) | ($val<<0); }
    printf(" Ctrl %2d %3d %5d %s", $Ch, $ctl, $val, GetAsciiVal($val));
    if     (exists($Prgs{$Port}{0xb}{$ctl})) { printf(" '%s'", $Prgs{$Port}{0xb}{$ctl}); }
     elsif (exists($Prgs{   -1}{0xb}{$ctl})) { printf(" '%s'", $Prgs{   -1}{0xb}{$ctl}); }
    }

   if ($Event == 0xc) { $Prg = $h0->{$k0}{$k1}{$k2}{1};  printf(" PgCh %2d %3d %41s", $Ch, $Prg, ''); my $BName = $Prgs{-1}{0xc}{-1}{-1}{-1}; my $PName = $Prgs{-1}{0xc}{-1}{-1}{$Prg};
	if     (exists($Prgs{$Port}{0xc}{$Ch}{$Bank}{  -1})) { $BName = $Prgs{$Port}{0xc}{$Ch}{$Bank}{  -1}; }
	 elsif (exists($Prgs{$Port}{0xc}{$Ch}{   -1}{  -1})) { $BName = $Prgs{$Port}{0xc}{$Ch}{   -1}{  -1}; }
	 elsif (exists($Prgs{$Port}{0xc}{ -1}{$Bank}{  -1})) { $BName = $Prgs{$Port}{0xc}{ -1}{$Bank}{  -1}; }
	 elsif (exists($Prgs{$Port}{0xc}{ -1}{   -1}{  -1})) { $BName = $Prgs{$Port}{0xc}{ -1}{   -1}{  -1}; }
	 elsif (exists($Prgs{   -1}{0xc}{$Ch}{$Bank}{  -1})) { $BName = $Prgs{   -1}{0xc}{$Ch}{$Bank}{  -1}; }
	 elsif (exists($Prgs{   -1}{0xc}{$Ch}{   -1}{  -1})) { $BName = $Prgs{   -1}{0xc}{$Ch}{   -1}{  -1}; }
	 elsif (exists($Prgs{   -1}{0xc}{ -1}{$Bank}{  -1})) { $BName = $Prgs{   -1}{0xc}{ -1}{$Bank}{  -1}; }
    if     (exists($Prgs{$Port}{0xc}{$Ch}{$Bank}{$Prg})) { $PName = $Prgs{$Port}{0xc}{$Ch}{$Bank}{$Prg}; }
     elsif (exists($Prgs{$Port}{0xc}{$Ch}{   -1}{$Prg})) { $PName = $Prgs{$Port}{0xc}{$Ch}{   -1}{$Prg}; }
     elsif (exists($Prgs{$Port}{0xc}{$Ch}{   -1}{  -1})) {                                               }
     elsif (exists($Prgs{$Port}{0xc}{ -1}{$Bank}{$Prg})) { $PName = $Prgs{$Port}{0xc}{ -1}{$Bank}{$Prg}; }
     elsif (exists($Prgs{$Port}{0xc}{ -1}{   -1}{$Prg})) { $PName = $Prgs{$Port}{0xc}{ -1}{   -1}{$Prg}; }
     elsif (exists($Prgs{   -1}{0xc}{$Ch}{$Bank}{$Prg})) { $PName = $Prgs{   -1}{0xc}{$Ch}{$Bank}{$Prg}; }
     elsif (exists($Prgs{   -1}{0xc}{$Ch}{   -1}{$Prg})) { $PName = $Prgs{   -1}{0xc}{$Ch}{   -1}{$Prg}; }
     elsif (exists($Prgs{   -1}{0xc}{$Ch}{   -1}{  -1})) {                                               }
     elsif (exists($Prgs{   -1}{0xc}{ -1}{$Bank}{$Prg})) { $PName = $Prgs{   -1}{0xc}{ -1}{$Bank}{$Prg}; }
	printf(" '$BName:$PName'");
    }

   if ($Event == 0xd) { my $val = $h0->{$k0}{$k1}{$k2}{1};
    printf(" CPrs %2d     %5d %s", $Ch, $val, GetAsciiVal($val));
    }

   if ($Event == 0xe) { my $val = ($h0->{$k0}{$k1}{$k2}{2}<<7)+$h0->{$k0}{$k1}{$k2}{1};
    printf(" Bend %2d     %5d %s", $Ch, $val-0x2000, GetAsciiVal($val, 0x3fff, 1));
    }

   if ($h0->{$k0}{$k1}{$k2}{0} == 0xff) { printf(" Meta");
	if (($h0->{$k0}{$k1}{$k2}{1} >= 0x01) && ($h0->{$k0}{$k1}{$k2}{1} <= 0x09)) {
     my $i = 2; my $txt = ""; while (exists($h0->{$k0}{$k1}{$k2}{$i})) { $txt .= chr($h0->{$k0}{$k1}{$k2}{$i}); $i++; } $txt =~ s/%/%%/g; printf(" Text '$txt'");
     }

    if ($h0->{$k0}{$k1}{$k2}{1} == 0x51) {
	 printf(" Tempo %.2f", 60000000/(($h0->{$k0}{$k1}{$k2}{2}<<16) + ($h0->{$k0}{$k1}{$k2}{3}<<8) + $h0->{$k0}{$k1}{$k2}{4}));
     }

    if ($h0->{$k0}{$k1}{$k2}{1} == 0x58) { printf(" TimeSignature"    ); }
    if ($h0->{$k0}{$k1}{$k2}{1} == 0x59) { printf(" KeySignature"     ); }
    if ($h0->{$k0}{$k1}{$k2}{1} == 0x21) { printf(" PortSel"          ); $Port = $h0->{$k0}{$k1}{$k2}{2}; if (exists($Prgs{$Port}{-1})) { printf(" '%s'", $Prgs{$Port}{-1}); }}
    if ($h0->{$k0}{$k1}{$k2}{1} == 0x2f) { printf(" TrackEnd"         ); }
    if ($h0->{$k0}{$k1}{$k2}{1} == 0x7f) { printf(" SequencerSpecific"); }
    }

   printf("\n");
   }
  }
 close(STDOUT);
 }

open(STDOUT, ">&", $out); return(0); }
#-------------------------------------------------------------------------------
sub ATime2MBT { my ($k1, $res, $n, $d) = @_; if (not defined($k1)) { return("-:-:" . '-' x length($res)); } my $sign = 1; if ($k1 < 0) { $sign = -1; $k1 = abs($k1); }

my $beat0 = int($k1/($n*$res*4/$d)); my $beat1 = int($k1 / ($res*4/$d)) % $n; my $beat2 = $k1 % ($res*4/$d);

my $ret = sprintf("%d:%0.*d:%0.*d", $sign*$beat0, length($n), $beat1, length($res), $beat2);
if (($sign < 0) && ($beat0 == 0)) { $ret = sprintf("-0:%0.*d:%0.*d", length($n), $beat1, length($res), $beat2); }

return($ret); }
#-------------------------------------------------------------------------------
sub GetAsciiVal {
my $val = shift(@_);
my $MaxVal   = 0x7f; if ($#_ >= 0) { $MaxVal   = shift(@_); }
my $Centered =    0; if ($#_ >= 0) { $Centered = shift(@_); }
my $n        =   32; if ($#_ >= 0) { $n        = shift(@_); } if ($Centered < 1) { $n++; }
my $RetVal = "";

my $n0 = int(sprintf("%.0f", ($val*$n)/$MaxVal)); my $n1 = $n-$n0; if ($n1 < 0) { $n1 = 0; } $RetVal = "x" x $n0 . "-" x $n1;

if ($Centered) { $n0 = $n0-int($n/2); my $n1 = int($n/2)-abs($n0);
 $RetVal = "-" x int($n/2) . "|" . "-" x int($n/2);
 if ($n0 < 0) { $RetVal = "-" x $n1 . "x" x abs($n0) . "|" . "-" x int($n/2); }
 if ($n0 > 0) { $RetVal = "-" x int($n/2) . "|" . "x" x abs($n0) . "-" x $n1; }
 }

return(sprintf("[%s]", $RetVal)); }
#-------------------------------------------------------------------------------
sub Flt2Len {
my $val = shift(@_);
my $RetVal = ""; my $sign = ""; if ($val == 0) { $RetVal = "0"; } if ($val < 0) { $sign = "<"; $val = abs($val); }

my $DeNom = 1; my $PNom = -1; my $PDeNom = -1; my $Tail = ""; my $Tail1 = ""; my $TailCnt = 0;
while ($val > 0) {
 my $i = 0; while ($val < 1.0) { $val *= 2; $i++; } my $Nom = int($val); $val -= $Nom; $DeNom *= 2**$i;
 if (length($RetVal) <= 0) { $RetVal .= sprintf("%d/%d", $Nom, $DeNom); }
  else { $TailCnt++; $Tail .= sprintf("+%d/%d", $Nom, $DeNom); if (($PNom/$PDeNom)/2 == ($Nom/$DeNom)) { $Tail1 .= "+"; }}
 $PNom = $Nom; $PDeNom = $DeNom;
 }

if (length($Tail1) < $TailCnt) { $RetVal .= $Tail; } else { $RetVal .= $Tail1; }
return($sign.$RetVal.$sign); }
#-------------------------------------------------------------------------------
sub WrStr { my $tmp = shift(@_); $tmp =~ s/\%/%%/g; printf("$tmp"); }
#===============================================================================

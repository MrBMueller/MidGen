use strict; use warnings; eval("use KX; use GM; use GS; use MMC; use Chord; use Arpeggio; use Percussion; use Bass; use Examples0; use Package0; use Tutorial; use DoReMix;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

my $Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
#KX::LoadSoundFonts(\%MidiDebug::Prgs);
#KX::GetFileNames("E:/INSTR", ".sf2");

#              track status       name       port      chn       bank      patch        vol        exp            pan     reverb        f-res        f-co            PBS             PB      #arr. setup
%main::trks = (0x00=>{-1=>1, -2=>"Ctrl", -3=>0x00                                                                                                                                        },  #
               0x01=>{-1=>1, -2=>"0x00", -3=>0x00, -4=>0x0, -5=>0x0000, -6=>  24, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x02=>{-1=>1, -2=>"0x01", -3=>0x00, -4=>0x1, -5=>0x0000, -6=>  24, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x03=>{-1=>1, -2=>"0x02", -3=>0x00, -4=>0x2, -5=>0x0000, -6=>  24, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x04=>{-1=>1, -2=>"0x03", -3=>0x00, -4=>0x3, -5=>0x0000, -6=>  24, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x05=>{-1=>1, -2=>"0x04", -3=>0x00, -4=>0x4, -5=>0x0000, -6=>  24, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x06=>{-1=>1, -2=>"0x05", -3=>0x00, -4=>0x5, -5=>0x0000, -6=>  24, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x07=>{-1=>1, -2=>"0x06", -3=>0x00, -4=>0x6, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x08=>{-1=>1, -2=>"0x07", -3=>0x00, -4=>0x7, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x09=>{-1=>1, -2=>"0x08", -3=>0x00, -4=>0x8, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0a=>{-1=>1, -2=>"0x09", -3=>0x00, -4=>0x9, -5=>0x0000, -6=>  25, 0x07=> .4, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #percussion
               0x0b=>{-1=>1, -2=>"0x0a", -3=>0x00, -4=>0xa, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0c=>{-1=>1, -2=>"0x0b", -3=>0x00, -4=>0xb, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0d=>{-1=>1, -2=>"0x0c", -3=>0x00, -4=>0xc, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0e=>{-1=>1, -2=>"0x0d", -3=>0x00, -4=>0xd, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0f=>{-1=>1, -2=>"0x0e", -3=>0x00, -4=>0xe, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x10=>{-1=>1, -2=>"0x0f", -3=>0x00, -4=>0xf, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef}); #

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

#Edit::Seq(\%main::out, 1, undef, undef, undef, $s, 60-0*12, 3, "32(1/1:0$Arpeggio::a0 -2$Arpeggio::a0 -1$Arpeggio::a0 0$Arpeggio::a1)");

my $c0 = $Chord::c;

my $scale = 3;

my ($gcpm, $gcp) = Chord::Guitar(0 , Edit::GetInt(0, 0), 1, '', '', '');

my ($gcm0, $gcu0) = Chord::Guitar($scale , Edit::GetInt($scale, 0), 0, ['*.5', '*.6', '*.7', '*.8', '*.9', '   '], '1/128');
my         $gcd0  = Chord::Guitar($scale , Edit::GetInt($scale, 0), 1, ['*.1', '*.2', '*.3', '*.4', '*.5', '*.6'], '1/128');
my ($gcm3, $gcu3) = Chord::Guitar($scale , Edit::GetInt($scale, 3), 0, ['*.5', '*.6', '*.7', '*.8', '*.9', '   '], '1/128');
my         $gcd3  = Chord::Guitar($scale , Edit::GetInt($scale, 3), 1, ['*.1', '*.2', '*.3', '*.4', '*.5', '*.6'], '1/128');
my ($gcm4, $gcu4) = Chord::Guitar($scale , Edit::GetInt($scale, 4), 0, ['*.5', '*.6', '*.7', '*.8', '*.9', '   '], '1/128');
my         $gcd4  = Chord::Guitar($scale , Edit::GetInt($scale, 4), 1, ['*.1', '*.2', '*.3', '*.4', '*.5', '*.6'], '1/128');

#MidiDebug::WrStr($gcp);

Edit::Seq(\%main::out, 0x1, undef, undef, undef, $s, 40, 8, " 2(| <1/16:% 2($gcu0 $gcd0) (3/4:$gcu0) $gcm0 | 2($gcu3 $gcd3) (3/4:$gcu3) $gcm3 | 2($gcu4 $gcd4) (3/4:$gcu4) $gcm4 | 2($gcu0 $gcd0) (3/4:$gcu0) $gcm0 |) ",1,.5, 0,0,0, 0,0,1, 1,1, 1,1, undef, 3, , {0=>6, 1=>5, 2=>4, 3=>3, 4=>2, 5=>1});

#Edit::Seq(\%main::out, 0x1, undef, undef, undef, $s, 40, 8, " 1/1:$gcp",1,.5, 0,0,0, 0,0,1, 1,1, 1,1, undef, 3, {0=>6, 1=>5, 2=>4, 3=>3, 4=>2, 5=>1});

for (my $t=1; $t<=6; $t++) { $main::trks{$t}{0x4000} = Edit::Portamento(\%main::out, $t, 1/16, 0, Edit::GetInt(8, 6-$t)+40, undef, 0x104, 4, undef, undef); }

Edit::Seq(\%main::out, 0xc, undef, undef, undef, $s, 60-0*12, 3, " 1/1:0$c0 3$c0 4$c0 0$c0 ", .3);

$s += Percussion::HSDR8100(\%main::out, 10, $s, 8*(4/1));

#MMC::Stop(\%main::out, 0x00, MIDI::GetEndTime(\%main::out)/($main::out{-1}{3}*4)+1/1); #stop+rewind
#MMC::Stop(\%main::out, 0x00, $s+1/1); #stop+rewind
Edit::AddLyricString(\%main::out);

#===============================================================================

eval("use Metronome; use GM; use STY; use playsmf;");

my $m = \%main::out; %main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>undef}); my ($N, $D) = (4, 4); my ($t, $V) = (0, 0);

my $f = "D:\\BUF\\STY\\8000\\EUROBEAT.STY"; if (($#ARGV >= 0) && ($ARGV[$#ARGV] =~ /\.(sty?|prs|scp|mid|smf)$/i)) { $f = $ARGV[$#ARGV]; }

$t += STY::CopyMarker($m, $t, $f); my $PPQ = $m->{-1}{3}; if (exists($m->{-1}{5}) && exists($m->{-1}{6})) { ($N, $D) = ($m->{-1}{5}, $m->{-1}{6}); } my $B = $N/$D; $t += 0*$B; my $MetronomeStart = $t;

playsmf::OverrideCmdLineArgs($m, 0, 0*$B, 0,  9, 0x7fefa189);

@main::InitParams = (undef, 0*$B); @main::trks = ([], []);

my $Ms = '';
foreach my $c (sort {$a <=> $b} keys(%STY::Marker)) {
 foreach my $M (sort {$a cmp $b} keys(%{$STY::Marker{$c}})) {
  if (length($M)) { my ($L, $R) = ($STY::Marker{$c}{$M}{0}, $STY::Marker{$c}{$M}{1}); my $d = $R-$L; my $Ls = MidiDebug::ATime2MBT($L, $PPQ, $N, $D); my $Ds = MidiDebug::ATime2MBT($d, $PPQ, $N, $D);
   if (length($Ms)) { $Ms .= " | "; } $Ms .= "'$M'"; if ($d || $c >= (sort {$b <=> $a} keys(%STY::Marker))[0]) { printf("%2d %9s %9s $Ms\n", $c, $Ls, $Ds); $Ms = ''; }
   }
  }
 }

my @Marker = ('Ending', 'Fill In CC', 'Fill In BB', 'Fill In AA', 'Main D', 'Main C', 'Main B', 'Main A'); #@Marker = ('Main A');

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | 1/2*$B:%% 1/2*$B:%%_C$GM::CCx7a\_$GM::CCoff | MLabelx17 1*$B:%% MJump-4 | ")) + 1*$B;

my $line = '';

for (my $j=$#Marker; $j>=0; $j--) { my $v = 0;
 for (my $i=0; $i<=11; $i++) { my $dt; my $T = $i; if ($T >= 7) { $T -= 12; }

  my %Trans = (0x200 => {-1=>{-1=>0+$T, 0=>0+$T, 1=>-1+$T, 2=>0+$T, 3=>1+$T, 4=> 0+$T, 5=>0+$T, 6=>1+$T, 7=>0+$T, 8=>-1+$T, 9=> 0+$T, 10=>-1+$T, 11=> 0+$T}},
               0x300 => {-1=>{-1=>0+$T, 0=>0+$T, 1=>-1+$T, 2=>0+$T, 3=>0+$T, 4=>-1+$T, 5=>0+$T, 6=>1+$T, 7=>0+$T, 8=> 0+$T, 9=>-1+$T, 10=> 0+$T, 11=>-1+$T}},
               0x400 => {-1=>{-1=>128}});

  if (exists($STY::CASM{$Marker[$j]})) {
   foreach my $c (sort {$a <=> $b} keys(%{$STY::CASM{$Marker[$j]}})) { my @a = @{$STY::CASM{$Marker[$j]}{$c}}; my $NoteEn = ($a[3]<<8) | $a[4]; my $ND = (($NoteEn >> $i) & 1)^1;
    my ($NTR, $NTT) = (0, 0); if ($#a+9 == 27 || $#a+9 == 31) { ($NTR, $NTT) = ($a[20-8], $a[21-8]); } elsif ($#a+9 == 47) { ($NTR, $NTT) = ($a[22-8], $a[23-8]); } my $NTRT = (($NTR<<8) | $NTT)  & ~0x80; my $PC = ($NTRT == 0x100)?1:0;
    #if ($i==0) { printf("$i '%s' (%2d) %x -> %x '%s' %x %02x%02x %02x%02x%02x%02x%02x - %02x %02x - %02x %02x\n", $Marker[$j], $#a+9, $c, $a[1], $a[0], $a[2], $a[3], $a[4], $a[5], $a[6], $a[7], $a[8], $a[9], $a[10], $a[11], $NTR, $NTT); }
	foreach my $k0 (sort {$a <=> $b} keys(%Trans)) { my $CD = 0; if ($k0==0x300 && !($a[8]&0x01) || $k0==0x200 && !($a[9]&0x01)) { $CD = 1; }
     #if ($ND | $CD) { $Trans{$k0}{$c+1} = undef; } elsif ($k0==0x400 && !$PC) {} elsif ($NTRT == 0x100) { $Trans{$k0}{$c+1} = \%{{-1=>0}}; } elsif ($NTRT == 0x001) { $Trans{$k0}{$c+1} = \%{{-1=>$T-$a[10]}}; } else { for (0..11) { if (exists($Trans{$k0}{-1}{$_})) { $Trans{$k0}{$c+1}{($_+$a[10])%12} = $Trans{$k0}{-1}{$_}-$a[10]; }}}
     }
    }
   }

                  $t += ($dt = STY::CopyMarker($m, $t, undef, $Marker[$j], ($V<<12)|0x200+$i, \%{$Trans{0x200}} )); if ($dt) { $v = 1; $t += 1*$B; }
                  $t += ($dt = STY::CopyMarker($m, $t, undef, $Marker[$j], ($V<<12)|0x300+$i, \%{$Trans{0x300}} )); if ($dt) { $v = 1; $t += 1*$B; }
  if ($i == 11) { $t += ($dt = STY::CopyMarker($m, $t, undef, $Marker[$j], ($V<<12)|0x400   , \%{$Trans{0x400}} )); if ($dt) { $v = 1; $t += 1*$B; }}
  }
 if ($v) { if (length($line)) { $line = sprintf(" | %s", $line); } $line = sprintf("$V:'%s'%s", $Marker[$j], $line); printf("\r| $line |"); $V++; }
 }

if (length($line)) { printf("\n"); }

Metronome::Generic($m, (sort {$b <=> $a} keys(%{$m}))[0]+1, $MetronomeStart, $t-$MetronomeStart, .3);

$t += Edit::Seq($m, 0, $t, 0, 0, sprintf(" | MLabelx18 <:%%_C$GM::CCx7a\_$GM::CCon "));

delete($m->{-1}{4}); delete($m->{-1}{5}); delete($m->{-1}{6}); delete($m->{-1}{7});

#===============================================================================

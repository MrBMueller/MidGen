use strict; use warnings; eval("use KX; use GM2; use RolandHp302; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

Misc::InsertCopyright(\%main::out);

#GM2::GMSystem(\%main::out, 0x00, $s, 1, 0x03); #
GS::Reset(\%main::out, 0x00, $s, 1, 0x00); #goto MyLabelEnd; #

#GS::System(\%main::out, 0x00, $s+1/4, 1, undef, 1.0, undef, undef); #

#GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x3f, 0x3f); #
#GS::Chorus(\%main::out, 0x00, $s+1/4, 1,  0x03, undef, 0x6f, 0x08, 0x50, 0x03, 0x3f); #

#RolandHp302::ScaleTuning(\%main::out, 0x00, $s+2/4, 1, -0x0001, 0, @RolandHp302::ScaleArab); #Equal, Just, Arab

@main::InitParams = (undef, 1/4); $MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames()};

my $p = \&RolandHp302::Patch; my @patch0 = RolandHp302::Patch(0,1); my @patch1 = RolandHp302::Patch(4,50);

sub v { return((  0+(shift(@_))<<7)/0x3fff); }
sub c { return(( 64+(shift(@_))<<7)/0x3fff); }

my $split = 60;

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx41, $GS::CCx05, $GS::BPx02, $GS::BPx13, $GS::BPx15, $GS::BPx1d, $GS::BPx1e, $GS::cBPx1a, $GS::cBPx1b, $GS::cBPx1c, $GS::BPx16, $GS::cBPx17],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev    prt   prtt                       # arr. setup
[1, "Ctrl", 0x00                                                                                                          ],  # 00
[1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   &$p(4,193), 1.0, 1.0,  0.0, 0.7,     1,    .4, v( 0), v(0), v(0), v($split), v(     127), 0, 0, -1.0, c(-24), 0],  # 01 live
[1, "0x01", 0x00, 0x1,  -12, 1.0, 1.0, +0.5, 1.0, +0.0,   &$p(4, 38), 1.0, 1.0,  0.0, 0.7, undef, undef, v( 0), v(1), v(0), v(     0), v($split-1), 0, 0, -0.9, c(  0), 0],  # 02 bass
[1, "0x02", 0x00, 0x2,  +12, 1.0, 1.0, -0.4, 1.0, +0.0, 0x0000,   48,  .2, 1.0,  0.0, 0.7, undef, undef, v( 2), v(1), v(0), v(     0), v($split-1), 0, 0,  1.0, c( 12), 0],  # 03 harmonics/pad
[0, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.3, 1.0, +0.0, 0x0000,   27, 1.0, 1.0,  0.0, 0.5, undef, undef, v( 3), v(1), v(0)],  # 04 rythm/chords
[1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, -0.2, 1.0, +0.0,      @patch0, 1.0, 1.0,  0.0, 0.0, undef, undef, v( 4), v(1), v(0)],  # 05
[1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.9, undef, undef, v( 5), v(1), v(0)],  # 06
[1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v( 6), v(1), v(0)],  # 07
[1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v( 7), v(1), v(0)],  # 08
[1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v( 8), v(1), v(0)],  # 09
[1, "0x09", 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.9, undef, undef, v( 9), v(1), v(1)],  # 0a percussion
[1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v(10), v(1), v(0)],  # 0b
[1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v(11), v(1), v(0)],  # 0c
[1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v(12), v(1), v(0)],  # 0d
[1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v(13), v(1), v(0)],  # 0e
[1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v(14), v(1), v(0)],  # 0f
[1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, v(15), v(1), v(0)]); # 10

my %DrumMap0 = (
# key      key+  dur* vel* vel+  rel* rel+
   -2 => [   -7, -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
   33 => [   34, 1.0, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
   35 => [undef, 1.0, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #BD2
   36 => [undef, 1.0, 1.0, +0.0, 1.0, +0.0,   -.1, undef,  -0.9,    .9], #BD1
   38 => [undef, 1.0, 1.0, +0.0, 1.0, +0.0,    .1, undef,   0.9,    .0]  #SD1
);

Misc::State2Param(\@main::trks);
#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => 1.0, $GM::CCx07 => 1.0});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs);
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);

Edit::Seq($m, 1, undef, undef, undef, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

#Edit::Seq($m, 1, 0, undef, undef, $s, 0, 0, " 8{4/1:%_C$GS::BPx19\_2_1_0_1} "); #

goto MyLabelEnd;

#===============================================================================
#percusion
{

my $c = $GS::NRPNx1d00+38; $c = $GS::DM0x5+38;

my %SymbolTable1 = ('o'=>"36", 's'=>"38_.8"); %SymbolTable1 = ('o'=>"38_.5_C$c\_.9 <:Cxa_.1", 's'=>"38_.25_C$c\_.1 <:Cxa_.9");

my $ps = " |x...|s..s|x.8.|s...| "; $ps =~ s/\./>/g; $ps = Edit::PreProc0($ps, \%SymbolTable1);

Edit::Seq($m, 10, undef, undef, undef, $s, 0, 0, " 1/16<:0_% $ps ", 1.0, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, 64/1);

}
#===============================================================================

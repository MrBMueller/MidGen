
%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); #general output smf settings (filename, smf type, PPQN)

@main::trks = ([], []); #empty track setup

#===============================================================================

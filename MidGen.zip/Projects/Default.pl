use strict; use warnings; eval("use GM; use GS; use KX; use MMC; use Percussion;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
#KX::LoadSoundFonts(\%MidiDebug::Prgs);

#              track status       name       port      chn       bank      patch        vol        exp            pan     reverb        f-res        f-co            PBS             PB      #arr. setup
%main::trks = (0x00=>{-1=>1, -2=>"Ctrl", -3=>0x00                                                                                                                                        },  #
               0x01=>{-1=>1, -2=>"0x00", -3=>0x00, -4=>0x0, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x02=>{-1=>1, -2=>"0x01", -3=>0x00, -4=>0x1, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x03=>{-1=>1, -2=>"0x02", -3=>0x00, -4=>0x2, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x04=>{-1=>1, -2=>"0x03", -3=>0x00, -4=>0x3, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x05=>{-1=>1, -2=>"0x04", -3=>0x00, -4=>0x4, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x06=>{-1=>1, -2=>"0x05", -3=>0x00, -4=>0x5, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x07=>{-1=>1, -2=>"0x06", -3=>0x00, -4=>0x6, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x08=>{-1=>1, -2=>"0x07", -3=>0x00, -4=>0x7, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x09=>{-1=>1, -2=>"0x08", -3=>0x00, -4=>0x8, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0a=>{-1=>1, -2=>"0x09", -3=>0x00, -4=>0x9, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #percussion
               0x0b=>{-1=>1, -2=>"0x0a", -3=>0x00, -4=>0xa, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0c=>{-1=>1, -2=>"0x0b", -3=>0x00, -4=>0xb, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0d=>{-1=>1, -2=>"0x0c", -3=>0x00, -4=>0xc, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0e=>{-1=>1, -2=>"0x0d", -3=>0x00, -4=>0xd, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0f=>{-1=>1, -2=>"0x0e", -3=>0x00, -4=>0xe, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x10=>{-1=>1, -2=>"0x0f", -3=>0x00, -4=>0xf, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef}); #

#                   s   name   port  chn    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                    ],   # 00
                   [1, "0x00", 0x00, 0x0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 01
                   [1, "0x01", 0x00, 0x1, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 02
                   [1, "0x02", 0x00, 0x2, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03
                   [1, "0x03", 0x00, 0x3, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

#MMC::Stop(\%main::out, 0x00, MIDI::GetEndTime(\%main::out)/($main::out{-1}{3}*4)+1/1); #stop+rewind
#MMC::Stop(\%main::out, 0x00, $s+1/1); #stop+rewind
#Edit::AddLyricString(\%main::out);

#===============================================================================

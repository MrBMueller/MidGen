use strict; use warnings; eval("use RolandHp302;");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; #general output setup

GM2::GMSystem          (\%main::out, 0x00, $s+0/64, undef, 0x01);
GM2::MasterVolume      (\%main::out, 0x00, $s+1/64, undef, 0.9);
#GM2::MasterFineTuning  (\%main::out, 0x00, $s+2/64, undef, 0.0);
#GM2::MasterCoarseTuning(\%main::out, 0x00, $s+3/64, undef, 0  );
#GM2::ReverbParameters  (\%main::out, 0x00, $s+4/64, undef, 4, 1.0);
#GM2::ChorusParameters  (\%main::out, 0x00, $s+5/64, undef, 0, 3);
#GS::Reset              (\%main::out, 0x00, $s+6/64, undef);
#GS::System             (\%main::out, 0x00, $s+7/64, undef, 0.0, 1.0, 0, 0.0);
#GS::Reverb             (\%main::out, 0x00, $s+8/64, undef, 0x04, 0x04, 0x00, 0x40, 0x40, 0x00, 0x00);
#GS::Chorus             (\%main::out, 0x00, $s+9/64, undef, 0x02, 0x00, 0x40, 0x08, 0x50, 0x03, 0x13, 0x00);

my $EfxType = 0x015b;
RolandHp302::SystemEfx(\%main::out, 0x00, $s+ 2/64, 1,      $EfxType, 0x00, 0x00, 0x7f);
RolandHp302::PartEfx  (\%main::out, 0x00, $s+ 8/64, 1, 0x0, $EfxType, 0x00, 0x7f, 0x00, 0x00);
RolandHp302::PartEfx  (\%main::out, 0x00, $s+16/64, 1, 0x1, $EfxType, 0x00, 0x7f, 0x00, 0x00);

splice(@{$main::trks[0]}, 4, 0, -7, -8); push(@{$main::trks[0]}, $GM::CCx7a, $GS::CCx5d); #insert/append inspector params

@main::InitParams = (undef, 1/2, 0/128, 0/128); #{ my @header = @{$main::trks[0]}; for (my $i = 6; $i <= $#header; $i++) { $main::trks[0][$i] = undef; }}

#                   s   name   port  chn  key+  vel+    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 01
                   [1, "0x01", 0x00, 0x1, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 02
                   [1, "0x02", 0x00, 0x2, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03
                   [1, "0x03", 0x00, 0x3, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

for (my $i = 0x01; $i < $#main::trks; $i++) { MIDI::InsertCtlr(\%main::out, $i, $s+3/4, 1, undef, 0/1, undef, $GM::CCx7a, 1, 0, 0.0); } #local control off
for (my $i = 0x01; $i < $#main::trks; $i++) { MIDI::InsertCtlr(\%main::out, $i, $s+3/4, 1, undef, 0/1, undef, $GS::CCx5d, 1, 0, 0.0); } #chorus depth

#for (my $i = 0x01; $i < $#main::trks; $i++) { MIDI::InsertCtlr(\%main::out, $i, $s+3/4, 1, undef, 0/1, undef, $GS::CCx05, 1, 0, 0.8); } # portamento time
#for (my $i = 0x01; $i < $#main::trks; $i++) { MIDI::InsertCtlr(\%main::out, $i, $s+3/4, 1, undef, 0/1, undef, $GS::CCx41, 1, 0, 1.0); } # portamento on/off
#for (my $i = 0x01; $i < $#main::trks; $i++) { MIDI::InsertCtlr(\%main::out, $i, $s+3/4, 1, undef, 0/1, undef, $GS::CCx54, 1, 0, 0.5); } # portamento control

Edit::Seq(\%main::out, 0x0a, undef, undef, undef, $s+1/1, 0x00, 0, " 4{1/4:x21} ", .5);

#===============================================================================

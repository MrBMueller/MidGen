use strict; use warnings; eval("use GM2; use KX; use BrotherGregory; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm;"); $MIDI::ContCtlRes = -10; $main::DummyNop = 0/1;

my $Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

GM2::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#GM2::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs);

splice(@{$main::trks[0]}, 4, 0, -7, -8); push(@{$main::trks[0]}, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9); #insert/append inspector params

#                   s   name   port  chn  key+  vel+    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, +0.0, 0x0003,    0,  .7, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 01
                   [1, "0x01", 0x00, 0x1, +000, +0.0, 0x0000,   50,  .5, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 02
                   [1, "0x02", 0x00, 0x2, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 03
                   [1, "0x03", 0x00, 0x3, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, +000, +0.0, 0x0001, 0x00, 1.0, 1.0,  0.0, 0.1, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

Seq0(\%main::out, $s);

#Brainstorm::InsertPhrase(\%main::out, 1, $s+0/1, "$main::SrcDir0/Midi/.", "20120226175539", 1/128, -1/128, 0, '>=60',   0, 0, 1, 0, .5);
#Brainstorm::InsertPhrase(\%main::out, 2, $s+0/1, "$main::SrcDir0/Midi/.", "20120226175539",   1/2,    1/2, 1,  '<60', +12, 0, 1, 0, .5);
Brainstorm::InsertPhrase(\%main::out, 1, $s+0/1, "$main::SrcDir0/Midi/.", "20120330211608", 1/128, -1/128, 0, undef,   0, 0, 1, 0, .5);

#my $p0 = "^4 % v4 % ^3  % v3 % *2:^2 /2:v2 *3:^1 /3:v1 %";

#my $p1 = "v % ^ % > % v |1/1:^";

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 1/16<:0_% 2( 2($p0) $p1 1/1:% ) ", 1, .5, 0,0,0,0,0,1,1,1,1, 1.0);

Edit::Seq($m, 2, undef, undef, undef, $s, 60-0*12, 3, "8(4/1:0_$Chord::c 2/1:3_$Chord::c 2/1:4_$Chord::c)", .5);
Edit::Seq($m, 2, undef, undef, undef, $s, 60-1*12, 3, "8(4/1:0_$Chord::c 2/1:3_$Chord::c 2/1:4_$Chord::c)", .5);

#Edit::Seq($m, 2, undef, undef, undef, $s, 60, 3, " 2([4/1:0_$Chord::c] Cxa_2_1_0_1)", .9);

#===============================================================================
sub Seq0 { my $m = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " Mv ");

my $q = '1/16'; my $r = 32; my $l = -1/32;

#drum example with pre and post sequences using different grid resolutions
#$s += Edit::Seq($m, 10, undef, undef, undef, $s, 37-1, 0, " <1/4<:% 1/32<:% |x.....7.| 1/16<:% 2{|x...|x...|x...|x...|} 1/32<:% |.......x| <1/4<:% ", 1.0, .5, 0,0,0,0,0,1,1,1,1, -1/32); #Kick/Bass Drum

my $BD1Seq = "";
my $BD2Seq = "";
my $SD1Seq = "";

#Book: "Composition for Computer Musicians", Chapter: 'Rythm and Drum Programming'

#fig. 3.4 - basic
#$BD1Seq = "|x...|....|x...|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.6 - variation 1
#$BD1Seq = "|x...|....|....|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.8 - variation 2
#$BD1Seq = "|x...|....|x.x.|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.10 - variation 3
#$BD1Seq = "|x...|....|..x.|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.12 - variation 4
$BD1Seq = "|x...|..x.|..x.|....|";
$SD1Seq = "|....|x...|....|x...|";

#fig. 3.14 - variation 5
#$BD1Seq = "|x.x.|....|x.x.|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.16 - two bar pattern
#$BD1Seq = "||x.x.|....|x.x.|....||x.x.|....|x.x.|....||";
#$BD2Seq = "||....|....|....|....||....|...x|....|....||";
#$SD1Seq = "||....|x...|....|x...||....|x...|....|x...||";

      Edit::Seq($m, 10, undef, undef, undef, $s, 37-1, 0, " <$q:% $r\{ $BD1Seq } ", .5, .5, 0,0,0,0,0,1,1,1,1, $l); #Kick/Bass Drum 1
      Edit::Seq($m, 10, undef, undef, undef, $s, 36-1, 0, " <$q:% $r\{ $BD2Seq } ", .7, .5, 0,0,0,0,0,1,1,1,1, $l); #Kick/Bass Drum 2
$s += Edit::Seq($m, 10, undef, undef, undef, $s, 39-1, 0, " <$q:% $r\{ $SD1Seq } ", .3, .5, 0,0,0,0,0,1,1,1,1, $l); #Snare Drum 1

$s += Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " M^ ");

return($s-$start); }
#===============================================================================

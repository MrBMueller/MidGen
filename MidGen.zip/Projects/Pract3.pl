use strict; use warnings; eval("use GM2; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0, 8=>Misc::GetCopyright()}); my $s = 0/1; my $m = \%main::out; #general output setup

GM2::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #GM2::Rec(\%main::out, 0x00, $s+1/2, 0); #stop/rewind/rec

#GM2::MasterVolume(\%main::out, 0x00, $s, 0, 0.9);

@main::trks = ([-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GM::RPN_0, $GM::cPB, $KX::CCx47, $KX::CCx4a, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9]);

#                   s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev   PBS     PB   frs(0) fco(1)    # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                                     ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,    0, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 01 live
                   [1, "0x01", 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 02 bass
                   [1, "0x02", 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   48,  .3, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03 harmonics/pad
                   [1, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x02, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,    0, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,    0, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, @DrumMaps::Generic             , 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

Misc::State2Param(\@main::trks);
#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => 1.0, $GM::CCx07 => 1.0});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs);

$s += Percussion::Metronome(\%main::out, 0x0a, $s,     4/4, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128*4/4, .2); #main counter

#Edit::Seq($m, 1, undef, undef, undef, $s, 60+0*12, 2, Edit::PreProc0(" 1/16<:0_% |>...|....|x...|x...| ", {'.'=>'>'})); goto MyLabelEnd;

#===============================================================================
#percusion
{

my %SymbolTable1 = ('o'=>"36", 's'=>"38_.8"); %SymbolTable1 = ('o'=>"36_.25_Cxa_.1", 's'=>"38_.5_Cxa_.9");

my $ps = " |x...|s..s|x.8.|s...| "; $ps =~ s/\./>/g; $ps = Edit::PreProc0($ps, \%SymbolTable1);

Edit::Seq($m, 10, undef, undef, undef, $s, 0, 0, " 1/16<:0_% $ps ", 1.0, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, 64/1);

}
#-------------------------------------------------------------------------------
#bass
{

my %SymbolTable1 = ('.'=>'>', 'v'=>"% (b:v7)", '^'=>"% (b:^7)");

my $ps  = Edit::PreProc0(" |x86x|v..v|x.8.|v...| ", \%SymbolTable1);
my $ps1 = Edit::PreProc0(" |x.^^|x.^^|           ", \%SymbolTable1);

Edit::Seq($m, 2, undef, undef, undef, $s, 60-2*12, 3, " 1/16<:0_% $ps <:-3_% $ps1 <:-2_% $ps1 <:0_% $ps ", 1.0, .5, undef, undef, undef, 0,0,1, 1,1, 1,1, 64/1);

}
#-------------------------------------------------------------------------------
#pad
{
my $c = $Chord::c;

Edit::Seq($m, 3, undef, undef, undef, $s, 60, 3, " 8{ 1/1:0$c /2:-3$c -2$c *2:0$c } ");
}
#===============================================================================

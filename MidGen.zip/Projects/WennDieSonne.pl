use strict; use warnings; eval("use KX; use GM; use GS; use MMC; use Chord; use Arpeggio; use Percussion; use Bass;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>2, 6=>4, 7=>2}); my $s = 0/1; #general output setup

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup

#              track status       name       port      chn       bank      patch        vol        exp            pan     reverb        f-res        f-co            PBS             PB      #arr. setup
%main::trks = (0x00=>{-1=>1, -2=>"Ctrl", -3=>0x00                                                                                                                                        },  #
               0x01=>{-1=>1, -2=>"0x00", -3=>0x00, -4=>0x0, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x02=>{-1=>1, -2=>"0x01", -3=>0x00, -4=>0x1, -5=>0x0000, -6=>  50, 0x07=>0.1, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x03=>{-1=>1, -2=>"0x02", -3=>0x00, -4=>0x2, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x04=>{-1=>1, -2=>"0x03", -3=>0x00, -4=>0x3, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x05=>{-1=>1, -2=>"0x04", -3=>0x00, -4=>0x4, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x06=>{-1=>1, -2=>"0x05", -3=>0x00, -4=>0x5, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x07=>{-1=>1, -2=>"0x06", -3=>0x00, -4=>0x6, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x08=>{-1=>1, -2=>"0x07", -3=>0x00, -4=>0x7, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x09=>{-1=>1, -2=>"0x08", -3=>0x00, -4=>0x8, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0a=>{-1=>1, -2=>"0x09", -3=>0x00, -4=>0x9, -5=>0x0000, -6=>0x00, 0x07=>0.1, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #percussion
               0x0b=>{-1=>1, -2=>"0x0a", -3=>0x00, -4=>0xa, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0c=>{-1=>1, -2=>"0x0b", -3=>0x00, -4=>0xb, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0d=>{-1=>1, -2=>"0x0c", -3=>0x00, -4=>0xc, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0e=>{-1=>1, -2=>"0x0d", -3=>0x00, -4=>0xd, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0f=>{-1=>1, -2=>"0x0e", -3=>0x00, -4=>0xe, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x10=>{-1=>1, -2=>"0x0f", -3=>0x00, -4=>0xf, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef}); #

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/2, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

Wenn_die_Sonne_ihre_Strahlen(\%main::out, $s);

#===============================================================================
sub Wenn_die_Sonne_ihre_Strahlen { my $m = shift(@_);
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s+= Edit::Seq($m, 1, undef, undef, undef, $s+1/4, 62+0*12, 2, " 1/8:4 . | v2 . . . | ^2 . . . | v ^ v v | 1/4:v ");

$s+= Edit::Seq($m, 1, undef, undef, undef, $s+1/4, 62+0*12, 2, " 1/8:3 . | v2 . . . | ^2 . . . | v ^ v v | 1/4:v ");

$s+= Edit::Seq($m, 1, undef, undef, undef, $s+1/4, 62+0*12, 2, " 1/8:4 . | v2 . . . | ^2 . v4 . | ^5 . . . | 1/4:^2 ");

$s+= Edit::Seq($m, 1, undef, undef, undef, $s+1/4, 62+0*12, 2, " 1/8:7 . | v . v . | v . v . | v . v . | v ");

$s+= Edit::Seq($m, 1, undef, undef, undef, $s+1/4, 62+0*12, 2, " 1/8:7 . . | . v2 = 1/4:v3 | 1/8:^7 . . | . v3 v2 1/4:= | 1/8:. ^2 v2 || 1/8:-3 ^2 = 1/4:^3 | 1/8:v2 ^2 v2 | v2 ^2 = 1/4:^3 ");

$s+= Edit::Seq($m, 1, undef, undef, undef, $s+1/4, 62+0*12, 2, " 1/8:7 . . | . v2 = 1/4:v3 | 1/8:^7 . . | . v3 v2 1/4:= | 1/8:. ^2 v2 || 1/8:-3 ^2 = 1/4:^3 | 1/8:v2 ^2 v2 | 1/2+1/8:= ");

$s = $start;

my $c0 = $Chord::c;
my $c0ii = $Chord::c7;

my $c7 = $Chord::c8;

Edit::Seq($m, 2, undef, undef, undef, $s, 62+0*12, 2, " 2/4:% | 2(0$c0) | 4(-3$c7) | 4(0$c0) | 2(3$c0ii) | 3(-3$c0) | 1(0$c0) 2(| 2(3$c0ii) | 2(0$c0) | 2(-3$c0) | 2(0$c0) |) ", .5);

my $a0 = $Arpeggio::a0;

our $a0ii = $Arpeggio::a0ii;

our $a7 = $Arpeggio::a7;

Edit::Seq($m, 3, undef, undef, undef, $s, 62-1*12, 2, " 2/4:% | 2(0$a0) | 4(-3_Mh$a7) | 4(0$a0) | 2(3$a0ii) | 3(-3$a0) | 1(0$a0) 2(| 2(3$a0ii) | 2(0$a0) | 2(-3$a0) | 2(0$a0) |) ", .5);

return(0); }
#===============================================================================

use strict; use warnings; eval("use KX; use GM; use GS; use MMC; use Chord; use Arpeggio; use Percussion; use Bass; use Examples0; use Package0; use Tutorial; use DoReMix;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

my $Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs);
#KX::GetFileNames("E:/INSTR", ".sf2");

push(@{$main::trks[0]}, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9); #append inspector params

#                   s   name   port  chn    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      #arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                    ],   #
                   [1, "0x00", 0x00, 0x0, 0x0002, 0x00, 1.0, 1.0,  0.0, 0.2,   1.0,   .55, undef, undef],   #
                   [1, "0x01", 0x00, 0x1, 0x0000,   50, 0.1, 1.0,  0.0, 0.9, undef, undef, undef, undef],   #
                   [1, "0x02", 0x00, 0x2, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x03", 0x00, 0x3, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x04", 0x00, 0x4, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x05", 0x00, 0x5, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x06", 0x00, 0x6, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x07", 0x00, 0x7, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x08", 0x00, 0x8, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x09", 0x00, 0x9, 0x0000,   25, 0.1, 1.0,  0.0, 0.8, undef, undef, undef, undef],   #percussion
                   [1, "0x0a", 0x00, 0xa, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x0b", 0x00, 0xb, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x0c", 0x00, 0xc, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x0d", 0x00, 0xd, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x0e", 0x00, 0xe, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   #
                   [1, "0x0f", 0x00, 0xf, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); #

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

Seq0(\%main::out, $s);

#my $PhraseDir = "$main::PrjDrive/Midi2/PHRASE/";
#$s += DoReMix::InsertPhrase(\%main::out, 10, $s, "$PhraseDir/HOUSE/HSDR8100.MID", undef, undef, undef, 1/32);

$s += Percussion::HSDR8100(\%main::out, 10, $s, 8*(4/1));

#MMC::Stop(\%main::out, 0x00, MIDI::GetEndTime(\%main::out)/($main::out{-1}{3}*4)+1/1); #stop+rewind
#MMC::Stop(\%main::out, 0x00, $s+1/1); #stop+rewind
#Edit::AddLyricString(\%main::out);

#===============================================================================
sub Seq0 { my $m = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

my $c0 = $Chord::c;
my $c4 = $Chord::c4;

my $bass0 = " | 3{1/8:0 1/16:. . .} . | 3{1/8:2 1/16:. . .} . | 3{1/8:-1 1/16:. . .} . | 3{1/8:0 1/16:. . .} . | ";

Edit::Seq($m, 1, undef, undef, undef, $s, 60-0*12, 3, " 8($bass0) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60-0*12, 3, " 8{16*1{1/16:0} 16*1{1/16:2} 16*1{1/16:-1} 16*1{1/16:0}} ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8*4*4( 2/1:C$SF201::NRPN_8\_2_1_-.37_.09_0 ) ");

Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8*4*4( 2/1:C$SF201::NRPN_8\_2_0_.31_.04_0 ) ");

Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8*4*4( 1/1:C$GM::CCx0a\_2_0_.5_.5_0 ) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8*4*4( 1/1:C$KX::CCx47\_2_0_.5__.5_0 ) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 8*4*4( 2/1:C$KX::CCx4a\_2_0_.21_-.08_0 ) ");

Edit::Seq($m, 2, undef, undef, undef, $s, 60-0*12, 3, " 8(1/1:0$c0 2$c4 -1$c0 0$c0) ", .4);

#Edit::Seq($m, 2, undef, undef, undef, $s, 60-0*12, 2, " 1/1:0$Arpeggio::a0 $Arpeggio::a0ii $Arpeggio::a7 ");

return(0); }
#===============================================================================

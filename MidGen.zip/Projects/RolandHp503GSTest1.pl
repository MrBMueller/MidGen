use strict; use warnings; eval("use KX; use GM2; use RolandHp302; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

Misc::InsertCopyright(\%main::out);

#GM2::GMSystem(\%main::out, 0x00, $s, 1, 0x03); #
GS::Reset(\%main::out, 0x00, $s, 1, 0x00); #goto MyLabelEnd; #

#GS::System(\%main::out, 0x00, $s+1/4, 1, undef, 1.0, undef, undef); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x07, undef, 0x6f, 0x6f); #
#GS::Chorus(\%main::out, 0x00, $s+1/4, 1,  0x03, undef, 0x6f, 0x08, 0x50, 0x03, 0x3f); #

#RolandHp302::AssignEfx(\%main::out, 0x00, $s+2/4, 1, undef, 0x7f, 0x7f, undef, 0x7f, 0, @RolandHp302::Phone);

@main::InitParams = (undef, 1/4); $MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames()};

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev    # arr. setup
[1, "Ctrl", 0x00                                                                         ],  # 00
[1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 01
[1, "0x01", 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 02
[1, "0x02", 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 03
[0, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 04
[1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 05
[1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 06
[1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 07
[1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 08
[1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 09
[1, "0x09", 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 0a
[1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 0b
[1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 0c
[1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 0d
[1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 0e
[1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0],  # 0f
[1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0]); # 10

#Edit::Seq($m, 1, undef, undef, undef, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

#my $c = $GS::DM0x2 + 36;
#Edit::Seq($m, 10, 9, undef, undef, $s, 0, 0, " 8{4/1:%_C$c\_2_1_0_1} "); #
#Edit::Seq($m, 10, 9, undef, undef, $s, 0, 0, " 8{4/1:%_C$c\_0} "); #

#Edit::Seq($m, 0, undef, undef, undef, $s, 60, 3, " 8{2/1:%_C$GS::MasterVolume\_3_0_0_1} "); #
Edit::Seq($m, 0, undef, undef, undef, $s, 60, 3, " 8{2/1:%_C$GS::MasterPan\_2_1_0_1} "); #
#Edit::Seq($m, 0, undef, undef, undef, $s, 60, 3, " 8{2/1:%_C$GS::MasterFineTune\_2_1_0_1} "); #

#Edit::Seq($m, 0, undef, undef, undef, $s, 60, 3, " 8/1:%_C$RolandHp302::EfxP3\_1_0_1_0 "); #

#===============================================================================

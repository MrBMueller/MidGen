use strict; use warnings; eval("use RolandHp302; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

Misc::InsertCopyright(\%main::out);

GS::Reset(\%main::out, 0x00, $s, 1, 0x00); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x3f, 0x3f); #

my $mv = -0.5; @main::InitParams = (undef, 1/4); $MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames()};

sub patch { return(@{$RolandHp302::Patches{shift(@_)}{shift(@_)}}); } my @patch0 = patch(4,4); my @patch1 = patch(4,223);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol      exp   pan  rev  chr    # arr. setup
[1, "Ctrl", 0x00                                                                                  ],  # 00
[0, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,      @patch1, 1.5+$mv, 1.0,  0.0, 0.7, 0.0],  # 01 live
[1, "0x01", 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0+$mv, 1.0,  0.0, 0.9, 0.9],  # 02 bass
[1, "0x02", 0x00, 0x2, +000, 1.0, 0.0, +0.4, 1.0, +0.0,      @patch0, 1.0+$mv, 1.0,  0.0, 0.7, 0.0],  # 03 harmonics/pad
[0, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 04 rythm/chords
[1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0,      @patch0, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 05
[1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 06
[1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 07
[1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 08
[1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 09
[1, "0x09", 0x00, 0x9, +000, 1.0, 1.0, +0.2, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.5, 0.0],  # 0a percussion
[1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0]); # 10

@main::trks = (
#arr. setup      00      01      02      03      04      05      06      07      08      09      0a      0b      0c      0d      0e      0f      10   #trk
[        -1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1], #s
[        -2, 'Ctrl', '0x00', '0x01', '0x02', '0x03', '0x04', '0x05', '0x06', '0x07', '0x08', '0x09', '0x0a', '0x0b', '0x0c', '0x0d', '0x0e', '0x0f'], #name
[        -3,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00], #port
[        -4,  undef,    0x0,    0x1,    0x2,    0x3,    0x4,    0x5,    0x6,    0x7,    0x8,    0x9,    0xa,    0xb,    0xc,    0xd,    0xe,    0xf], #chn
[        -7,  undef,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000,   +000], #key+
[       -12,  undef,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0], #dur*
[        -9,  undef,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0], #vel*
[        -8,  undef,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0], #vel+
[       -11,  undef,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0], #rel*
[       -10,  undef,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0,   +0.0], #rel+
[        -5,  undef, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000], #bank
[        -6,  undef,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00,   0x00], #prg
[$GM::CCx07,  undef,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0], #vol
[$GM::CCx0b,  undef,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0,    1.0], #exp
[$GM::CCx0a,  undef,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0], #pan
[$GS::CCx5b,  undef,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0], #rev
[$GS::CCx5d,  undef,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0], #chr
);

my %DrumMap0 = (
# key      key+  dur* vel* vel+  rel* rel+
   -2 => [   -7, -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
   33 => [   34, 1.0, 1.0, +0.2, 1.0, +0.0, undef, undef, undef, undef], #metronome
   35 => [undef, 1.0, 1.0, +0.2, 1.0, +0.0, undef, undef, undef, undef], #BD2
   36 => [undef, 1.0, 1.0, +0.2, 1.0, +0.0, undef, undef,  -0.9,    .9], #BD1
   38 => [undef, 1.0, 1.0, +0.2, 1.0, +0.0, undef, undef,   0.9,    .1]  #SD1
);

@main::trks = Misc::TransposeArray(\@main::trks);
Misc::State2Param(\@main::trks);
#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => 1.0, $GM::CCx07 => 1.0});
Misc::InsertInstrumentNames(\%main::out, \@main::trks, \%MidiDebug::Prgs, $s);
#Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);

Edit::Seq($m, 1, undef, undef, undef, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

goto MyLabelEnd;

my $r = 0; eval("use Style3;"); my $split = 60+1*12+1; my $Phrase = './*20131006204338*'; $Phrase = "$main::SrcDir0/Midi/*20131006204338*";

for (1..8) { #MIDI::InsertText(\%main::out, 0, $s, 0, sprintf("%d", $_), 6, " -> ", 1);

         Brainstorm::InsertPhrase(\%main::out,  5, $s, $Phrase, undef, 1/128, -1/128, 0, ">=$split",   0, 0, 1.0, 0, .5);
         Brainstorm::InsertPhrase(\%main::out,  3, $s, $Phrase, undef, 1/128, -1/128, 0,  "<$split",   0, 0, 1.0, 0, .5);
my $bs = Brainstorm::InsertPhrase(\%main::out,  1, $s, $Phrase, undef, 1/128, -1/128, 0,      undef,   0, 0, 0.0, 0, .5); #printf("$bs\n");

(undef, undef, $bs, undef, undef, undef) = Edit::Quantize($bs, 1/1); $s += $bs; if (!$bs) { $s += Style0::Var0($m, $s, 128/1,  0, 0xf); $r++; }} #goto MyLabelEnd;

Tools::QuantizeChords(\%main::out, 3, undef, 1/32, 1/16, 1/2, 1/2, 1); #goto MyLabelEnd;

my %RecChords = Tools::GetChords(\%main::out, 3); Tools::ReduceChords(\%RecChords); Tools::PrintChords(\%main::out, \%RecChords); #goto MyLabelEnd;

#$m->{1} = {}; #delete($m->{1});
$m->{3} = {}; #delete($m->{3});

foreach my $start (sort {$a <=> $b} keys(%RecChords)) { my ($ints, $note, $crd, $inv, $length, $MidiNote) = @{$RecChords{$start}};
 if     (($crd == 2) || ($crd == 3)) { Style0::Var0($m, $start, $length,  0, 0b0001, $MidiNote, $crd, 1.0, '', $inv); }
  elsif  ($crd == 4)                 { Style0::Var0($m, $start, $length,  0, 0b1101, $MidiNote,    3, 1.0, '', $inv); }
  else                               { Style0::Var0($m, $start, $length,  0, 0b1111, $MidiNote,    3, 1.0, '', $inv); }
 }

#===============================================================================

use strict; use warnings; eval("use GM; use GS; use KX; use MMC; use BrotherGregory; use Chord; use Arpeggio; use Percussion;"); $MIDI::ContCtlRes = -10; $main::DummyNop = 0/1;

my $Bank = 0x0000; #base (GM/GS)
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2";                                                                       #  7.586.050   Sun Mar 18 12:17:00 2001

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs);

push(@{$main::trks[0]}, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9); #append inspector params

#                   s   name   port  chn    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                    ],   # 00
                   [1, "0x00", 0x00, 0x0, 0x0000,   40, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 01
                   [1, "0x01", 0x00, 0x1, 0x0000,   40, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 02
                   [1, "0x02", 0x00, 0x2, 0x0000,   40, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 03
                   [1, "0x03", 0x00, 0x3, 0x0000,   71, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, 0x0000,   40, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.1, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

Seq0(\%main::out, $s);

#===============================================================================
sub Seq0 { my $m = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " Mv ");

      Edit::Seq($m, 1, undef, undef, undef, $s, 60+ 0, 2, " | 3/1+1/2:1 1/2:^6 | 1/4:v |1/1:% | "); #Arco
      Edit::Seq($m, 2, undef, undef, undef, $s, 60- 0, 2, " | 1/4+:% 1/8:-6 1/4+:-1 1/8+1/4+1/8:v 1/8:^ 1/4:^ = | 1/4:-3 ^ +:^ 1/8:-3 | 1/1:-2 | 1/4:-1 |1/1:% | "); #Arco 2
$s += Edit::Seq($m, 3, undef, undef, undef, $s, 60+ 0, 2, " | 1/1:% | 1/4+:% 1/8:6 1/4:^ = | 4 ^ +:^ 1/8:^ | 1/2:^ ^ | 1/4:#^ |1/1:% | "); #Arco 3

Edit::Seq($m, 4, undef, undef, undef, $start, 60+ 0, 2, " 4{| 1/1:% |}  1/8:% 1/16:#0 #1 1/8:#3 #4 #5 3 | "); #Calrinet

#Edit::Seq($m, 5, undef, undef, undef, $start, 60+ 0, 2, " | 1/4:2 % 0 % | -2 % -3 % 2{| 1/8:-6 % > % # % # % | -7 % -7 % # % # % |} "); #Arco 2

$s += Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " M^ ");

return($s-$start); }
#===============================================================================

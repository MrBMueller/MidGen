

#my $t = 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 1, 0, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 1, 0, 1,  0) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 1, 1, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 1, 1, 0, -1) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 2, 0, .5,  .5) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 2, 0, .5, -.5) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 2, 1, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 2, 1, 0, -1) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 3, 0, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 3, 0, 1, -1) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 3, 1, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 3, 1, 0, -1) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 4, 0, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 4, 0, 1,  0) + 1/1;

#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 5, 0, 0,  1) + 1/1;
#$t += MIDI::InsertCtlr(\%main::out, 1, $t, 0, undef, 1/1, undef, 0xa, 5, 0, 1,  0) + 1/1;


#$main::out{-1}{4} = 100.0; Edit::Seq(\%main::out, 0, 1/1, 60, 2, " 1/1:%_Cx103_2_1_0_.25 ");



#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " | 1/4:0 1/8:. .:. 1/4:4 .:7 | 1/4:0 . . . | % . . . | 6 . . . | ");

#%main::out = MIDI::Read("D:\\Midi\\mid\\BEST_OF\\RADIODNC.MID"); $main::out{-1}{0} = "midifile.mid"; #MidiDebug::PrintInfo(\%smf); MIDI::Write(\%smf, "filename.mid");

#my $t = 1/1;

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " | 1/4:0_.25_r1 2_.5_r.75 4_.75_r.25 6_1.0_r0 | .75_r.25 .5_r.5 .25_r.75 .0_r1 | ", 1, 1);

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1/4:0_.25 2_.5 4_.75 6_1.0 .75 .5 .25 .0 ");



#my $a = " [( > ^2 ^2 . )] "; #simple apreggio sequence template

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1/4<:0_% $a <:2_% $a <:4_% $a <:6_% $a "); #insert template


#my $a = " > ^2 ^2 v4 "; #simple apreggio sequence template

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1/4<:0_% $a 1/4<:3_% $a <:4_% $a 1/4<:0_% $a "); #insert template


#my $c = " <:> <:^2 ^2 "; #simple chord termplate: starts with base note and 2 stacked thirds

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1/1<:0_% $c 1/2<:3_% $c <:4_% $c 1/1<:0_% $c "); #instanciate chord template

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " | 1/4:0 . % . | > . . . | ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry 1/4<:-1_%_.5 4( ^ ^_.6 ^ ^ ) Mreturn ");


#$t += Edit::Seq(\%main::out, 1, $t, 60, 2, " Mentry1 <1/4<:% 1/8:-2 -1 | 0 1 2 3 4 5 6 7 | 8 9 <1/4<:% Mreturn1 ");
#$t += Edit::Seq(\%main::out, 2, $t, 60, 2, " Mentry2 <1/4<:% 1/8:-2 -1 | 0 1 2 3 4 5 6 7 | 8 9 <1/4<:% Mreturn2 ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry 1/1<:0 <:2 4 Mreturn ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry 1/4:0 Mreturn ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry <1/4<:0 Mreturn ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry 1/4<:0 Mreturn ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry <1/4:0 Mreturn ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " Mentry 4{ 2{ 1/8:0 1 2 3 } 7 6 5 4 } Mreturn ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1/4:0 ^ v ^2 v2 ^3 v3 ^4 ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1/4:0 1b 2b 3# 4# 5 6 7 ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " || 1/4:0 1 2 3 | 3 2 1 0 || ");

#Edit::Seq(\%main::out, 1, 1/1, 60, 2, " 1:0 0.5:1 .25:2 1/4:3 1/4+1/8:4 |1/1:% 1/2+++:5 ");


#$t += Edit::Seq(\%main::out, 1, $t, 60, 2, " Mentry1 <1/4<:% 1/2:0 2 4 <1/4<:% Mreturn1 ");
#$t += Edit::Seq(\%main::out, 2, $t, 60, 2, " Mentry2 <1/4<:% 1/2:0 2 4 <1/4<:% Mreturn2 ");

#$t += ($a = Edit::Seq(\%main::out, 0, $t, 60, 2, " Mentry 3[1/4:^2] Mreturn ")) + 1/1; printf("$a\n");

#$t += ($a = Edit::Seq(\%main::out, 0, $t, 60, 2, " Mentry <1/4:0 Mreturn ")) + 1/1; printf("$a\n");
#$t += ($a = Edit::Seq(\%main::out, 0, $t, 60, 2, " Mentry 1/4<:0 Mreturn ")) + 1/1; printf("$a\n");

goto MyLabelEnd;



$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSetValue    1/1:0_C11_0.5 ") + 1/1;

$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepLinear 1/1:0_C11__1_0_0_1 ") + 1/1;
$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepLinear 1/1:0_C11_-1_0_0_1 ") + 1/1;

$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepSinusoid 1/1:0_C11__2_1_0_1 ") + 1/1;
$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepSinusoid 1/1:0_C11_-2_1_0_1 ") + 1/1;

$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepHalfSin 1/1:0_C11__3_0_0_1 ") + 1/1;
$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepHalfSin 1/1:0_C11_-3_0_0_1 ") + 1/1;

$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepHalfSin 1/1:0_C11__4_0_0_1 ") + 1/1;
$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepHalfSin 1/1:0_C11_-4_0_0_1 ") + 1/1;

$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepSigmoid 1/1:0_C11__5_0_0_1 ") + 1/1;
$t += Edit::Seq(\%main::out, 0, $t, 60, 2, " MSweepSigmoid 1/1:0_C11_-5_0_0_1 ") + 1/1;

#===============================================================================

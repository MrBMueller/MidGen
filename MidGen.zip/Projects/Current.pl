use GS; use Metronome; use Misc;

use constant { u=>undef, p=>0x01 }; my $m = \%main::out; my @l; my $B = 1/1; my $t = 0/1;

GS::Reset($m, 0x00, $t+0/4, 1, 0x00); #

GS::Reverb($m, 0x00, $t+1/4, 1, undef, 0x04, undef, 0x3f, 0x6f); #

@main::InitParams = (undef, $t+2/4);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, 0x47, 0x4a, $GM::RPN_0],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev  chr    # arr. setup
[1, 'Ctrl',    p                                                                              ],  # 00
[1, '0x00',    p, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 01 left  - harmonics/pad
[1, '0x01',    p, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 02 right - melody
[1, '0x02',    p, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   38, 1.0, 1.0,  0.0, 0.0, 0.0],  # 03 bass
[1, '0x03',    p, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 04 rythm/chords
[1, '0x04',    p, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 05
[1, '0x05',    p, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 06
[1, '0x06',    p, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 07
[1, '0x07',    p, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 08
[1, '0x08',    p, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 09
[1, '0x09',    p, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0a percussion
[1, '0x0a',    p, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0b
[1, '0x0b',    p, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0c
[1, '0x0c',    p, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0d
[1, '0x0d',    p, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0e
[1, '0x0e',    p, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 0f
[1, '0x0f',    p, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, 0.0],  # 10
); #

my %DrumMap0 = (
#key      s    key    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10, $GS::cNRPNx1800, $GS::NRPNx1a00, $GS::cNRPNx1c00, $GS::NRPNx1d00, $GS::NRPNx1e00],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef, undef], #metronome
  35 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0, undef, undef, undef,    .0], #Conga Lo
);

Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);


#MIDI::InsertGeneric($m, 2, $t+3/1, 1, 0xf7, 0xc0, 99);


#$t += Edit::Seq($m, 0, $t, 0, 0, " | $B:% | MLabelx17 $B:% MJump-4 | ") + 1*$B;

$t += Edit::Seq($m, 0, $t, 0, 0, " | $B:% | ") + 1*$B;


$t += Beat0($m, $t, 60); $t += 1*$B;
#$t += Beat0($m, $t, 61); $t += 1*$B;


Metronome::Generic($m, 10, 0*$B, (Edit::Quantize(MIDI::GetEndTime($m)/($m->{-1}{3}*4), $B))[2]+1*$B, .2, undef, undef, 0, 1, 33); #main counter

Edit::Seq($m, 0, (Edit::Quantize(MIDI::GetEndTime($m)/($m->{-1}{3}*4), $B))[2], 0, 0, " $B:% MLabelx18 "); #

#==============================================================================#

sub Beat0 { my ($m, $t, $Label) = (@_);

push(@l, Edit::Seq($m, 10, $t, 0, 0, " 1/16<:35_% |X...|....|X...|....||X.X.|....|X...|....| ")); #base drum
push(@l, Edit::Seq($m, 10, $t, 0, 0, " 1/16<:38_% |....|X...|....|X...||....|X...|....|X...| ")); #snare drum

push(@l, Edit::Seq($m, 10, $t, 0, 0, " 1/16<:44_% |X...|X...|X...|X...||X...|X...|X...|X...| ")); #pedal HH
push(@l, Edit::Seq($m, 10, $t, 0, 0, " 1/16<:42_% |..X.|..X.|..X.|..X.||..X.|..X.|..X.|....| ")); #closed HH

push(@l, Edit::Seq($m, 10, $t, 0, 0, " 1/16<:46_% |....|....|....|....||....|....|....|..X.| ")); #open HH


#push(@l, Edit::Seq($m,  3, $t, 0, 0, " 1/16<:44_% |X...|X...|X...|X...||X...|X...|X...|X...| ")); #pedal HH


my $l = undef; foreach (@l) { if (not(defined($l)) || $_ > $l) { $l = $_; }}


Edit::Seq(\%main::out, 0, $t, 0, 0, " MLabel$Label $l:% MJump-4 "); #

return($l); }

#==============================================================================#

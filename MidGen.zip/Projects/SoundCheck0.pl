use strict; use warnings; eval("use GM2; use KX; use BrotherGregory; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools; use Style0;"); $MIDI::ContCtlRes = -10; $main::DummyNop = 0/1;

my $Bank = 0x0000; #base (GM/GS)
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2";                                                                       #  7.586.050   Sun Mar 18 12:17:00 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/AWEGOLD/4GMGSMT.SF2";                                                                        #  4.174.814   Tue Jul 30 11:52:32 1996

$Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/TR808WAV/tr808.sf2";                                                                         #  1.019.288   Wed Mar 28 21:31:24 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

#$MidiDebug::Prgs{0x01} = {MidiDebug::ImportCubaseParseFile("$main::SrcDir0/DeviceMaps/BrotherGregory.txt", "BrG")}; #port 1

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

Misc::InsertCopyright(\%main::out, $s);

GM2::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#GM2::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00, 0x00);

@main::trks = ([-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GM::RPN_0, $GM::cPB, $KX::CCx47, $KX::CCx4a, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9]);

#                   s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev   PBS     PB   frs(0) fco(1)    # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                                     ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,    0, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 01 live
                   [1, "0x01", 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   34, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 02 bass
                   [1, "0x02", 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0003,    0,  .3, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03 harmonics/pad
                   [1, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04 rythm/chords
                   [1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   11, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, @DrumMaps::Generic             , 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

Misc::InsertInstrumentNames(\%main::out, \@main::trks, \%MidiDebug::Prgs, $s);

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

#eval("use Tutorial;"); $m->{-1}{7} = 0; $s += Tutorial::Regr4($m, 1, $s); Edit::AddLyricString($m); goto MyLabelEnd;

for (my $i=0; $i<=0x7f; $i++) {
 #my $name = "unknown"; if (exists($MidiDebug::Prgs{0}{0xc}{ -1}{0}{$i}   )) { $name = $MidiDebug::Prgs{0}{0xc}{ -1}{0}{$i};    }
 my $name = "unknown"; if (exists($MidiDebug::Prgs{0}{0x9}{0x9}{0}{0}{$i})) { $name = $MidiDebug::Prgs{0}{0x9}{0x9}{0}{0}{$i}; }
 MIDI::InsertText($m, 0, $s, 0, sprintf("0x%02x %s", $i, $name), 6, " -> ", 1);
 #$s += Edit::Seq($m,  1, undef, undef, $i, $s, 60, 2, " 1/4:0 ^ = = ");
 $s += Edit::Seq($m, 10, undef, undef, undef, $s, $i, 0, " 1/8:0 ");
 } goto MyLabelEnd;

#Brainstorm::InsertPhrase(\%main::out, 1, $s+0/1, ".", undef, 1/128, -1/128, 0, undef,   0, 0, 1, 0, .5); #rec or play last in current dir

my $PhraseDir = "."; my $Phrase = undef; my $split = 72; my $tr = 0; $PhraseDir = "$main::SrcDir0/Midi/."; $Phrase = "20120226175539"; $split = 60; $tr = +12;

my $bs  = Brainstorm::InsertPhrase(\%main::out, 3, $s+0/1, $PhraseDir, $Phrase,   1/2,    1/2, 1,  "<$split", $tr, 0, 1, 0, .5);
   #$bs += Brainstorm::InsertPhrase(\%main::out, 5, $s+0/1, $PhraseDir, $Phrase, 1/128, -1/128, 0,  "<$split", +12, 0, 1, 0, .5);
   $bs += Brainstorm::InsertPhrase(\%main::out, 1, $s+0/1, $PhraseDir, $Phrase, 1/128, -1/128, 0, ">=$split",   0, 0, 1, 0, .5);

if (!$bs) { Style0::Var0($m, $s, 128/1,  0, 0xf); }

my %RecChords = Tools::GetChords(\%main::out, 3); Tools::ReduceChords(\%RecChords); Tools::PrintChords(\%main::out, \%RecChords);

foreach my $start (sort {$a <=> $b} keys(%RecChords)) { my ($ints, $note, $crd, $inv, $length, $MidiNote) = @{$RecChords{$start}};
 if     (($crd == 2) || ($crd == 3)) { Style0::Var0($m, $start, $length,  0, 0x5, 60+$note, $crd); }
  elsif  ($crd == 4)                 { Style0::Var0($m, $start, $length,  0, 0xd, 60+$note,    3); }
  else                               { Style0::Var0($m, $start, $length,  0, 0xf, 60+    0,    3); }
 }

#===============================================================================

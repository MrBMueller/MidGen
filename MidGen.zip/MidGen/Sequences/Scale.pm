use strict; use warnings; package Scale;

#scales - chromatic/diatonic
#chromatic  - 12 [+1] notes -> 11 [+1] intervals
#heptatonic -  7 [+1] notes ->  6 [+1] intervals
#pentatonic -  5 [+1] notes ->  4 [+1] intervals

#interval number       0  1  2  3  4  5  6  7  8  9 10 11
our %Scales = (  0 => [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], # chromatic
                 1 => [7, 5],                               # quint
                 2 => [2, 2, 1, 2, 2, 2, 1],                # major
                 3 => [2, 1, 2, 2, 1, 2, 2],                # minor (natural/pure/aeolic)
                 4 => [2, 1, 2, 2, 2, 2, 1],                # minor (melodic)
                 5 => [2, 1, 2, 2, 1, 3, 1],                # minor (harmonic)
                 6 => [1, 3, 1, 2, 1, 3, 1],                # minor (gypsy/arabic)
                 7 => [12],                                 # oct
                 8 => [5, 5, 5, 4, 5],                      # 6 string guitar
                 9 => [2, 2, 3, 2, 3],                      # pentatonic major
                10 => [3, 2, 2, 3, 2],                      # pentatonic minor
                11 => [2, 2, 1, 2, 2, 2, 1],                # heptatonic - 0 ionisch (major)
                12 => [2, 1, 2, 2, 2, 1, 2],                # heptatonic - 1 dorisch
                13 => [1, 2, 2, 2, 1, 2, 2],                # heptatonic - 2 phrygisch
                14 => [2, 2, 2, 1, 2, 2, 1],                # heptatonic - 3 lydisch
                15 => [2, 2, 1, 2, 2, 1, 2],                # heptatonic - 4 mixolydisch
                16 => [2, 1, 2, 2, 1, 2, 2],                # heptatonic - 5 aeolisch (minor)
                17 => [1, 2, 2, 1, 2, 2, 2]                 # heptatonic - 6 hypophrygisch
	          );

#usage mode example:
#for (my $i=11; $i<scalar(keys(%Scale::Scales)); $i++) { %{$Edit::Scales{$i}} = Scale::Array2Hash(@{$Scale::Scales{$i}}); }

return(1);
#===============================================================================
sub Array2Hash { my %RetVal; my $i=0; while ($#_ >= 0) { $RetVal{$i++} = shift(@_); } return(%RetVal); }
#===============================================================================

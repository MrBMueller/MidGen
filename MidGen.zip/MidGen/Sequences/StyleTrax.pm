use strict; use warnings; package StyleTrax; eval("use Brainstorm; use Tools;"); return(1);
#===============================================================================
sub LiveStyle { my $m = shift(@_); my $s = shift(@_); my $Phrase = shift(@_); my $split = shift(@_); my $ct = shift(@_); my $mt = shift(@_);
my $Var  = undef; if ($#_ >= 0) { $Var  = shift(@_); }
my $mute =   0b0; if ($#_ >= 0) { $mute = shift(@_); }

my $csq = 1; if (ref($s) =~ /ARRAY/i) { $s = (@{$s})[0]; $csq = -1; }

my ($tc, $vc, $vc0, $vc1) = (undef, 0, 1, .5); if (ref($ct) =~ /ARRAY/i) { $ct = (@{$ct})[0]; ($tc, $vc, $vc0, $vc1) = (0, 1, 0, 0); }
my ($tm, $vm, $vm0, $vm1) = (undef, 0, 1, .5); if (ref($mt) =~ /ARRAY/i) { $mt = (@{$mt})[0]; ($tm, $vm, $vm0, $vm1) = (0, 1, 0, 0); }

if ((not(defined($tc))) && ($#_ >= 0)) { $tc = shift(@_); } if (not(defined($tc))) { $tc = 0; }
if ((not(defined($tm))) && ($#_ >= 0)) { $tm = shift(@_); } if (not(defined($tm))) { $tm = 0; }

my ($N, $DN) = (1, 1); if (exists($m->{-1}{5}) && defined($m->{-1}{5})) { $N = $m->{-1}{5}; } if (exists($m->{-1}{6}) && defined($m->{-1}{6})) { $DN = $m->{-1}{6}; }

my $t0 = (sort {$b <=> $a} keys(%{$m}))[0]+1; if (defined($ct) && ($ct >= $t0)) { $t0 = $ct+1; } if (defined($mt) && ($mt >= $t0)) { $t0 = $mt+1; } my $t1 = $t0+1;

if ($s >= 0) { MIDI::InsertText($m, 0, $s, 1, sprintf("StyleTrax::LiveStyle($Phrase, $t0, $t1);"), 6, " -> ", 1); }

my ($ps, $pl) = Brainstorm::InsertPhrase($m, $t0, $s, $Phrase, undef, 0/128, -0/128, 0, undef, 0, 1,0, 1,0, $N/$DN, $mt, undef);

                                      Edit::Copy($m, $t1, $m, $t0, 0x9, undef, StyleTrax::GetSplits($m, $t0, '<' , $split), 0, 0, undef,   0, $vc,$vc0, $vc,$vc1);
my $lc = 0; if (defined($ct)) { $lc = Edit::Copy($m, $ct, $m, $t0, 0x9, undef, StyleTrax::GetSplits($m, $t0, '<' , $split), 0, 0, undef, $tc, $vc,$vc0, $vc,$vc1); $mute ^= (1 << $ct); }
my $lm = 0; if (defined($mt)) { $lm = Edit::Copy($m, $mt, $m, $t0, 0x9, undef, StyleTrax::GetSplits($m, $t0, '>=', $split), 0, 0, undef, $tm, $vm,$vm0, $vm,$vm1); $mute ^= (1 << $mt); }

if ($lc) { Edit::Copy($m, $ct, $m, $t0, 0xb, undef, "==0x40"); }
if ($lm) { Edit::Copy($m, $mt, $m, $t0, 0xb, undef, "==0x40"); }

my %RecChords = Tools::GetChords($m, $t1);
Tools::QuantizeChords1(\%RecChords, $csq/$DN, 1/1, 1/1, 1);
Tools::ReduceChords(\%RecChords);

delete($m->{$t0}); delete($m->{$t1});

my $Idx = -1;
foreach my $start (sort {$a <=> $b} keys(%RecChords)) { $Idx++; my (undef, undef, $crd, $inv, $length, $MidiNote, $von, $vof, $dmin, $dmax, $dmed, $start1) = @{$RecChords{$start}};
 #if ($dmed < $length) { $length = $dmed; }
 if (defined($Var)) { $Var->($m, $start1, $length, $mute, $MidiNote, $crd, $inv, $von, $vof, $Idx, $start1-$s, @_); }
 }

return($ps, $pl); }
#===============================================================================
sub ChordStyle { my ($m, $s, $Line, $Var, $mute) = (shift(@_), shift(@_), shift(@_), shift(@_), shift(@_));
if (not(defined($mute))) { $mute = 0b0; }

my ($length, %Events) = StyleTrax::ParseLine($Line);

my ($LastVal, $Idx) = (undef, -1);
foreach my $start (sort {$a <=> $b} keys(%Events)) { $Idx++; my ($length, $event) = @{$Events{$start}};
 $event =~ s/^_//g; $event =~ s/_$//g; my @ValSplit = split('_', $event);
 my @a; foreach (@_) { push(@a, $_); } for (my $p=1; $p<=$#ValSplit; $p++) { if ($#ValSplit-1 >= $#a) { $a[$p-1] = $ValSplit[$p]; } else { $a[$#a-($#ValSplit-$p)] = $ValSplit[$p]; }}
 if ($ValSplit[0] =~ /^>$/) { $ValSplit[0] = $LastVal; } $LastVal = $ValSplit[0];
 if ($#a < 0) { push(@a, 1); } if ($#a < 1) { push(@a, .5); }
 $Var->($m, $s+$start, $length, $mute, Tools::GetChord($ValSplit[0]), shift(@a), shift(@a), $Idx, $start, @a);
 }

return($length); }
#===============================================================================
sub ParseLine { my ($Line) = @_; my $start = 0; my %rv;

$Line =~ s/{/{ /g; $Line =~ s/}/ } /g; $Line =~ s/\[/[ /g; $Line =~ s/\]/ ] /g; $Line =~ s/\(/( /g; $Line =~ s/\)/ ) /g;
$Line = Edit::ResolveRepeats($Line); $Line = Edit::ResolveRepeats($Line, '['); $Line = Edit::ResolveRepeats($Line, '(');
$Line =~ s/\|+/\|/g; $Line =~ s/\|\s/ /g; $Line =~ s/\|$/ /g; $Line =~ s/\_+/\_/g; $Line =~ s/!/ ! /g;
$Line =~ s/^\s+//g; $Line =~ s/\s+/ /g; $Line =~ s/\s+$//g; my @Events = split(/\s+/, $Line);

my @stack1; my @Times = ("."); my @Evnts = (".");
my $SeqStart = $start; my $LastValTm = "0"; my $LastValOp = "%"; my $CurrentTime = 0; my $CurTime0 = 0; my $CurTime2 = $CurrentTime;
my $flgs = 0; my $CurrentVal = 'C';

for (my $i=0; $i<=$#Events; $i++) {

 if ($Events[$i] =~ /\($/) { push(@stack1, [$Times[$#Times], $Evnts[$#Evnts], $LastValTm, $LastValOp, $CurrentTime, $CurTime0, $CurTime2, $flgs, $CurrentVal]);                  }
 if ($Events[$i] =~ /\)$/) {               ($Times[$#Times], $Evnts[$#Evnts], $LastValTm, $LastValOp, $CurrentTime, $CurTime0, $CurTime2, $flgs, $CurrentVal) = @{pop(@stack1)}; }

 if ($Events[$i] =~ /[{}\(\)\[\]!]$/) { next(); }

 $Events[$i] =~ s/:$/:./g; $Events[$i] =~ s/^:/.:/g; my @EventSplit = split(":", $Events[$i]);

 for (my $j=0; $j<=$#EventSplit; $j++) { if (length($EventSplit[$j]) <= 0 ) { $EventSplit[$j] = "."; }}

 my $DefTime = '.';
 if      ($#EventSplit <= 0) { push(@Times, $DefTime      ); push(@Evnts, $EventSplit[0]); }
  elsif  ($#EventSplit <= 1) { push(@Times, $EventSplit[0]); push(@Evnts, $EventSplit[1]); }

 my $p0 = -1;
 if     ($Times[$#Times] =~ /^\.$/) { $Times[$#Times] = $Times[$#Times-1]; $p0++; }
  elsif ($Times[$#Times] =~ /^=$/ ) { $Times[$#Times] = $LastValTm;               }
  else                              { $LastValTm = $Times[$#Times];               }

 my $p1 = -1;
 if     ($Evnts[$#Evnts] =~ /^\.$/) { $Evnts[$#Evnts] = $Evnts[$#Evnts-1]; $p1++; }
  elsif ($Evnts[$#Evnts] =~ /^=$/ ) { $Evnts[$#Evnts] = $LastValOp;               }
  else                              { $LastValOp = $Evnts[$#Evnts];               }

 if (($p0 < 0) || ($Times[$#Times] =~ /^=$/ )) { my $val = $LastValTm; $val =~ s/x/0x/gi; $val =~ s/_//g; my $sign = 0;

  if    ($val =~ /\|/    ) { $val =~ s/\|//; $sign |= 0x2; }
  while ($val =~ /[<>]/  ) {
  if    ($val =~ /^<(.+)/) { $val = $1;      $sign ^= 0x1; }
  if    ($val =~ /(.+)<$/) { $val = $1;      $sign ^= 0x4; }
  if    ($val =~ /^<$/   ) { $val = '';      $sign ^= 0x4; }}

  my @ds; while ($val =~ /(.*)([+-])$/) { $val = $1; my $d = $2; push(@ds, $d); }

  if     ($val =~ /^([\*\/+-].+)/) { $CurrentTime = eval($CurrentTime.$1); } #modify previous
   elsif ($val =~ /^[*]$/        ) { $CurrentTime *= 2;                    } #modify previous
   elsif ($val =~ /^[\/]$/       ) { $CurrentTime /= 2;                    } #modify previous
   elsif (length($val)           ) { $CurrentTime = eval($val);            } #set new

  my $AddTime = 0; for (my $d=$#ds; $d>=0; $d--) { my $t = $CurrentTime/(2**($#ds-$d+1)); $AddTime = eval($AddTime.$ds[$d].$t); } $CurrentTime += $AddTime;

  if ($sign & 0x2) { my (undef, undef, undef, $fd, undef, $cd) = Edit::Quantize($start-$SeqStart, $CurrentTime); $CurrentTime = $cd; if ($sign & 0x1) { $CurrentTime = $fd; }}
  if ($sign & 0x1) { $CurTime0 = 0 - abs($CurrentTime); $CurTime2 = abs($CurrentTime); }
   else            { $CurTime0 = 0;                     $CurTime2 = abs($CurrentTime); }
  if ($sign & 0x4) {                                    $CurTime2 = 0;                 }
  }

 if (($p1 < 0) || ($Evnts[$#Evnts] =~ /^=$/ )) { my $val = $LastValOp;

  if ($CurrentTime == 0) { $flgs |= 0x01; } #default pause if no progressive time

  if     ($val =~ /^%$/) { $flgs |= 0x01; } #nop/pause
   elsif ($val =~ /^>$/) { $flgs &= 0x0e; } #continue
   else                  { $flgs &= 0x0e; $CurrentVal = $val; }
  }

 $start += $CurTime0;

 if (($flgs & 0x09) == 0) { $rv{$start} = [$CurrentTime, $CurrentVal]; }

 $flgs &= 0x01; $start += $CurTime2; $CurTime0 = 0; $CurTime2 = abs($CurrentTime);
 }

return($start, %rv); }
#===============================================================================
sub GetSplits { my ($m, $trk, $o, $s) = @_;

if ((defined($s)) && (ref($s) !~ /HASH/i) && ($s =~ /[=,]/g)) { $s =~ s/\s*//g; $s =~ s/^,/=,/; my @l = split(',', $s); my %h;
 foreach (@l) { my ($k, $v) = (undef, undef);
  if     ($_ =~ /(.+)=(.+)/) { ($k, $v) = ($1, $2   ); }
   elsif ($_ =~     /=(.+)/) { ($k, $v) = ('', $1   ); }
   elsif ($_ =~ /(.+)=/    ) { ($k, $v) = ($1, undef); }
   elsif ($_ =~     /=/    ) {                 next(); }
   else                      { ($k, $v) = ('', $_   ); }
  if ((defined($v)) && ($v =~ /\%/)) { $v = undef; } $h{$k} = $v;
  } $s = \%h; }

if (defined($s)) {
 if (ref($s) =~ /HASH/i) {
  if (scalar(keys(%{$s}))) { my %r0;
   foreach (sort(keys(%{$s}))) { my $t = $_; $t =~ s/\s*//g;
    if     ($t =~ /^$/               ) { $t = 0; if ((exists($m->{$trk})) && (scalar(keys(%{$m->{$trk}})))) { $t = (sort {$a <=> $b} (keys(%{$m->{$trk}})))[0]; } $t -= 1*$m->{-1}{3}*4; }
     elsif ($t =~ /(\d+):(\d+):(\d+)/) { $t = ($1-1)*$m->{-1}{3}*4 + ($2-1)*$m->{-1}{3} + $3; }
     elsif ($t =~ /(\d+):(\d+)/      ) { $t = ($1-1)*$m->{-1}{3}*4 + ($2-1)*$m->{-1}{3} +  0; }
     else                              { $t = (eval($t)-1/1)*$m->{-1}{3}*4;                   }
    $r0{$t} = $s->{$_}; if (defined($r0{$t})) { if ($r0{$t} =~ /^\s*$/) { $r0{$t} = undef; } else { $r0{$t} = $o.Tools::GetNote($r0{$t}); }}
    } return(\%r0);
   } else { return(undef); }
  } elsif ($s =~ /^\s*$/) { return(undef); } else { return($o.Tools::GetNote($s)); }
 }

return($s); }
#===============================================================================

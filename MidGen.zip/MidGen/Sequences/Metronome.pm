use strict; use warnings; package Metronome; return(1);
#===============================================================================
sub Generic { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $v =     1; if ($#_ >= 0) { $v = shift(@_); }
my $n = undef; if ($#_ >= 0) { $n = shift(@_); } if (not(defined($n))) { $n = 4; if (defined($m->{-1}{5})) { $n = $m->{-1}{5}; }}
my $d = undef; if ($#_ >= 0) { $d = shift(@_); } if (not(defined($d))) { $d = 4; if (defined($m->{-1}{6})) { $d = $m->{-1}{6}; }}
my $C =     0; if ($#_ >= 0) { $C = shift(@_); }
my $L = -1/64; if ($#_ >= 0) { $L = shift(@_); }
my $k =    33; if ($#_ >= 0) { $k = shift(@_); }
my $c =   0x9; if ($#_ >= 0) { $c = shift(@_); }

if (not(defined($l))) { my ($e, $ppb) = (MIDI::GetEndTime($m), $m->{-1}{3}*4); $l = int($e/$ppb); if ($e%$ppb) { $l += $n/$d; } $l -= $s; }

if ($C) { MIDI::InsertTimeSig($m, 0, $s, 0, $n, $d); }

$s += Edit::Seq($m, $t, $s, 0, 0, sprintf(" 1/%d:$k\_c$c %s ", $d, " .5" x ($n-1)), $v, .5, 0,0,1, 1,1, 1, $L, $l); #metronome click

return($s-$start); }
#===============================================================================
sub GenericWoMain { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $v =     1; if ($#_ >= 0) { $v = shift(@_); }
my $n = undef; if ($#_ >= 0) { $n = shift(@_); } if (not(defined($n))) { $n = 4; if (defined($m->{-1}{5})) { $n = $m->{-1}{5}; }}
my $d = undef; if ($#_ >= 0) { $d = shift(@_); } if (not(defined($d))) { $d = 4; if (defined($m->{-1}{6})) { $d = $m->{-1}{6}; }}
my $C =     0; if ($#_ >= 0) { $C = shift(@_); }
my $L = -1/64; if ($#_ >= 0) { $L = shift(@_); }
my $k =    33; if ($#_ >= 0) { $k = shift(@_); }
my $c =   0x9; if ($#_ >= 0) { $c = shift(@_); }

if (not(defined($l))) { my ($e, $ppb) = (MIDI::GetEndTime($m), $m->{-1}{3}*4); $l = int($e/$ppb); if ($e%$ppb) { $l += $n/$d; } $l -= $s; }

if ($C) { MIDI::InsertTimeSig($m, 0, $s, 0, $n, $d); }

$s += Edit::Seq($m, $t, $s, 0, 0, sprintf(" 1/%d:$k\_c$c\_%% %s ", $d, " >_.5" x ($n-1)), $v, .5, 0,0,1, 1,1, 1, $L, $l); #metronome click

return($s-$start); }
#===============================================================================

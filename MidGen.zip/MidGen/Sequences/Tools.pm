use strict; use warnings; package Tools;

*QuantizeChords = \&Edit::QuantizeTrkChords;

return(1);
#===============================================================================
sub GetChords { my $h0 = shift(@_); my $t0 = shift(@_);
my $split =     undef; if ($#_ >= 0) { $split = shift(@_); } if (not(defined($split))) { $split = -0x7f; }
my $snap  =         0; if ($#_ >= 0) { $snap  = shift(@_); }

my %Crd1Lut;
$Crd1Lut{7}    = [1, 0];
$Crd1Lut{5}    = [1, 1];

my %Crd2Lut;
$Crd2Lut{4}{3} = [2, 0];
$Crd2Lut{5}{4} = [2, 1];
$Crd2Lut{3}{5} = [2, 2];

$Crd2Lut{3}{4} = [3, 0];
$Crd2Lut{5}{3} = [3, 1];
$Crd2Lut{4}{5} = [3, 2];

$Crd2Lut{2}{5} = [4, 0];
$Crd2Lut{5}{2} = [4, 1];
$Crd2Lut{5}{5} = [4, 2];

my %Crd3Lut;
$Crd3Lut{4}{3}{4} = [2, 0];
$Crd3Lut{1}{4}{3} = [2, 1];
$Crd3Lut{4}{1}{4} = [2, 2];
$Crd3Lut{3}{4}{1} = [2, 3];

$Crd3Lut{3}{4}{3} = [3, 0];
$Crd3Lut{2}{3}{4} = [3, 1];
$Crd3Lut{3}{2}{3} = [3, 2];
$Crd3Lut{4}{3}{2} = [3, 3];

$Crd3Lut{4}{3}{3} = [2, 0];
$Crd3Lut{2}{4}{3} = [2, 1];
$Crd3Lut{3}{2}{4} = [2, 2];
$Crd3Lut{3}{3}{2} = [2, 3];

my %pending; my $LastStart = undef; my %RecChords; my $TrkEnd = 0;
foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$t0}}) { my $m = 0; if ($k1 > $TrkEnd) { $TrkEnd = $k1; }
 foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$t0}{$k1}}) { if ((($h0->{$t0}{$k1}{$k2}{0} >> 4) != 0x9) || ($h0->{$t0}{$k1}{$k2}{3} <= 0)) { next; }
  if (($split < 0) && ($h0->{$t0}{$k1}{$k2}{1} > abs($split))) { next; }
  if (($split > 0) && ($h0->{$t0}{$k1}{$k2}{1} < abs($split))) { next; }

  if ($k1+$h0->{$t0}{$k1}{$k2}{3} > $TrkEnd) { $TrkEnd = $k1+$h0->{$t0}{$k1}{$k2}{3}; }

  $m++; $pending{$h0->{$t0}{$k1}{$k2}{1}} = [$k1, $h0->{$t0}{$k1}{$k2}{3}, $h0->{$t0}{$k1}{$k2}{2}, $h0->{$t0}{$k1}{$k2}{4}];

  foreach my $note (sort {$a <=> $b} keys %pending) { my ($start, $dur, undef, undef) = @{$pending{$note}}; if ($k1 >= $start+$dur) { delete($pending{$note}); }}
  }

 my ($von, $vof, $dmin, $dmax) = (0, 0, undef, undef); my %chords;
 foreach my $note (sort {$a <=> $b} keys %pending) {
  my $o = int($note/12); if ((exists($chords{$note%12})) && ($chords{$note%12} < $o)) { $o = $chords{$note%12}; } $chords{$note%12} = $o; #fold (store olny lowest octave)
  my ($s, $d, $v0, $v1) = @{$pending{$note}}; $von += $v0; $vof += $v1; $d = (Edit::Quantize(($d-($k1-$s))/($h0->{-1}{3}*4)))[1];
  if ((not(defined($dmin))) || ($d < $dmin)) { $dmin = $d; }
  if ((not(defined($dmax))) || ($d > $dmax)) { $dmax = $d; }
  }
 if (scalar(keys(%pending))) { $von = ($von / scalar(keys(%pending))) / 127; $vof = ($vof / scalar(keys(%pending))) / 127; }

 my %ints; my $LastNote = undef; foreach my $note (sort {$a <=> $b} keys %chords) { if (defined($LastNote)) { $ints{scalar(keys(%ints))} = $note-$LastNote; } $LastNote = $note; } #get intervals

 (undef, my $start, undef, undef, undef, undef) = Edit::Quantize($k1/($h0->{-1}{3}*4), $snap); my $crd = -1; my $note = -1; my $inv = -1; my $MidiNote = -1;

 if ($m) {

  if (scalar(keys(%ints)) == 0) { $crd = 0; $note = (sort {$a <=> $b} keys(%chords))[0]; $MidiNote = $chords{$note}*12 + $note; $inv = 0; }

  if ((scalar(keys(%ints)) == 1) && (exists($Crd1Lut{$ints{0}}))) {
   ($crd, $note) = @{$Crd1Lut{$ints{0}}}; $note = (sort {$a <=> $b} keys(%chords))[$note];
   $MidiNote = $chords{$note}*12 + $note; my $idx = 0; foreach my $note (sort {$a <=> $b} keys %pending) { if ($MidiNote == $note) { $inv = $idx; } $idx++; }
   }

  if ((scalar(keys(%ints)) == 2) && (exists($Crd2Lut{$ints{0}}{$ints{1}}))) {
   ($crd, $note) = @{$Crd2Lut{$ints{0}}{$ints{1}}}; $note = (sort {$a <=> $b} keys(%chords))[$note];
   $MidiNote = $chords{$note}*12 + $note; my $idx = 0; foreach my $note (sort {$a <=> $b} keys %pending) { if ($MidiNote == $note) { $inv = $idx; } $idx++; }
   }

  if ((scalar(keys(%ints)) == 3) && (exists($Crd3Lut{$ints{0}}{$ints{1}}{$ints{2}}))) {
   ($crd, $note) = @{$Crd3Lut{$ints{0}}{$ints{1}}{$ints{2}}}; $note = (sort {$a <=> $b} keys(%chords))[$note];
   $MidiNote = $chords{$note}*12 + $note; my $idx = 0; foreach my $note (sort {$a <=> $b} keys %pending) { if ($MidiNote == $note) { $inv = $idx; } $idx++; }
   }

  if (defined($LastStart)) { @{$RecChords{$LastStart}}[4] = $start - $LastStart; } $LastStart = $start; $RecChords{$start} = [scalar(keys(%ints)), $note, $crd, $inv, undef, $MidiNote, $von, $vof, $dmin, $dmax, ($dmin+$dmax)/2, $start];
  }
 }

(undef, $TrkEnd, undef, undef, undef, undef) = Edit::Quantize($TrkEnd/($h0->{-1}{3}*4), $snap); if (defined($LastStart)) { my $t = (sort {$a <=> $b} keys(%RecChords))[-1]; @{$RecChords{$t}}[4] = $TrkEnd - $LastStart; }

return(%RecChords); }
#===============================================================================
sub ReduceChords { my $RecChords = shift(@_);

my $start0 = undef;
foreach my $start (sort {$a <=> $b} keys(%{$RecChords})) {
 if (@{$RecChords->{$start}}[2] < 2) { if (defined($start0)) { @{$RecChords->{$start0}}[4] += @{$RecChords->{$start}}[4]; } delete($RecChords->{$start}); }
  else { $start0 = $start; }
 }

($start0, my $start2) = (undef, undef);
foreach my $start (sort {$a <=> $b} keys(%{$RecChords})) { my $start1 = @{$RecChords->{$start}}[11];
 if ((defined($start0))
  && (@{$RecChords->{$start}}[0] == @{$RecChords->{$start0}}[0])
  && (@{$RecChords->{$start}}[1] == @{$RecChords->{$start0}}[1])
  && (@{$RecChords->{$start}}[2] == @{$RecChords->{$start0}}[2])
  && (@{$RecChords->{$start}}[3] == @{$RecChords->{$start0}}[3])
  && (@{$RecChords->{$start}}[5] == @{$RecChords->{$start0}}[5])
  && ($start2 + @{$RecChords->{$start0}}[4] >= $start1)
  ) { @{$RecChords->{$start0}}[4] += @{$RecChords->{$start}}[4]; delete($RecChords->{$start});
  } else { ($start0, $start2) = ($start, $start1); }
 }

return(0); }
#===============================================================================
sub QuantizeChords1 { my ($h0, $qs) = @_; my $ql = $qs; if ($#_ >= 2) { $ql = $_[2]; } my $qd = $ql; if ($#_ >= 3) { $qd = $_[3]; } my $sc = 0; if ($#_ >= 4) { $sc = $_[4]; }

my %new; my $s0 = undef;
foreach my $s (sort {$a <=> $b} keys(%{$h0})) {
 my ($sf, $sq, $Sc, undef, undef, undef) = Edit::Quantize($s                  , $qs); if ($qs < 0) { $sq = $Sc; } if ($sc) { $sc = $s-$sq; }
 my ($lf, $lq, $lc, undef, undef, undef) = Edit::Quantize(@{$h0->{$s}}[ 4]    , $ql); if ($ql < 0) { $lq = $lf; } if ($lq <= 0) { $lq = $lc; }
 my ($af, $aq, $ac, undef, undef, undef) = Edit::Quantize(@{$h0->{$s}}[ 8]+$sc, $qd); if ($ql < 0) { $aq = $af; } if ($aq <= 0) { $aq = $ac; }
 my ($bf, $bq, $bc, undef, undef, undef) = Edit::Quantize(@{$h0->{$s}}[ 9]+$sc, $qd); if ($ql < 0) { $bq = $bf; } if ($bq <= 0) { $bq = $bc; }
 my ($cf, $cq, $cc, undef, undef, undef) = Edit::Quantize(@{$h0->{$s}}[10]+$sc, $qd); if ($ql < 0) { $cq = $cf; } if ($cq <= 0) { $cq = $cc; }
 $new{$sq} = $h0->{$s};
 @{$new{$sq}}[ 4] = $lq;
 @{$new{$sq}}[ 8] = $aq;
 @{$new{$sq}}[ 9] = $bq;
 @{$new{$sq}}[10] = $cq;
 @{$new{$sq}}[11] = $sq;
 if ((defined($s0)) && ($sq-$s0)) { @{$new{$s0}}[4] = $sq-$s0; }
 $s0 = $sq; } %{$h0} = %new;

return(0); }
#===============================================================================
sub PrintChords { my $m = shift(@_); my $RecChords = shift(@_);

foreach my $start (sort {$a <=> $b} keys(%{$RecChords})) { my ($ints, $note, $crd, $inv, $length, $MidiNote) = @{$RecChords->{$start}};
 MIDI::InsertText($m, 0x0, $start, 1, sprintf("%d %s %1.2f", $ints, Tools::GetNoteName($MidiNote, $crd, $inv), $length), 6, " -> ", 1);
 }

return(0); }
#===============================================================================
sub GetVarHead { my $c = (caller(1))[3]; if (ref($_[0]) ne 'HASH') { $c = shift(@_); } my $m = shift(@_); my $s = shift(@_); my $args = "";
my $l     = undef; if ($#_ >= 0) { $l     = shift(@_); }
my $k     =     0; if ($#_ >= 0) { $k     = shift(@_); $args .= sprintf("%d"      , $k    ); }
my $msk   =     0; if ($#_ >= 0) { $msk   = shift(@_); $args .= sprintf(", 0b%b"  , $msk  ); }
my $key   =    60; if ($#_ >= 0) { $key   = shift(@_); $args .= sprintf(", %d"    , $key  ); }
my $scale =     3; if ($#_ >= 0) { $scale = shift(@_); $args .= sprintf(", %d"    , $scale); }
my $v     =     1; if ($#_ >= 0) { $v     = shift(@_); $args .= sprintf(", %1.1f" , $v    ); }
my $cmt   =    ''; if ($#_ >= 0) { $cmt   = shift(@_); $args .= sprintf(", \'%s\'", $cmt  ); }

for (my $i=0; $i<=$#_; $i++) { my $t = $_[$i]; $args .= sprintf(", $t"); }

MIDI::InsertText($m, 0, $s, 0, sprintf("%s(%s);", $c, $args), 6, " ", 1); $msk ^= -1;

return($m, $s, $l, $k, $msk, $key, $scale, $v, @_); }
#===============================================================================
sub GetVarPars { my $c = (caller(1))[3]; if (ref($_[0]) ne 'HASH') { $c = shift(@_); } my $m = shift(@_); my $s = shift(@_); my $args = "";
my $l     = undef; if ($#_ >= 0) { $l     = shift(@_); }
my $msk   =     0; if ($#_ >= 0) { $msk   = shift(@_); $args .= sprintf("0b%b"     , $msk  ); }
my $key   =    60; if ($#_ >= 0) { $key   = shift(@_); $args .= sprintf(", %d"     , $key  ); }
my $scale =     3; if ($#_ >= 0) { $scale = shift(@_); $args .= sprintf(", %d"     , $scale); }
my $inv   =     0; if ($#_ >= 0) { $inv   = shift(@_); $args .= sprintf(", %d"     , $inv  ); }
my $von   =     1; if ($#_ >= 0) { $von   = shift(@_); $args .= sprintf(", %1.1f"  , $von  ); }
my $vof   =   0.5; if ($#_ >= 0) { $vof   = shift(@_); $args .= sprintf(", %1.1f"  , $vof  ); }

for (my $i=0; $i<=$#_; $i++) { my $t = $_[$i]; $args .= sprintf(", $t"); }

MIDI::InsertText($m, 0, $s, 0, sprintf("%s(%s);", $c, $args), 6, " ", 1); $msk ^= -1;

return($m, $s, $l, $msk, $key, $scale, $inv, $von, $vof, @_); }
#===============================================================================
sub GetNoteName { my $note = shift(@_); my $scale = -1; if ($#_ >= 0) { $scale = shift(@_); } my $inv = 0; if ($#_ >= 0) { $inv = shift(@_); }

my %ScaleLut = (-1 => '?', 0 => 'plain', 1 => 'quint', 2 => 'maj', 3=> 'min', 4=> 'MmR');
my %NoteLut  = (-1 => '?', 0 => 'C', 1 => 'C#', 2 => 'D', 3 => 'D#', 4 => 'E', 5 => 'F', 6 => 'F#', 7 => 'G', 8 => 'G#', 9 => 'A', 10 => 'A#', 11 => 'B');

my $crd = $NoteLut{$note%12}; if ($scale == 2) {} elsif ($scale == 3) { $crd = lc($crd); } else { $crd .= "_".$ScaleLut{$scale}; }

return(sprintf("%d_%s_%d", int($note/12), $crd, $inv)); }
#===============================================================================
sub GetNote { my ($n) = @_;

my @LUT = (9, 11, 0, 2, 4, 5, 7, 11);

if ($n =~ /[a-h]/i) { $n =~ s/\s*//g; my ($u, $d, $o, $k, $f, $s) = ($n, $n, $n, $n, $n, $n);

 $u =~ s/[^^]//g; $d =~ s/[^v]//g; $o =~ s/[^\d]//g; $k =~ s/[^a-h]//gi; $f =~ s/[^b]//g; $s =~ s/[^#]//g;

 my $c = length($d)-length($u); my $fs = length($s)-length($f); $o = substr($o, 0, 1); $k = substr($k, 0, 1);

 if (length($o)<=0) { $o = 5; } if ($k =~ /b/) { $fs++; } $n = $o*12+$LUT[ord(uc($k))-65]+$fs+$c;
 }

return($n); }
#===============================================================================
sub GetChord { my ($o, $c) = @_; if ($#_ <= 0) { ($c, $o) = ($o, 5); } $c =~ s/\s*//g;

my %FlagLUT = ('sus2'=>0x2, 'sus4'=>0x4); my ($scale, $ScaleInc, $i) = (0, 1, 0);

foreach my $n (keys(%FlagLUT)) { if ($c =~ $n) { $c =~ s/$n//; $scale |= $FlagLUT{$n}; $ScaleInc = 0; }}
if     ($c =~ /^(\d+)(.*)([0-6])$/) { ($o, $c, $i) = ($1, $2, $3); }
 elsif ($c =~ /^(\d+)(.*)$/       ) { ($o, $c    ) = ($1, $2    ); }
 elsif ($c =~      /^(.*)([0-6])$/) { (    $c, $i) = (    $1, $2); }

my $k = -1; if ($c =~ /^([a-g])(.*)/i) { $c = $2; $k = ord($1); }

my $fs = 0; if ($c =~ /^([\#b])(.*)/) { $c = $2; if ($1 =~ /\#/) { $fs++; } else { $fs--; } }

if ($c =~ /^n$/) { $scale -= 0x3; $ScaleInc = 0; }
if ($c =~ /^p$/) { $scale -= 0x2; $ScaleInc = 0; }
if ($c =~ /^f$/) { $scale -= 0x1; $ScaleInc = 0; }
if ($c =~ /^7$/) { $scale |= 0x8; }

$scale += 2; if ($k >= 0) { $k -= 65; if ($k >= 32) { $k -= 32; $scale += $ScaleInc; }} else { ($o, $k, $fs, $scale) = (0, 2, -1, -1); }

my @LUT = (9, 11, 0, 2, 4, 5, 7); my @rv = ($o*12+$LUT[$k]+$fs, $scale); if ($#_ <= 0) { push(@rv, $i); } return(@rv); }
#===============================================================================
sub GetStaff {
my $clef = 0; if ($#_ >= 0) { $clef = shift(@_); }
my $sign = 0; if ($#_ >= 0) { $sign = shift(@_); }
my $ref  = 0; if ($#_ >= 0) { $ref  = shift(@_); }

my %Keys   = (-7=>11, -6=>6, -5=>1, -4=>8, -3=>3, -2=>10, -1=>5, 0=>0, 1=>7, 2=>2, 3=>9, 4=>4, 5=>11, 6=>6, 7=>1);
my %Scales = (-7=> 2, -6=>3, -5=>2, -4=>2, -3=>2, -2=> 2, -1=>2, 0=>2, 1=>2, 2=>2, 3=>2, 4=>2, 5=> 2, 6=>2, 7=>2);

my %ClefShift = (0=>0, 1=>-6, 2=>-8, 3=>-12, 4=>0-7, 5=>-12-7); #treble, alto, tenor, bass, octav-treble, 8va bass

my %StaffShift = (2=>{0=>0, 1=>1, 2=>1, 3=>2, 4=>2, 5=>3, 6=>3, 7=>4, 8=>5, 9=>5, 10=>6, 11=>6},
                  3=>{0=>0, 1=>1, 2=>1, 3=>2, 4=>2, 5=>3, 6=>4, 7=>4, 8=>5, 9=>5, 10=>6, 11=>6});

my %Base = (2=>60, 3=>57); my %Ofs = (2=>2, 3=>4);

$sign &= 0xff; if ($sign > 127) { $sign = sprintf("%d", $sign | -1<<8); } my $key = $Keys{$sign}; my $scale = $Scales{$sign}; $ref += int($sign/7);

return((($ClefShift{$clef}-$StaffShift{$scale}{$key}+$Ofs{$scale}+$ref)<<16)+$Base{$scale}+$key, $scale); }
#===============================================================================
sub Scale2KeySig { my ($Key, $Scale) = @_; my $KeySig = undef;

#15 SMF KeySigs (-7..7), 12 scales (0..11) -> 3 "redundant" variation posibilities (C#-Db, B-Cb, F#-Gb)
#               ( C     C#     D     Eb     E     F      F#     G     Ab     A      Bb      B   )
my %KeySigLUT = (0=>0, 1=>-5, 2=>2, 3=>-3, 4=>4, 5=>-1, 6=> 6, 7=>1, 8=>-4, 9=>3, 10=>-2, 11=> 5);

my %ChrShftLUT = (0=>0, 1=>10, 2=>8, 3=>7, 4=>5, 5=>3, 6=>1); #scale based key correction
my %MajMinLUT  = (0=>0, 1=> 0, 2=>0, 3=>0, 4=>0, 5=>1, 6=>0); #maj/min scale indicator

if (defined($Scale)) {

 if     ($Scale ==  2) { $Scale  =  0; } #ionisch  (major)
  elsif ($Scale ==  3) { $Scale  =  5; } #aeolisch (minor)
  else                 { $Scale -= 11; } #generic (all heptatonic scales [0..6])

 my $sign = 1; if ($KeySigLUT{($Key+$ChrShftLUT{$Scale})%12} < 0) { $sign = -1; }
 $KeySig = $MajMinLUT{$Scale}*0x0100 + (($sign*abs($KeySigLUT{($Key+$ChrShftLUT{$Scale})%12}))&0x00ff);
 }

return($KeySig); }
#===============================================================================
sub KeySig2Scale { my ($KeySig, $KeySigOct) = @_; my ($Key, $Scale) = (0, 0);

#number of flats/sharps (  Cb      Gb     Db     Ab     Eb     Bb      F     C     G     D     A     E     B      F#    C# )
my %KeySignatures =     (-7=>11, -6=>6, -5=>1, -4=>8, -3=>3, -2=>10, -1=>5, 0=>0, 1=>7, 2=>2, 3=>9, 4=>4, 5=>11, 6=>6, 7=>1);

if (defined($KeySig)) {
 ($Key, $Scale) = ($KeySig&0xff, (abs($KeySig)>>8)+2); if ($Key > 127) { $Key = sprintf("%d", $Key | -1<<8); }
 $Key = $KeySignatures{$Key}-($Scale-2)*3; if ($Key < 0) { $Key += 12; }
 }

return($KeySigOct*12+$Key, $Scale); }
#===============================================================================
sub Chromatic2Scalar { my ($Key, $Scale, $key, $scale) = @_; my $DTS = 0;

my %DiaToLUT = (2=>{0=>0, 2=>1, 4=>2, 5=>3, 7=>4, 9=>5, 11=>6}, 3=>{0=>0, 2=>1, 3=>2, 5=>3, 7=>4, 8=>5, 10=>6});
my %ScaleLUT = (2=>{0=>2, 2=>3, 4=>3, 5=>2, 7=>2, 9=>3, 11=>3}, 3=>{0=>3, 2=>3, 3=>2, 5=>3, 7=>3, 8=>2, 10=>2});

my ($KeyDiff, $KeyDiffOct) = (($key-$Key)%12, int(($key-$Key)/12)); if (($key-$Key < 0) && ($KeyDiff)) { $KeyDiffOct--; }

if (exists($DiaToLUT{$Scale}{$KeyDiff})) { ($key, $scale, $DTS) = ($Key, $Scale, $DiaToLUT{$Scale}{$KeyDiff}+$KeyDiffOct*7); }

if (($scale == 0) && (exists($ScaleLUT{$Scale}{$KeyDiff}))) { $scale = $ScaleLUT{$Scale}{$KeyDiff}; } #single finger chord
if (($scale == 1) && (exists($ScaleLUT{$Scale}{$KeyDiff}))) { $scale = $ScaleLUT{$Scale}{$KeyDiff}; } #dual   finger chord

return($key, $scale, $DTS); }
#===============================================================================
sub Analyze {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)

my %test0; my %test1;

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {

   my $Event = $h0->{$k0}{$k1}{$k2}{0} >> 4; my $Chn = $h0->{$k0}{$k1}{$k2}{0} & 0xf;

   if ($Event == 0x9) { my $note = $h0->{$k0}{$k1}{$k2}{1}; my $length = $h0->{$k0}{$k1}{$k2}{3}; $note %= 12; my $p = $length;

	if (not exists($test0{$Chn}{$note})) { $test0{$Chn}{$note} = $p; } else { $test0{$Chn}{$note} += $p; }
    }

   }
  }
 }

foreach my $k0 (sort {$a <=> $b} keys %test0) {
 foreach my $k1 (sort {$a <=> $b} keys %{$test0{$k0}}) {
  printf("0x%02x 0x%02x %3d %5d\n", $k0, $k1, $k1, $test0{$k0}{$k1});
  $test1{$k0}{$test0{$k0}{$k1}}{$k1} = 0;
  }
 }

foreach my $k0 (sort {$a <=> $b} keys %test1) {
 foreach my $k1 (sort {$a <=> $b} keys %{$test1{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$test1{$k0}{$k1}}) {
   printf("0x%02x %5d %3d\n", $k0, $k1, $k2);
   }
  }
 }

return(0); }
#===============================================================================
sub Pitch2Ctl {
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $ctl =        0x104; if ($#_ >= 0) { $ctl = shift(@_); }
my $inv =            0; if ($#_ >= 0) { $inv = shift(@_); }

my $LoNote = 128; my $HiNote = -1;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) { my $Note = $h0->{$k0}{$k1}{$k2}{1};
    if ($Note < $LoNote) { $LoNote = $Note; }
    if ($Note > $HiNote) { $HiNote = $Note; }
    }
   }
  }
 }

my $fLoNote = 440*2**(($LoNote-69)/12); my $fHiNote = 440*2**(($HiNote-69)/12); my $fDiff = $fHiNote-$fLoNote; #key 69 = mid a = 440Hz

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { my $s = $k1/($h0->{-1}{3}*4);
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) { my $Ch = $h0->{$k0}{$k1}{$k2}{0}&0xf; my $note = $h0->{$k0}{$k1}{$k2}{1}; my $fNote = 440*2**(($note-69)/12); my $val = ($fNote-$fLoNote)/$fDiff; if ($inv) { $val = 1-$val; }
   	MIDI::InsertCtlr($h0, $k0, $s, 0, $Ch, undef, undef, $ctl, 1, 0, $val);
    }
   }
  }
 }

return(0); }
#===============================================================================
sub GetTimes { my $rv = "";
my $h0  =    shift(@_);
my $trk =        undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)
my $s   =        undef; if ($#_ >= 0) { $s   = shift(@_); } if (defined($s)) { $s = int($s*$h0->{-1}{3}*4); }
my $flg =          0x0; if ($#_ >= 0) { $flg = shift(@_); }

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; } my $LastNoteStart = $s;
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) { my $key = $h0->{$k0}{$k1}{$k2}{1}; my $dur = $h0->{$k0}{$k1}{$k2}{3};

    if ((defined($LastNoteStart)) && ($k1 > $LastNoteStart)) {
     $rv .= sprintf(" %s:%%", MidiDebug::Flt2Len(($k1-$LastNoteStart)/($h0->{-1}{3}*4)));
     MIDI::InsertText($h0, 0, $LastNoteStart/($h0->{-1}{3}*4), 0, sprintf("%s:%%", MidiDebug::Flt2Len(($k1-$LastNoteStart)/($h0->{-1}{3}*4))), 6, " ", 1);
     }

    if (($flg & 0x1) == 0) {
     $rv .= sprintf(" \[%s:$key\]", MidiDebug::Flt2Len($dur/($h0->{-1}{3}*4)));
     MIDI::InsertText($h0, 0, $k1/($h0->{-1}{3}*4), 0, sprintf("\[%s:$key\]", MidiDebug::Flt2Len($dur/($h0->{-1}{3}*4))), 6, " ", 1);
	 }

    $LastNoteStart = $k1;
    }
   }
  }
 }

return("$rv"); }
#===============================================================================
sub CopyRegion { my ($m, $s, $LL, $Ll) = (shift(@_), shift(@_), shift(@_), shift(@_)); my ($LLt, $Llt, $st) = ($LL*$m->{-1}{3}*4, $Ll*$m->{-1}{3}*4, $s*$m->{-1}{3}*4); my ($RLt, $td) = ($LLt+$Llt, 0);

my $t   = undef; if ($#_ >= 0) { $t   = shift(@_); if (not(defined($t))) { $td = 1; }} if (not(defined($t))) { $t = 0; }
my $T   = undef; if ($#_ >= 0) { $T   = shift(@_); }
my $v0s = undef; if ($#_ >= 0) { $v0s = shift(@_); } if (not(defined($v0s))) { $v0s = 1; }
my $v0o = undef; if ($#_ >= 0) { $v0o = shift(@_); } if (not(defined($v0o))) { $v0o = 0; }
my $v1s = undef; if ($#_ >= 0) { $v1s = shift(@_); } if (not(defined($v1s))) { $v1s = 1; }
my $v1o = undef; if ($#_ >= 0) { $v1o = shift(@_); } if (not(defined($v1o))) { $v1o = 0; }
my $var = undef; if ($#_ >= 0) { $var = shift(@_); } if (not(defined($var))) { $var = 0; }

my $l = 0; my @a = (0,0,0,0,0,0,0,0,0,0,0,0); if (ref($t) !~ /ARRAY/i) { $l = abs($t) % 12; if ($t < 0) { $l = 12 - $l; } for (0..$#a) { $a[$_] = $t; }} else { @a = @{$t}; }

my ($ChPos, @Trks) = (undef, undef);

if (defined($T)) { @Trks = @{$T}; my @h = @{$Trks[0]}; my %hh; for (my $i=0; $i<=$#h; $i++) { if (defined($h[$i])) { $hh{$h[$i]} = $i; }} if (exists($hh{-4})) { $ChPos = $hh{-4}; }}

foreach my $k0 (sort {$a <=> $b} keys %{$m}) { if ($k0 == -1) { next(); } my $Ch = -1; if (defined($ChPos) && (($k0+1) <= $#Trks) && exists($Trks[$k0+1][$ChPos]) && defined($Trks[$k0+1][$ChPos])) { $Ch = $Trks[$k0+1][$ChPos]; }
 foreach my $k1 (sort {$a <=> $b} keys %{$m->{$k0}}) { if ($k1 < $LLt) { next(); } if ($k1 > $RLt) { last(); } my $k1c = $st+($k1-$LLt);
  foreach my $k2 (sort {$a <=> $b} keys %{$m->{$k0}{$k1}}) { if ($td && (($m->{$k0}{$k1}{$k2}{0} >> 4) == 0x9) && (($m->{$k0}{$k1}{$k2}{0} & 0xf) != 0x9)) { next(); }
   my $k2c = 0; if (scalar(keys(%{$m->{$k0}{$k1c}}))) { $k2c = (sort {$b <=> $a} keys(%{$m->{$k0}{$k1c}}))[0]+1; }
   %{$m->{$k0}{$k1c}{$k2c}} = %{$m->{$k0}{$k1}{$k2}};

   if (($m->{$k0}{$k1}{$k2}{0} == 0xff) && ($m->{$k0}{$k1}{$k2}{1} == 0x06)) { my ($txt, $i) = ('', 2); while (exists($m->{$k0}{$k1}{$k2}{$i})) { $txt .= chr($m->{$k0}{$k1}{$k2}{$i++}); }

    $txt =~ s/(Label|Jump)(0x[0-9a-fA-F]+|[-0-9]+)/Tools::MySubst($1, eval($2), $l, $var)/ge;

    my @tmp0 = split('', $txt); for (my $i=0; $i<=$#tmp0; $i++) { $m->{$k0}{$k1c}{$k2c}{$i+2} = ord($tmp0[$i]); }
    }

   if (($m->{$k0}{$k1}{$k2}{0} >> 4) == 0x9) { if ($Ch <= -1) { $Ch = $m->{$k0}{$k1}{$k2}{0} & 0xf; } if ($Ch != 0x9) { if (($m->{$k0}{$k1c}{$k2c}{1} += $a[$m->{$k0}{$k1c}{$k2c}{1}%12]) >> 7) { $m->{$k0}{$k1c}{$k2c}{1} = $m->{$k0}{$k1}{$k2}{1}; $m->{$k0}{$k1c}{$k2c}{3} = 0; }}
	my ($v0, $v1) = ($m->{$k0}{$k1c}{$k2c}{2}, $m->{$k0}{$k1c}{$k2c}{4});
                       $v0 = int($v0*$v0s+0x80*$v0o); if ($v0 <= 0x00) { $v0 = 0x01; } if ($v0 > 0x7f) { $v0 = 0x7f; }
    if ($v1 <= 0x7f) { $v1 = int($v1*$v1s+0x80*$v1o); if ($v1 <= 0x00) { $v1 = 0x00; } if ($v1 > 0x7f) { $v1 = 0x7f; }}
	($m->{$k0}{$k1c}{$k2c}{2}, $m->{$k0}{$k1c}{$k2c}{4}) = ($v0, $v1);
	}
   }
  }
 }

return($Ll); }
#===============================================================================
sub MySubst { my ($k, $v, $l, $var) = @_; my $r = ($v&-16)+(($v&0xf)+$l)%12;

if (($v & 0xfff) <= 0xff) { $r = $v+$l; }

if (($k =~ /Label/) && (($v & 0xfff) >= 0xfff)) { $r = $v; }

if ($v < 0) { $r = sprintf("%s%d", $k, $v); } else { $r = sprintf("%s0x%x", $k, $var+$r); } return($r); }
#===============================================================================

use strict; use warnings; package Misc;

our $L = "<:%_L"; #lyric
our $M = "<:%_M"; #marker

#usage example
#MidiDebug::WrStr(" $Misc::L\Qtext\E \n");
#MidiDebug::WrStr(" $Misc::M\Qtext\E \n");

return(1);
#===============================================================================
sub PatchDump {
my $h = shift(@_);

printf("\nPatchDump(); #start\n");

foreach my $k0 (sort {$a <=> $b} keys %{$h}) { if (ref($h->{$k0}) !~ 'HASH') { printf("%2d NoHashL0 %s", $k0, $h->{$k0}); next; }

 foreach my $k1 (sort {$b <=> $a} keys %{$h->{$k0}}) { if (ref($h->{$k0}{$k1}) !~ 'HASH') { printf("%2d %3d %s", $k0, $k1, $h->{$k0}{$k1}); next; }

  foreach my $k2 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}}) { if (ref($h->{$k0}{$k1}{$k2}) !~ 'HASH') { printf("%2d 0x%x %3d %s\n", $k0, $k1, $k2, $h->{$k0}{$k1}{$k2}); next; }

   foreach my $k3 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}{$k2}}) { if (ref($h->{$k0}{$k1}{$k2}{$k3}) !~ 'HASH') { printf("%2d %3d %2d %2d NoHashL3 %s\n", $k0, $k1, $k2, $k3, $h->{$k0}{$k1}{$k2}{$k3}); next; }

    my $BnkHi = $k3>>7; my $BnkLo = $k3&0x7f; if ($k3 < 0) { $BnkHi = -1; $BnkLo = -1; } printf("\n");

    foreach my $k4 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}{$k2}{$k3}}) {
     if (ref($h->{$k0}{$k1}{$k2}{$k3}{$k4}) !~ 'HASH') {
      my $s0 = ''; my $s1 = ''; if ($k4 < 0) { $s0 = '['; $s1 = ']'; }
      printf("%2d 0x%x %2d %3d %3d %3d $s0%s$s1\n", $k0, $k1, $k2, $BnkHi, $BnkLo, $k4, $h->{$k0}{$k1}{$k2}{$k3}{$k4});
      next; }

     if (exists($h->{$k0}{0xc}{$k2}{$k3}{$k4})) { printf("%2d 0x%x %2d %3d %3d %3d     \[%s\]\n", $k0, 0xc, $k2, $BnkHi, $BnkLo, $k4, $h->{$k0}{0xc}{$k2}{$k3}{$k4}); }
     foreach my $k5 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}{$k2}{$k3}{$k4}}) {
      printf("%2d 0x%x %2d %3d %3d %3d %3d %s\n", $k0, $k1, $k2, $BnkHi, $BnkLo, $k4, $k5, $h->{$k0}{$k1}{$k2}{$k3}{$k4}{$k5});
      }

	 printf("\n");
	 }
    }
   }
  printf("\n");
  }
 printf("\n");
 }

printf("\nPatchDump(); #done\n"); return(0); }
#===============================================================================
sub DumpKeyTable {
my $h = shift(@_);
my $port = -1; if ($#_ >= 0) { $port = shift(@_); }

my %table0; my %ColWidth0;
foreach my $k2 (sort {$a <=> $b} keys(%{$h->{$port}{0x9}{0x9}})) { #bank
 foreach my $k3 (sort {$a <=> $b} keys(%{$h->{$port}{0x9}{0x9}{$k2}})) { #patch
  foreach my $k4 (sort {$a <=> $b} keys(%{$h->{$port}{0x9}{0x9}{$k2}{$k3}})) { #key
   my $BnkPrg = ($k2<<8)+$k3; my $name = $h->{$port}{0x9}{0x9}{$k2}{$k3}{$k4}; my $length = length($name);
   $table0{$k4}{$BnkPrg} = $name; if (not(exists($ColWidth0{$BnkPrg}))) { $ColWidth0{$BnkPrg} = 0; } if ($length > $ColWidth0{$BnkPrg}) { $ColWidth0{$BnkPrg} = $length; }
   }
  }
 }

foreach my $k1 (sort {$a <=> $b} keys(%table0)) {
 foreach my $k0 (sort {$a <=> $b} keys(%ColWidth0)) {
  my $Bnk = $k0 >> 8; my $Prg = $k0 & 0xff; my $ColWidth = $ColWidth0{$k0}; my $name = ""; if (exists($table0{$k1}{$k0})) { $name = $table0{$k1}{$k0}; }
  printf("|%s$name", " " x ($ColWidth-length($name)));
  }
 printf("|\n");
 }

return(0); }
#===============================================================================
sub ExportCubaseParseFile {
my $h = shift(@_);
my $port = -1; if ($#_ >= 0) { $port = shift(@_); }

printf("\nPatchDump(%d); #start\n", $port); my $mode = 1;

foreach my $k0 (sort {$a <=> $b} keys %{$h}) { if ((ref($h->{$k0}) !~ 'HASH') || ($k0 != $port)) { next; }

 foreach my $k1 (sort {$b <=> $a} keys %{$h->{$k0}}) { if ((ref($h->{$k0}{$k1}) !~ 'HASH') || ($k1 == 0xb)) { next; }

  foreach my $k2 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}}) { if (ref($h->{$k0}{$k1}{$k2}) !~ 'HASH') { next; }

   foreach my $k3 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}{$k2}}) { if (ref($h->{$k0}{$k1}{$k2}{$k3}) !~ 'HASH') { next; }

    my $BnkHi = $k3>>7; my $BnkLo = $k3&0x7f; if ($k3 < 0) { $BnkHi = -1; $BnkLo = -1; } printf("\n");

    if (($k1 == 0xc) && ($k2 == 9)) { next; }

    foreach my $k4 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}{$k2}{$k3}}) {
     if (ref($h->{$k0}{$k1}{$k2}{$k3}{$k4}) !~ 'HASH') {
      printf("\[p3, %3d, %3d, %3d\] %s\n", $k4, $BnkHi, $BnkLo, $h->{$k0}{$k1}{$k2}{$k3}{$k4});
      next; }

     if (($k3 < 0) && ($k4 < 0)) { next; } if ($mode) { printf("\[mode 10\] Drum Sets\n"); } $mode = 0;

	 printf("\n");
     if (exists($h->{$k0}{0xc}{$k2}{$k3}{$k4})) { printf("[p1, %3d, %3d, %3d] %s\n", $k4, -1, -1, $h->{$k0}{0xc}{$k2}{$k3}{$k4}); }
     foreach my $k5 (sort {$a <=> $b} keys %{$h->{$k0}{$k1}{$k2}{$k3}{$k4}}) {
      printf("\[k %3d\] %s\n", $k5+1, $h->{$k0}{$k1}{$k2}{$k3}{$k4}{$k5});
      }

     }
    }
   }
  }
 }

printf("\n\[end\]\n"); return(0); }
#===============================================================================
sub ImportCakewalkInsFile {
my $fname  = ""; if ($#_ >= 0) { $fname      = shift(@_); }
my %RetVal = (); if ($#_ >= 0) { $RetVal{-1} = shift(@_); } #PortName

my @NoteLut = ('C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B');

$RetVal{0xc}{ -1}{-1}{-1} = sprintf("-1"); #bankname (channel x, bank x)
#$RetVal{0xc}{0x9}{-1}{-1} = sprintf("-1"); #bankname (channel 9, bank x)
for (my $i=0; $i <= 0x7f; $i++) {
 $RetVal{0xb}{$i}              = sprintf("%d", $i);                             #ctrl  name
 $RetVal{0xc}{ -1}{-1}{$i}     = sprintf("%d", $i);                             #patch name (channel x, bank x)
 #$RetVal{0xc}{0x9}{-1}{$i}     = sprintf("%d", $i);                             #patch name (channel 9, bank x)
 $RetVal{0x9}{ -1}{-1}{-1}{$i} = sprintf("%d %s", int($i/12), $NoteLut[$i%12]); #key   name (channel x, bank x, patch x)
 $RetVal{0x9}{0x9}{-1}{-1}{$i} = sprintf("%d", $i);                             #key   name (channel 9, bank x, patch x)
 }

$RetVal{0xb}{0x00} = 'BankSelectMSB';
$RetVal{0xb}{0x01} = 'Modulation';
$RetVal{0xb}{0x07} = 'Volume';
$RetVal{0xb}{0x0a} = 'Pan';
$RetVal{0xb}{0x0b} = 'Expression';
$RetVal{0xb}{0x20} = 'BankSelectLSB';
$RetVal{0xb}{0x21} = 'ModulationLSB';
$RetVal{0xb}{0x27} = 'VolumeLSB';
$RetVal{0xb}{0x2a} = 'PanLSB';
$RetVal{0xb}{0x2b} = 'ExpressionLSB';
$RetVal{0xb}{0x5b} = 'Reverb';
$RetVal{0xb}{0x5d} = 'Chorus';
$RetVal{0xb}{0x79} = 'Reset All Controllers';

my @MyAttrs0 = stat($fname); if ($#MyAttrs0 < 0) { return(%RetVal); }
open(my_file1, $fname); my %tmp; my $class = ""; my $name = "";
while (<my_file1>) { my $line = $_; $line =~ s/\n|\r//g;

 if ($line =~ /^\s*\.(.*)\s*$/) { $class = $1; $tmp{$class}{""}{""} = ""; }

 if ($line =~ /^\s*\[(.*)\]\s*$/) { $name = $1; if (exists($tmp{$class}{""}{""})) { delete($tmp{$class}{""}{""}); } $tmp{$class}{$name}{""} = ""; }

 if ($line =~ /^\s*(.*)\s*=\s*(.*)\s*$/) { if (exists($tmp{$class}{$name}{""})) { delete($tmp{$class}{$name}{""}); } $tmp{$class}{$name}{$1} = $2; }
 }
close(my_file1);

foreach my $k1 (sort {$a cmp $b} keys %{$tmp{"Note Names"}}) { my $BasedOn = ""; if (exists($tmp{"Note Names"}{$k1}{"BasedOn"})) { $BasedOn = delete($tmp{"Note Names"}{$k1}{"BasedOn"}); }
 if (length($BasedOn)) { foreach my $k2 (sort {$a <=> $b} keys %{$tmp{"Note Names"}{$BasedOn}}) { $tmp{"Note Names"}{$k1}{$k2} = $tmp{"Note Names"}{$BasedOn}{$k2}; }}
 }

foreach my $k1 (sort {$a cmp $b} keys %{$tmp{"Instrument Definitions"}}) {

 foreach my $k2 (sort {$a cmp $b} keys %{$tmp{"Instrument Definitions"}{$k1}}) { my $val = $tmp{"Instrument Definitions"}{$k1}{$k2};

  if     (length($k2)==0) {
   $RetVal{0xc}{-1}{-1} = $tmp{"Patch Names"}{$k1}; $RetVal{0xc}{-1}{-1}{-1} = $k1;
   }
   elsif (($k2 =~ /Key\[\s*\*\s*,\s*\*\s*\]/ ) && exists($tmp{"Note Names"}{$val})) {
   foreach my $i (sort {$a <=> $b} keys(%{$tmp{"Note Names"}{$val}})) { $RetVal{0x9}{0x9}{-1}{-1}{$i} = $tmp{"Note Names"}{$val}{$i}; } $RetVal{0xc}{0x9}{-1}{-1} = $k1;
   }
   elsif ($k2 =~ /Patch\[\s*(\d+)\s*\]/) { my $Bank = $1; my $c = -1; if ($val =~ /drum/i) { $c = 0x9; }
   #if ($val =~ /roland/i) { $RetVal{0xc}{$c}{$Bank} = $tmp{"Patch Names"}{$val}; $RetVal{0xc}{$c}{$Bank}{-1} = $val; }
   }
   elsif ($k2 =~ /Key\[\s*(\d+)\s*,\s*(\d+)\s*\]/ ) { my $Bank = $1; my $Patch = $2;
   #if ($val =~ /roland/i) { $RetVal{0x9}{0x9}{$Bank}{$Patch} = $tmp{"Note Names"}{$val}; }
   }

  }
 }

return(%RetVal); }
#===============================================================================
sub GetCopyright { my $t = localtime(time); my @a = stat($main::InFile); my $b = localtime($a[9]); return(sprintf("%s (%s) %s (%s)", $t, getlogin(), $main::InFile, $b)); }
#===============================================================================
sub InsertCopyright { my $m = shift(@_); $m->{-1}{8} = Misc::GetCopyright(); return(0); }
#===============================================================================
sub WriteMixerSnapshot { my $m = shift(@_); my $t = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); }

my @Trks = @{$t}; my @h = @{$Trks[0]};

for (my $t = 0x01; $t <= $#Trks; $t++) { my @trk = @{$Trks[$t]}; my $bnk = undef; my $pgm = undef;

 for (my $c=$#trk; $c>=0; $c--) {
  if (($c <= $#h) && (defined($h[$c])) && (defined($trk[$c]))) { my $key = $h[$c]; my $val = $trk[$c];

   if ($key >= 0) {
    my $ctl = $key; my $c = ($ctl >> 17) & 1; $ctl &= 0x1ffff; if ($ctl == 0x4000) { $val = ((int($val)<<7)+($val-int($val))*0x7f)/0x3fff; }
    MIDI::InsertCtlr($m, $t-1, $s, 0, undef, 0/1, undef, $ctl, 1, $c, $val);
    }

   if ($key == -5) { $bnk = $val; }
   if ($key == -6) { $pgm = $val; }
   }
  }

 MIDI::InsertPrgChg($m, $t-1, $s, 0, undef, $bnk, $pgm);
 }

return(0); }
#===============================================================================
sub InsertInstrumentNames { if ($#_ >= 2) { shift(@_); } my $t = shift(@_); my $Prgs = shift(@_);

my @Trks = @{$t}; my @h = @{$Trks[0]}; my %hh; for (my $i=0; $i<=$#h; $i++) { if (defined($h[$i])) { $hh{$h[$i]} = $i; }}

my $PortPos = undef; if (exists($hh{ -3})) { $PortPos = $hh{ -3}; }
my $ChPos   = undef; if (exists($hh{ -4})) { $ChPos   = $hh{ -4}; }
my $BankPos = undef; if (exists($hh{ -5})) { $BankPos = $hh{ -5}; }
my $PrgPos  = undef; if (exists($hh{ -6})) { $PrgPos  = $hh{ -6}; }
my $InsPos  = undef; if (exists($hh{-13})) { $InsPos  = $hh{-13}; }

if (not(defined($InsPos))) { unshift(@{$Trks[0]}, -13); for (my $t = 0x01; $t <= $#Trks; $t++) { unshift(@{$Trks[$t]}, undef); } $PortPos++; $ChPos++; $BankPos++; $PrgPos++; $InsPos = 0; }

for (my $t = 0x01; $t <= $#Trks; $t++) { my @trk = @{$Trks[$t]}; my $Port = -1; my $Ch = -1; my $Bank = -1; my $Prg = -1;

 if (defined($PortPos) && exists($Trks[$t][$PortPos]) && defined($Trks[$t][$PortPos])) { $Port = $Trks[$t][$PortPos]; }
 if (defined($ChPos  ) && exists($Trks[$t][$ChPos  ]) && defined($Trks[$t][$ChPos  ])) { $Ch   = $Trks[$t][$ChPos  ]; }
 if (defined($BankPos) && exists($Trks[$t][$BankPos]) && defined($Trks[$t][$BankPos])) { $Bank = $Trks[$t][$BankPos]; }
 if (defined($PrgPos ) && exists($Trks[$t][$PrgPos ]) && defined($Trks[$t][$PrgPos ])) { $Prg  = $Trks[$t][$PrgPos ]; }
 my $PrtName = $Prgs->{-1}{-1}; if (exists($Prgs->{$Port}{-1})) { $PrtName = $Prgs->{$Port}{-1}; } my $BName = $Prgs->{-1}{0xc}{-1}{-1}{-1}; my $PName = $Prgs->{-1}{0xc}{-1}{-1}{$Prg};

 if     (exists($Prgs->{$Port}{0xc}{$Ch}{$Bank}{  -1})) { $BName = $Prgs->{$Port}{0xc}{$Ch}{$Bank}{  -1}; }
  elsif (exists($Prgs->{$Port}{0xc}{$Ch}{   -1}{  -1})) { $BName = $Prgs->{$Port}{0xc}{$Ch}{   -1}{  -1}; }
  elsif (exists($Prgs->{$Port}{0xc}{ -1}{$Bank}{  -1})) { $BName = $Prgs->{$Port}{0xc}{ -1}{$Bank}{  -1}; }
  elsif (exists($Prgs->{$Port}{0xc}{ -1}{   -1}{  -1})) { $BName = $Prgs->{$Port}{0xc}{ -1}{   -1}{  -1}; }
  elsif (exists($Prgs->{   -1}{0xc}{$Ch}{$Bank}{  -1})) { $BName = $Prgs->{   -1}{0xc}{$Ch}{$Bank}{  -1}; }
  elsif (exists($Prgs->{   -1}{0xc}{$Ch}{   -1}{  -1})) { $BName = $Prgs->{   -1}{0xc}{$Ch}{   -1}{  -1}; }
  elsif (exists($Prgs->{   -1}{0xc}{ -1}{$Bank}{  -1})) { $BName = $Prgs->{   -1}{0xc}{ -1}{$Bank}{  -1}; }

 if     (exists($Prgs->{$Port}{0xc}{$Ch}{$Bank}{$Prg})) { $PName = $Prgs->{$Port}{0xc}{$Ch}{$Bank}{$Prg}; }
  elsif (exists($Prgs->{$Port}{0xc}{$Ch}{   -1}{$Prg})) { $PName = $Prgs->{$Port}{0xc}{$Ch}{   -1}{$Prg}; }
  elsif (exists($Prgs->{$Port}{0xc}{$Ch}{   -1}{  -1})) {                                                 }
  elsif (exists($Prgs->{$Port}{0xc}{ -1}{$Bank}{$Prg})) { $PName = $Prgs->{$Port}{0xc}{ -1}{$Bank}{$Prg}; }
  elsif (exists($Prgs->{$Port}{0xc}{ -1}{   -1}{$Prg})) { $PName = $Prgs->{$Port}{0xc}{ -1}{   -1}{$Prg}; }
  elsif (exists($Prgs->{   -1}{0xc}{$Ch}{$Bank}{$Prg})) { $PName = $Prgs->{   -1}{0xc}{$Ch}{$Bank}{$Prg}; }
  elsif (exists($Prgs->{   -1}{0xc}{$Ch}{   -1}{$Prg})) { $PName = $Prgs->{   -1}{0xc}{$Ch}{   -1}{$Prg}; }
  elsif (exists($Prgs->{   -1}{0xc}{$Ch}{   -1}{  -1})) {                                                 }
  elsif (exists($Prgs->{   -1}{0xc}{ -1}{$Bank}{$Prg})) { $PName = $Prgs->{   -1}{0xc}{ -1}{$Bank}{$Prg}; }

 my $PrgName = "$PrtName:$BName:$PName"; if ($Prg < 0) { $PrgName =~ s/^(.*):(.*):(.*)$/$1:$2/gi; if ($Bank < 0) { $PrgName =~ s/^(.*):(.*)$/$1/gi; }}
 $PrgName =~ s/[:]*$//gi; $PrgName = "'$PrgName'"; $PrgName =~ s/^''$//gi;
 if (not(defined($Trks[$t][$InsPos]))) { $Trks[$t][$InsPos] = sprintf("%02d %s:%05d:%03d -> $PrgName", $t-2, $Port, $Bank, $Prg); }
 }

return(0); }
#===============================================================================
sub SetGroupedTrkValues { my $t = shift(@_);
my $port = undef; if ($#_ >= 0) { $port = shift(@_); }
my $vals = undef; if ($#_ >= 0) { $vals = shift(@_); } my %vals = %{$vals};

my @Trks = @{$t}; my @h = @{$Trks[0]};

for (my $t=1; $t<=$#Trks; $t++) { my @trk = @{$Trks[$t]}; my $Port = -1;

 for (my $c=0; $c<=$#trk; $c++) { if (($c <= $#h) && (defined($h[$c])) && ($h[$c] == -3)) { $Port = $Trks[$t][$c]; }}

 if (not(defined($port)) || ($Port == $port)) { for (my $c=0; $c<=$#trk; $c++) {

  foreach my $k (sort {$a <=> $b} keys(%vals)) { if (($c <= $#h) && (defined($h[$c])) && ($h[$c] == $k) && (defined($Trks[$t][$c]))) { $Trks[$t][$c] = eval($Trks[$t][$c].$vals{$k}); }}

  }}
 }

return(0); }
#===============================================================================
sub State2Param { my $t = shift(@_); my $rv = 0;

my @Trks = @{$t}; my @h = @{$Trks[0]}; my %hh; for (my $i=0; $i<=$#h; $i++) { if (defined($h[$i])) { $hh{$h[$i]} = $i; }}

my $SPos  = undef; if (exists($hh{ -1})) { $SPos  = $hh{ -1}; } else { return($rv); }
my $DPos  = undef; if (exists($hh{-12})) { $DPos  = $hh{-12}; } else { return($rv); }
#my $VSPos = undef; if (exists($hh{ -9})) { $VSPos = $hh{ -9}; } else { return($rv); }
#my $VOPos = undef; if (exists($hh{ -8})) { $VOPos = $hh{ -8}; } else { return($rv); }
#my $VPos  = undef; if (exists($hh{  7})) { $VPos  = $hh{  7}; }

my $solo = 0;
for (my $t=1; $t<=$#Trks; $t++) {
 if (exists($Trks[$t][$SPos]) && defined($Trks[$t][$SPos]) && ($Trks[$t][$SPos] > 1)) { $solo++; }
 }

for (my $t=1; $t<=$#Trks; $t++) {
 if (exists($Trks[$t][$SPos]) && defined($Trks[$t][$SPos]) && exists($Trks[$t][$DPos])) {

  if (($Trks[$t][$SPos] < 1) || ($Trks[$t][$SPos] == 1) && ($solo)) { $Trks[$t][$DPos] = 0.0;
   #$Trks[$t][$VSPos] = 0.0; $Trks[$t][$VOPos] = 0.0;
   #$Trks[$t][$VPos ] = 0.0;
   }

  $Trks[$t][$SPos] = 1;
  }
 }

return($rv); }
#===============================================================================
sub State2ParamM { my $m = shift(@_); my $rv = undef;

my @h = @{$m->{-2}}; my %hh; for (my $i=0; $i<=$#h; $i++) { if (defined($h[$i])) { $hh{$h[$i]} = $i; }}

my $SPos  = undef; if (exists($hh{ -1})) { $SPos  = $hh{ -1}; } else { return($rv); }
my $DPos  = undef; if (exists($hh{-12})) { $DPos  = $hh{-12}; } else { return($rv); }
#my $VSPos = undef; if (exists($hh{ -9})) { $VSPos = $hh{ -9}; } else { return($rv); }
#my $VOPos = undef; if (exists($hh{ -8})) { $VOPos = $hh{ -8}; } else { return($rv); }
#my $VPos  = undef; if (exists($hh{0x8000 | (0x1a << 7)})) { $VPos = $hh{0x8000 | (0x1a << 7)}; }

my $solo = 0;
foreach my $key (sort {$a <=> $b} keys %{$m}) { if ($key < -1) { next(); } my @row = @{$m->{$key}};
 if (exists($row[$SPos]) && defined($row[$SPos]) && ($row[$SPos] != 1) && ($key < 0)) { $rv = $row[$SPos]; next(); }
 if (exists($row[$SPos]) && defined($row[$SPos]) && ($row[$SPos] > 2)) { $rv = 2; }
 if (exists($row[$SPos]) && defined($row[$SPos]) && ($row[$SPos] > 1)) { $solo++; }
 }

foreach my $key (sort {$a <=> $b} keys %{$m}) { if ($key <  0) { next(); } my @row = @{$m->{$key}};
 if (exists($row[$SPos]) && defined($row[$SPos]) && exists($row[$DPos])) {

  if (($row[$SPos] < 1) || ($row[$SPos] == 1) && ($solo)) { @{$m->{$key}}[$DPos] = 0.0;
   #@{$m->{$key}}[$VSPos] = 0.0; @{$m->{$key}}[$VOPos] = 0.0;
   #@{$m->{$key}}[$VPos ] = 0.0;
   }

  @{$m->{$key}}[$SPos] = 1;
  }
 }

return($rv); }
#===============================================================================
sub AssignDrumMap { my ($t, $trk, $h0) = @_; if ($#_ < 2) { return(Misc::InsertDrumMap($t)); } my @Trks = @{$t}; my @RetVal; my $TrkState = Misc::State2ParamM($h0);

#read map
my @mh = @{$h0->{-2}}; my %map; my $cf = -1;
foreach my $key (sort {$a <=> $b} keys %{$h0}) { if ($key < -1) { next(); } my @row = @{$h0->{$key}};
 for (my $i = 0; $i <= $#row; $i++) { my $ctl = $mh[$i]; my $val = $row[$i];
  if ((defined($ctl)) && (defined($val))) { if ($ctl >= 0) { $cf = 1; } $map{$ctl}{$key} = $val; }
  }
 }

#get max column
if ($cf) { $cf = -1; for (my $t=0; $t<=$#Trks; $t++) { my @trk = @{$Trks[$t]}; if ($#trk > $cf) { $cf = $#trk; }}}

#align header/track columns
my @h   = @{$Trks[   0]}; for (my $c = $#h+1;   $c <= $cf; $c++) { $Trks[   0][$c] = undef; } @h   = @{$Trks[   0]}; #align header
my @trk = @{$Trks[$trk]}; for (my $c = $#trk+1; $c <= $cf; $c++) { $Trks[$trk][$c] = undef; } @trk = @{$Trks[$trk]}; #align track

my %hh; for (my $i=0; $i<=$#h; $i++) { if (defined($h[$i])) { $hh{$h[$i]} = $i; }}

#override params
for (my $i = 0; $i <= $#mh; $i++) { my $ctl = $mh[$i]; if (not(defined($ctl))) { next(); }
 if ($ctl < -1) { push(@RetVal, \%{$map{$ctl}});
  if (defined($Trks[$trk][$hh{$ctl}])) {
   foreach my $key (sort {$a <=> $b} keys(%{$map{$ctl}})) {
    if (($ctl == -9) || ($ctl == -11) || ($ctl == -12) && ($map{$ctl}{$key} >= 0)) { $map{$ctl}{$key} *= $Trks[$trk][$hh{$ctl}]; }
    if (($ctl == -8) || ($ctl == -10) || ($ctl ==  -7)                           ) { $map{$ctl}{$key} += $Trks[$trk][$hh{$ctl}]; }
   }}
  if (not(exists($map{$ctl}{-1}))) { $map{$ctl}{-1} = $Trks[$trk][$hh{$ctl}]; } $Trks[$trk][$hh{$ctl}] = \%{$map{$ctl}}; }
 }

#append ctls
foreach my $ctl (sort {$a <=> $b} keys(%map)) {
 foreach my $key (sort {$a <=> $b} keys(%{$map{$ctl}})) { my $val = $map{$ctl}{$key};
  if (($ctl >= 0) && ($key >=  0) && (defined($val))) { my $k = $key; my $lko = 0;
   if (exists($map{-7})) { if (exists($map{-7}{-1})) { $lko = $map{-7}{-1}; } if (exists($map{-7}{$k})) { $lko = 0; $k = $map{-7}{$k}; }}
   push(@{$Trks[0]}, $ctl+$k+$lko); push(@{$Trks[$trk]}, $val);
   }
  }
 }

if ((defined($TrkState)) && (exists($hh{-1}))) { $Trks[$trk][$hh{-1}] = $TrkState; }

return(@RetVal); }
#===============================================================================
sub InsertDrumMap { my ($h0) = @_; my @RetVal;

#read map
my @mh = @{$h0->{-2}}; my %map;
foreach my $key (sort {$a <=> $b} keys %{$h0}) { my @row  = @{$h0->{$key}};
 for (my $i = 0; $i <= $#row; $i++) { my $ctl = $mh[$i]; my $val = $row[$i];
  if (($key >= -1) && (defined($ctl)) && (defined($val))) { $map{$ctl}{$key} = $val; }
  }
 }

#override params
for (my $i = 0; $i <= $#mh; $i++) { my $ctl = $mh[$i]; if ((defined($ctl)) && ($ctl < 0)) { push(@RetVal, \%{$map{$ctl}}); }}

return(@RetVal); }
#===============================================================================
sub TransposeArray { my @a = @{shift(@_)}; my @ra;

my $maxc = -1; for (my $i=0; $i<=$#a; $i++) { my @r = @{$a[$i]}; if ($#r > $maxc) { $maxc = $#r; }}

for (my $i=0; $i<=$maxc; $i++) {
 for (my $j=0; $j<=$#a; $j++) { my @r = @{$a[$j]};
  my $v = undef; if ($i <= $#r) { $v = $r[$i]; } $ra[$i][$j] = $v;
  }
 }

return(@ra); }
#===============================================================================

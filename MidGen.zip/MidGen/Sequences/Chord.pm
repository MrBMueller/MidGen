use strict; use warnings; package Chord; eval("use Interval;");

#chord type definitions (1 timeunit)

#none
our $n    = "_%"; #pause

#singles
our $p    = "_>"; #plain root

#simple triads w/o inversion (root bottom)
our $o    = "_> (b:^$Interval::Octave)"; #stacked octav
our $f    = "_> (b:^$Interval::Fifth )"; #stacked quint

#regular triads w/o inversion (root bottom)
our $c    = "_> (b:^$Interval::Third    b:^$Interval::Third   )"; #base - 2 stacked thirds
our $dim  = "_> (b:^$Interval::Third    b:^$Interval::ThirdDim)"; #vermindert   (diminished fifth)
our $aug  = "_> (b:^$Interval::Third    b:^$Interval::ThirdAug)"; #uebermaessig (augmented  fifth)
our $sus2 = "_> (b:^$Interval::Second   b:^$Interval::Fourth  )"; #suspended sus2 - decrased  bottom interval (second) == (double fifth inverted)
our $sus4 = "_> (b:^$Interval::Fourth   b:^$Interval::Second  )"; #suspended sus4 - increased bottom interval (fourth) == (double fifth inverted)
our $c5   = "_> (b:^$Interval::ThirdAug b:^$Interval::Third   )"; #uebermaessige untere terz

our $SixthChord = "_> (b:^$Interval::Third b:^$Interval::Fourth)"; #sextakkord

#first inversion (root mid)
our $f4   = "_> (b:_v$Interval::Fourth)"; #quint inversion
our $c4   = "_> (b:^$Interval::Third  b:_v$Interval::Sixth)"; #base
our $c6   = "_> (b:^$Interval::Second b:_v$Interval::Fifth)"; #sus2

#second inversion (root top)
our $c7   = "_> (b:v$Interval::Fourth b:_v$Interval::Third)"; #base

#regular 7th
our $c8    = "_> (b:^$Interval::Third b:^$Interval::Third b:###)";                   #base (root bottom)
our $c8i1  = "_> (b:^$Interval::Third b:^$Interval::Third b:v$Interval::Octave###)"; #1st inversion
our $c8i2  = "_> (b:^$Interval::Third b:v$Interval::Sixth b:###)";                   #2nd inversion
our $c8i3  = "_> (b:v$Interval::Sixth b:^$Interval::Third b:###)";                   #3rd inversion

#regular 7th w/o fifth
our $c81   = "_> (b:^$Interval::Third b:^$Interval::Third###)"; #base (root bottom)
our $c81i1 = "_> (b:^$Interval::Third b:v$Interval::Sixth###)"; #1st inversion
our $c81i2 = "_> (b:^$Interval::Third b:v$Interval::Sixth###)"; #2nd inversion
our $c81i3 = "_> (b:v$Interval::Sixth b:^$Interval::Third###)"; #3rd inversion

#$dim   = "_> (b:^$Interval::Third  b:_v$Interval::SixthDim)"; #diminished 5th
#$aug   = "_> (b:^$Interval::Third  b:_v$Interval::SixthAug)"; #augmented  5th

#our $c3 = "_^7 b:v5 r:_^2 v4_%"; #sextakkord - c0 inversion (grundton oben)
#our $add9 = "_> (b:_^1 b:_^1 b:_^2)"; #add9

our $GuitPlain = "_0 (b:^1 b:^1 b:^1 b:^1 b:^1)"; #

#chord type names
#our $c0l = "_Lc0$c0";
#our $c1l = "_Lc1$c1";
#our $c2l = "_Lc2$c2";
#our $c3l = "_Lc3$c3";

our $c0 = $c;
our $c1 = $aug;
our $c2 = $sus2;

our %chords = (-1=>{-2=>-1, 0=>$Chord::n},
                0=>{-2=> 0, 0=>$Chord::p},
                1=>{-2=> 1, 0=>$Chord::f,    1=>$Chord::f4},
                2=>{-2=> 2, 0=>$Chord::c,    1=>$Chord::c4,   2=>$Chord::c7},
                3=>{-2=> 3, 0=>$Chord::c,    1=>$Chord::c4,   2=>$Chord::c7},
                4=>{-2=> 4, 0=>$Chord::sus2, 1=>$Chord::c6,   2=>"_> (b:v$Interval::Seventh b:^$Interval::Fourth  )"},
                6=>{-2=> 6, 0=>$Chord::sus4, 1=>$Chord::sus4, 2=>$Chord::sus4},
               10=>{-2=> 2, 0=>$Chord::c8,   1=>$Chord::c8i1, 2=>$Chord::c8i2, 3=>$Chord::c8i3},
               11=>{-2=> 3, 0=>$Chord::c8,   1=>$Chord::c8i1, 2=>$Chord::c8i2, 3=>$Chord::c8i3}
               );

foreach my $k (keys(%Chord::chords)) { $Chord::chords{$k}{-1} = $Chord::chords{$k}{0}; }

#6/12-string guitar tablatures
#physical              top                 bot   -- (handle left / corpus right)
#freq                  bass               treble
#                       E   A   D   G   B   E
#                       0   1   2   3   4   5
our %Tabs = (-1=>{ 0=>[-1, -1, -1, -1, -1, -1]},
              0=>{ 0=>[ 0,  0,  0,  0,  0,  0]},

              2=>{ 0=>[-1,  3,  2,  0,  1,  0],
                   1=>[-1, -1, -1,  1,  2,  1],
                   2=>[-1, -1,  0,  2,  3,  2],
                   3=>[-1, -1, -1,  3,  4,  3],
                   4=>[ 0,  2,  2,  1,  0,  0],
                   5=>[ 1,  3,  3,  2,  1,  1],
                   6=>[ 2,  4,  4,  3,  2,  2],
                   7=>[ 3,  2,  0,  0,  0,  3],
                   8=>[ 4,  6,  6,  5,  4,  4],
                   9=>[-1,  0,  2,  2,  2,  0],
                  10=>[-1, -1, -1,  3,  3,  1],
                  11=>[-1, -1, -1,  4,  4,  2]},

              3=>{ 0=>[-1,  3,  5,  5,  4, -1],
                   1=>[-1,  4,  2,  1, -1, -1],
                   2=>[-1, -1,  0,  2,  3,  1],
                   3=>[-1, -1,  4,  3,  4, -1],
                   4=>[ 0,  2,  2,  0,  0,  0],
                   5=>[ 1,  3,  3,  1,  1,  1],
                   6=>[ 2,  4,  4,  2,  2,  2],
                   7=>[-1, -1,  5,  3,  3,  3],
                   8=>[ 4,  6,  6,  4,  4,  4],
                   9=>[-1,  0,  2,  2,  1,  0],
                  10=>[-1, -1, -1,  3,  2,  1],
                  11=>[-1, -1, -1,  4,  3,  2]});

return(1);
#===============================================================================
sub Guitar {
my $key0 = 0;  if ($#_ >= 0) { $key0 = shift(@_); }
my $note = 0;  if ($#_ >= 0) { $note = shift(@_); } if (defined($note)) { if ($note < 0) { $note = 12-(abs($note)%12); } $note = $note % 12; }
my $rev  = 0;  if ($#_ >= 0) { $rev  = shift(@_); } #play reverse
my $vel  = ''; if ($#_ >= 0) { $vel  = shift(@_); }
my $dly  = ''; if ($#_ >= 0) { $dly  = shift(@_); }
my $TrkLt  = undef; if (($#_ >= 0) && (ref($_[0]) =~ /HASH/i)) { $TrkLt = shift(@_); }
my ($rval, $mval) = ("", "");

if (not(exists($Chord::Tabs{$key0}))) { $key0 = -1; }

my @shift1 = (); if (ref($key0) =~ /ARRAY/i) { @shift1 = @{$key0}; } else { @shift1 = @{$Chord::Tabs{$key0}{$note%scalar(keys(%{$Chord::Tabs{$key0}}))}}; }

my @vels; if (ref($vel) =~ /ARRAY/i) { @vels = @{$vel}; } else { for (my $i=0; $i<=$#shift1; $i++) { push(@vels, $vel); }}
my @dlys; if (ref($dly) =~ /ARRAY/i) { @dlys = @{$dly}; } else { for (my $i=0; $i<=$#shift1; $i++) { push(@dlys, $dly); }}

for (my $i=0; $i<=$#vels; $i++) { $vels[$i] =~ s/\s*//g; if (length($vels[$i])) { $vels[$i] = "_".$vels[$i]; }}
for (my $i=0; $i<=$#dlys; $i++) { $dlys[$i] =~ s/\s*//g; }

my @Strings; my @Signs; my @Vels; my @Dlys; my @DlyAcc = ("");
for (my $i=0; $i<=$#shift1; $i++) { if ($shift1[$i] > -1) {
 if (!$rev) { push(@Strings,         $i ); } else { unshift(@Strings,         $i ); }
 if (!$rev) { push(@Signs  , $shift1[$i]); } else { unshift(@Signs  , $shift1[$i]); }
 #if (!$rev) { unshift(@Vels, pop(@vels)); unshift(@Dlys, pop(@dlys)); } else { push(@Vels, pop(@vels)); push(@Dlys, pop(@dlys)); }
 #if (!$rev) { push(@Vels, shift(@vels)); push(@Dlys, shift(@dlys)); } else { unshift(@Vels, shift(@vels)); unshift(@Dlys, shift(@dlys)); }
 unshift(@Vels, pop(@vels)); unshift(@Dlys, pop(@dlys));
 push(@DlyAcc, sprintf("%s+%s", $DlyAcc[$#DlyAcc], $Dlys[$#Dlys]));
 }}
pop(@DlyAcc);

foreach (@Strings) { my ($string, $sign, $vel, $dly, $DlyAcc) = ($_, shift(@Signs), pop(@Vels), pop(@Dlys), pop(@DlyAcc));

 my $Trk = ""; if (exists($TrkLt->{$_})) { $Trk = sprintf("_t%d", $TrkLt->{$_}); }
 $rval .= sprintf("(b:%s%d%s%s) ", '#' x $sign, $_, $Trk, $vel); if (($#Signs >= 0) && (length($dly))) { $rval .= sprintf("(%s:%%) ", $dly); }
 $mval .= sprintf( "0:%s%d%s "   , '#' x $sign, $_, $Trk);
 }

return("( ".$mval.")", "_% [ ".$rval."]"); }
#===============================================================================
sub MergeGroove0 {
my $TimeLine0 = ""; if ($#_ >= 0) { $TimeLine0 = shift(@_); } $TimeLine0 =~ s/^\s*//gi; $TimeLine0 =~ s/\s*$//gi; my @Times0 = split(/\s+/, $TimeLine0);
my $TimeLine1 = ""; if ($#_ >= 0) { $TimeLine1 = shift(@_); } $TimeLine1 =~ s/^\s*//gi; $TimeLine1 =~ s/\s*$//gi; my @Times1 = split(/\s+/, $TimeLine1);
my $EvntLine  = ""; if ($#_ >= 0) { $EvntLine  = shift(@_); } $EvntLine  =~ s/^\s*//gi; $EvntLine  =~ s/\s*$//gi; my @Evnts0 = split(/\s+/, $EvntLine );
my $RetVal    = ""; my $cnt = $#Times0; if ($#Times1 > $cnt) { $cnt = $#Times1; } if ($#Evnts0 > $cnt) { $cnt = $#Evnts0; }

my @Evnts1 = @_;

for (my $i=0; $i<=$cnt; $i++) {

 if ($i > $#Times0) { push(@Times0, "."); }
 if ($i > $#Times1) { push(@Times1, "."); }
 if ($i > $#Evnts0) { push(@Evnts0, "."); }
 if ($i > $#Evnts1) { push(@Evnts1, "" ); }

 if ($Times0[$i] =~ /^\.$/) { $Times0[$i] = "";            }
 if ($Times1[$i] =~ /^\.$/) { $Times1[$i] = $Times1[$i-1]; }
 if ($Evnts0[$i] =~ /^\.$/) { $Evnts0[$i] = ">";           }
 if ($Evnts1[$i] =~ /^$/  ) { $Evnts1[$i] = $Evnts1[$i-1]; }

 if (eval($Times1[$i]) == 0) { $RetVal .= sprintf(        "%s:%s%s "                , $Times0[$i],              $Evnts0[$i], $Evnts1[$i]                          ); }
  else                       { $RetVal .= sprintf("%s<:%% -%s:%s%s (%s:%%) +%s<:%% ", $Times0[$i], $Times1[$i], $Evnts0[$i], $Evnts1[$i], $Times1[$i], $Times1[$i]); }
 }

$RetVal =~ s/\s*$//gi; return($RetVal); }
#===============================================================================
sub MergeGroove1 {
my $TimeLine0 = ""; if ($#_ >= 0) { $TimeLine0 = shift(@_); } $TimeLine0 =~ s/^\s*//gi; $TimeLine0 =~ s/\s*$//gi; my @Times0 = split(/\s+/, $TimeLine0);
my $TimeLine1 = ""; if ($#_ >= 0) { $TimeLine1 = shift(@_); } $TimeLine1 =~ s/^\s*//gi; $TimeLine1 =~ s/\s*$//gi; my @Times1 = split(/\s+/, $TimeLine1);
my $EvntLine  = ""; if ($#_ >= 0) { $EvntLine  = shift(@_); } $EvntLine  =~ s/^\s*//gi; $EvntLine  =~ s/\s*$//gi; my @Evnts0 = split(/\s+/, $EvntLine );
my $RetVal    = "";

my @Evnts1 = @_;

for (my $i=0; $i<=$#Times0-2; $i++) {

 if ($i > $#Times0) { push(@Times0, "."); }
 if ($i > $#Times1) { push(@Times1, "."); }
 if ($i > $#Evnts0) { push(@Evnts0, "."); }
 if ($i > $#Evnts1) { push(@Evnts1, "" ); }

 if ($Times0[$i] =~ /^\.$/) { $Times0[$i] = $Times0[$i-1]; } if ($Times0[$i] =~ /^</) { $Times0[$i] .= "<"; }
 if ($Times1[$i] =~ /^\.$/) { $Times1[$i] = $Times1[$i-1]; }
 if ($Evnts0[$i] =~ /^\.$/) { $Evnts0[$i] = ">";           }
 if ($Evnts1[$i] =~ /^$/  ) { $Evnts1[$i] = $Evnts1[$i-1]; }

 $RetVal .= sprintf("[(%s:%%) %s:%s%s] ", $Times0[$i], $Times1[$i], $Evnts0[$i], $Evnts1[$i]);
 }

$RetVal .= sprintf("[%s:%% 0:>] %s:%%", $Times0[$#Times0-1], $Times0[$#Times0]); return("(".$RetVal.")"); }
#===============================================================================
sub MergeGroove2 {
my $TimeLine0 = ""; if ($#_ >= 0) { $TimeLine0 = shift(@_); } $TimeLine0 =~ s/^\s*//gi; $TimeLine0 =~ s/\s*$//gi; my @Times0 = split(/\s+/, $TimeLine0);
my $TimeLine1 = ""; if ($#_ >= 0) { $TimeLine1 = shift(@_); } $TimeLine1 =~ s/^\s*//gi; $TimeLine1 =~ s/\s*$//gi; my @Times1 = split(/\s+/, $TimeLine1);
my $EvntLine  = ""; if ($#_ >= 0) { $EvntLine  = shift(@_); } $EvntLine  =~ s/^\s*//gi; $EvntLine  =~ s/\s*$//gi; my @Evnts0 = split(/\s+/, $EvntLine );
my $RetVal    = "";

my @Evnts1 = @_;

for (my $i=0; $i<=$#Times0-1; $i++) {

 if ($i > $#Times0) { push(@Times0, "."); }
 if ($i > $#Times1) { push(@Times1, "."); }
 if ($i > $#Evnts0) { push(@Evnts0, "."); }
 if ($i > $#Evnts1) { push(@Evnts1, "" ); }

 if ($Times0[$i] =~ /^\.$/) { $Times0[$i] = $Times0[$i-1]; } if ($Times0[$i] =~ /^</) { $Times0[$i] .= "<"; }
 if ($Times1[$i] =~ /^\.$/) { $Times1[$i] = $Times1[$i-1]; }
 if ($Evnts0[$i] =~ /^\.$/) { $Evnts0[$i] = ">";           }
 if ($Evnts1[$i] =~ /^$/  ) { $Evnts1[$i] = $Evnts1[$i-1]; }

 $RetVal .= sprintf("[(%s:%%) %s:%s%s] ", $Times0[$i], $Times1[$i], $Evnts0[$i], $Evnts1[$i]);
 }

$RetVal .= sprintf(" %s:%%", $Times0[$#Times0]); return("(".$RetVal.")"); }
#===============================================================================

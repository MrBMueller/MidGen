use strict; use warnings; package Constants;

use constant { wn => 1/1, hn => 1/2, qn => 1/4, en => 1/8, sn => 1/16 }; #floating point note length

use constant { dwn => wn+hn, dqn => qn+en }; #floating point dotted note length

use constant { pppp => .1, ppp => .2, pp => .3, p => .4, mp => .45, mf => .55, f => .6, ff => .7, fff => .8, ffff => .9 }; #floating point dynamic signs (..., piano, mezzopiano, mezzoforte, forte, ...)

#printf("${\(Constants->dqn)} %f\n", Constants->mf); #usage example

#sub n; n dqn, mf; #define and call sub example

return(1);
#===============================================================================
sub n { printf("%f %f\n", shift(@_), shift(@_)); }
#===============================================================================

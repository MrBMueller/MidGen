use strict; use warnings; package Interval;

#signs
our $Dim = 'b'; #flat/diminished
our $Aug = '#'; #sharp/augmented

#diatonic intervals
our $Base     = '>';
our $Unison   =  0; #prim
our $Second   =  1; #sekund
our $Third    =  2; #terz
our $Fourth   =  3; #quart
our $Fifth    =  4; #quint
our $Sixth    =  5; #sext
our $Seventh  =  6; #septim
our $Octave   =  7; #octav

#chromatic intervals
our $ThirdDim = $Dim.$Third;
our $ThirdAug = $Aug.$Third;
our $SixthDim = $Dim.$Sixth;
our $SixthAug = $Aug.$Sixth;

return(1);
#===============================================================================

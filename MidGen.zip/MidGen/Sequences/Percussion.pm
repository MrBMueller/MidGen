use strict; use warnings; package Percussion;

our $p = "36 38";

return(1);
#===============================================================================
sub Metronome { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $v =     1; if ($#_ >= 0) { $v = shift(@_); }

$s += Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " ( 1/4:33 .5 . . ) ", $v, .5, 0,0,0,0,0,1,1,1,1, -1/64, $l); #metronome click

return($s-$start); }
#===============================================================================
sub SwingExample { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $v =     1; if ($#_ >= 0) { $v = shift(@_); }

$s += Edit::Seq($m, $t, undef, undef, undef, $s , 42, 0, " 1/8:0 [(1/32++:%) >] % > . . . . . ", $v, .5, undef, undef, undef, 0,0, 1,1,1,1, {42=>-1/32}, $l); #CHH swing (delayed 2nd 8th)

return($s-$start); }
#===============================================================================
sub SimpleBassDrum { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $v =     1; if ($#_ >= 0) { $v = shift(@_); }

$s += Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x24_% {|x.......|x.......|x.......|x.......|} ", $v, .5, 0,0,0,0,0,1,1,1,1, 1, $l); #

return($s-$start); }
#===============================================================================
sub Perc1 { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }

      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:_42_% {|..x.8.6.|..x.8.6.|..x.8.6.|..x.8.6.|} ", .2, .5, 0,0,0,0,0,1,1,1,1, 1, $l); #CHH
      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:_44_% {|x.......|x.......|x.......|x.......|} ", .3, .5, 0,0,0,0,0,1,1,1,1, 1, $l); #OHH

      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x24_% {|x.......|........|x...x...|........|} ", .3, .5, 0,0,0,0,0,1,1,1,1, 1, $l); #
$s += Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x26_% {|........|x.....x.|........|x.......|} ", .5, .5, 0,0,0,0,0,1,1,1,1, 1, $l); #

return($s-$start); }
#===============================================================================
sub PercFill { my $m = shift(@_);
my $t = 0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =    0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 8{1/32:x32} 8{1/32:x30} 8{1/32:x2f} 8{1/32:x2d} 8{1/32:x2b} 8{1/32:x29} ", .3); #

#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 8{1/32:x32} 8{1/32:x2f} 8{1/32:x2b} 1/4:x31 ", .6); #

#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x32_% 1{|x.8...8.|........|........|........|} "); #
#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x30_% 1{|........|x.......|........|........|} "); #
#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x2f_% 1{|........|....8...|........|........|} "); #
#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x2d_% 1{|........|........|x.......|........|} "); #
#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x2b_% 1{|........|........|.....8..|........|} "); #
#Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x29_% 1{|........|........|........|x.......|} "); #

      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:_49_% 1{|........|........|........|x.......|} "); #

      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x32_% 1{|x.8...8.|........|........|........|} "); #
      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x2f_% 1{|........|x...8.6.|........|........|} "); #
$s += Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/32<:x29_% 1{|........|........|x...8.6.|........|} "); #

return($s-$start); }
#===============================================================================
sub HSDR8100 { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }

      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/16<:42_% 4*2{ |6363|.363| }   ", 1, .5, 0,0,0,0,0,1,1,1,1, -1/32, $l);
      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 4{1/4:% 1/2:38 1/4:.}           ", 1, .5, 0,0,0,0,0,1,1,1,1, -1/32, $l);
      Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 1/1:36 . . .                    ", 1, .5, 0,0,0,0,0,1,1,1,1, -1/32, $l);
$s += Edit::Seq($m, $t, undef, undef, undef, $s, 0, 0, " 4{1/4++:% 1/16:36 % > > |1/1:%} ", 1, .5, 0,0,0,0,0,1,1,1,1, -1/32, $l);

return($s-$start); }
#===============================================================================
sub Seq0 { my $m = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;

$s += Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " Mv ");

my $q = '1/16'; my $r = 32; my $l = -1/32;

#drum example with pre and post sequences using different grid resolutions
#$s += Edit::Seq($m, 10, undef, undef, undef, $s, 37-1, 0, " <1/4<:% 1/32<:% |x.....7.| 1/16<:% 2{|x...|x...|x...|x...|} 1/32<:% |.......x| <1/4<:% ", 1.0, .5, 0,0,0,0,0,1,1,1,1, -1/32); #Kick/Bass Drum

my $BD1Seq = "";
my $BD2Seq = "";
my $SD1Seq = "";

#Book: "Composition for Computer Musicians", Chapter: 'Rythm and Drum Programming'

#fig. 3.4 - basic
#$BD1Seq = "|x...|....|x...|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.6 - variation 1
#$BD1Seq = "|x...|....|....|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.8 - variation 2
#$BD1Seq = "|x...|....|x.x.|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.10 - variation 3
#$BD1Seq = "|x...|....|..x.|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.12 - variation 4
$BD1Seq = "|x...|..x.|..x.|....|";
$SD1Seq = "|....|x...|....|x...|";

#fig. 3.14 - variation 5
#$BD1Seq = "|x.x.|....|x.x.|....|";
#$SD1Seq = "|....|x...|....|x...|";

#fig. 3.16 - two bar pattern
#$BD1Seq = "||x.x.|....|x.x.|....||x.x.|....|x.x.|....||";
#$BD2Seq = "||....|....|....|....||....|...x|....|....||";
#$SD1Seq = "||....|x...|....|x...||....|x...|....|x...||";

      Edit::Seq($m, 10, undef, undef, undef, $s, 37-1, 0, " <$q:% $r\{ $BD1Seq } ", .5, .5, 0,0,0,0,0,1,1,1,1, $l); #Kick/Bass Drum 1
      Edit::Seq($m, 10, undef, undef, undef, $s, 36-1, 0, " <$q:% $r\{ $BD2Seq } ", .7, .5, 0,0,0,0,0,1,1,1,1, $l); #Kick/Bass Drum 2
$s += Edit::Seq($m, 10, undef, undef, undef, $s, 39-1, 0, " <$q:% $r\{ $SD1Seq } ", .3, .5, 0,0,0,0,0,1,1,1,1, $l); #Snare Drum 1

$s += Edit::Seq($m, 0, undef, undef, undef, $s, 0, 0, " M^ ");

return($s-$start); }
#===============================================================================

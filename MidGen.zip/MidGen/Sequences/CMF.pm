use strict; use warnings; package CMF; return(1);
#===============================================================================
sub Cmf2Mid {
my $fname0 = shift(@_); my $fname1 = "$main::WrkDir0/MyTemp0.mid";
my $flgs   = undef; if ($#_ >= 0) { $flgs = shift(@_); }

my @LUT = (
"\x00", "\x01", "\x02", "\x03", "\x04", "\x05", "\x06", "\x07", "\x08", "\x09", "\x0a", "\x0b", "\x0c", "\x0d", "\x0e", "\x0f",
"\x10", "\x11", "\x12", "\x13", "\x14", "\x15", "\x16", "\x17", "\x18", "\x19", "\x1a", "\x1b", "\x1c", "\x1d", "\x1e", "\x1f",
"\x20", "\x21", "\x22", "\x23", "\x24", "\x25", "\x26", "\x27", "\x28", "\x29", "\x2a", "\x2b", "\x2c", "\x2d", "\x2e", "\x2f",
"\x30", "\x31", "\x32", "\x33", "\x34", "\x35", "\x36", "\x37", "\x38", "\x39", "\x3a", "\x3b", "\x3c", "\x3d", "\x3e", "\x3f",
"\x40", "\x41", "\x42", "\x43", "\x44", "\x45", "\x46", "\x47", "\x48", "\x49", "\x4a", "\x4b", "\x4c", "\x4d", "\x4e", "\x4f",
"\x50", "\x51", "\x52", "\x53", "\x54", "\x55", "\x56", "\x57", "\x58", "\x59", "\x5a", "\x5b", "\x5c", "\x5d", "\x5e", "\x5f",
"\x60", "\x61", "\x62", "\x63", "\x64", "\x65", "\x66", "\x67", "\x68", "\x69", "\x6a", "\x6b", "\x6c", "\x6d", "\x6e", "\x6f",
"\x70", "\x71", "\x72", "\x73", "\x74", "\x75", "\x76", "\x77", "\x78", "\x79", "\x7a", "\x7b", "\x7c", "\x7d", "\x7e", "\x7f",
"\x80", "\x81", "\x82", "\x83", "\x84", "\x85", "\x86", "\x87", "\x88", "\x89", "\x8a", "\x8b", "\x8c", "\x8d", "\x8e", "\x8f",
"\x90", "\x91", "\x92", "\x93", "\x94", "\x95", "\x96", "\x97", "\x98", "\x99", "\x9a", "\x9b", "\x9c", "\x9d", "\x9e", "\x9f",
"\xa0", "\xa1", "\xa2", "\xa3", "\xa4", "\xa5", "\xa6", "\xa7", "\xa8", "\xa9", "\xaa", "\xab", "\xac", "\xad", "\xae", "\xaf",
"\xb0", "\xb1", "\xb2", "\xb3", "\xb4", "\xb5", "\xb6", "\xb7", "\xb8", "\xb9", "\xba", "\xbb", "\xbc", "\xbd", "\xbe", "\xbf",
"\xc0", "\xc1", "\xc2", "\xc3", "\xc4", "\xc5", "\xc6", "\xc7", "\xc8", "\xc9", "\xca", "\xcb", "\xcc", "\xcd", "\xce", "\xcf",
"\xd0", "\xd1", "\xd2", "\xd3", "\xd4", "\xd5", "\xd6", "\xd7", "\xd8", "\xd9", "\xda", "\xdb", "\xdc", "\xdd", "\xde", "\xdf",
"\xe0", "\xe1", "\xe2", "\xe3", "\xe4", "\xe5", "\xe6", "\xe7", "\xe8", "\xe9", "\xea", "\xeb", "\xec", "\xed", "\xee", "\xef",
"\xf0", "\xf1", "\xf2", "\xf3", "\xf4", "\xf5", "\xf6", "\xf7", "\xf8", "\xf9", "\xfa", "\xfb", "\xfc", "\xfd", "\xfe", "\xff");

my @CmfData; open(my_file1, $fname0); my @fstats = stat(my_file1); my $fsize = $fstats[7]; my $ts = localtime($fstats[9]); for (my $i=0; $i<$fsize; $i++) { sysread(my_file1, my $byte, 1); push(@CmfData, ord($byte)); } close(my_file1);

my $ID = chr($CmfData[0x00]).chr($CmfData[0x01]).chr($CmfData[0x02]).chr($CmfData[0x03]);

my $Version       = ($CmfData[0x05] << 8) + ($CmfData[0x04] << 0);
my $StartIns      = ($CmfData[0x07] << 8) + ($CmfData[0x06] << 0);
my $StartMus      = ($CmfData[0x09] << 8) + ($CmfData[0x08] << 0);
my $clk0          = ($CmfData[0x0b] << 8) + ($CmfData[0x0a] << 0);
my $clk1          = ($CmfData[0x0d] << 8) + ($CmfData[0x0c] << 0);
my $StartTitle    = ($CmfData[0x0f] << 8) + ($CmfData[0x0e] << 0);
my $StartComposer = ($CmfData[0x11] << 8) + ($CmfData[0x10] << 0);
my $StartRemarks  = ($CmfData[0x13] << 8) + ($CmfData[0x12] << 0);
my $NumIns        = ($CmfData[0x25] << 8) + ($CmfData[0x24] << 0);
my $tempo         = ($CmfData[0x27] << 8) + ($CmfData[0x26] << 0);

my $Chns = 0x0000; for (my $i=0x23; $i>=0x14; $i--) { $Chns = ($Chns << 1) | $CmfData[$i]; }

my $title    = ""; if ($StartTitle   ) { my $i = 0x00; while ($CmfData[$StartTitle   +$i]) { $title    .= chr($CmfData[$StartTitle   +$i]); $i++; }}
my $composer = ""; if ($StartComposer) { my $i = 0x00; while ($CmfData[$StartComposer+$i]) { $composer .= chr($CmfData[$StartComposer+$i]); $i++; }}
my $remarks  = ""; if ($StartRemarks ) { my $i = 0x00; while ($CmfData[$StartRemarks +$i]) { $remarks  .= chr($CmfData[$StartRemarks +$i]); $i++; }}

my ($sig, $j) = (0, -1); for (my $i = $StartMus; $i < $fsize; $i++) { $sig = (($sig << 8) | $CmfData[$i]) & 0xffffff; if ($sig == 0xff2f00) { $j = $i; last(); }} if ($sig != 0xff2f00) { $j = $fsize-1; } $sig = $j;

my $TrkLength = ($sig+1) - $StartMus;

my $bpm = ($clk1 / $clk0) * 60; # == tempo!?

open(my_file1, ">$fname1"); binmode(my_file1);

print(my_file1 "MThd"); print(my_file1 $LUT[0x00]); print(my_file1 $LUT[0x00]); print(my_file1 $LUT[0x00]); print(my_file1 $LUT[0x06]);
print(my_file1 $LUT[    0x00]); print(my_file1 $LUT[      0x00]); #type (single track)
print(my_file1 $LUT[    0x00]); print(my_file1 $LUT[      0x01]); #number of tracks (single)
print(my_file1 $LUT[$clk0>>8]); print(my_file1 $LUT[$clk0&0xff]); #ppqn

print(my_file1 "MTrk"); print(my_file1 $LUT[($TrkLength>>24) & 0xff]); print(my_file1 $LUT[($TrkLength>>16) & 0xff]); print(my_file1 $LUT[($TrkLength>> 8) & 0xff]); print(my_file1 $LUT[($TrkLength>> 0) & 0xff]);

for (my $i = $StartMus; $i < $StartMus+$TrkLength; $i++) { print(my_file1 $LUT[$CmfData[$i]]); }

close(my_file1);

my $info = sprintf("$fname0 ($ts) %s 0x%04x %d %d \'$title\' \'$composer\' \'$remarks\' 0x%04x %d %.2f - %d %d %d", $ID, $Version, $clk0, $clk1, $Chns, $NumIns, $bpm, $tempo, ($StartMus-$StartIns)-$NumIns*16, $fsize-($sig+1));

printf("$info\n");

my %PercMap = (12=>36, 13=>38, 14=>47, 15=>49, 16=>42);

if (defined($flgs)) {
 my %test1 = MIDI::Read($fname1);
 MIDI::InsertText(   \%test1, 0x00, 0/1, 0, $info,  0x01);
 #MIDI::InsertGeneric(\%test1, 0x00, 0/1, 0, 0xff, 0x21, 0x00);
 MIDI::InsertKeySig( \%test1, 0x00, 0/1, 0, 0);
 MIDI::InsertTimeSig(\%test1, 0x00, 0/1, 0, 4, 4);
 MIDI::InsertTempo(  \%test1, 0x00, 0/1, 0, $bpm);
 MIDI::InsertText(   \%test1, 0x00, 0/1, 0, "Ctrl", 0x03);

 for (my $c=12; $c<=16; $c++) { if (exists($test1{$c})) { #delete($test1{$c});
  foreach my $k1 (sort {$a <=> $b} keys %{$test1{$c}}) {
   foreach my $k2 (sort {$a <=> $b} keys %{$test1{$c}{$k1}}) {
    if ($test1{$c}{$k1}{$k2}{0} >> 4 <= 0xe) { $test1{$c}{$k1}{$k2}{0} = ($test1{$c}{$k1}{$k2}{0} & 0xf0) | 0x9; }
    if ($test1{$c}{$k1}{$k2}{0} >> 4 == 0x9) { $test1{$c}{$k1}{$k2}{1} = $PercMap{$c}; }
    if ($test1{$c}{$k1}{$k2}{0} >> 4 == 0xc) { $test1{$c}{$k1}{$k2}{1} = 0x00; }
    }
   }
  }}

 MidiDebug::PrintInfo(\%test1); MIDI::Write(\%test1, $main::OutFile);
 }

return (0); }
#===============================================================================

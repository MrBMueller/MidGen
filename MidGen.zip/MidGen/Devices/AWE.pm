use strict; use warnings; use MIDI; package AWE;

#notes from AWE32FAQ:
#- all values are increments (offsets) to existing predefined values
#- all values are taken as centered values (0.5 -> 0.0 -> offset 0 => no change)

our $NRPN_21 = 0x8000 | (127<<7) | 21; #initial filter cutoff    (0x00-0x7f) 0.0-0.0156
our $NRPN_22 = 0x8000 | (127<<7) | 22; #initial filter resonance (0x00-0x7f)
our $NRPN_25 = 0x8000 | (127<<7) | 25; #chorus effects send (0x00-0xff)
our $NRPN_26 = 0x8000 | (127<<7) | 26; #reverb effects send (0x00-0xff)

our $cNRPN_21  = 0x20000 | $NRPN_21;
our $cNRPN_22  = 0x20000 | $NRPN_22;
our $cNRPN_25  = 0x20000 | $NRPN_25;
our $cNRPN_26  = 0x20000 | $NRPN_26;

return(1);
#===============================================================================

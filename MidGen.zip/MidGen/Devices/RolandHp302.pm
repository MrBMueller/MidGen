use strict; use warnings; use MIDI; use GM; use GM2; use GS; package RolandHp302;

our @IdentityRequest  = (0x7e, 0x10, 0x06, 0x01); #device specific identity request (13+2 byte receive)

#    Efx             c1     c2    Type    1    2    3    4    5    6    7    8    9   10   11   12   13   14   15   16   17   18   19   20
our @Thru      = (undef, undef, 0x0001);
our @Spectrum  = (undef, undef, 0x0101,  28,  20,  10,   2,   2,  10,  20,  28,   2, 127);
our @Humanizer = (undef, undef, 0x0103,   0,   0,   3,   4,   0,  32,  64, 127,   0,  64,  64,  15,  15,  64, 127);
our @AutoWah   = (undef, undef, 0x0121,   0,   0,  32,  64,   0,   0,  32,  10, 127,  90,  15,  15, 127);
our @Rotary    = (undef, undef, 0x0122,   1,  64, 127,  15, 127,  64, 127,  15, 127,  64, 127);
our @Tremolo   = (undef, undef, 0x0125,   2,   0,  32,  10, 127,  15,  15, 127);
our @AutoPan   = (undef, undef, 0x0126,   2,   0,  32,  10, 127,  15,  15, 127);
our @MDly      = (   -3,   -10, 0x0150,   1, 127,  21,   0,  49,  17,  64,  15,  15,  64, 127);                     #doesnt work on channel 14!?
our @RDly      = (   -3,   -11, 0x015a,  16,   1, 127,  21,  49,  17,  64, 127,  15,  15,  64, 127);                #doesnt work on channel 2/3!?
our @SDly1     = (  -10,   -14, 0x015b,   1,  10,   6,   1,  10,   6,   0,   0,   1,  79,  17,  15,  15,  64, 127); #doesnt work on channel 1/2!?
our @SDly2     = (  -10,   -14, 0x015c,   1,  10,   6,   1,  10,   6,   0,   0,   1,  79,  17,  15,  15,  64, 127); #doesnt work on channel 0/1!?
our @SDly3     = (  -10,   -14, 0x015d,   1,  10,   6,   1,  10,   6,   0,   0,   1,  79,  17,  15,  15,  64, 127); #doesnt work on channel 0/9!?
our @SDly4     = (undef, undef, 0x015e,   1,  10,   6,   1,  10,   6,   0,   0,   1,  79,  17,  15,  15,  64, 127);
our @SDly5     = (undef, undef, 0x015f,   1,  10,   6,   1,  10,   6,   0,   0,   1,  79,  17,  15,  15,  64, 127);
our @LoFi      = (undef, undef, 0x0172,   0,   8,   0,   8,  15,  15, 100, 127);
our @Phone     = (undef, undef, 0x0175,   0,  15, 100, 127);

for (1..20) { $MIDI::CtlCallBackRefs{0x410+$_} = \&RolandHp302::EfxPx; }

our ($EfxP1 , $EfxP2 , $EfxP3 , $EfxP4 , $EfxP5 , $EfxP6 , $EfxP7 , $EfxP8 , $EfxP9 , $EfxP10,
     $EfxP11, $EfxP12, $EfxP13, $EfxP14, $EfxP15, $EfxP16, $EfxP17, $EfxP18, $EfxP19, $EfxP20) =
	(0x411, 0x412, 0x413, 0x414, 0x415, 0x416, 0x417, 0x418, 0x419, 0x41a,
     0x41b, 0x41c, 0x41d, 0x41e, 0x41f, 0x420, 0x421, 0x422, 0x423, 0x424);

our %EfxParams = ( 0x0101 => { 1 => [ 1,   0,  30],
                               2 => [ 1,   0,  30],
                               3 => [ 1,   0,  30],
                               4 => [ 1,   0,  30],
                               5 => [ 1,   0,  30],
                               6 => [ 1,   0,  30],
                               7 => [ 1,   0,  30],
                               8 => [ 1,   0,  30],
                               9 => [ 1,   0,   4],
							  10 => [ 2,   0, 127]},
	               0x0175 => { 1 => [ 0,   0,  15], #audio quality 0:low, 15:good
                               2 => [ 1,   0,  30],
							   3 => [ 2,   0, 100],
							   4 => [ 2,   0, 127]});

our %Patches;

return(1);
#===============================================================================
sub SystemEfx {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =    0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =      0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =      1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } #if (not defined($val0 )) { $val0  = 0x0001; } #type
my $val1  = undef; if ($#_ >= 0) { $val1  = shift(@_); } #if (not defined($val1 )) { $val1  =   0x00; } #send level to reverb
my $val2  = undef; if ($#_ >= 0) { $val2  = shift(@_); } #if (not defined($val2 )) { $val2  =   0x00; } #send level to chorus
my $val3  = undef; if ($#_ >= 0) { $val3  = shift(@_); } #if (not defined($val3 )) { $val3  =   0x7f; } #depth

if (defined($val0)) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x03, 0x00, $val0>>8, $val0&0x7f); $start += 0.040*$tc; }

#GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x03, 0x03, @_); $start += 0.040*($h0->{-1}{4}/240);

for (my $i=0; $i<=$#_; $i++) {
 if (defined($_[$i])) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x03, 0x03+$i, $_[$i]); $start += 0.040*$tc; }
 }

if (defined($val1)) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x03, 0x17, $val1, $val2); $start += 0.040*$tc; }
if (defined($val3)) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x03, 0x1a, $val3       ); $start += 0.040*$tc; }

return($start-$s); }
#===============================================================================
sub PartEfx {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =     0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =       0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =       1; }
my $chn   = undef; if ($#_ >= 0) { $chn   = shift(@_); } if (not defined($chn  )) { $chn   = -0xffff; } #undef, 0x0..0xf
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =  0x0001; } #type

#           0  1  2  3  4  5  6  7  8  9  10  11  12  13  14  15   #channel/part (default assignment - see GS spec)
my @BLUT = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15); #physical block (address)

if    ($chn < 0) { $chn = abs($chn); }
 else            { $chn = 1 << $chn; }

for (my $c=0; $c<=$#BLUT; $c++) {
 if ($chn & 1) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x40+$BLUT[$c], 0x23, $val0>>8, $val0&0x7f, @_); $start += 0.040*$tc; }
 $chn >>= 1;
 }

return($start-$s); }
#===============================================================================
sub AssignEfx {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } #
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start = 0; } my $s = $start;
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } #
my $c     = undef; if ($#_ >= 0) { $c     = shift(@_); } #channel undef/-1, 0x0..0xf
my $sd    = undef; if ($#_ >= 0) { $sd    = shift(@_); } #system depth
my $rs    = undef; if ($#_ >= 0) { $rs    = shift(@_); } #reverb send level
my $cs    = undef; if ($#_ >= 0) { $cs    = shift(@_); } #chorus send level
my $pd    = undef; if ($#_ >= 0) { $pd    = shift(@_); } #part   depth
my $pm    = undef; if ($#_ >= 0) { $pm    = shift(@_); } #part   macro
my $c1    = undef; if ($#_ >= 0) { $c1    = shift(@_); } #ctl #1
my $c2    = undef; if ($#_ >= 0) { $c2    = shift(@_); } #ctl #2
my $t     = undef; if ($#_ >= 0) { $t     = shift(@_); } #EFXType

if (defined($c1) && ($c1 < 0)) { $c1 = $_[abs($c1)-1]; }
if (defined($c2) && ($c2 < 0)) { $c2 = $_[abs($c2)-1]; }

$start += RolandHp302::SystemEfx($h0, $trk, $start, $ep,     $t, $rs, $cs, $sd, @_ ); #enable system EFX (type, level, depth)
$start += RolandHp302::PartEfx(  $h0, $trk, $start, $ep, $c, $t, $pm, $pd, $c1, $c2); #assign part (chn, type, macro, depth, #1, #2)

return($start-$s); }
#===============================================================================
sub EfxPx {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   = 0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =   0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =   1; }
my $ch    = undef; if ($#_ >= 0) { $ch    = shift(@_); } if (not defined($ch   )) { $ch    =   0; }
my $ctl   = undef; if ($#_ >= 0) { $ctl   = shift(@_); } if (not defined($ctl  )) { $ctl   =   0; }
my $Val   = undef; if ($#_ >= 0) { $Val   = shift(@_); }
my $LVal  = undef; if ($#_ >= 0) { $LVal  = shift(@_); }

if ($Val>>7 != $LVal>>7) { GS::DT1SysEx($h0, $trk, $start, $ep, 0x40, 0x03, 0x03+($ctl-0x410)-1, ($Val>>7)&0x7f); }

return(0); }
#===============================================================================
sub GetEfxSweepStr {
my $EfxNum = 0x101; if ($#_ >= 0) { $EfxNum = shift(@_); }
my $p      =     1; if ($#_ >= 0) { $p      = shift(@_); }
my $a      =     1; if ($#_ >= 0) { $a      = shift(@_); }
my $o      =     0; if ($#_ >= 0) { $o      = shift(@_); }

my ($c, $ll, $ul) = @{$RolandHp302::EfxParams{$EfxNum}{$p}};

my $f = 3; $ll = $ll/127; $ul = $ul/127; my $d = abs($ul-$ll);

if ($a < 0) { if (abs($c) == 1) { $c *= -1; } else { $c = abs($c-2); }}

if     ($c ==  0) { $f =  3;                            }
 elsif ($c ==  1) { $f =  2; $d /= 2; $ll =   ($ll+$d); }
 elsif ($c == -1) { $f = -2; $d /= 2; $ll = 1-($ll+$d); }
 else             { $f = -3;          $ll = 1-($ul   ); }

$ll += $o; $d *= abs($a); return(sprintf("Cx%x_%d_0_$ll\_$d", 0x410+$p, $f)); }
#===============================================================================
sub ImportPatchNames { my %RetVal;
my ($h0, $p) = (undef, -2); if (($#_ >= 1) && (ref($_[0]) =~ 'HASH')) { $h0 = shift(@_); $p = shift(@_); }
my $fname  = undef; if ($#_ >= 0) { $fname = shift(@_); } if (not(defined($fname))) { $fname = "$main::SrcDir0/DeviceMaps/Hp503Tones0.txt"; }
my $pname  = undef; if ($#_ >= 0) { $pname = shift(@_); } if (not(defined($pname))) { if ($fname =~ /Hp(\d+)Tones/) { $pname = "HP$1"; }} $RetVal{-1} = $pname;

if (not(defined($p))) { $p = -1; } if ($p < -1) { $p = undef; }

if ((defined($p)) && (not(exists($h0->{$p}{-1})))) { $h0->{$p}{-1} = $RetVal{-1}; }

my @MyAttrs0 = stat($fname);
open(my_file1, $fname); my $group = ""; my %GroupCnt;
while (<my_file1>) { my $line = $_; $line =~ s/\n|\r//g; $line =~ s/^\s*//g; $line =~ s/\s*$//g; if (length($line) <= 0) { next(); }

 my $No = -1; my $ToneName = ""; my $MSB = -1; my $LSB = -1; my $PC = -1;

 if ($line =~ /^(\d+)\s+(.*)\s+(\d+)\s+(\d+)\s+(\d+)$/) { $No = $1; $ToneName = $2; $MSB = $3; $LSB = $4; $PC = $5; } $PC--;

 $ToneName =~ s/^\s*//g; $ToneName =~ s/\s*$//g;

 if ($No < 0) { $group = $line; next(); }
 
 #$RetVal{0xc}{-1}{($MSB<<7)+$LSB}{ -1} = sprintf("HP");
 $RetVal{0xc}{-1}{($MSB<<7)+$LSB}{$PC} = sprintf("%s-%d-%s", $group, $No, $ToneName);

 #if ((defined($p)) && (not(exists($h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}     )))) { $h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{ -1} = sprintf("HP"); }
 #if ((defined($p)) && (not(exists($h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{$PC})))) { $h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{$PC} = sprintf("%s-%d-%s", $group, $No, $ToneName); }
 if (defined($p)) { $h0->{$p}{0xc}{-1}{($MSB<<7)+$LSB}{$PC} = sprintf("%s-%d-%s", $group, $No, $ToneName); }

 $GroupCnt{$group}++; $RolandHp302::Patches{scalar(keys(%GroupCnt))-1}{$No} = [($MSB<<7)+$LSB, $PC];

 #printf("0x%04x, 0x%02x %-7s %3d %s\n", ($MSB<<7)+$LSB, $PC, $group, $No, $ToneName);
 }
close(my_file1);

return(%RetVal); }
#===============================================================================
sub Patch { my $g = shift(@_)-1; my $t = shift(@_); my @RetVal = (0x0000, 0x00);

if (exists($RolandHp302::Patches{$g}{$t})) { @RetVal = @{$RolandHp302::Patches{$g}{$t}}; }
 else { printf("RolandHp302::Patch(%d, %d); #doesnt exist!\n", $g+1, $t); }

return(@RetVal); }
#===============================================================================

use strict; use warnings; package SMF;

#not a real device, but defines SMF (Standard MIDI File) specific values

#SMF types (0: single merged track, 1: multiple simultaneous tracks, 2: multiple independent tracks)
our @Types = (0, 1, 2);

#common pulses (ticks) per quarter note - taken from WinJammer (48-960)
#Cakewalk/Sonar: 48, 72, 96, 120, 144, 168, 192, 216, 240, 360, 384, 480 / 600, 720, 960
#Cubase/Nuendo : 24-960
#-> multiple (1..40) of 24 !?
#               0    1    2    3    4    5    6    7    8    9
our @PPQNs = ( 24,  48,  72,  96, 120, 144, 168, 192, 216, 240,  #0
			  264, 288, 312, 336, 360, 384, 408, 432, 456, 480,  #1
			  504, 528, 552, 576, 600, 624, 648, 672, 696, 720,  #2
			  744, 768, 792, 816, 840, 864, 888, 912, 936, 960); #3

#meta KeySignature => number of flats/sharps (key) + scale (0/1 = major/minor) based on heptatonic scales
#                    (   enh. eq.   |  rd  |         unique             center         unique        |  rd  |  enh. eq. )
#                    (--------------|------|------------------------------|--------------------------|------|-----------) # heptatonic scale
#                    (  Cb      Gb  |  Db  |  Ab     Eb     Bb      F     C     G     D     A     E  |  B   |  F#    C# ) 0 ionisch  (major)
#                    (              |      |                C                                        |      |           ) 1 dorisch
#                    (              |      |  C                                                      |      |           ) 2 phrygisch
#                    (              |      |                                    C                    |      |           ) 3 lydisch
#                    (              |      |                        C                                |      |           ) 4 mixolydisch
#                    (  ab      eb  |  bb  |  f      c      g       d     a     e     b     f#    c# |  g#  |  d#    a# ) 5 aeolisch (minor)
#                    (              |  C   |                                                         |      |        C  ) 6 hypophrygisch
our %KeySignatures = (-7=>11, -6=>6, -5=>1, -4=>8, -3=>3, -2=>10, -1=>5, 0=>0, 1=>7, 2=>2, 3=>9, 4=>4, 5=>11, 6=>6, 7=>1);

#tempo = beats (quarter notes) per minute

#meta text events (generic, copyright, track, instrument, lyric, marker, CuePoint)
our @MetaText =   (   0x01,      0x02,  0x03,       0x04,  0x05,   0x06,     0x07);

return(1);
#===============================================================================

use strict; use warnings; use MIDI; use GM; use GS; package GM2;

#RPN definitions
our $RPN_5 = 0x4005; #modulation depth range

our $MasterVolume = 0x600; $MIDI::CtlCallBackRefs{$GM2::MasterVolume} = \&GM2::CbMasterVolume;

our @IdentityRequest  = (0x7e, 0x7f, 0x06, 0x01); #broadcast identity request (13+2 byte receive)

return(1);
#===============================================================================
# Universal SysEx
# ID number		(0x7e non-realtime; 0x7f realtime)
# Device ID		(0x00-0x7e channel; 0x7f broadcast)
# Sub ID#1		(non-realtime: 0x09 GM; realtime: 0x04 Device control, 0x06 MMC)
# Sub ID#2
#===============================================================================
# -= non-realtime =-
# GM
#===============================================================================
sub GMSystem {
my $h0    = shift(@_); my $tc = 0; if (exists($h0->{-1}{4})) { $tc = $h0->{-1}{4}/240; }
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  = 0x02; } #0x01 GM1, 0x02 GMOff, 0x03 GM2

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7e, 0x7f, 0x09, $val0);

return(0.050*$tc); } #return approx. processing time
#===============================================================================
# -= realtime =-
# Device control
#===============================================================================
sub MasterVolume {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =  0.5; } # 0.0 .. 1.0

$val0 = int($val0*0x4000); if ($val0 > 0x3fff) { $val0 = 0x3fff; } $val0 &= 0x3f80;

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x04, 0x01, $val0&0x7f, $val0>>7);

return(0); }
#===============================================================================
sub MasterFineTuning {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =  0.0; } # -1.0 .. 1.0

$val0 = ($val0+1)/2; $val0 = int($val0*0x4000); if ($val0 > 0x3fff) { $val0 = 0x3fff; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x04, 0x03, $val0&0x7f, $val0>>7);

return(0); }
#===============================================================================
sub MasterCoarseTuning {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =    0; } # -24 .. 24

$val0 = ($val0 + 0x40) << 7; $val0 &= 0x3f80;

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x04, 0x04, $val0&0x7f, $val0>>7);

return(0); }
#===============================================================================
sub ReverbParameters {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =    0; } # 0,1,2,3,4,8
my $val1  = undef; if ($#_ >= 0) { $val1  = shift(@_); } if (not defined($val1 )) { $val1  =    0; } # 0.0 .. 1.0

$val1 = int($val1 * 0x80); if ($val1 > 0x7f) { $val1 = 0x7f; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x04, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, $val0, $val1);

return(0); }
#===============================================================================
sub ChorusParameters {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  =    0; } # 0,1,2,3,4
my $val1  = undef; if ($#_ >= 0) { $val1  = shift(@_); } if (not defined($val1 )) { $val1  =    0; } # 0..127

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x04, 0x05, 0x01, 0x01, 0x01, 0x01, 0x02, $val0, $val1);

return(0); }
#===============================================================================
# MMC
#===============================================================================
sub Stop {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }
my $val0  = undef; if ($#_ >= 0) { $val0  = shift(@_); } if (not defined($val0 )) { $val0  = 0x60; } #fps (24)
my $val1  = undef; if ($#_ >= 0) { $val1  = shift(@_); } if (not defined($val1 )) { $val1  = 0x00; } #min
my $val2  = undef; if ($#_ >= 0) { $val2  = shift(@_); } if (not defined($val2 )) { $val2  = 0x00; } #sec
my $val3  = undef; if ($#_ >= 0) { $val3  = shift(@_); } if (not defined($val3 )) { $val3  = 0x00; } #frame
my $val4  = undef; if ($#_ >= 0) { $val4  = shift(@_); } if (not defined($val4 )) { $val4  = 0x00; } #sub-frame

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x01); #stop
MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x44, 0x06, 0x01, $val0, $val1, $val2, $val3, $val4); #set locator

return(0); }
#===============================================================================
sub Play {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x02);

return(0); }
#===============================================================================
sub Rec {
my $h0    = shift(@_);
my $trk   = undef; if ($#_ >= 0) { $trk   = shift(@_); } if (not defined($trk  )) { $trk   =  0x0; }
my $start = undef; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { $start =    0; }
my $ep    = undef; if ($#_ >= 0) { $ep    = shift(@_); } if (not defined($ep   )) { $ep    =    1; }

MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x06, 0x06);

return(0); }
#===============================================================================
#callback subs
#===============================================================================
sub CbMasterVolume { my ($h0, $trk, $start, $ep, $ch, $ctl, $v0, $v1) = @_;

if ($v0>>7 != $v1>>7) { MIDI::InsertSysEx($h0, $trk, $start, $ep, 0x7f, 0x7f, 0x04, 0x01, 0x00, $v0>>7); }

return(0); }
#===============================================================================

use strict; use warnings; package HostSystem;

our %MidiInDevices;
our %MidiOutDevices;

return(1);
#===============================================================================
sub MidiOx {

my $StartupDir = "$main::SrcDir0/Bin/MidiOx"; $StartupDir =~ s/\//\\/g;

if (($^O !~ /linux/i) && (`tasklist /FI \"IMAGENAME eq midiox.exe\" 2>&1` !~ /midiox\.exe/)) {
 system("start /min /d$StartupDir $StartupDir\\midiox.exe"); #min/max window setting
 }

return(0); }
#===============================================================================
sub ProcessRunning { my ($name) = @_; my $rv = 0; if ($^O !~ /MSWin/i) { return($rv); }

if (`tasklist /FI \"IMAGENAME eq $name\" 2>&1` =~ /$name/) { $rv = 1; }

return($rv); }
#===============================================================================
sub ProcessKill { my ($name) = @_; my $rv = 0; if ($^O !~ /MSWin/i) { return($rv); }

`taskkill /F /IM $name > nul 2>&1`;

return($rv); }
#===============================================================================
sub Panic { my $args = join(" ", @_); my $rv = 0; if ($^O !~ /MSWin/i) { return($rv); }

`$main::SrcDir0/Bin/panic.exe $args > nul 2>&1`;

return($rv); }
#===============================================================================
sub lsmidiins { if (scalar(keys(%HostSystem::MidiInDevices)) || ($^O !~ /MSWin/i)) { return(%HostSystem::MidiInDevices); }

my @lines = split("\n", `$main::SrcDir0/Bin/lsmidiins.exe`);

for (my $i=0; $i<=$#lines; $i++) { if ($lines[$i] =~ /^\s*(\d+)\s+(.*)$/) { $HostSystem::MidiInDevices{$1} = $2; }}

return(%HostSystem::MidiInDevices); }
#===============================================================================
sub lsmidiouts { if (scalar(keys(%HostSystem::MidiOutDevices)) || ($^O !~ /MSWin/i)) { return(%HostSystem::MidiOutDevices); }

my @lines = split("\n", `$main::SrcDir0/Bin/lsmidiouts.exe`);

for (my $i=0; $i<=$#lines; $i++) { if ($lines[$i] =~ /^\s*(\d+)\s+(.*)$/) { $HostSystem::MidiOutDevices{$1} = $2; }}

return(%HostSystem::MidiOutDevices); }
#===============================================================================
sub GetMidiInPortID { my ($name) = @_; my $port = -1; HostSystem::lsmidiins();

foreach my $p (sort({$a <=> $b} keys(%HostSystem::MidiInDevices))) { if ($HostSystem::MidiInDevices{$p} =~ /$name/i) { $port = $p; last(); }}

return($port); }
#===============================================================================
sub GetMidiOutPortID { my ($name) = @_; my $port = -1; HostSystem::lsmidiouts();

foreach my $p (sort({$a <=> $b} keys(%HostSystem::MidiOutDevices))) { if ($HostSystem::MidiOutDevices{$p} =~ /$name/i) { $port = $p; last(); }}

return($port); }
#===============================================================================
sub GetMidiInPortName { my ($port) = @_; my $name = '';

if (defined($port) && ($port >= 0)) { HostSystem::lsmidiins(); if (exists($HostSystem::MidiInDevices{$port})) { $name = $HostSystem::MidiInDevices{$port}; }}

return($name); }
#===============================================================================
sub GetMidiOutPortName { my ($port) = @_; my $name = '';

if (defined($port) && ($port >= 0)) { HostSystem::lsmidiouts(); if (exists($HostSystem::MidiOutDevices{$port})) { $name = $HostSystem::MidiOutDevices{$port}; }}

return($name); }
#===============================================================================

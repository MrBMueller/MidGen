use strict; use warnings; use MIDI; package Sync; return(1);
#===============================================================================
sub InsertMC {
my $m   = shift(@_);
my $trk =   0x0; if ($#_ >= 0) { $trk = shift(@_); }
my $t0  =     0; if ($#_ >= 0) { $t0  = shift(@_); }
my $l   =     0; if ($#_ >= 0) { $l   = shift(@_); }
my $t2  = undef; if ($#_ >= 0) { $t2  = shift(@_); } if (not(defined($t2))) { $t2 = $t0; }

my $SPP = MIDI::RoundInt($t2*16); my $t1 = 0; #SPP: number of midi beats (16th notes)

MIDI::InsertGeneric($m, $trk, $t0+$t1, 0, 0xf7, 0xf2, $SPP&0x7f, $SPP>>7);

MIDI::InsertGeneric($m, $trk, $t0+$t1, 1, 0xf7, 0xfb); #restart/continue from SPP

#$t1 += 1/96; #skip clock pulse when SPP changes? (but might cause tempo hickup)

while ($t1 < $l-1/(96*2)) { MIDI::InsertGeneric($m, $trk, $t0+$t1, 1, 0xf7, 0xf8); $t1 += 1/96; }

return($t1); }
#===============================================================================
sub InsertMTC {
my $m   = shift(@_);
my $trk =   0x0; if ($#_ >= 0) { $trk = shift(@_); }
my $t0  =     0; if ($#_ >= 0) { $t0  = shift(@_); }
my $l   =     0; if ($#_ >= 0) { $l   = shift(@_); }
my $t2  = undef; if ($#_ >= 0) { $t2  = shift(@_); } if (not(defined($t2))) { $t2 = $t0; }
my $fr  =     0; if ($#_ >= 0) { $fr  = shift(@_); } my %fps = (0=>24, 1=>25, 2=>30, 3=>30, 6=>29.97, 7=>29.97); my $fps1 = $fps{$fr}; my $fps2 = $fps{$fr &= 3};
my $bpm = undef; if ($#_ >= 0) { $bpm = shift(@_); } if (not(defined($bpm))) { $bpm = 120; if (exists($m->{-1}{4})) { $bpm = $m->{-1}{4}; }}

my ($t1, $rev, $dir) = (0, 0, 1); if ($l < 0) { $t2 += $l = abs($l); ($rev, $dir) = (7, -1); } my $qf = $bpm/($fps1*960);

my ($Hour, $Minute, $Second, $Frame, $QuarterFrame) = Sync::GetSMPTE($t2, $fps2, $bpm);

MIDI::InsertGeneric($m, $trk, $t0+$t1, 0, 0xf0, 0x7f, 0x7f, 0x01, 0x01, $Hour, $Minute, $Second, $Frame, 0xf7); #full frame position

while ($t1 < $l-$qf/2) {

 my ($Hour, $Minute, $Second, $Frame, $QuarterFrame) = Sync::GetSMPTE($t2, $fps2, $bpm);

 if ($fr == 2 && $Minute != 10 && !$Second && !$Frame && !$QuarterFrame) { ($Hour, $Minute, $Second, $Frame, $QuarterFrame) = Sync::GetSMPTE($t2 += $dir*$bpm/($fps2*120), $fps2, $bpm); }

 #printf("$fr $fps1 $fps2 %02d:%02d:%02d:%02d:%d\n", $Hour, $Minute, $Second, $Frame, $QuarterFrame);

 my @data = ();
 push(@data, 0x00 |              ($Frame  >> 0) & 0xf); #-\
 push(@data, 0x10 |              ($Frame  >> 4)      ); #  \ 4 sub (quarter) frames ->
 push(@data, 0x20 |              ($Second >> 0) & 0xf); #  / single full frame
 push(@data, 0x30 |              ($Second >> 4)      ); #-/
 push(@data, 0x40 |              ($Minute >> 0) & 0xf); #-\
 push(@data, 0x50 |              ($Minute >> 4)      ); #  \ 4 sub (quarter) frames ->
 push(@data, 0x60 |              ($Hour   >> 0) & 0xf); #  / single full frame
 push(@data, 0x70 | ($fr << 1) | ($Hour   >> 4)      ); #-/  -> complete SMPTE time update after 2 frames (double frame)

 for (my $i = 0; $i <= $#data; $i++) { MIDI::InsertGeneric($m, $trk, $t0+$t1, 1, 0xf7, 0xf1, $data[$rev^$i]); $t1 += $bpm/($fps1*960); $t2 += $dir*$bpm/($fps2*960); }
 }

return($t1); }
#===============================================================================
sub GetSMPTE { my ($t, $fps, $bpm) = @_; $t -= int($t/43200)*43200; if ($t < 0) { $t += 43200; }

my     $SubFrame = MIDI::RoundInt($fps*$t*960/$bpm);
my $QuarterFrame =          $SubFrame                       &    3;
my        $Frame =         ($SubFrame >> 2)                 % $fps;
my       $Second =     int(($SubFrame >> 2) / $fps)         %   60;
my       $Minute = int(int(($SubFrame >> 2) / $fps) / 60)   %   60;
my         $Hour = int(int(($SubFrame >> 2) / $fps) / 3600) %   24;

return($Hour, $Minute, $Second, $Frame, $QuarterFrame); }
#===============================================================================

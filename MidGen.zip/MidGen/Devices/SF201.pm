use strict; use warnings; use MIDI; package SF201;

#notes from sfspec:
#All values are taken as centered offsets (modulators) to given parameter settings.
#Therefore a value of 0.5 (0.0 centered) will not change a given setting.

our $NRPN_8  = 0x18000 | (120<<7) |  8; #filter cutoff
our $NRPN_9  = 0x18000 | (120<<7) |  9; #filter q
our $NRPN_15 = 0x18000 | (120<<7) | 15; #chorus
our $NRPN_16 = 0x18000 | (120<<7) | 16; #reverb
our $NRPN_17 = 0x18000 | (120<<7) | 17; #pan
our $NRPN_51 = 0x18000 | (120<<7) | 51; #coarse tune
our $NRPN_52 = 0x18000 | (120<<7) | 52; #fine tune

our $cNRPN_8  = 0x20000 | $NRPN_8;
our $cNRPN_9  = 0x20000 | $NRPN_9;
our $cNRPN_15 = 0x20000 | $NRPN_15;
our $cNRPN_16 = 0x20000 | $NRPN_16;
our $cNRPN_17 = 0x20000 | $NRPN_17;
our $cNRPN_51 = 0x20000 | $NRPN_51;
our $cNRPN_52 = 0x20000 | $NRPN_52;

return(1);
#===============================================================================

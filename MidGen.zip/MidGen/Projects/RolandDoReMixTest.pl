use strict; use warnings; eval("use KX; use GM; use GS; use MMC; use Chord; use Percussion; use Bass; use Examples0; use Package0; use Tutorial;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

my $Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001

$Bank = 0x0006;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs);

#              track status       name       port      chn       bank      patch        vol        exp            pan     reverb        f-res        f-co            PBS             PB      #arr. setup
%main::trks = (0x00=>{-1=>1, -2=>"Ctrl", -3=>0x00                                                                                                                                        },  #
               0x01=>{-1=>1, -2=>"0x00", -3=>0x00, -4=>0x0, -5=>0x0006, -6=>0x00, 0x07=> .5, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x02=>{-1=>1, -2=>"0x01", -3=>0x00, -4=>0x1, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x03=>{-1=>1, -2=>"0x02", -3=>0x00, -4=>0x2, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x04=>{-1=>1, -2=>"0x03", -3=>0x00, -4=>0x3, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x05=>{-1=>1, -2=>"0x04", -3=>0x00, -4=>0x4, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x06=>{-1=>1, -2=>"0x05", -3=>0x00, -4=>0x5, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x07=>{-1=>1, -2=>"0x06", -3=>0x00, -4=>0x6, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x08=>{-1=>1, -2=>"0x07", -3=>0x00, -4=>0x7, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x09=>{-1=>1, -2=>"0x08", -3=>0x00, -4=>0x8, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0a=>{-1=>1, -2=>"0x09", -3=>0x00, -4=>0x9, -5=>0x0000, -6=>0x00, 0x07=> .4, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.1, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #percussion
               0x0b=>{-1=>1, -2=>"0x0a", -3=>0x00, -4=>0xa, -5=>0x0002, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #bass
               0x0c=>{-1=>1, -2=>"0x0b", -3=>0x00, -4=>0xb, -5=>0x0000, -6=>  50, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #pad
               0x0d=>{-1=>1, -2=>"0x0c", -3=>0x00, -4=>0xc, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0e=>{-1=>1, -2=>"0x0d", -3=>0x00, -4=>0xd, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0f=>{-1=>1, -2=>"0x0e", -3=>0x00, -4=>0xe, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x10=>{-1=>1, -2=>"0x0f", -3=>0x00, -4=>0xf, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef}); #

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

Chords(\%main::out, 0xc, $s, 32/1);

my $PhraseDir = "$main::PrjDrive/Midi2/PHRASE/";
$s += InsertRolandDoReMixPhrase(\%main::out, 10, $s, "$PhraseDir/HOUSE/HSDR8100.MID", 1*4/1, 0, 25);
$s += InsertRolandDoReMixPhrase(\%main::out, 10, $s, "$PhraseDir/HOUSE/HSDR8103.MID", 1*1/1);
$s += 1/1;
$s += InsertRolandDoReMixPhrase(\%main::out, 10, $s, "$PhraseDir/HOUSE/HSDR8103.MID", 1*1/1);
$s += 1/1;
$s += InsertRolandDoReMixPhrase(\%main::out, 10, $s, "$PhraseDir/HOUSE/HSDR8104.MID", 8*4/1);

MMC::Stop(\%main::out, 0x00, MIDI::GetEndTime(\%main::out)/($main::out{-1}{3}*4)+1/1); #stop+rewind
Edit::AddLyricString(\%main::out);

#===============================================================================
sub Chords { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }

my $c0 = $Chord::c0;
my $c1 = $Chord::c1;
my $c2 = $Chord::c2;

Edit::Seq($m, $t, undef, undef, undef, $s, 60+ 0, 3, " 2/1:0$c0 $c1 ^2$c0 /2:0$c2 -1$c0 ", .3, .5, 0,0,0,0,0,1,1,1,1, 1, $l);

my $ChordSeq0 = "$c0 % $c0 % 2($c0) % /:$c0 $c0"; #8 timeunits
my $ChordSeq1 = "$c1 % $c1 % 2($c1) % /:$c1 $c1";
my $ChordSeq2 = "$c2 % $c2 % 2($c2) % /:$c2 $c2";

my $b0 = $Bass::b0;

Edit::Seq($m, 0xb, undef, undef, undef, $s, 60-1*12, 3, " 4*4(1/8:0$b0) 2*4(1/8:^2$b0) 1*4(1/8:0$b0) 1*4(1/8:-1$b0) ", .5, .5, 0,0,0,0,0,1,1,1,1, 1, $l);

Edit::Seq($m, 0x1, undef, undef, undef, $s-3/8, 60, 3, " 1/8:-4 -2 -1 1/4:0 . 2 1/8:3 3/4:0 ", .5, .5, 0,0,0,0,0,1,1,1,1, .8, undef);

return(0); }
#===============================================================================
sub InsertRolandDoReMixPhrase {
my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s; my $PrgChgStart = undef;
my $p =     0; if ($#_ >= 0) { $p = shift(@_); }
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }
my $bnk = undef; if ($#_ >= 0) { $bnk = shift(@_); }
my $pgm = undef; if ($#_ >= 0) { $pgm = shift(@_); }

my %test1 = MIDI::Read($p); Edit::QuantizeTrk(\%test1, undef, 1/64, -1/64, 0, 1, $m->{-1}{3});

if (scalar(keys %test1) > 3) { printf("Info: $p has %d tracks.\n", scalar(keys %test1)-1); }

my $SrcTrk = (sort {$a <=> $b} keys %test1)[2];

while ((not defined($l)) || ($l > 0)) {
 MIDI::InsertText($m, 0x00, $s, 1, "v", 0x6, undef);
 (my $cstart, my $clength) = Edit::Copy($m, 10, \%test1, $SrcTrk, 0x9, undef, undef, 0, $s-1/1, $l); if (not defined($PrgChgStart)) { $PrgChgStart = $cstart; }
 (undef, my $near, undef, undef, undef, undef) = Edit::Quantize($clength, 1/1);
 $s += $near; if (not defined($l)) { $l = 0; } $l -= $near;
 MIDI::InsertText($m, 0x00, $s, 1, "^", 0x6, undef);
 }

MIDI::InsertPrgChg($m, 10, $PrgChgStart, 0, undef, $bnk, $pgm);

return($s-$start); }
#===============================================================================

use strict; use warnings; eval("use GM2; use KX; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

my $Bank = 0x0000; #base (GM/GS)
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2";                                                                       #  7.586.050   Sun Mar 18 12:17:00 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/AWEGOLD/4GMGSMT.SF2";                                                                        #  4.174.814   Tue Jul 30 11:52:32 1996

$Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/TR808WAV/tr808.sf2";                                                                         #  1.019.288   Wed Mar 28 21:31:24 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/From_mods/PSB/PANINARO.SF2";                                                                 #    411.314   Fri Nov  1 11:51:38 1996

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3, 8=>Misc::GetCopyright()}); my $s = 0/1; my $m = \%main::out; #general output setup

GM2::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #GM2::Rec(\%main::out, 0x00, $s+1/2, 0); #stop/rewind/rec

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00, 0x00); #device setup
#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9);

@main::trks = ([-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GM::RPN_0, $GM::cPB, $KX::CCx47, $KX::CCx4a, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9]);

#                   s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev   PBS     PB   frs(0) fco(1)    # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                                     ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0006,    4, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 01 live
                   [1, "0x01", 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0006,    1, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 02 bass
                   [1, "0x02", 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0003,    0,  .8, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03 harmonics/pad
                   [1, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0006, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0006, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0006, 0x02, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0006,   10, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   88, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, @DrumMaps::Generic             , 0x0001, 0x00, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

Misc::State2Param(\@main::trks);
#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => 1.0, $GM::CCx07 => 1.0});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs);

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

#Brainstorm::InsertPhrase(\%main::out, 1, $s+0/1, ".", undef, 1/128, -1/128, 0, undef, 0, 0, 1, 0, .5); #rec or play last in current dir

#my $seq = Tools::GetTimes(\%main::out, 1, 1/1, 0); MidiDebug::WrStr("$seq\n"); Edit::Seq($m, 16, undef, undef, undef, 1/1, 0, 0, " $seq "); #goto MyLabelEnd;

my $seq1v1 = "<1/4<:% 1/8+:0 1/16:-1 1/8:2 0 3/4:%";
my $seq1   = "<1/4<:% 1/8_:0      -1     2 0 3/4:%";

my $seq3 = "<2/4<:% 1/8:-1 *2:2 0 3/4+1/8:%";

eval("use Style2;"); my $key = 55; #goto label0;

$s += Style0::Timpani($m, $s, 1/1,  0, 0b0, $key);
$s += Style0::Pause  ($m, $s, 1/2);
$s += Style0::Timpani($m, $s, 2/1,  0, 0b0, $key);
$s += Style0::Pause  ($m, $s, 1/2);

Brainstorm::InsertPhrase(\%main::out, 6, $s+0/1, "$main::SrcDir0/Midi/.", "20121027225916", 1/128, -1/128, 0, undef, 0, 0, 1, 0, .5); #rec or play last in current dir

Edit::Seq($m, 8, undef, undef, undef, $s+4/1+0/128, 55+1*12, 3, " 3($seq1) $seq3 ",  .8); #goto MyLabelEnd;

$s += Style0::BassTrail($m, $s, 0/1,  0, 0b0, $key);
for (1..3*1) {
 $s += Style0::Var0($m, $s, 1/1,  0, 0b1110, $key, 3, 1.0, $_);
 $s += Style0::Var0($m, $s, 1/1, -4, 0b1110, $key);
 $s += Style0::Var0($m, $s, 1/1, -1, 0b1110, $key);
 $s += Style0::Var0($m, $s, 1/1,  0, 0b1110, $key);
 }

$s += Style0::Var0($m, $s, 1/2,  0, 0b10000, $key);
$s += Style0::Pause($m, $s, 1/2);
$s += Style0::Var0($m, $s, 2/1,  0, 0b10000, $key);

$s += Style0::Timpani($m, $s, 1/1,  0, 0b0, $key);
$s += Style0::Pause  ($m, $s, 1/2);
$s += Style0::Timpani($m, $s, 2/1,  0, 0b0, $key);
$s += Style0::Pause  ($m, $s, 1/2);

Brainstorm::InsertPhrase(\%main::out, 6, $s+0/1, "$main::SrcDir0/Midi/.", "20121027225916", 1/128, -1/128, 0, undef, 0, 0, 1, 0, .5); #rec or play last in current dir

$s += Style0::BassTrail($m, $s, 0/1,  0, 0b0, $key);
for (1..3*1) {
 $s += Style0::Var0($m, $s, 1/1,  0, 0b1110, $key, 3, 1.0, $_);
 $s += Style0::Var0($m, $s, 1/1, -4, 0b1110, $key);
 $s += Style0::Var0($m, $s, 1/1, -1, 0b1110, $key);
 $s += Style0::Var0($m, $s, 1/1,  0, 0b1110, $key);
 }

$s += Style0::Var0($m, $s, 1/2,  0, 0b10000, $key);
$s += Style0::Pause($m, $s, 1/2);
$s += Style0::Var0($m, $s, 2/1,  0, 0b10000, $key);

$s += Style0::Timpani($m, $s, 1/1,  0, 0b0, $key);
$s += Style0::Pause  ($m, $s, 1/2);
$s += Style0::Timpani($m, $s, 2/1,  0, 0b0, $key);
$s += Style0::Pause  ($m, $s, 1/2);

$s += Style0::BassTrail($m, $s, 0/1,  0, 0b0, $key);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0010, $key);
$s += Style0::Var0($m, $s, 1/1, -4, 0b0010, $key);
$s += Style0::Var0($m, $s, 1/1, -1, 0b0010, $key);
$s += Style0::Var0($m, $s, 1/1,  0, 0b0010, $key);

$s += Style0::Var0($m, $s, 1/1,  0, 0b1010, $key);
$s += Style0::Var0($m, $s, 1/1, -4, 0b1010, $key);
$s += Style0::Var0($m, $s, 1/1, -1, 0b1010, $key);
$s += Style0::Var0($m, $s, 1/1,  0, 0b1010, $key);

$s += Style0::Var0($m, $s, 1/1,  0, 0b1110, $key);
$s += Style0::Var0($m, $s, 1/1, -4, 0b1110, $key);
$s += Style0::Var0($m, $s, 1/1, -1, 0b1110, $key);
$s += Style0::Var0($m, $s, 1/1,  0, 0b1110, $key);

#===============================================================================

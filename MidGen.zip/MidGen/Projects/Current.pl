eval("use Misc; use Tools; use GM2; use KX; use Metronome; use StyleTrax; use Chord; use Percussion;");

$MidiDebug::Prgs{0x00} = {-1 => 'SF201'}; #base (GM/GS)
$MidiDebug::Prgs{0x00}{0xc}{-1}{   -1}{-1} = "E:/INSTR/COMMERC/8mbgm_21.sf2";                                                                       #  7.586.050   Sun Mar 18 12:17:00 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{   -1}{-1} = "E:/INSTR/AWEGOLD/4GMGSMT.SF2";                                                                        #  4.174.814   Tue Jul 30 11:52:32 1996

my $Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/TR808WAV/tr808.sf2";                                                                         #  1.019.288   Wed Mar 28 21:31:24 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>Tools::Scale2KeySig(Tools::GetChord(0, 'C')), 8=>Misc::GetCopyright()}); my ($m, $s) = (\%main::out, 0/1); #general output setup

use constant { u=>undef, p=>0x00, dv=>100/127, dr=>40/127};

#GM2::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #GM2::Rec(\%main::out, 0x00, $s+1/2, 0); #stop/rewind/rec

KX::LoadSoundFonts(\%MidiDebug::Prgs, 0x00, 0x00); #device setup
KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9);

@main::trks = (
[-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GM::RPN_0, $GM::cPB, $KX::CCx47, $KX::CCx4a, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9],
#s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol  exp   pan  rev   PBS     PB   frs(0) fco(1)   # arr. setup
[1, "Ctrl", p                                                                                                        ],  # 00
[1, "0x00", p   , 0x0, +000, 1.0, 1.0, -0.5, 1.0, +0.0, 0x0006,    2, .29, 1.0,  0.0, 0.5, undef, undef, undef, undef],  # 01 live
[1, "0x01", p   , 0x1, +000, 1.0, 1.0, -0.2, 1.0, +0.0, 0x0003,    0, .29, 1.0,  0.0, 0.5, undef, undef, undef, undef],  # 02 harmonics/pad
[1, "0x02", p   , 0x2,  +12, 1.0, 1.0, +0.9, 1.0, +0.0, 0x0002,    0, .99, 1.0,  0.0, 0.5, undef, undef, undef, undef],  # 03 bass
[1, "0x03", p   , 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000,   27, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 04 rythm/chords
[1, "0x04", p   , 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 05
[1, "0x05", p   , 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 06
[1, "0x06", p   , 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 07
[1, "0x07", p   , 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 08
[1, "0x08", p   , 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 09
[1, "0x09", p   , 0x9, +000, 1.0, 1.0, +0.5, 1.0, +0.0, 0x0001, 0x00, .99, 1.0,  0.0, 0.9, undef, undef, undef, undef],  # 0a percussion
[1, "0x0a", p   , 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 0b
[1, "0x0b", p   , 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 0c
[1, "0x0c", p   , 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 0d
[1, "0x0d", p   , 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 0e
[1, "0x0e", p   , 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef],  # 0f
[1, "0x0f", p   , 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, .99, 1.0,  0.0, 0.0, undef, undef, undef, undef]); # 10

my %DrumMap0 = (
#key      s   key+    dur* vel* vel+  rel* rel+
  -2 => [-1,    -7,   -12,  -9,   -8, -11,  -10],
  -1 => [ 1,    +0, -1/32, 1.0, +0.0, 1.0, +0.0], #def
  33 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #metronome
  35 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #BD2
  36 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0], #BD1
  38 => [ 1, undef, -1/16, 1.0, +0.0, 1.0, +0.0], #SD1
  42 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #CHH
  44 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #PHH
  46 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #OHH
  60 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #Bongo Hi
  61 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #Bongo Lo
  62 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #Conga Hi Mute
  63 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #Conga Hi Open
  64 => [ 1, undef, undef, 1.0, +0.0, 1.0, +0.0], #Conga Lo
);

#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => '*1.0+0.0', $GM::CCx07 => '*.5+0.0'});
Misc::InsertInstrumentNames(\@main::trks, \%MidiDebug::Prgs); $main::trks[1][0] = undef;
Misc::AssignDrumMap(\@main::trks, 1+1+0x9, \%DrumMap0);
Misc::State2Param(\@main::trks);

#$main::trks[15][12+1] = 1.0;

$s += Metronome::Generic(      \%main::out, 0x0a, $s,   1*$m->{-1}{5}/$m->{-1}{6}, .4); #pre counter
      Metronome::GenericWoMain(\%main::out, 0x0a, $s, 256*$m->{-1}{5}/$m->{-1}{6}, .0); #main counter

my ($PhrDir, $Phr) = ($main::WrkDir0, ''); if ($main::PrjDir0 !~ /$main::SrcDir0\/Projects/) { $PhrDir = $main::PrjDir0; }
if ($#ARGV >= 1) { $Phr = 'rec'; }

#$s += StyleTrax::LiveStyle($m, $s, "$PhrDir/*$Phr*", 60+0*12+1, 2, 1); #goto MyLabelEnd;

#$s += StyleTrax::LiveStyle($m, $s, "$main::SrcDir0/Midi/*20121008213928*", 60+1*12-3, 2, 1, \&main::Var0, -1^0b10000011111, 0, 0, 1.0, .5, 0); #goto MyLabelEnd;
#$s += StyleTrax::LiveStyle($m, $s, "$main::SrcDir0/Midi/*20121008213928*", 60+1*12-3, 2, 1, \&main::Var0, -1^0b10000011111, 0, 0, 1.0, .5, 0); goto MyLabelEnd;

#$s += StyleTrax::ChordStyle($m, $s, " 4( | 1/1:4g# 4B d# 4F# | ) ", \&main::Var0, -1^0b10000011111, 1.0, .5, 0); #


$s += Edit::Seq($m, 0, $s, 0, 0, " MLabel26 1/1:% MJump26 % ");

for (my $i=0; $i<=11; $i++) {
 $s += main::Var0($m, $s, 1/1, -1^0b10000001011, 60+$i, 2, 0, 1.0, .5, $i, 0/1, 0x200); $s += 1/1;
 $s += main::Var0($m, $s, 1/1, -1^0b10000001011, 60+$i, 3, 0, 1.0, .5, $i, 0/1, 0x300); $s += 1/1;
 $s += main::Var0($m, $s, 1/1, -1^0b10000000011, 60+$i, 3, 0, 1.0, .5, $i, 0/1, 0x400); $s += 1/1;
 }

#===============================================================================
sub Var0 { my ($m, $s, $l, $msk, $key, $chord, $inv, $von, $vof, $ci, $so, $p0) = Tools::GetVarPars(@_); if ((caller(1))[3] =~ /Live/) { ($von, $vof) = (1, .5); }

my $scale = $chord; if ($scale >= 2) { $scale = (($scale-2)&1)+2; } #-1..3

if ($msk>> 2&1) { MIDI::InsertText($m, 2, $s, 1, sprintf("%s", Tools::GetNoteName($key, $scale, $inv)), 5, " -> ", 1); }

my $ScS = 0; #($key, $scale, $ScS) = Tools::Chromatic2Scalar(Tools::KeySig2Scale($main::out{-1}{7}, 5), $key, $scale);

if ($key < 0)                           { $msk &= 0b00000010000000001; } #unrecognized chords -> mask melodic tracks + chord line
 elsif (($scale != 2) && ($scale != 3)) { $msk &= 0b00000010000000101; $scale = 3; } #unsupported scales -> mask melodic tracks

my %SymbolTable = ('o'=>$Chord::c, 'v'=>'.8_> (b:^2 b:^2-1)', '^'=>'.8_> (b:^2 b:^2+1)');

my %SymbolTable1 = ('o'=>'0', '0'=>'0', '1'=>'-1', '2'=>'-2', '3'=>'-3', '4'=>'4', '7'=>'7');

my $cs = $Chord::c; if ($inv == 1) { $cs = $Chord::c4; } elsif ($inv == 2) { $cs = $Chord::c7; }
my $ps = $Percussion::p;
my $bs = "|x.77|x.77|x.77|x2x2|"; $bs =~ s/\./>/g;
my $rs = "|x.x8|x..^|x.8.|x..v|"; $rs =~ s/\./>/g;

if ($msk>> 2&1) { Edit::Seq($m,  2, $s, [$key+0*12, $ScS], $scale, "1/_1_:% $cs", .3*$von, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 3&1) { Edit::Seq($m,  3, $s, [$key-2*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($bs, \%SymbolTable1), .5*$von, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 4&1) { Edit::Seq($m,  4, $s, [$key+0*12, $ScS], $scale, "<1/16:%".Edit::PreProc0($rs, \%SymbolTable ), .2*$von, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>10&1) { Edit::Seq($m, 10, $s,                 0,      0, "1/_4_:__$ps", .2*$von, .5, 0,0,1, 1,1, 1,-1/16, $l); }

MIDI::InsertText($m, 0, $s+0/1, 0, sprintf("Label0x%x", $p0+$ci));
MIDI::InsertText($m, 0, $s+ $l, 1, sprintf("Jump0x%x" , $p0+$ci));

return($l); }
#===============================================================================

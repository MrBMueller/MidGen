
use playsmf; use GM; use GS; use RolandRd600; use Metronome; use Tools;

if (not(defined($Chord::c     ))) { eval("use Chord;"     ); }
if (not(defined($Arpeggio::a  ))) { eval("use Arpeggio;"  ); }
if (not(defined($Bass::b      ))) { eval("use Bass;"      ); }
if (not(defined($Percussion::p))) { eval("use Percussion;"); }

printf("Perl: $^V ($])\n");

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96}); my $B = 1/1; my $t = 0/$B; my $m = \%main::out; #general output setup

use constant { u=>undef, p=>0x00 };

$MidiDebug::Prgs{&p} = {%RolandRd600::PatchNames};

#playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  8, 0x8000); #overwrite: enable record
playsmf::OverrideCmdLineArgs($m, 0, $t, 0,  9, 0x7fffa199); #overwrite: sync
#playsmf::OverrideCmdLineArgs($m, 0, $t, 0, -1, 0x5ffff); #append: enable text output

my $dt = 1/32;

$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x00, 0x00, 0x00, 0x00) + $dt; #System common

#default - all off
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x00, 0x00, 1, 0, 0, u, 0,0,0, 0,1,0) + $dt; #Temporary setup - Setup common

#turn internal off
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x10, 0x00) + $dt; #Temporary setup - Local part (INT U)
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x11, 0x00) + $dt; #Temporary setup - Local part (INT L)

#turn Tx off
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x12, 0x00) + $dt; #Temporary setup - Local part (Tx U)
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x13, 0x00) + $dt; #Temporary setup - Local part (Tx L)


#assign internal U/L to part (channel) x,y
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x10, 0x0c, 0x2) + $dt; #Temporary setup - Local part (INT U)
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x11, 0x0c, 0x3) + $dt; #Temporary setup - Local part (INT L)

#turn local Tx U on and set transmit channel (typ. 0)
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x12, 0x05, 1, 0, 1,1,1,1,1, 0, 1, u, u, 1) + $dt; #Temporary setup - Local part (Tx U)

$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x01, 0x00, 0x30, 0x00, 5,99,99,17,0, 1,0,0,0,0,0) + $dt; #Temporary setup - Effect (Reverb, Chorus)

$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x03, 0x00, 0x00, 0x00) + $dt; #Tone

my $p0 = 32; my $p1 = 100;
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x03, $p0, 0x00, 0x0b,  0x06, 127, 64, 64) + $dt; #Tone - apply EFX
$t += RolandRd600::DT1SysExDefault($m, 0, $t, 1, 0x03, $p1, 0x00, 0x0b,  0x07, 127, 64, 64) + $dt; #Tone - apply EFX


@main::InitParams = (undef, $t);

@main::trks = ([-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -6, $GM::CCx07, $GS::CCx5b, $GS::NRPNx0120]);

#                   s   name   port  chn  key+  dur* vel* vel+  rel* rel+   prg  vol  rev)    # track
push(@main::trks, ([1, "Ctrl", 0x00                                                      ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  $p0, 1.0, 0.7],   # 01
                   [1, "0x01", 0x00, 0x1, +000, 1.0, 1.0, +0.0, 1.0, +0.0,  $p1, 1.0, 0.7],   # 02
                   [1, "0x02", 0x00, 0x2, +000, 1.0, 1.0, +0.0, 1.0, +0.0,   54, 1.0, 0.9],   # 03
                   [1, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.8],   # 04
                   [1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 05
                   [1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.5],   # 06
                   [1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 07
                   [1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 08
                   [1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 09
                   [1, "0x09", 0x00, 0x9, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x7d,  .4, 0.9],   # 0a
                   [1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.0],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x00, 1.0, 0.7])); # 10

Edit::Seq($m, 10, 3/4, 0, 0, " 1/4:36 "); #ready signal

$t = Edit::Seq($m, 0, 0, 0, 0, " $t:% |$B:% | MLabelx17 $B:% MJump-4 | ") + 1*$B;

$t += Var0($m, $t, 0b10000000000, 60, 4, 1) + 1*$B;

my $L = $t-(1/2)*$B;

$t += Var0($m, $t, ~0b110, 60, 2, 1) + 1*$B;
$t += Var0($m, $t, ~0b110, 60, 3, 1) + 1*$B;

my $R = $t-(1/2)*$B;

for (my $i=1; $i<=11; $i++) { $t += Tools::CopyRegion($m, $t-(1/2)*$B, $L, $R-$L, $i-12*($i>6), \@main::trks) + (0/1)*$B; }

Metronome::Generic($m, 10, 1*$B, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2]+0*$B, .2, u, u, 0, 1, 33); #main counter

Edit::Seq($m, 1, (Edit::Quantize(MIDI::GetEndTime($m, undef)/($m->{-1}{3}*4), $B))[2], 0, 0, sprintf(" $B:%% MLabelx%x <:%%_C$GM::CCx7a\_$GM::CCon ", 0x18)); #

for (my $i=0; $i<=127; $i++) { my @Syx = @{$RolandRd600::SysExDefault{0x03000000+($i<<16)}};
 my ($EfxType, $EfxLevel, $EfxP0, $EfxP1) = ($Syx[0xb], $Syx[0xc], $Syx[0xd], $Syx[0xe]); my @EFX = @{$RolandRd600::EFX[$EfxType]};
 #printf("%02x %02x %02x %02x %02x '%s' '%s'\n", $i, $EfxType, $EfxLevel, $EfxP0, $EfxP1, $MidiDebug::Prgs{&p}{0xc}{-1}{-1}{$i}, $EFX[0]);
 }

#===============================================================================
sub Var0 { my ($m, $t, $msk, $key, $scale, $v) = @_; my $t0 = $t; my ($l, $k) = (1/1, 0);

my %SymbolTable = ('o'=>$Chord::c, 'v'=>'.8_> (b:^2 b:^2-1)', '^'=>'.8_> (b:^2 b:^2+1)');

my %SymbolTable1 = ('0'=>"0", '2'=>"2", '7'=>"7");

my $cs = $Chord::c;
my $as = $Arpeggio::a;
my $bs = $Bass::b;
my $ps = $Percussion::p;
my $rs = " |x.x8|x..^|x.8.|x..v| "; $rs =~ s/\./>/g; $rs = Edit::PreProc0($rs, \%SymbolTable);

$bs = " |0070|0700|2002|0000| "; $bs =~ s/\./>/g; $bs = Edit::PreProc0($bs, \%SymbolTable1);

Edit::Seq($m, 0, $t, 0, 0, sprintf(" MLabelx%x ", $scale*0x100));

#if ($msk>> 1&1) { Edit::Seq($m,  1, $t, $key-0*12, $scale, " 1/_1_:$k\_$cs "  , 1.0*$v, .5, 0,0,1, 1,1, 1,1, $l); }
#if ($msk>> 2&1) { Edit::Seq($m,  2, $t, $key-0*12, $scale, " 1/_8_:$k\_$as "  , 1.0*$v, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>> 3&1) { Edit::Seq($m,  3, $t, $key-2*12, $scale, " 1/16:$k\_$bs "         ,  .5*$v, .5, 0,0,1, 1,1, 1,1, $l);
				  #Edit::Seq($m,  3, $t, $key-2*12, $scale, " 2/1:Cx4a_-2_0_.5_.3_0 ", 1.0   , .5, 0,0,1, 1,1, 1,1, $l);
				  Edit::Seq($m,  3, $t, $key-2*12, $scale, " 1/1:C$GS::NRPNx0120\_-2_0_.5_.3_0 ", 1.0   , .5, 0,0,1, 1,1, 1,1, $l);
 }

#if ($msk>> 4&1) { Edit::Seq($m,  4, $t, $key-0*12, $scale, " 1/16<:$k\_% $rs ", 1.0*$v, .5, 0,0,1, 1,1, 1,1, $l); }

if ($msk>>10&1) { Edit::Seq($m, 10, $t,    0     ,      0, " 1/_4_:____$ps "  ,  .7*$v, .5, 0,0,1, 1,1, 1,-1/16, $l); }

$t += $l;

Edit::Seq($m, 0, $t, 0, 0, sprintf(" MJump-4 "));

return($t-$t0); }
#===============================================================================

use strict; use warnings; eval("use KX; use GM; use GS; use MMC; use Chord; use Arpeggio; use Percussion; use Bass; use Examples0; use Package0; use Tutorial; use DoReMix;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

my $Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs);
#KX::GetFileNames("E:/INSTR", ".sf2");

#              track status       name       port      chn       bank      patch        vol        exp            pan     reverb        f-res        f-co            PBS             PB      #arr. setup
%main::trks = (0x00=>{-1=>1, -2=>"Ctrl", -3=>0x00                                                                                                                                        },  #
               0x01=>{-1=>1, -2=>"0x00", -3=>0x00, -4=>0x0, -5=>0x0006, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x02=>{-1=>1, -2=>"0x01", -3=>0x00, -4=>0x1, -5=>0x0002, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x03=>{-1=>1, -2=>"0x02", -3=>0x00, -4=>0x2, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x04=>{-1=>1, -2=>"0x03", -3=>0x00, -4=>0x3, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x05=>{-1=>1, -2=>"0x04", -3=>0x00, -4=>0x4, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x06=>{-1=>1, -2=>"0x05", -3=>0x00, -4=>0x5, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>    0},  #
               0x07=>{-1=>1, -2=>"0x06", -3=>0x00, -4=>0x6, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x08=>{-1=>1, -2=>"0x07", -3=>0x00, -4=>0x7, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x09=>{-1=>1, -2=>"0x08", -3=>0x00, -4=>0x8, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0a=>{-1=>1, -2=>"0x09", -3=>0x00, -4=>0x9, -5=>0x0000, -6=>  25, 0x07=> .5, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #percussion
               0x0b=>{-1=>1, -2=>"0x0a", -3=>0x00, -4=>0xa, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0c=>{-1=>1, -2=>"0x0b", -3=>0x00, -4=>0xb, -5=>0x0000, -6=>  50, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0d=>{-1=>1, -2=>"0x0c", -3=>0x00, -4=>0xc, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0e=>{-1=>1, -2=>"0x0d", -3=>0x00, -4=>0xd, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x0f=>{-1=>1, -2=>"0x0e", -3=>0x00, -4=>0xe, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef},  #
               0x10=>{-1=>1, -2=>"0x0f", -3=>0x00, -4=>0xf, -5=>0x0000, -6=>0x00, 0x07=>1.0, 0x0b=>1.0, 0x2000a=> 0.0, 0x5b=>0.5, 0x47=>undef, 0x4a=>undef, 0x4000=>undef, 0x20104=>undef}); #

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

#Examples0::Var0(\%main::out, $s);

#my $c0 = $Chord::c;

#Edit::Seq(\%main::out, 1, undef, undef, undef, $s, 60-0*12, 3, "32(1/1:0$Arpeggio::a0 -2$Arpeggio::a0 -1$Arpeggio::a0 Tx2_7$Arpeggio::a1)");

#Edit::Seq(\%main::out, 1, undef, undef, undef, $s, 60-0*12, 3, " 32(4/1:C-1_2_1_0_1) ");

#Edit::Seq(\%main::out, 0xc, undef, undef, undef, $s, 60-0*12, 3, " 32(1/1:0$c0 -2$c0 -1$c0 0$c0) ", .1);

#Edit::Seq(\%main::out, {-1=>1, 0=>2, 1=>3}, undef, undef, undef, $s, 60+1*12, 3, " 8([1/16:0] [^2] ^2 15/16:%) ",1,.5, undef,undef,undef, -.1,1/16,.9, 1,1, 1,1, undef, 3);

Chords(\%main::out, 0xc, $s);

#my $PhraseDir = "$main::PrjDrive/Midi2/PHRASE/";
#$s += DoReMix::InsertPhrase(\%main::out, 10, $s, "$PhraseDir/HOUSE/HSDR8100.MID", undef, undef, undef, 1/32);

$s += Percussion::HSDR8100(\%main::out, 10, $s, 8*(4/1));

#MMC::Stop(\%main::out, 0x00, MIDI::GetEndTime(\%main::out)/($main::out{-1}{3}*4)+1/1); #stop+rewind
#MMC::Stop(\%main::out, 0x00, $s+1/1); #stop+rewind
Edit::AddLyricString(\%main::out);

#===============================================================================
sub Chords { my $m = shift(@_);
my $t =  0x0a; if ($#_ >= 0) { $t = shift(@_); }
my $s =     0; if ($#_ >= 0) { $s = shift(@_); } my $start = $s;
my $l = undef; if ($#_ >= 0) { $l = shift(@_); }

my $c0 = $Chord::c;
my $c1 = $Chord::aug;
my $c2 = $Chord::sus2;
my $c4 = $Chord::c4;
my $c5 = $Chord::c5;
my $c6 = $Chord::c6;

Edit::Seq($m, 0xc, undef, undef, undef, $s, 60-0*12, 3, " 4(1/1:0$c0 2$c4 -1$c0 0$c0 1/1:0$c0) ", .3, .5, 0,0,0,0,0,1,1,1,1, 1, $l, 0x7);

#Edit::Seq($m, 0xc, undef, undef, undef, $s, 60-0*12, 3, " 2(2/1:0$c4 -3$c0 -1$c4 -4$c5) ", .3);

my $ChordRythmV0 = "($c4 % $c4 $c4 % $c4 % /2:$c4    $c4)";
my $ChordRythmV1 = "($c4 % $c4 $c4 % $c4 % /2:$c4    $c6)";
#Edit::Seq($m, 0x4, undef, undef, 100, $s, 60+1*12, 3, " 2( 1/8<:0_% $ChordRythmV1 $ChordRythmV0 <:-3_% 2( $c0 % $c0 $c0 % $c0 % /2:$c0 $c0 ) ) ");

my $ChordSeq0 = "$c0 % $c0 % 2($c0) % /:$c0 $c0"; #8 timeunits
my $ChordSeq1 = "$c1 % $c1 % 2($c1) % /:$c1 $c1";
my $ChordSeq2 = "$c2 % $c2 % 2($c2) % /:$c2 $c2";

#Edit::Seq($m, 1, undef, undef, undef, $s, 60+12, 3, " 2( 2(1/8:0$ChordSeq0) 2(1/8:0$ChordSeq1) 2(1/8:^2$ChordSeq0) 1(1/8:0$ChordSeq2) 1(1/8:-1$ChordSeq0) ) ", .3, .5, 0,0,0,0,0,1,1,1,1, 1, $l);

my $b0 = $Bass::b0;

#Edit::Seq($m, 0xb, undef, undef, undef, $s, 60-1*12, 3, " 4*4(1/8:0$b0) 2*4(1/8:^2$b0) 1*4(1/8:0$b0) 1*4(1/8:-1$b0) ", .5, .5, 0,0,0,0,0,1,1,1,1, 1, $l);

#Edit::Seq($m, 1, undef, undef, undef, $s, 60-1*12, 3, " 1/16:4 v |1/1:^ ", .3);

my $var0 = " | <1/2<:% 1/8:-1 0 2 3 | 1/2:4 1/8:% 1/4:v       1/8:v | 3/4:4 1/4:% | 1/4:3       1/8:2 1/4:3 1/4:4 1/8:% | 1/4:3 /2:2 |1/1:0 | 1/1:% | ";
my $var1 = " | <1/2<:% 1/8:-1 0 2 3 | 1/2:4 1/8:% 2{1/16:3 %} 1/8:v | 3/4:4 1/4:% | 2{1/16:3 %} 1/8:2 1/4:3 1/4:4 1/8:% | 1/4:3 /2:2 |1/1:0 | 1/1:% | ";

      Edit::Seq($m, 1, undef, undef, undef, $s+0/32, 60+0*12, 3, " 2(1($var0) 1($var1)) ", .7, .5, 0,0,0,0,0,1,1,1,1, 1.1);
#$s += Edit::Seq($m, 2, undef, undef, undef, $s+1/32, 60+1*12, 3, " 2(1($var0) 1($var1)) ");

#portamento modi (-2 push to note, -1 pull to note, 0 flat notes without melting, 1 flat/melt notes but keep equals seperate, 2 flat/melt all notes)
$main::trks{0x01}{0x4000} = Edit::Portamento($m, 1, 1/4, -0, undef, undef, 0x104, 4, undef, undef);

#my $bass0 = "<1/8<:% /:-3 -1 | 1/4:0 . /:. *:. /4:-1 0 | 1/4:2 . /:. *:. /4:> 0 | 1/4:-1 . /:. *:. /4:-3 -1 | 1/4:0 . /:. *:. /4:-3 -1 | 1/4:0 . /:. *:. /4:% % | ";

#my $bass0 = " | 5{1/8:0 1/16:.} . | 5{1/8:2 1/16:.} . |  5{1/8:-1 1/16:.} . | 5{1/8:0 1/16:.} . | 5{1/8:0 1/16:.} . | ";

my $bass0 = " | 3{1/8:0 1/16:. . .} . | 3{1/8:2 1/16:. . .} . | 3{1/8:-1 1/16:. . .} . | 3{1/8:0 1/16:. . .} . | 3{1/8:0 1/16:. . .} . | ";

Edit::Seq($m, 2, undef, undef, undef, $s+0/32, 60-0*12, 3, " 8($bass0) ");

return(0); }
#===============================================================================

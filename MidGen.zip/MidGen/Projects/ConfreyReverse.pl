use strict; use warnings; eval("use Percussion;"); $MIDI::ContCtlRes = -10; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

splice(@{$main::trks[0]}, 4, 0, -7, -8); #insert/append inspector params

#                   s   name   port  chn  key+  vel+    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 01
                   [1, "0x01", 0x00, 0x1, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 02
                   [1, "0x02", 0x00, 0x2, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03
                   [1, "0x03", 0x00, 0x3, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, +000, +0.0, 0x0000, 0x00, 0.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, +0.0, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

my %test1 = MIDI::Read("$main::SrcDir0/Midi/ZezConfreyMyPet.mid"); Edit::QuantizeTrk(\%test1, undef, 0/64, -0/64, 0, $main::out{-1}{4}/$test1{-1}{4}, $main::out{-1}{3});

(undef, my $length0) = Edit::Copy(\%main::out, 98, \%test1, 1, 0x9, undef, undef, 0, 0, undef, 0, 1,0, 1,0, undef);
(undef, my $length1) = Edit::Copy(\%main::out, 99, \%test1, 2, 0x9, undef, undef, 0, 0, undef, 0, 1,0, 1,0, undef);

Edit::Copy(\%main::out, 1, \%main::out, 98, 0x9, undef, undef, 0, -($length1+1/1), undef, 0, 1,0, 1,0, -0);
Edit::Copy(\%main::out, 2, \%main::out, 99, 0x9, undef, undef, 0, -($length1+1/1), undef, 0, 1,0, 1,0, -0);

MIDI::InsertText(\%main::out, 0x00, $length1+1/1, 0, "here"); delete($main::out{98}); delete($main::out{99});

#===============================================================================

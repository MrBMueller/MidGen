use strict; use warnings; eval("use KX; use GM2; use RolandHp302; use Ctrl; use Chord; use Arpeggio; use Percussion; use Bass; use Brainstorm; use DrumMaps; use Misc; use Tools;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>120.00, 5=>4, 6=>4, 7=>-3}); my $s = 0/1; my $m = \%main::out; #general output setup

Misc::InsertCopyright(\%main::out);

#GM2::GMSystem(\%main::out, 0x00, $s, 1, 0x03); #
GS::Reset(\%main::out, 0x00, $s, 1, 0x00); #

#GS::System(\%main::out, 0x00, $s+1/4, 1, undef, 1.0, undef, undef); #

GS::Reverb(\%main::out, 0x00, $s+1/4, 1, undef, 0x04, undef, 0x3f, 0x3f); #
#GS::Chorus(\%main::out, 0x00, $s+1/4, 1,  0x03, undef, 0x6f, 0x08, 0x50, 0x03, 0x3f); #

#RolandHp302::ScaleTuning(\%main::out, 0x00, $s+2/4, 1, -0x0001, 0, @RolandHp302::ScaleArab); #Equal, Just, Arab

my $mv = 0.0; @main::InitParams = (undef, 1/4); $MidiDebug::Prgs{0x00} = {RolandHp302::ImportPatchNames()};

sub patch { return(@{$RolandHp302::Patches{shift(@_)}{shift(@_)}}); } my @patch0 = patch(4,15); my @patch1 = patch(4,245);

@main::trks = ([-1, -2, -3, -4, -7, -12, -9, -8, -11, -10, -5, -6, $GM::CCx07, $GM::CCx0b, $GM::cCCx0a, $GS::CCx5b, $GS::CCx5d, $GM::RPN_0, $GM::cPB, $KX::CCx47, $KX::CCx4a, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9]);

#                   s   name   port  chn  key+  dur* vel* vel+  rel* rel+    bank   prg  vol      exp   pan  rev  chr   PBS     PB   frs(0) fco(1)    # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                                                              ],   # 00
                   [1, "0x00", 0x00, 0x0, +000, 1.0, 1.0, +0.0, 1.0, +0.0,      @patch0, 1.0+$mv, 1.0,  0.0, 0.7, 0.0, undef, undef, undef, undef],   # 01 live
                   [1, "0x01", 0x00, 0x1,  -12, 1.0, 1.0, +0.5, 1.0, +0.0, 0x0000,   38,  .7+$mv, 1.0,  0.0, 0.5, 0.0, undef, undef, undef, undef],   # 02 bass
                   [1, "0x02", 0x00, 0x2,  +12, 1.0, 1.0, -0.4, 1.0, +0.0,  patch(4,19), 0.6+$mv, 1.0,  0.0, 0.7, 0.0, undef, undef, undef, undef],   # 03 harmonics/pad
                   [0, "0x03", 0x00, 0x3, +000, 1.0, 1.0, +0.3, 1.0, +0.0, 0x0000,   27, 1.0+$mv, 1.0,  0.0, 0.5, 0.0, undef, undef, undef, undef],   # 04 rythm/chords
                   [1, "0x04", 0x00, 0x4, +000, 1.0, 1.0, -0.2, 1.0, +0.0,      @patch0, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.9, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, +000, 1.0, 1.0, +0.2, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.5, 0.0, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, +000, 1.0, 1.0, +0.0, 1.0, +0.0, 0x0000, 0x00, 1.0+$mv, 1.0,  0.0, 0.0, 0.0, undef, undef, undef, undef])); # 10

Misc::State2Param(\@main::trks);
#Misc::SetGroupedTrkValues(\@main::trks, undef, {-8 => 1.0, $GM::CCx07 => 1.0});
Misc::InsertInstrumentNames(\%main::out, \@main::trks, \%MidiDebug::Prgs, $s);

Edit::Seq($m, 1, undef, undef, undef, $s+1/2, 0, 0, " <:%_C$GM::CCx7a\_$GM::CCoff "); #local control

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .2); #main counter

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 6, " 1/8:0 1 2 3 4 5 6 7 % 7 6 5 4 3 2 1 0 ", .5); #

#goto MyLabelEnd;

my $r = 0; eval("use Style1;"); my $split = 60+0*12+1; my $Phrase = './*'; $Phrase = "$main::SrcDir0/Midi/*20130616142811*";

for (1..1) { #MIDI::InsertText(\%main::out, 0, $s, 0, sprintf("%d", $_), 6, " -> ", 1);

         Brainstorm::InsertPhrase(\%main::out,  5, $s, $Phrase, undef, 1/128, -1/128, 0, ">=$split",   0, 0, 1.0, 0, .5);
         Brainstorm::InsertPhrase(\%main::out,  3, $s, $Phrase, undef, 1/128, -1/128, 0,  "<$split",   0, 0, 1.0, 0, .5);
my $bs = Brainstorm::InsertPhrase(\%main::out,  1, $s, $Phrase, undef, 1/128, -1/128, 0,      undef,   0, 0, 0.0, 0, .5); #printf("$bs\n");

(undef, undef, $bs, undef, undef, undef) = Edit::Quantize($bs, 1/1); $s += $bs; if (!$bs) { $s += Style0::Var0($m, $s, 128/1,  0, 0xf); $r++; }} #goto MyLabelEnd;

Tools::QuantizeChords(\%main::out, 3, undef, 1/32, 1/16, 1/2, 1/2, 1); #goto MyLabelEnd;

my %RecChords = Tools::GetChords(\%main::out, 3); Tools::ReduceChords(\%RecChords); Tools::PrintChords(\%main::out, \%RecChords); #goto MyLabelEnd;

foreach my $start (sort {$a <=> $b} keys(%RecChords)) { my ($ints, $note, $crd, $inv, $length, $MidiNote) = @{$RecChords{$start}};
 if     (($crd == 2) || ($crd == 3)) { Style0::Var0($m, $start, $length,  0, 0x5, 60+$note, $crd); }
  elsif  ($crd == 4)                 { Style0::Var0($m, $start, $length,  0, 0xd, 60+$note,    3); }
  else                               { Style0::Var0($m, $start, $length,  0, 0xf, 60+$note,    3); }
 }

#===============================================================================

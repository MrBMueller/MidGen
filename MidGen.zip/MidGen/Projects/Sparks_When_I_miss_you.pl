use strict; use warnings; eval("use KX; use GM; use GS; use MMC; use BrotherGregory; use Chord; use Arpeggio; use Percussion; use Bass;"); $MIDI::ContCtlRes = -1; $main::DummyNop = 0/1;

my $Bank = 0x0001; #drum
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/WavItGld/Drumkits/Beat.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{0x00} = 'BeatKit';

$Bank = 0x0002; #bass
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = "E:/INSTR/WavItGld/BassSynt/EMUBas_M.sf2";                                                             #  1.400.818   Tue Mar 27 23:07:50 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/BrsBas_M.sf2";                                                             #  1.420.116   Tue Mar 27 23:07:48 2001
$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/BassSynt/DetBass_M.sf2";                                                            #  1.692.962   Tue Mar 27 23:07:50 2001

$Bank = 0x0003; #pad
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\JMJPad_L.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\Attpad_M.sf2';
$MidiDebug::Prgs{0x00}{0xc}{ -1}{$Bank}{  -1} = 'E:\INSTR\WavItGld\SynPads\PercPd_M.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Choir/Choir_M.sf2";                                                                 #  1.397.100   Tue Mar 27 23:09:16 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/StrEns/Bigstr_L.sf2";                                                               #  3.254.864   Tue Mar 27 23:12:04 2001

$Bank = 0x0004;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  -1} = 'E:/INSTR/SBK/Cdrom1.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x00} = 'NYLGUIT';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x01} = 'HARPS2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x02} = 'GUIT2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x03} = 'Banjo';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x04} = 'ORGAN';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x05} = 'TUBELL';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x06} = 'TOM';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x07} = 'BD';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{0x08} = 'CELLO';

$Bank = 0x0005;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ -1} = 'E:/INSTR/SBK/Notre.sf2';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{  0} = 'MIDI_PNO';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 19} = 'NTRDAME';
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{ 51} = 'M_STR5';

$Bank = 0x0006;
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/PC/analog/Juno_FAT.sf2";                                                           #    494.914   Sun Sep 14 01:38:18 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Soundfont_CD_Gold/DEVCD/FLUTE__L.SF2";                                                       #  1.707.026   Thu Jul 20 06:22:04 1995
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/SBK/Test.sf2";                                                                               #     66.182   Wed Mar 28 21:28:28 2001 - Jarre Harpsichord
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/New/gothorgn.sf2";                                                                           #    800.434   Wed Mar 28 21:25:40 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItMic/WIND/PANFLUTE.SF2";                                                                 #    454.972   Thu Feb  6 12:05:38 1997
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/WavItGld/Woodwind/Panflu_S.sf2";                                                             #    458.478   Tue Mar 27 23:12:32 2001
#$MidiDebug::Prgs{0x00}{0xc}{-1}{$Bank}{-1} = "E:/INSTR/Iufdjf_cd/Emu_3/world/Pan Flute.sf2";                                                        #    311.194   Mon Nov 30 13:36:34 1998

%main::out = (-1=>{0=>$main::OutFile, 1=>1, 3=>96, 4=>138.00, 5=>4, 6=>4, 7=>-0}); my $s = 0/1; #general output setup

MMC::Stop(\%main::out, 0x00, $s, 1, 0x60, 0, 0, 0, 0); #stop+rewind
#MMC::Rec(\%main::out, 0x00, $s+1/2, 0);

#KX::SetSynthVolume(\%main::out, 0x00, $s, 0, 0.9); #device setup
KX::LoadSoundFonts(\%MidiDebug::Prgs);
#KX::GetFileNames("E:/INSTR", ".sf2");

push(@{$main::trks[0]}, $AWE::cNRPN_21, $AWE::cNRPN_22, $SF201::cNRPN_8, $SF201::cNRPN_9); #append inspector params

#                   s   name   port  chn    bank   prg  vol  exp   pan  rev   res    fco    PBS     PB      # arr. setup
push(@main::trks, ([1, "Ctrl", 0x00                                                                    ],   # 00
                   [1, "0x00", 0x00, 0x0, 0x0000,  100, 1.0, 1.0,  0.0, 0.5, undef, undef, undef, undef],   # 01
                   [1, "0x01", 0x00, 0x1, 0x0003, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 02
                   [1, "0x02", 0x00, 0x2, 0x0000,   54, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 03
                   [1, "0x03", 0x00, 0x3, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 04
                   [1, "0x04", 0x00, 0x4, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 05
                   [1, "0x05", 0x00, 0x5, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 06
                   [1, "0x06", 0x00, 0x6, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 07
                   [1, "0x07", 0x00, 0x7, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 08
                   [1, "0x08", 0x00, 0x8, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 09
                   [1, "0x09", 0x00, 0x9, 0x0001, 0x00, 1.0, 1.0,  0.0, 0.2, undef, undef, undef, undef],   # 0a percussion
                   [1, "0x0a", 0x00, 0xa, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0b
                   [1, "0x0b", 0x00, 0xb, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0c
                   [1, "0x0c", 0x00, 0xc, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0d
                   [1, "0x0d", 0x00, 0xd, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0e
                   [1, "0x0e", 0x00, 0xe, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef],   # 0f
                   [1, "0x0f", 0x00, 0xf, 0x0000, 0x00, 1.0, 1.0,  0.0, 0.0, undef, undef, undef, undef])); # 10

$s += Percussion::Metronome(\%main::out, 0x0a, $s,   1/1, .4); #pre counter
      Percussion::Metronome(\%main::out, 0x0a, $s, 128/1, .3); #main counter

Seq0(\%main::out, $s);

#$s += Percussion::HSDR8100(\%main::out, 10, $s, 8*(4/1));

#MMC::Stop(\%main::out, 0x00, MIDI::GetEndTime(\%main::out)/($main::out{-1}{3}*4)+1/1); #stop+rewind
#MMC::Stop(\%main::out, 0x00, $s+1/1); #stop+rewind
#Edit::AddLyricString(\%main::out);

#===============================================================================
sub Seq0 { my $m = shift(@_);
my $s = 0; if ($#_ >= 0) { $s = shift(@_); }

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, "  ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 16( 1/1:C$BrotherGregory::CCx05\_2_0_.5_.5 ) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 16( 1/1:C$BrotherGregory::CCx0b\_2_0_.5_.5 ) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 16( 1/1:C$BrotherGregory::CCx0c\_2_0_.5_.5 ) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 16( 1/1:C$BrotherGregory::CCx0d\_2_0_.5_.5 ) ");

#Edit::Seq($m, 1, undef, undef, undef, $s, 60, 3, " 16( 1/1:C$BrotherGregory::PB\_2_0_.5_.5 ) ");

#for (my $t=1; $t<=16; $t++) { Edit::Seq($m, $t, undef, undef, undef, $s+($t-1)*1/16, 60, 3, " 32( 1/2:Cx7_2_0_.5_.5 ) "); }

#my $t1 = " 1/8    1/16    1/16 ";
#my $e1 = " >_1.0  >_.5    >_.9 ";

#my $p1 = Edit::MergeGroove($t1, $e1, '.', '.'); $p1 = "$p1 0:v7 $p1";

#Edit::Seq($m, 1, undef, undef, undef, $s , 60-12*1, 3, " 4( 4($p1) 0:v4 2($p1) 0:^ 2($p1) ) ");

my $ms0 = "0_M0 7 v ^";
my $ms1 = "0_M1 4 v ^";
my $ms2 = "0_M2 3 v ^";

my $ms0v1 = "(<1/16:0) 0_M2v1 7 v ^";

my $ms3 = "(1/4:9 1/8+:7 1/8-:%)";

my $ms3v1 = "(1/4:9 7)";

my $s1 = $s + Edit::Seq($m, 1, undef, undef, undef, $s , 60+0*12, 3, " 1/8<:% 2($ms0 $ms1 $ms2 $ms1 $ms0 $ms3 $ms0v1 $ms3v1) ", .3);

Edit::Seq($m, 1, undef, undef, undef, $s , 60-1*12, 3, " 1/8<:% 2($ms0 $ms1 $ms2 $ms1 $ms0 $ms3 $ms0v1 $ms3v1) ", .3);
Edit::Seq($m, 1, undef, undef, undef, $s , 60+1*12, 3, " 1/8<:% 2($ms0 $ms1 $ms2 $ms1 $ms0 $ms3 $ms0v1 $ms3v1) ", .3);

Edit::Seq($m, 10, undef, undef, undef, $s , 0, 0, " 128(1/4:36_.9 .5 .8 .4) ", .2, .5, undef, undef, undef, 0,0, 1,1,1,1,1, 64/1); #BD

#Edit::Seq($m, 10, undef, undef, undef, $s , 42, 0, " 1/16<:% 128{|x.3.|} ", .5, .5, undef, undef, undef, 0,0, 1,1,1,1,1, 64/1); #CHH
#Edit::Seq($m, 10, undef, undef, undef, $s , 44, 0, " 1/16<:% 128{|.5.3|} ", .5, .5, undef, undef, undef, 0,0, 1,1,1,1,1, 64/1); #PHH

Edit::Seq($m, 10, undef, undef, undef, $s , 42, 0, " 1/8:0 [(1/32++:%) >] % > . . . . . ", .1, .5, undef, undef, undef, 0,0, 1,1,1,1, {42=>-1/32}, 64/1); #CHH swing (delayed 2nd 8th)

#Edit::Seq($m, 4, undef, undef, undef, $s , 60+1*12, 3, " <1/4<:% 1/8:0 2 1/4+:3 . 1/8:3 5 1/4+:6 . 1/8:6 5 1/4:6 . . 7 1/4+:6 5 1/8:0 3 1/4+:5 . 1/8:6 5 1/4+:4 . 1/8:. . 1/4+:. 1/8:.     1/4:0 2 1/1:3 ");

Edit::Seq($m, 4, undef, undef, undef, $s1+0/64 , 60+0*12, 3, " <1/4<:% 2(1/8:0 2 | 1/4+:3 . 1/8:3 5 | 1/4+:6 . 1/8:6 5 | 1/4:6 . . 7 | 1/4+:6 5 1/8:0 3 | 1/4+:5 . 1/8:6 5 | 1/4+:4 . 1/8:. . | 1/4:. . . 0 | 3/4:2) ");

Edit::Seq($m, 4, undef, undef, undef, $s1+1/64 , 60+1*12, 3, " <1/4<:% 2(1/8:0 2 | 1/4+:3 . 1/8:3 5 | 1/4+:6 . 1/8:6 5 | 1/4:6 . . 7 | 1/4+:6 5 1/8:0 3 | 1/4+:5 . 1/8:6 5 | 1/4+:4 . 1/8:. . | 1/4:. . . 0 | 3/4:2) ");

return(0); }
#===============================================================================

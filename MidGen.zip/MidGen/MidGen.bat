
echo off

%~d0

cd %~p0

cd .\mid\.

del /Q .\*.txt > nul 2>&1

rem optional argument: input perl script, else default ./Projects/Current.pl will be used
rem replace below path with your local perl installation
C:\BUF\strawberry-perl-5.40.2.1-64bit-portable\perl\bin\perl.exe ..\MidGen.pl %1

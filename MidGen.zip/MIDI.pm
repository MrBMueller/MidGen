use strict; use warnings; package MIDI;

our $ContCtlRes = -1; our %CtlCallBackRefs = ();

return(1);
#===============================================================================
sub RoundInt { if ($_[0] >= 0) { return(int($_[0]+.5)); } return(int($_[0]-.5)); }
#===============================================================================
sub InsertText {
my $h0    = shift(@_);
my $trk   = 0x0; if ($#_ >= 0) { $trk   = shift(@_); }
my $start =   0; if ($#_ >= 0) { $start = shift(@_); } my $s = int($start*$h0->{-1}{3}*4);
my $ep    =   0; if ($#_ >= 0) { $ep    = shift(@_); } my ($k2, $k3) = (0, $ep);
my $val   = "0"; if ($#_ >= 0) { $val   = shift(@_); } my $NewTxt = $val;
my $type  = 0x6; if ($#_ >= 0) { $type  = shift(@_); }
my $sep = undef; if ($#_ >= 0) { $sep   = shift(@_); } my $apd = 0; if (defined($sep)) { $apd++; } else { $sep = ""; }
                 if ($#_ >= 0) { $apd   = shift(@_); } my $event = undef;

if ($ep) { foreach my $k2 (sort {$b <=> $a} keys %{$h0->{$trk}{$s}}) { if (($h0->{$trk}{$s}{$k2}{0} == 0xff) && ($h0->{$trk}{$s}{$k2}{1} == $type)) { $event = $k2; last; }}}
 else    { foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$trk}{$s}}) { if (($h0->{$trk}{$s}{$k2}{0} == 0xff) && ($h0->{$trk}{$s}{$k2}{1} == $type)) { $event = $k2; last; }}}

my $txt = ""; if (defined($event)) { my $i = 2; while (exists($h0->{$trk}{$s}{$event}{$i})) { $txt .= chr($h0->{$trk}{$s}{$event}{$i}); $i++; }}

if (($apd) && (defined($event))) { $NewTxt = $txt.$sep.$val; if ($apd < 0) { $NewTxt = $val.$sep.$txt; } ($k2, $k3) = ($event, undef); }

my %tmp1 = (0=>0xff, 1=>$type); my @tmp0 = split('', $NewTxt); for (my $i=0; $i<=$#tmp0; $i++) { $tmp1{$i+2} = ord($tmp0[$i]); }

MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, $k2, $k3, \%tmp1);
return(0); }
#-------------------------------------------------------------------------------
sub InsertTempo {
my $h0    = shift(@_);
my $trk   = 0x0; if ($#_ >= 0) { $trk   = shift(@_); }
my $start =   0; if ($#_ >= 0) { $start = shift(@_); }
my $ep    =   0; if ($#_ >= 0) { $ep    = shift(@_); }
my $val   = 120; if ($#_ >= 0) { $val   = shift(@_); } my $v = MIDI::RoundInt((60/$val)*1000000);

MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>0xff, 1=>0x51, 2=>($v >> 16) & 0xff, 3=>($v >> 8) & 0xff, 4=>($v >> 0) & 0xff});
return(0); }
#-------------------------------------------------------------------------------
sub InsertTimeSig {
my $h0    = shift(@_);
my $trk   = 0x0; if ($#_ >= 0) { $trk   = shift(@_); }
my $start =   0; if ($#_ >= 0) { $start = shift(@_); }
my $ep    =   0; if ($#_ >= 0) { $ep    = shift(@_); }
my $val0  =   4; if ($#_ >= 0) { $val0  = shift(@_); }
my $val1  =   4; if ($#_ >= 0) { $val1  = shift(@_); }

MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>0xff, 1=>0x58, 2=>$val0, 3=>MIDI::RoundInt(log($val1)/log(2)), 4=>0x18, 5=>MIDI::RoundInt(32/4)});
return(0); }
#-------------------------------------------------------------------------------
sub InsertKeySig {
my $h0    = shift(@_);
my $trk   = 0x0; if ($#_ >= 0) { $trk   = shift(@_); }
my $start =   0; if ($#_ >= 0) { $start = shift(@_); }
my $ep    =   0; if ($#_ >= 0) { $ep    = shift(@_); }
my $val   =   0; if ($#_ >= 0) { $val   = shift(@_); }

MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>0xff, 1=>0x59, 2=>$val&0xff, 3=>abs($val)>>8});
return(0); }
#-------------------------------------------------------------------------------
sub InsertGeneric {
my $h0    = shift(@_);
my $trk   = 0x0; if ($#_ >= 0) { $trk   = shift(@_); }
my $start =   0; if ($#_ >= 0) { $start = shift(@_); }
my $ep    =   0; if ($#_ >= 0) { $ep    = shift(@_); }

my %tmp1 = (); while ($#_ >= 0) { $tmp1{scalar(keys(%tmp1))} = shift(@_)&0xff; }
MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, \%tmp1);
return(0); }
#-------------------------------------------------------------------------------
sub InsertSysEx {
my $h0    = shift(@_);
my $trk   = 0x0; if ($#_ >= 0) { $trk   = shift(@_); }
my $start =   0; if ($#_ >= 0) { $start = shift(@_); }
my $ep    =   0; if ($#_ >= 0) { $ep    = shift(@_); }

my %tmp1 = (0=>0xf0); while ($#_ >= 0) { $tmp1{scalar(keys(%tmp1))} = shift(@_); } $tmp1{scalar(keys(%tmp1))} = 0xf7;
MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, \%tmp1);
return(0); }
#-------------------------------------------------------------------------------
sub InsertPrgChg {
my $h0    = shift(@_);
my $trk   =  0x00; if ($#_ >= 0) { $trk   = shift(@_); } my $ch = $trk & 0xf;
my $start =     0; if ($#_ >= 0) { $start = shift(@_); } if (not defined($start)) { return(0); }
my $ep    =     0; if ($#_ >= 0) { $ep    = shift(@_); }
my $fch   = undef; if ($#_ >= 0) { $fch   = shift(@_); } if (defined($fch)) { $ch = $fch; }
my $bnk   = undef; if ($#_ >= 0) { $bnk   = shift(@_); }
my $pgm   =  0x00; if ($#_ >= 0) { $pgm   = shift(@_); }

if (defined($pgm)) { MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>(0xc0 | $ch), 1=>$pgm}); }
if (defined($bnk)) { MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>(0xb0 | $ch), 1=>0x20, 2=>($bnk &  0x7f)});
                     MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>(0xb0 | $ch), 1=>0x00, 2=>($bnk >>    7)}); }
return(0); }
#-------------------------------------------------------------------------------
sub InsertCtlr { my $PNum = $#_;
my $h0       = shift(@_);
my $trk      =   0x0; if ($#_ >= 0) { $trk      = shift(@_); } my $ch = $trk & 0xf;
my $start    =     0; if ($#_ >= 0) { $start    = shift(@_); }
my $ep       =     0; if ($#_ >= 0) { $ep       = shift(@_); }
my $fch      = undef; if ($#_ >= 0) { $fch      = shift(@_); } if (defined($fch)) { $ch = $fch; }
my $dur      = undef; if ($#_ >= 0) { $dur      = shift(@_); } if (not(defined($dur ))) { $dur  = 0; } my $tdir = 1; if ($dur < 0) { $tdir = -1; } $dur = abs($dur); my $retval0 = $dur;
my $step     =  $dur; if ($#_ >= 0) { $step     = shift(@_); } if (not(defined($step))) { $step = $MIDI::ContCtlRes; if ($step < 0) { $step = $h0->{-1}{3}*4*$dur/$step; }} if ($step < 0) { $step = $dur / abs($step); } if ($step == 0) { $step = $dur; }
my $Ctl      =  0x00; if ($#_ >= 0) { $Ctl      = eval(shift(@_)); } my $cflgs = $Ctl >> 16; $Ctl &= 0xffff;
my $Fn       =     2; if ($#_ >= 0) { $Fn       = shift(@_); } my $Inv = 0; if ($Fn < 0) { $Inv++; $Fn = abs($Fn); }
my $Center   =     1; if ($Fn != 2) { $Center   = 0;                                                             } if ($#_ >= 0) { $Center   = shift(@_); }
my $StartVal =  -1.0; if ($Fn != 2) { $StartVal = 0 - $Center;                                                   } if ($#_ >= 0) { $StartVal = shift(@_); }
my $StopVal  =   1.0; if ($Fn == 2) { $StopVal  = 1 - $StartVal; if ($StartVal < 0) { $StopVal = $StartVal + 1; }} if ($#_ >= 0) { $StopVal  = shift(@_); }
my $align    = undef; if ($#_ >= 0) { $align    = shift(@_); } if (($Ctl == 0x0101) || ($Ctl == 0x0102)) { $align = 0; }
my $Res      = undef; if ($#_ >= 0) { $Res      = shift(@_); } if (not(defined($Res))) { $Res = 2*7; if ($Ctl == 0x0103) { $Res = 3*8+2; }}

if ($PNum == 10) { $dur = 0; } #force single event if just StartVal is given
if (($PNum >= 11) && ($dur == 0) && ($Fn != 2) && ($Fn != 3)) { $StartVal = $StopVal; } #make StartVal=StopVal if dur==0 and sweep functions selected

my $SingleEvent = 0; if ($dur == 0) { $SingleEvent++; $dur = 1/1; $step = $dur; } my $num = int($dur / $step);

if (($SingleEvent <= 0) && ($num <= 1)) { $step = $dur/2; $num = 2; if ($step < 1/($h0->{-1}{3}*4)) { $num = 1; $Fn = 1; $StartVal = $StopVal; }}

my $dir = 1; my $range = $StopVal - $StartVal; if ($StartVal > $StopVal) { $dir = -1; $range = $StartVal - $StopVal; } my $Lastval = -1; my $LastVal = -1; if ($Ctl == 0x0103) { $LastVal = $h0->{-1}{4}; }

my $Range0 = $range; my $StartVal0 = $StartVal; if ($Center) { $Range0 /= 2; $StartVal0 = ($StartVal0+1)/2; } #[ 0,1]

my $Step = int($step*$h0->{-1}{3}*4)*$tdir; my $Time = int($start*$h0->{-1}{3}*4); my $LastTime = $Time-1; my $e = 2.718281828; my $Num = $num-1; if ($Num == 0) { $Num++; } my $idx0 = 0;

my %Times; my %NoteEvents;
if (defined($align)) {
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$trk}}) { my $s = $k1/($h0->{-1}{3}*4);
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$trk}{$k1}}) {
   if (($h0->{$trk}{$k1}{$k2}{0} >> 4 == 9) && ($s >= $start) && ($s < $start+$dur)) { if (scalar(keys(%{$NoteEvents{$k1}})) < 1) { $Times{scalar(keys(%Times))} = $k1; } $NoteEvents{$k1}{$k2} = 0; }
   }
  }
 $num = scalar(keys(%Times));
 }

while ($idx0 < $num) { my $x = $idx0/$Num; if (scalar(keys(%Times)) > 0) { $Time = $Times{$idx0}; $x = ($Time/($h0->{-1}{3}*4)-$start)/$dur; $Time += eval($align)*$h0->{-1}{3}*4; $LastTime = $Time-1; } #range [0,1] or point [0]

 my $y = $StartVal + $x * $range * $dir; #lin [StartVal,StopVal] -> centered [-1,1] or non-centered [0,1]

 if ($Fn == 2) { $y = $StartVal + sin((2*atan2(1,0)*2*$x)) * $StopVal; } #full sin [0,2pi]: offset = StartVal; amp = StopVal;

 if ($Fn == 3) { $y = $StartVal + sin((2*atan2(1,0)*1*$x)) * $StopVal; } #half sin [0, pi]: offset = StartVal; amp = StopVal;

 if ($Fn == 4) { $y = $StartVal0 + (sin(atan2(1,0)*(2*$x-1))+1)/2 * $Range0 * $dir; if ($Center) { $y = 2*$y-1; }} #half sin [-pi/2,pi/2] -> [-1,1]

 if ($Fn == 5) { $y = $StartVal0 + 1/(1+$e**-(8*$x-4)) * $Range0 * $dir; if ($Center) { $y = 2*$y-1; }} #sigmoid

 if ($Inv > 0) { $y = 1 - $y - $Center; } $y = sprintf("%1.13f", $y); #inversion and round

 my                    $Val = MIDI::RoundInt((0x0001<<($Res-$Center))*($y+$Center));   #float -> int
 if ($Ctl == 0x0103) { $Val = MIDI::RoundInt($h0->{-1}{4}            *($y+$Center)); } #float -> int

 if ($Val > ((0x0001<<$Res)-1)) { $Val = (0x0001<<$Res)-1; } if ($Val < 0) { $Val = 0; } #set binary limits

 if (($Time != $LastTime) && ((abs($Val - $LastVal) >= 1) || ($Ctl == 0x0101) || ($Ctl == 0x0102))) { #write only changes or set note on/off velocities
  if    ($Ctl <= 0x007f) { if ($Val>>7 != $LastVal>>7) { #normal controller
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>($Ctl-0x00)&0x7f, 2=>($Val>>7)&0x7f});
   }}
  elsif ($Ctl <= 0x00ff) { if ($Val>>7 != $LastVal>>7) { #PolyAfterTouch
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xa0 | $ch), 1=>($Ctl-0x80)&0x7f, 2=>($Val>>7)&0x7f});
   }}
  elsif ($Ctl <= 0x0100) { if ($Val>>7 != $LastVal>>7) { #ChAfterTouch
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xd0 | $ch), 1=>($Val>>7)&0x7f});
   }}
  elsif ($Ctl <= 0x0101) { #NoteOnVel
   foreach my $k2 (sort {$a <=> $b} keys %{$NoteEvents{$Time}}) { my $v = $h0->{$trk}{$Time}{$k2}{2};      $v = int($v*$Val/16383); if ($v < 1) { $v++; } $h0->{$trk}{$Time}{$k2}{2} = $v; }
   }
  elsif ($Ctl <= 0x0102) { #NoteOffVel
   foreach my $k2 (sort {$a <=> $b} keys %{$NoteEvents{$Time}}) { my $v = $h0->{$trk}{$Time}{$k2}{4}&0x7f; $v = int($v*$Val/16383);                       $h0->{$trk}{$Time}{$k2}{4} = $v; }
   }
  elsif ($Ctl <= 0x0103) { #Tempo
   MIDI::InsertTempo($h0, $trk, $Time/($h0->{-1}{3}*4), $ep, $Val);
   }
  elsif ($Ctl <= 0x0104) { #PitchBend
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xe0 | $ch), 1=>($Val>>0)&0x7f, 2=>($Val>>7)&0x7f});
   }
  elsif ($Ctl <= 0x0105) { #Prg
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xc0 | $ch), 1=>($Val>>7)&0x7f});
   }
  elsif ($Ctl <= 0x021f) { #extended MSB/LSB controller
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>($Ctl-0x200+0x20)&0x7f, 2=>($Val>>0)&0x7f});
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>($Ctl-0x200+0x00)&0x7f, 2=>($Val>>7)&0x7f});
   }
  elsif ($Ctl <= 0x0303) { #extended MSB/LSB controller (GP #5-#8)
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>($Ctl-0x300+0x56)&0x7f, 2=>($Val>>0)&0x7f});
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>($Ctl-0x300+0x50)&0x7f, 2=>($Val>>7)&0x7f});
   }
  elsif ($Ctl <= 0x3fff) { #callback functions
   $MIDI::CtlCallBackRefs{$Ctl}->($h0, $trk, $Time/($h0->{-1}{3}*4), $ep, $ch, $Ctl, $Val, $LastVal);
   }
  else                   { #(N)RPN (CC,misc: x0000-x3fff; RPN: x4000-x7fff; NRPN: x8000-xbfff; unused: xc000-xffff)
   my $a = 0x00; my $b = 0x0; if ($cflgs & 1) { $a = 0x20; $b= 0x7; }
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>0x26^$a,                 2=>($Val>>(0^$b))&0x7f}); #Data   LSB
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>0x06^$a,                 2=>($Val>>(7^$b))&0x7f}); #Data   MSB
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>0x62+(($Ctl>>14)&0x1)*2, 2=>($Ctl>> 0    )&0x7f}); #(N)RPN LSB
   MIDI::InsEvent($h0, $trk, $Time, 0, $ep, {0=>(0xb0 | $ch), 1=>0x63+(($Ctl>>14)&0x1)*2, 2=>($Ctl>> 7    )&0x7f}); #(N)RPN MSB
   }
  }

 $LastTime = $Time; $Time += $Step; $LastVal = $Val; $Lastval = $y; $idx0++; }

return($Lastval, $retval0); }
#-------------------------------------------------------------------------------
sub InsertNote { my ($h0, $trk, $start, $ep, $fch, $dur, $note, $VOn, $VOf, $rpt, $dly, $dmp) = @_; my $retval0 = $dur; if (($note < 0x00) || ($note > 0x7f)) { return($retval0); } #dont write notes out of range

if ($dur < 0) { $start += $dur; $dur = abs($dur); } if ($rpt >= 0) { $rpt++; } my $ch = $trk & 0xf; if (defined($fch)) { $ch = $fch; }

while (($rpt > 0) || (($rpt < 0) && ($VOn > abs($rpt)))) {
 my $VOn0 = int($VOn*0x80); if ($VOn0 <= 0x00) { $VOn0 = 0x01; } if ($VOn0 >= 0x7f) { $VOn0 = 0x7f; } #limit velocity
 my $VOf0 = int($VOf*0x80); if ($VOf0 <  0x00) { $VOf0 = 0x00; } if ($VOf0 >= 0x7f) { $VOf0 = 0x7f; } #limit velocity
 MIDI::InsEvent($h0, $trk, $start*$h0->{-1}{3}*4, 0, $ep, {0=>(0x90 | $ch), 1=>$note, 2=>$VOn0, 3=>int($dur*$h0->{-1}{3}*4), 4=>$VOf0});
 if ($rpt > 0) { $rpt--; } $start += $dly; $VOn *= $dmp;
 }
 
return($retval0); }
#-------------------------------------------------------------------------------
sub Init { my $h0 = shift(@_); my $h1 = shift(@_);
my $s     = undef; if ($#_ >= 0) { $s    = shift(@_); } if (    defined($s)   ) { $s    *= $h0->{-1}{3}*4; }
my $Ofs0  = undef; if ($#_ >= 0) { $Ofs0 = shift(@_); } if (not defined($Ofs0)) { $Ofs0  = 0;              }
my $Ofs1  = undef; if ($#_ >= 0) { $Ofs1 = shift(@_); } if (not defined($Ofs1)) { $Ofs1  = 0;              }
my $Ofs2  = undef; if ($#_ >= 0) { $Ofs2 = shift(@_); } if (not defined($Ofs2)) { $Ofs2  = 0;              }

my $solo = 0; foreach my $trk (sort {$a <=> $b} keys %{$h1}) { if (exists($h1->{$trk}{-1}) && ($h1->{$trk}{-1} > 1)) { $solo++; }}

my $fatime = undef; my $fbtime = undef;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if ($k0 == -1) { next(); }
 if (exists($h1->{$k0}) && exists($h1->{$k0}{-1}) && ($h1->{$k0}{-1} < 1) || ($solo) && (not(exists($h1->{$k0}{-1})) || ($h1->{$k0}{-1} == 1))) { delete($h0->{$k0}); next(); }
 if ((defined($s)) && ($s > 0)) { foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { if ($k1 >= $s) { $h0->{$k0}{$k1-$s} = $h0->{$k0}{$k1}; } delete($h0->{$k0}{$k1}); }}
 if ((scalar(keys %{$h0->{$k0}})>0) && ((not defined($fatime)) || ((sort {$a <=> $b} keys %{$h0->{$k0}})[ 0] < $fatime))) { $fatime = (sort {$a <=> $b} keys %{$h0->{$k0}})[ 0]; }
 if ((scalar(keys %{$h0->{$k0}})>0) && ((not defined($fbtime)) || ((sort {$a <=> $b} keys %{$h0->{$k0}})[-1] > $fbtime))) { $fbtime = (sort {$a <=> $b} keys %{$h0->{$k0}})[-1]; }
 }

if ((not defined($fatime)) || ($fatime > 0)) { $fatime = 0; } if (not defined($fbtime)) { $fbtime = $fatime; } my $start = $fatime/($h0->{-1}{3}*4); my $end = $fbtime/($h0->{-1}{3}*4);

if (defined($h0->{-1}{8})) { MIDI::InsertText   ($h0, 0, $start, 0, $h0->{-1}{8}, 0x02        ); }
if (defined($h0->{-1}{7})) { MIDI::InsertKeySig ($h0, 0, $start, 0, $h0->{-1}{7}              ); }
if (defined($h0->{-1}{5})) { MIDI::InsertTimeSig($h0, 0, $start, 0, $h0->{-1}{5}, $h0->{-1}{6}); }
if (defined($h0->{-1}{4})) { MIDI::InsertTempo  ($h0, 0, $start, 0, $h0->{-1}{4}              ); }

foreach my $trk (sort {$a <=> $b} keys %{$h1}) {

 my $nam = undef; if (exists($h1->{$trk}{ -2})) { $nam = $h1->{$trk}{ -2}; }
 my $prt = undef; if (exists($h1->{$trk}{ -3})) { $prt = $h1->{$trk}{ -3}; }
 my $fch = undef; if (exists($h1->{$trk}{ -4})) { $fch = $h1->{$trk}{ -4}; }
 my $bnk = undef; if (exists($h1->{$trk}{ -5})) { $bnk = $h1->{$trk}{ -5}; }
 my $pgm = undef; if (exists($h1->{$trk}{ -6})) { $pgm = $h1->{$trk}{ -6}; }
 my $ins = undef; if (exists($h1->{$trk}{-13})) { $ins = $h1->{$trk}{-13}; }

 my %h2; foreach my $k0 (sort {$b <=> $a} keys %{$h1->{$trk}}) { my $t = $k0; if ($t > 0) {$t &= 0xffff; } $h2{$t} = $k0; }

 foreach my $k0 (sort {$b <=> $a} keys %h2) { my $ctl = $h2{$k0}; my $val = $h1->{$trk}{$ctl};
  if (($ctl > -1) && (defined($val))) { my $c = 0; if ($k0 == 0x4000) { $val = ((int($val)<<7)+($val-int($val))*0x7f)/0x3fff; } $c = ($ctl >> 17) & 1; $ctl &= 0x1ffff;
   $Ofs0 += $Ofs2; MIDI::InsertCtlr($h0, $trk, $start+$Ofs0, 0, $fch, undef, undef, $ctl, 1, $c, $val); }
  }
 
 if ((defined($bnk)) || (defined($pgm))) { $Ofs0 += $Ofs2; } MIDI::InsertPrgChg($h0, $trk, $start+$Ofs0, 0, undef, $bnk, $pgm);
 if (defined($prt)) { if ($prt =~ /^\d+$/) { MIDI::InsertGeneric($h0, $trk, $start, 0, 0xff, 0x21, $prt); } else { MIDI::InsertText($h0, $trk, $start, 0, $prt, 0x9); }} #midi port

 if (defined($ins)) { MIDI::InsertText($h0, $trk, $start, 0, $ins, 0x04); } #instrument
 if (defined($nam)) { MIDI::InsertText($h0, $trk, $start, 0, $nam, 0x03); } #trackname
 $Ofs0 += $Ofs1;
 }

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (not exists($h1->{$k0}))) { next; }

 my $ko = 0; if (exists($h1->{$k0}{ -7})) { $ko = $h1->{$k0}{ -7}; }
 my $vo = 0; if (exists($h1->{$k0}{ -8})) { $vo = $h1->{$k0}{ -8}; }
 my $vs = 1; if (exists($h1->{$k0}{ -9})) { $vs = $h1->{$k0}{ -9}; }
 my $ro = 0; if (exists($h1->{$k0}{-10})) { $ro = $h1->{$k0}{-10}; }
 my $rs = 1; if (exists($h1->{$k0}{-11})) { $rs = $h1->{$k0}{-11}; }
 my $ds = 1; if (exists($h1->{$k0}{-12})) { $ds = $h1->{$k0}{-12}; }

 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if (($h0->{$k0}{$k1}{$k2}{0} >> 4 >= 0x8) && ($h0->{$k0}{$k1}{$k2}{0} >> 4 <= 0xe) && (exists($h1->{$k0}{-4})) && (defined($h1->{$k0}{-4}))) { $h0->{$k0}{$k1}{$k2}{0} = $h0->{$k0}{$k1}{$k2}{0} & 0xf0 | $h1->{$k0}{-4}; }
   if  ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) { my ($k, $v, $d, $r) = ($h0->{$k0}{$k1}{$k2}{1}, $h0->{$k0}{$k1}{$k2}{2}, $h0->{$k0}{$k1}{$k2}{3}, $h0->{$k0}{$k1}{$k2}{4}); my ($km, $vm, $dm, $rm) = ($k, $v, $d, $r&0x7f);

	my $lds = $ds; if (ref($ds) =~ 'HASH') { $lds = 1; if (exists($ds->{$k})) { $lds = $ds->{$k}; } elsif (exists($ds->{-1})) { $lds = $ds->{-1}; }} $dm = int($dm * $lds); if ($lds<0) { $dm = int(abs($lds)*$h0->{-1}{3}*4); }
	my $lko = $ko; if (ref($ko) =~ 'HASH') { $lko = 0; if (exists($ko->{$k})) { $km  = $ko->{$k}; } elsif (exists($ko->{-1})) { $lko = $ko->{-1}; }} $km += $lko; if ($km >> 7) { $km = $k; $dm = 0; }
	my $lvo = $vo; if (ref($vo) =~ 'HASH') { $lvo = 0; if (exists($vo->{$k})) { $lvo = $vo->{$k}; } elsif (exists($vo->{-1})) { $lvo = $vo->{-1}; }}
	my $lvs = $vs; if (ref($vs) =~ 'HASH') { $lvs = 1; if (exists($vs->{$k})) { $lvs = $vs->{$k}; } elsif (exists($vs->{-1})) { $lvs = $vs->{-1}; }}
	my $lro = $ro; if (ref($ro) =~ 'HASH') { $lro = 0; if (exists($ro->{$k})) { $lro = $ro->{$k}; } elsif (exists($ro->{-1})) { $lro = $ro->{-1}; }}
	my $lrs = $rs; if (ref($rs) =~ 'HASH') { $lrs = 1; if (exists($rs->{$k})) { $lrs = $rs->{$k}; } elsif (exists($rs->{-1})) { $lrs = $rs->{-1}; }}

    $vm = int($vm*$lvs + $lvo*0x80); if ($vm < 0x01) { $vm = 0x01; } if ($vm > 0x7f) { $vm = 0x7f; } if ($lvs < 0) { $vm = 0x00; }
    $rm = int($rm*$lrs + $lro*0x80); if ($rm < 0x00) { $rm = 0x00; } if ($rm > 0x7f) { $rm = 0x7f; }

	($h0->{$k0}{$k1}{$k2}{1}, $h0->{$k0}{$k1}{$k2}{2}, $h0->{$k0}{$k1}{$k2}{3}, $h0->{$k0}{$k1}{$k2}{4}) = ($km, $vm, $dm, $rm);
	}
   }
  }
 }

return($start, $end); }
#-------------------------------------------------------------------------------
sub ConvertType0To1 { my $h0  = shift(@_); my %h1 = (-1 => $h0->{-1}); printf("%s(); #\n", (caller(0))[3]);

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if ($k0 == -1) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { my $Event = $h0->{$k0}{$k1}{$k2}{0}>>4; my $Ch = $h0->{$k0}{$k1}{$k2}{0}&0xf;
   my $trk = $Ch+1; if ($Event == 0xf) { $trk = 0x0; } if ($h0->{$k0}{$k1}{$k2}{0}==0xff && $h0->{$k0}{$k1}{$k2}{1}==0x2f && scalar(keys(%{$h0->{$k0}{$k1}}))>1) { next(); } $h1{$trk}{$k1}{scalar(keys(%{$h1{$trk}{$k1}}))} = $h0->{$k0}{$k1}{$k2};
   }
  }
 }

$h1{-1}{1} = 1; $h1{-1}{2} = scalar(keys(%h1))-1; return(%h1); }
#-------------------------------------------------------------------------------
sub ConvertType1To0 { my $h0  = shift(@_); my %h1 = (-1 => $h0->{-1}); printf("%s(); #\n", (caller(0))[3]);

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if ($k0 == -1) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { my $Event = $h0->{$k0}{$k1}{$k2}{0}>>4; my $Ch = $h0->{$k0}{$k1}{$k2}{0}&0xf;
   my $trk = 0; if (($k0 == $trk) || ($h0->{$k0}{$k1}{$k2}{0} != 0xff)) { $h1{$trk}{$k1}{scalar(keys(%{$h1{$trk}{$k1}}))} = $h0->{$k0}{$k1}{$k2}; }
   }
  }
 }

$h1{-1}{1} = 0; $h1{-1}{2} = scalar(keys(%h1))-1; return(%h1); }
#-------------------------------------------------------------------------------
sub RemoveOverlap { my $h0 = shift(@_); my ($cnt1, $cnt2, $cnt3) = (0, 0, 0);

foreach my $k0 (sort {$a <=> $b} keys(%{$h0})) { if ($k0 == -1) { next(); } my %Pending;
 foreach my $k1 (sort {$a <=> $b} keys(%{$h0->{$k0}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$h0->{$k0}{$k1}})) {
   if (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) && ($h0->{$k0}{$k1}{$k2}{2} > 0x0) && (scalar(keys(%{$h0->{$k0}{$k1}{$k2}})) > 3)) { #NoteOn
    my $ch = $h0->{$k0}{$k1}{$k2}{0} & 0x0f; my $note = $h0->{$k0}{$k1}{$k2}{1}; my $dur = $h0->{$k0}{$k1}{$k2}{3};

    if (exists($Pending{$ch}{$note})) {
	 for (my $i=0; $i<scalar(@{$Pending{$ch}{$note}}); $i++) { my ($k1p, $k2p) = @{@{$Pending{$ch}{$note}}[$i]}; my $dp = $h0->{$k0}{$k1p}{$k2p}{3};
      if ($k1p+$dp > $k1) { if ($dur <= 0) { $h0->{$k0}{$k1p}{$k2p}{3} = $k1-$k1p; $cnt2++; } else { $cnt3++; }}
	   else               { splice(@{$Pending{$ch}{$note}}, $i--, 1); }
	  }
	 }

    if ($dur <= 0) { delete($h0->{$k0}{$k1}{$k2}); $cnt1++; } else { push(@{$Pending{$ch}{$note}}, [$k1, $k2]); } #delete if zero length else mark pending
	}
   }
  if (scalar(keys(%{$h0->{$k0}{$k1}})) <= 0) { delete($h0->{$k0}{$k1}); } #delete current NoteOff time if no events anymore
  }
 }

if ($cnt1+$cnt2+$cnt3) { printf("%s(); #ZeroLength:$cnt1 Overlaps:$cnt3 Cuts:$cnt2\n", (caller(0))[3]); }
return($cnt1, $cnt2, $cnt3); }
#-------------------------------------------------------------------------------
sub RemoveNoteOff { my $h0 = shift(@_); my ($cnt0, $cnt1, $cnt2, $cnt3, $cnt4, $cnt5, $cnt6) = (0, 0, 0, 0, 0, 0, 0); my %EOTs;

my $gMaxTime = undef; foreach my $k0 (sort {$a <=> $b} keys(%{$h0})) { if ($k0 == -1) { next(); } my $m = (sort {$b <=> $a} keys(%{$h0->{$k0}}))[0]; if (not(defined($gMaxTime)) || $m > $gMaxTime) { $gMaxTime = $m; }}

foreach my $k0 (sort {$a <=> $b} keys(%{$h0})) { if ($k0 == -1) { next(); } my %Pending; my $k1num = scalar(keys(%{$h0->{$k0}})); my $Maxk1 = (sort {$b <=> $a} keys(%{$h0->{$k0}}))[0];
 foreach my $k1 (sort {$a <=> $b} keys(%{$h0->{$k0}})) {
  foreach my $k2 (sort {$a <=> $b} keys(%{$h0->{$k0}{$k1}})) {
   if (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) && ($h0->{$k0}{$k1}{$k2}{2} > 0x0)) { #NoteOn
    my $ch = $h0->{$k0}{$k1}{$k2}{0} & 0x0f; my $note = $h0->{$k0}{$k1}{$k2}{1}; push(@{$Pending{$ch}{$note}}, [$k1, $k2]);
    }
   elsif (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x8) || (($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9) && ($h0->{$k0}{$k1}{$k2}{2} <= 0x00))) { #NoteOff
    my $ch = $h0->{$k0}{$k1}{$k2}{0} & 0x0f; my $note = $h0->{$k0}{$k1}{$k2}{1};
	if (exists($Pending{$ch}{$note}) && (scalar(@{$Pending{$ch}{$note}}))) { my ($k1on, $k2on) = @{shift(@{$Pending{$ch}{$note}})};
	 $h0->{$k0}{$k1on}{$k2on}{3} = $k1-$k1on; if ($h0->{$k0}{$k1on}{$k2on}{3} <= 0) { $cnt1++; }
	 $h0->{$k0}{$k1on}{$k2on}{4} = (($h0->{$k0}{$k1}{$k2}{0}>>4)&0x01)*0xc0+$h0->{$k0}{$k1}{$k2}{2};
	 if (scalar(@{$Pending{$ch}{$note}})) { $cnt2++; }
	 } else { $cnt0++; }
    delete($h0->{$k0}{$k1}{$k2});
    }
   elsif (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x2f)) { my $Maxk2 = (sort {$b <=> $a} keys(%{$h0->{$k0}{$k1}}))[0]; delete($h0->{$k0}{$k1}{$k2}); $EOTs{$k0}{$k1}{$k2}++; #meta - delete track end
    if ($k1num > 1 && $k2 == 0 || $k1 != $Maxk1 || $k2 != $Maxk2) { my %tmp1 = (0=>0xff, 1=>0x06); my @tmp0 = split('', sprintf("EOT%d", $k0)); for (my $i=0; $i<=$#tmp0; $i++) { $tmp1{$i+2} = ord($tmp0[$i]); } %{$h0->{$k0}{$k1}{$k2}} = %tmp1; $cnt4++; }
    }
   elsif (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x51) && (not exists($h0->{-1}{4}))) { #meta - extract tempo
    $h0->{-1}{4} = 60000000/(($h0->{$k0}{$k1}{$k2}{2}<<16) + ($h0->{$k0}{$k1}{$k2}{3}<<8) + $h0->{$k0}{$k1}{$k2}{4});
    }
   elsif (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x58) && (not exists($h0->{-1}{5}))) { $h0->{-1}{5} = $h0->{$k0}{$k1}{$k2}{2}; $h0->{-1}{6} = 1 << $h0->{$k0}{$k1}{$k2}{3}; } #meta - extract TimeSig
   elsif (($h0->{$k0}{$k1}{$k2}{0} == 0xff) && ($h0->{$k0}{$k1}{$k2}{1} == 0x59) && (not exists($h0->{-1}{7}))) { $h0->{-1}{7} = ($h0->{$k0}{$k1}{$k2}{3} << 8) | $h0->{$k0}{$k1}{$k2}{2}; } #meta - extract KeySig
   }
  if (scalar(keys(%{$h0->{$k0}{$k1}})) <= 0) { delete($h0->{$k0}{$k1}); }
  }
 foreach my $ch (sort {$a <=> $b} keys %Pending) {
  foreach my $note (sort {$a <=> $b} keys %{$Pending{$ch}}) {
   while (scalar(@{$Pending{$ch}{$note}})) { my ($k1on, $k2on) = @{shift(@{$Pending{$ch}{$note}})}; $cnt3++; my ($EOTT, $k1) = ($k0, $gMaxTime); if (not(exists($EOTs{$EOTT}))) { $EOTT = 0; }
    foreach my $EOTk1 (sort {$b <=> $a} keys(%{$EOTs{$EOTT}})) { foreach my $EOTk2 (sort {$b <=> $a} keys(%{$EOTs{$EOTT}{$EOTk1}})) { if ($EOTk1 > $k1on || $EOTk1 == $k1on && $EOTk2 > $k2on) { $k1 = $EOTk1; }}}
    $h0->{$k0}{$k1on}{$k2on}{3} = $k1-$k1on; if ($h0->{$k0}{$k1on}{$k2on}{3} <= 0) { $cnt5++; } $h0->{$k0}{$k1on}{$k2on}{4} = 0x1c0;
    }
   }
  }
 }

foreach my $EOTk0 (sort {$b <=> $a} keys(%EOTs)) { my $n = 0; foreach my $EOTk1 (sort {$b <=> $a} keys(%{$EOTs{$EOTk0}})) { $n += scalar(keys(%{$EOTs{$EOTk0}{$EOTk1}})); } if ($n > 1) { $cnt6 += $n; }}

if ($cnt0+$cnt1+$cnt2+$cnt3+$cnt4+$cnt5+$cnt6) { printf("%s(); #MissingNoteOn:$cnt0 MissingNoteOff:$cnt3 ZeroLength:$cnt1+$cnt5 Overlaps:$cnt2 ExtraEOT:$cnt4 MultiEOT:$cnt6\n", (caller(0))[3]); }
return($cnt0, $cnt1, $cnt2, $cnt3, $cnt4, $cnt5, $cnt6); }
#-------------------------------------------------------------------------------
sub InsertNoteOff { my ($h0, $dl) = @_; my $gtime = undef; my %ttimes;

foreach my $k0 (sort {$a <=> $b} keys(%{$h0})) { if ($k0 == -1) { next(); } my $ttime = undef;
 foreach my $k1 (sort {$b <=> $a} keys(%{$h0->{$k0}})) {
  if ((not(defined($gtime))) || ($k1 > $gtime)) { $gtime = $k1; }
  if ((not(defined($ttime))) || ($k1 > $ttime)) { $ttime = $k1; }
  foreach my $k2 (sort {$b <=> $a} keys(%{$h0->{$k0}{$k1}})) {
   if ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9 && scalar(keys(%{$h0->{$k0}{$k1}{$k2}})) > 3) {
    my $ch = $h0->{$k0}{$k1}{$k2}{0} & 0x0f; my $note = $h0->{$k0}{$k1}{$k2}{1}; my $vel = $h0->{$k0}{$k1}{$k2}{4} & 0x7f; my $dur = $h0->{$k0}{$k1}{$k2}{3};
    if ((not(defined($gtime))) || ($k1+$h0->{$k0}{$k1}{$k2}{3} > $gtime)) { $gtime = $k1+$h0->{$k0}{$k1}{$k2}{3}; }
    if ((not(defined($ttime))) || ($k1+$h0->{$k0}{$k1}{$k2}{3} > $ttime)) { $ttime = $k1+$h0->{$k0}{$k1}{$k2}{3}; }
    if ($dur > 0) { MIDI::InsEvent($h0, $k0, $k1+$dur, 0, 0, {0=>(0x80 | $ch), 1=>$note, 2=>$vel}); } #insert before 1st event
     else         { MIDI::InsEvent($h0, $k0, $k1+$dur, 0, 1, {0=>(0x80 | $ch), 1=>$note, 2=>$vel}); } #append after last event
    }
   }
  }
 if (not(defined($ttime))) { $ttime = 0; } $ttimes{$k0} = $ttime;
 }

my $eof = undef; if (not(defined($dl)) || ($dl > 0)) { $eof = $gtime; } if (not(defined($dl))) { $dl = 0; } $dl = abs($dl)*$h0->{-1}{3}*4;

foreach my $k0 (sort {$a <=> $b} keys(%ttimes)) { my $eot = $ttimes{$k0}+$dl; if (defined($eof)) { $eot = $eof+$dl; } my $k2 = (sort {$b <=> $a} keys(%{$h0->{$k0}{$eot}}))[0];
 if (not(defined($k2)) || scalar(keys(%{$h0->{$k0}{$eot}{$k2}}))!=2 || $h0->{$k0}{$eot}{$k2}{0}!=0xff || $h0->{$k0}{$eot}{$k2}{1}!=0x2f) { MIDI::InsEvent($h0, $k0, $eot, 0, 1, {0=>0xff, 1=>0x2f}); }
 } #meta - end of track

return($gtime); }
#-------------------------------------------------------------------------------
sub InsEvent { my ($h0, $k0, $k1, $k2, $ep, $h1) = @_; $k1 = MIDI::RoundInt($k1);

if (defined($ep) && scalar(keys(%{$h0->{$k0}{$k1}}))) { $k2 = (sort {$a <=> $b} keys(%{$h0->{$k0}{$k1}}))[-$ep]+2*$ep-1; } %{$h0->{$k0}{$k1}{$k2}} = %{$h1};

return($k2); }
#-------------------------------------------------------------------------------
sub Read {
my $fname = "MyTest0.mid"; if ($#_ >= 0) { $fname = shift(@_); } $fname =~ s/\\/\//gi;
my $RNO   =             1; if ($#_ >= 0) { $RNO   = shift(@_); }
my $CMT   =             1; if ($#_ >= 0) { $CMT   = shift(@_); }

my %EvtTypes = (0x80=>2, 0x90=>2, 0xa0=>2, 0xb0=>2, 0xc0=>1, 0xd0=>1, 0xe0=>2, 0xf0=>-1, 0xf1=>1, 0xf2=>2, 0xf3=>1, 0xf4=>-2, 0xf5=>-2, 0xf6=>0, 0xf7=>-1, 0xf8=>0, 0xf9=>-2, 0xfa=>0, 0xfb=>0, 0xfc=>0, 0xfd=>-2, 0xfe=>0, 0xff=>-1);

foreach my $t (sort {$a <=> $b} keys(%EvtTypes)) { if ($t < 0xf0) { for (my $c=0; $c<=0xf; $c++) { $EvtTypes{$t|$c} = $EvtTypes{$t}; }}}

open(my_file1, $fname); my @fstats = stat(my_file1); my $fsize = $fstats[7]; my $pos0 = 0; my %r0; my $h0 = \%r0; my $chunk = -1; $h0->{-1}{1} = 1; $h0->{-1}{3} = 96;
while (($pos0+8) <= $fsize)
 {
 sysread(my_file1, my $byte, 1); $pos0++; my $ChunkType  = $byte;
 sysread(my_file1,    $byte, 1); $pos0++;    $ChunkType .= $byte;
 sysread(my_file1,    $byte, 1); $pos0++;    $ChunkType .= $byte;
 sysread(my_file1,    $byte, 1); $pos0++;    $ChunkType .= $byte;

 sysread(my_file1,    $byte, 1); $pos0++; my $length =                  ord($byte);
 sysread(my_file1,    $byte, 1); $pos0++;    $length = ($length << 8) + ord($byte);
 sysread(my_file1,    $byte, 1); $pos0++;    $length = ($length << 8) + ord($byte);
 sysread(my_file1,    $byte, 1); $pos0++;    $length = ($length << 8) + ord($byte);

 if     (($ChunkType =~ /^(MThd|STYL)$/) && (($pos0+6) <= $fsize)) {
  sysread(my_file1, $byte, 1); $pos0++; my $format =                  ord($byte);
  sysread(my_file1, $byte, 1); $pos0++;    $format = ($format << 8) + ord($byte);
  sysread(my_file1, $byte, 1); $pos0++; my $ntrks  =                  ord($byte);
  sysread(my_file1, $byte, 1); $pos0++;    $ntrks  = ($ntrks  << 8) + ord($byte);
  sysread(my_file1, $byte, 1); $pos0++; my $PPQN   =                  ord($byte);
  sysread(my_file1, $byte, 1); $pos0++;    $PPQN   = ($PPQN   << 8) + ord($byte); if ($PPQN & 0x8000) { printf("MIDI::Read($fname); # SMPTE %d\n", 256-(($PPQN>>8)&0xff)); $PPQN = $PPQN&0xff; }
  if (not(exists($h0->{-1}{2}))) { $h0->{-1}{1} = $format; $h0->{-1}{2} = $ntrks; $h0->{-1}{3} = $PPQN; } elsif ($chunk >= 0) { $h0->{-1}{1} = 1; }
  }
  elsif (($ChunkType =~ /^MTrk$/) && (($pos0+$length) <= $fsize)) { $chunk++; my $pos1 = 0; my $EventCntr1 = -1; my $ByteCntr = -1; my $atime = 0; my $LastEvent = 0;
  while ($pos1 < $length) {
   my $len = 0; $byte = 0xff; while ($byte >= 0x80) { sysread(my_file1, $byte, 1); $pos0++; $pos1++; $byte = ord($byte); $len = ($len << 7) + ($byte & 0x7f); }
   sysread(my_file1, $byte, 1); $pos0++; $pos1++; my $event = ord($byte); $atime += $len; if ($len == 0) { $EventCntr1++; $ByteCntr = 0; } else { $EventCntr1 = 0; $ByteCntr = 0; }

   if ($event >= 0x80) { if ($event <= 0xef) { $LastEvent = $event; }}                        #regular status
    elsif ($LastEvent) { sysseek(my_file1, -1, 1); $pos0--; $pos1--; $event = $LastEvent; }   #running status
    else { printf("MIDI::Read($fname); #$chunk $atime $EventCntr1 %02x\n", $event); next(); } #unknown/invalid running status -> ignore

   $len = $EvtTypes{$event};
   if ($len >= -1) { $h0->{$chunk}{$atime}{$EventCntr1}{$ByteCntr++} = $event; }              #accepted status
    else { printf("MIDI::Read($fname); #$chunk $atime $EventCntr1 %02x\n", $event); next(); } #unknown/invalid status         -> ignore

   if ($event == 0xff) { sysread(my_file1, $byte, 1); $pos0++; $pos1++; $h0->{$chunk}{$atime}{$EventCntr1}{$ByteCntr++} = ord($byte); } #meta

   if ($len == -1) { $len = 0; $byte = 0xff; while ($byte >= 0x80) { sysread(my_file1, $byte, 1); $pos0++; $pos1++; $byte = ord($byte); $len = ($len << 7) + ($byte & 0x7f); }} #sysex or meta

   while ($len > 0) { sysread(my_file1, $byte, 1); $pos0++; $pos1++; $len--; $h0->{$chunk}{$atime}{$EventCntr1}{$ByteCntr++} = ord($byte); }
   }
  if ($length-$pos1 != 0) { printf("MIDI::Read($fname); # %d byte(s) left in Trk $chunk! FilePos: 0x%04x\n", ($length-$pos1), $pos0); }
  }
  else { $pos0 -= 8; last(); }
 }
close(my_file1); $h0->{-1}{0} = $fname; $h0->{-1}{-1} = localtime($fstats[9]); $h0->{-1}{-2} = $fsize; $h0->{-1}{-3} = $pos0;

if ($fsize-$pos0 != 0) { printf("MIDI::Read($fname); # %d byte(s) left! FilePos: 0x%04x;\n", ($fsize-$pos0), $pos0); }

if (($CMT) && ($h0->{-1}{1} == 0)) { my %t0 = MIDI::ConvertType0To1($h0); $h0 = \%t0; } if ($RNO) { MIDI::RemoveNoteOff($h0); } return(%{$h0}); }
#-------------------------------------------------------------------------------
sub Write {
my $h0    = shift(@_);
my $fname =     undef; if ($#_ >= 0) { $fname = shift(@_); } if (not defined($fname)) { $fname = "MyTest0.mid"; if (exists($h0->{-1}{0})) { $fname = $h0->{-1}{0}; }}
my $INO   =         0; if ($#_ >= 0) { $INO   = shift(@_); }
my $CMT   =         1; if ($#_ >= 0) { $CMT   = shift(@_); }

MIDI::InsertNoteOff($h0, $INO); if (($CMT) && ($h0->{-1}{1} == 0)) { my %t0 = MIDI::ConvertType1To0($h0); $h0 = \%t0; }

my $trks = scalar(keys(%{$h0})) - 1; my $GStartTime = GetStartTime($h0); if (defined($GStartTime) && ($GStartTime > 0)) { $GStartTime = 0; } my %pos;

open(my_file1, ">$fname"); binmode(my_file1);
print(my_file1 "MThd"); for (my $i=0; $i<4; $i++) { print(my_file1 chr(0x00)); } $pos{-1}{0} = tell(my_file1);
print(my_file1 chr($h0->{-1}{1}>>8)); print(my_file1 chr(($h0->{-1}{1}>>0)&0xff));
print(my_file1 chr($trks       >>8)); print(my_file1 chr(($trks       >>0)&0xff));
print(my_file1 chr($h0->{-1}{3}>>8)); print(my_file1 chr(($h0->{-1}{3}>>0)&0xff));
$pos{-1}{1} = tell(my_file1);

foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if ($k0 == -1) { next(); } my $LastATime = $GStartTime;
 print(my_file1 "MTrk"); for (my $i=0; $i<4; $i++) { print(my_file1 chr(0x00)); } $pos{$k0}{0} = tell(my_file1);
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) { if (scalar(keys %{$h0->{$k0}{$k1}{$k2}}) <= 0) { next(); } my $len = $k1 - $LastATime; if ($len < 0) { $len = 0; }

   my $tmp0 = 0; while ($len >= 0x80) { $tmp0 = ($tmp0 << 8) + (($len & 0x7f) | 0x80); $len = $len >> 7; } $tmp0 = ($tmp0 << 8) + ($len & 0x7f);
   while ($tmp0 >= 0x100) { print(my_file1 chr(($tmp0 & 0x7f) | 0x80)); $tmp0 = $tmp0 >> 8; } print(my_file1 chr($tmp0 & 0x7f));

   print(my_file1 chr($h0->{$k0}{$k1}{$k2}{0}));

   my ($pos, $pos1) = (1, undef); $len = -1;
   if     ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 0x9)  { $pos1 = 2;                                                                                           }
    elsif ($h0->{$k0}{$k1}{$k2}{0}      == 0xf0) { $len = scalar(keys %{$h0->{$k0}{$k1}{$k2}})-1;                                                       }
    elsif ($h0->{$k0}{$k1}{$k2}{0}      == 0xf7) { $len = scalar(keys %{$h0->{$k0}{$k1}{$k2}})-1;                                                       }
    elsif ($h0->{$k0}{$k1}{$k2}{0}      == 0xff) { $len = scalar(keys %{$h0->{$k0}{$k1}{$k2}})-2; print(my_file1 chr($h0->{$k0}{$k1}{$k2}{1})); $pos++; }

   if ($len > -1) {
    my $tmp0 = 0; while ($len >= 0x80) { $tmp0 = ($tmp0 << 8) + (($len & 0x7f) | 0x80); $len = $len >> 7; } $tmp0 = ($tmp0 << 8) + ($len & 0x7f);
    while ($tmp0 >= 0x100) { print(my_file1 chr(($tmp0 & 0x7f) | 0x80)); $tmp0 = $tmp0 >> 8; } print(my_file1 chr($tmp0 & 0x7f));
    }

   $len = -1; foreach my $k3 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}{$k2}}) { $len++; if ($len < $pos) { next(); } if (defined($pos1) && ($len > $pos1)) { last(); } print(my_file1 chr($h0->{$k0}{$k1}{$k2}{$k3})); }
   $LastATime = $k1;
   }
  }
 $pos{$k0}{1} = tell(my_file1);
 }
close(my_file1);

foreach my $k0 (sort {$a <=> $b} keys %pos) {
 open(my_file1, "+<$fname"); binmode(my_file1);
 my $h0size = $pos{$k0}{1}-$pos{$k0}{0}; my $pos0 = sysseek(my_file1, $pos{$k0}{0}-4, 0);
 print(my_file1 chr(($h0size >> 24) & 0xff)); print(my_file1 chr(($h0size >> 16) & 0xff));
 print(my_file1 chr(($h0size >>  8) & 0xff)); print(my_file1 chr(($h0size >>  0) & 0xff));
 close(my_file1);
 }

return(0); }
#-------------------------------------------------------------------------------
sub GetStartTime {
my $h0  = shift(@_);
my $trk = undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)

my $time = undef;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || (defined($trk)) && ($k0 != $trk)) { next; }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) {
  if ((not(defined($time))) || ($k1 < $time)) { $time = $k1; } last();
  }
 }

return($time); }
#-------------------------------------------------------------------------------
sub GetEndTime {
my $h0  = shift(@_);
my $trk = undef; if ($#_ >= 0) { $trk = shift(@_); } #track (undef = all tracks)

my $time = undef;
foreach my $k0 (sort {$a <=> $b} keys %{$h0}) { if (($k0 == -1) || defined($trk) && ($k0 != $trk)) { next(); }
 foreach my $k1 (sort {$a <=> $b} keys %{$h0->{$k0}}) { if (not(defined($time)) || ($k1 > $time)) { $time = $k1; }
  foreach my $k2 (sort {$a <=> $b} keys %{$h0->{$k0}{$k1}}) {
   if ((scalar(keys(%{$h0->{$k0}{$k1}{$k2}})) >= 4) && ($h0->{$k0}{$k1}{$k2}{0} >> 4 == 9) && ($k1+$h0->{$k0}{$k1}{$k2}{3} > $time)) { $time = $k1+$h0->{$k0}{$k1}{$k2}{3}; }
   }
  }
 }

return($time); }
#===============================================================================
